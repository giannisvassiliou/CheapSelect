# budgets46: grid includes b = 0; delta = 1.0 MRR point(s)

pair | gain | random(exp) | WIG pt/NI | tag pt/NI | margin pt/NI | NQC pt/NI | top5 pt/NI | termcov pt/NI | oracle pt
amazon_testfull:bgedense | +26.2 | 100 | 100/100 | 90/100 | 90/100 | 100/100 | 100/100 | 100/100 | 40
mag_testfull:bgedense | +22.2 | 100 | 100/100 | 90/90 | 90/100 | 100/100 | 100/100 | 90/90 | 30
prime_testfull:bgedense | +11.9 | 100 | 90/100 | 90/100 | 90/100 | 90/100 | 90/100 | 90/90 | 20
dbpedia_test:bgedense | +9.9 | 90 | 90/100 | 80/90 | 80/90 | 80/90 | 90/90 | 90/100 | 20
beir_scifact:bgedense | +11.1 | 100 | 100/100 | 60/70 | 50/70 | 100/100 | 100/100 | 60/100 | 20
beir_nfcorpus:bgedense | +3.7 | 80 | 90/100 | 30/100 | 30/100 | 80/100 | 80/100 | 30/100 | 10
beir_fiqa:bgedense | +8.5 | 90 | 100/100 | 60/70 | 60/80 | 80/100 | 90/100 | 70/90 | 10
beir_arguana:bgedense | +19.1 | 100 | 100/100 | 100/100 | 100/100 | 100/100 | 100/100 | 100/100 | 40
beir_scidocs:bgedense | -3.7 | 0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0
amazon_testfull:bgehybrid | +16.2 | 100 | 90/90 | 90/100 | 90/100 | 80/90 | 80/90 | 100/100 | 20
mag_testfull:bgehybrid | +16.5 | 100 | 100/100 | 90/90 | 100/100 | 80/80 | 80/80 | 70/80 | 20
prime_testfull:bgehybrid | +7.6 | 90 | 80/90 | 80/90 | 90/100 | 70/80 | 70/80 | 80/90 | 10
dbpedia_test:bgehybrid | +14.1 | 100 | 90/100 | 100/100 | 100/100 | 80/100 | 90/100 | 90/100 | 20
beir_scifact:bgehybrid | +7.3 | 90 | 90/100 | 90/100 | 80/100 | 100/100 | 90/100 | 70/100 | 10
beir_nfcorpus:bgehybrid | +0.4 | 0 | 0/60 | 0/90 | 0/100 | 0/40 | 0/70 | 0/100 | 0
beir_fiqa:bgehybrid | +10.0 | 90 | 90/90 | 100/100 | 90/100 | 90/100 | 90/100 | 80/90 | 20
beir_arguana:bgehybrid | +18.7 | 100 | 100/100 | 100/100 | 100/100 | 100/100 | 100/100 | 100/100 | 40
beir_scidocs:bgehybrid | -1.9 | 0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0
