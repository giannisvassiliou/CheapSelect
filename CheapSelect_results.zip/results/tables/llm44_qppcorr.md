## mag_testfull  (n=1000; mean gain +10.4 MRR; queries helped 28%, hurt 13%)
   corr(BM25 quality, gain) = -0.40
   signal                      rho(quality) [95% CI]         rho(gain) [95% CI]
   BM25 margin            +0.31 [+0.25,+0.36]      -0.17 [-0.22,-0.11]
   tag alarm (negated)    +0.32 [+0.27,+0.38]      -0.24 [-0.31,-0.18]
   top5 vs rest           +0.16 [+0.10,+0.23]      -0.08 [-0.14,-0.01]
   NQC-like spread        +0.26 [+0.20,+0.32]      -0.13 [-0.20,-0.07]
   WIG-like               +0.01 [-0.05,+0.08]      -0.13 [-0.20,-0.07]
   term coverage top1     +0.19 [+0.13,+0.24]      -0.15 [-0.20,-0.08]

## prime_testfull  (n=1000; mean gain +10.8 MRR; queries helped 34%, hurt 14%)
   corr(BM25 quality, gain) = -0.11
   signal                      rho(quality) [95% CI]         rho(gain) [95% CI]
   BM25 margin            +0.20 [+0.14,+0.26]      +0.00 [-0.06,+0.06]
   tag alarm (negated)    +0.15 [+0.09,+0.21]      -0.16 [-0.22,-0.10]
   top5 vs rest           +0.36 [+0.30,+0.41]      -0.03 [-0.10,+0.03]
   NQC-like spread        +0.40 [+0.35,+0.46]      -0.07 [-0.13,-0.01]
   WIG-like               +0.38 [+0.32,+0.43]      -0.08 [-0.13,-0.01]
   term coverage top1     +0.21 [+0.15,+0.27]      -0.06 [-0.12,+0.00]

## dbpedia_test  (n=400; mean gain +22.9 MRR; queries helped 43%, hurt 6%)
   corr(BM25 quality, gain) = -0.52
   signal                      rho(quality) [95% CI]         rho(gain) [95% CI]
   BM25 margin            +0.10 [+0.00,+0.20]      -0.12 [-0.22,-0.02]
   tag alarm (negated)    +0.27 [+0.18,+0.36]      -0.17 [-0.27,-0.06]
   top5 vs rest           +0.25 [+0.16,+0.34]      -0.07 [-0.16,+0.03]
   NQC-like spread        +0.30 [+0.21,+0.39]      -0.10 [-0.19,+0.00]
   WIG-like               +0.45 [+0.37,+0.52]      -0.20 [-0.29,-0.11]
   term coverage top1     +0.34 [+0.25,+0.43]      -0.14 [-0.24,-0.04]

## beir_scifact  (n=300; mean gain +10.7 MRR; queries helped 27%, hurt 7%)
   corr(BM25 quality, gain) = -0.46
   signal                      rho(quality) [95% CI]         rho(gain) [95% CI]
   BM25 margin            +0.54 [+0.46,+0.61]      -0.23 [-0.33,-0.13]
   tag alarm (negated)    +0.05 [-0.07,+0.16]      +0.00 [-0.11,+0.12]
   top5 vs rest           -0.15 [-0.26,-0.04]      +0.04 [-0.07,+0.16]
   NQC-like spread        +0.39 [+0.29,+0.49]      -0.19 [-0.29,-0.08]
   WIG-like               +0.31 [+0.20,+0.42]      -0.18 [-0.29,-0.06]
   term coverage top1     +0.40 [+0.30,+0.50]      -0.19 [-0.30,-0.09]

## beir_nfcorpus  (n=323; mean gain +7.3 MRR; queries helped 26%, hurt 10%)
   corr(BM25 quality, gain) = -0.27
   signal                      rho(quality) [95% CI]         rho(gain) [95% CI]
   BM25 margin            +0.25 [+0.13,+0.35]      -0.10 [-0.20,-0.00]
   tag alarm (negated)    -0.03 [-0.13,+0.08]      +0.03 [-0.07,+0.12]
   top5 vs rest           +0.25 [+0.14,+0.36]      -0.03 [-0.13,+0.07]
   NQC-like spread        +0.33 [+0.22,+0.43]      -0.11 [-0.21,-0.01]
   WIG-like               +0.47 [+0.38,+0.56]      -0.09 [-0.19,+0.01]
   term coverage top1     +0.44 [+0.34,+0.54]      -0.11 [-0.21,-0.00]

## beir_scidocs  (n=1000; mean gain +10.3 MRR; queries helped 43%, hurt 14%)
   corr(BM25 quality, gain) = -0.08
   signal                      rho(quality) [95% CI]         rho(gain) [95% CI]
   BM25 margin            +0.13 [+0.06,+0.19]      -0.07 [-0.13,-0.01]
   tag alarm (negated)    -0.05 [-0.11,+0.01]      +0.02 [-0.05,+0.08]
   top5 vs rest           +0.29 [+0.24,+0.35]      +0.03 [-0.03,+0.10]
   NQC-like spread        +0.37 [+0.32,+0.43]      +0.01 [-0.04,+0.07]
   WIG-like               +0.32 [+0.27,+0.38]      -0.02 [-0.08,+0.04]
   term coverage top1     +0.03 [-0.03,+0.09]      -0.10 [-0.16,-0.04]

## amazon_testfull  (n=500; mean gain +9.8 MRR; queries helped 32%, hurt 14%)
   corr(BM25 quality, gain) = -0.54
   signal                      rho(quality) [95% CI]         rho(gain) [95% CI]
   BM25 margin            +0.35 [+0.27,+0.42]      -0.15 [-0.23,-0.07]
   tag alarm (negated)    +0.25 [+0.16,+0.33]      -0.13 [-0.21,-0.04]
   top5 vs rest           +0.42 [+0.35,+0.49]      -0.24 [-0.33,-0.16]
   NQC-like spread        +0.44 [+0.37,+0.51]      -0.25 [-0.33,-0.17]
   WIG-like               +0.23 [+0.14,+0.32]      -0.17 [-0.25,-0.09]
   term coverage top1     -0.20 [-0.28,-0.11]      +0.05 [-0.04,+0.13]

saved qpp_gain_corr.md
