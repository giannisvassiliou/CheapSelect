# router41: label-free signals vs pre-retrieval vs trained routers  (deltas [1.0, 0.5] MRR points)

## amazon_testfull (tag full; n=1642; mean gain +11.7 MRR; helped 34% hurt 15%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.07   rho(gain) +0.05
   avgIDF   rho(quality) +0.25   rho(gain) -0.13
   maxIDF   rho(quality) +0.29   rho(gain) -0.13
   avgICTF  rho(quality) +0.25   rho(gain) -0.12
   avgSCQ   rho(quality) +0.18   rho(gain) -0.10
   maxSCQ   rho(quality) +0.14   rho(gain) -0.04
   SCS      rho(quality) +0.16   rho(gain) -0.07

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/80          90/90           +20             -3.9     -0.6 (0.423)
   tag alarm                                 90/80          90/90           +20             -4.0     -0.7 (0.298)
   top5 vs rest                              80/80          90/80           +20             -2.6     +0.7 (0.269)
   NQC-like spread                           80/80          90/80           +20             -2.3     +0.9 (0.093)
   WIG-like                                 100/70         100/100          +30             -3.3          -
   term coverage top1                       100/100        100/100           +0             -6.9     -3.7 (0.000)
   pre:qlen                                 100/100        100/100           +0             -6.3     -3.0 (0.000)
   pre:avgIDF                               100/90         100/100          +10             -3.8     -0.5 (0.354)
   pre:maxIDF                                90/80         100/80           +20             -3.8     -0.5 (0.387)
   pre:avgICTF                               90/90         100/90           +10             -4.3     -1.0 (0.096)
   pre:avgSCQ                               100/90         100/100          +10             -4.5     -1.2 (0.027)
   pre:maxSCQ                               100/100        100/100           +0             -5.3     -2.1 (0.001)
   pre:SCS                                  100/90         100/100          +10             -5.0     -1.7 (0.008)
   router ridge S (5-fold CV)                80/60          80/70           +40             -1.4     +1.8 (0.000)
   router gbm S (5-fold CV)                  90/70         100/80           +30             -2.2     +1.0 (0.071)
   router ridge S+P (5-fold CV)              80/70          80/70           +30             -2.0     +1.3 (0.007)
   router gbm S+P (5-fold CV)                90/80         100/90           +20             -3.1     +0.2 (0.758)
   router ridge S (other collections)        90/90         100/90           +10             -3.2     +0.1 (0.860)
   router gbm S (other collections)          90/80         100/90           +20             -2.7     +0.5 (0.374)
   router ridge S+P (other collections)     100/80         100/90           +20             -3.1     +0.2 (0.752)
   router gbm S+P (other collections)       100/80         100/100          +20             -3.1     +0.1 (0.809)
   ORACLE                                    20/20          20/20           +80             +6.2     +9.5 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.147, tag alarm +0.079, top5 vs rest -0.144, NQC-like spread -0.004, WIG-like -0.179, term coverage top1 +0.068
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.157, tag alarm +0.069, top5 vs rest -0.114, NQC-like spread -0.068, WIG-like -0.260, term coverage top1 +0.114, qlen +0.104, avgIDF -0.103, maxIDF +0.006, avgICTF +0.043, avgSCQ +0.001, maxSCQ +0.102, SCS +0.173

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -5.9   -3.3   -0.9
   n=  50  router ridge S+P        -6.4   -3.7   -1.6   P(router > WIG-like @50%) = 39%
   n=  50  router gbm   S+P        -6.8   -4.2   -2.2   P(router > WIG-like @50%) = 18%
   n= 100  WIG-like                 -5.9   -3.3   -0.9
   n= 100  router ridge S+P        -5.8   -3.0   -1.2   P(router > WIG-like @50%) = 67%
   n= 100  router gbm   S+P        -6.5   -3.9   -2.1   P(router > WIG-like @50%) = 27%
   n= 200  WIG-like                 -5.9   -3.3   -0.9
   n= 200  router ridge S+P        -5.3   -2.6   -0.8   P(router > WIG-like @50%) = 88%
   n= 200  router gbm   S+P        -6.4   -3.9   -2.0   P(router > WIG-like @50%) = 17%

## mag_testfull (tag full; n=2665; mean gain +4.4 MRR; helped 24% hurt 17%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.31   rho(gain) +0.10
   avgIDF   rho(quality) +0.20   rho(gain) +0.01
   maxIDF   rho(quality) +0.07   rho(gain) -0.02
   avgICTF  rho(quality) +0.18   rho(gain) +0.02
   avgSCQ   rho(quality) +0.10   rho(gain) -0.02
   maxSCQ   rho(quality) +0.01   rho(gain) -0.02
   SCS      rho(quality) +0.28   rho(gain) +0.06

Budgets (share of questions reranked). random expected point budget: delta 1.0: 80%, delta 0.5: 90%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               70/60          70/60           +20             -1.2     -1.2 (0.015)
   tag alarm                                 30/20          50/30           +60             +0.3     +0.4 (0.424)
   top5 vs rest                              90/80         100/90            +0             -1.3     -1.3 (0.000)
   NQC-like spread                           90/80         100/90            +0             -1.2     -1.2 (0.001)
   WIG-like                                  50/20          70/40           +60             -0.0          -
   term coverage top1                        40/30          50/40           +50             +0.4     +0.4 (0.241)
   pre:qlen                                 100/100        100/100          -20             -3.9     -3.8 (0.000)
   pre:avgIDF                                90/80         100/90            +0             -2.3     -2.3 (0.000)
   pre:maxIDF                                80/80          90/90            +0             -1.9     -1.8 (0.000)
   pre:avgICTF                               90/90         100/100          -10             -2.5     -2.4 (0.000)
   pre:avgSCQ                                90/80         100/90            +0             -1.9     -1.9 (0.000)
   pre:maxSCQ                                90/70         100/80           +10             -1.4     -1.4 (0.000)
   pre:SCS                                  100/80         100/100           +0             -2.9     -2.9 (0.000)
   router ridge S (5-fold CV)                30/20          30/20           +60             +1.4     +1.4 (0.000)
   router gbm S (5-fold CV)                  30/20          80/30           +60             +0.6     +0.6 (0.127)
   router ridge S+P (5-fold CV)              30/20          30/20           +60             +1.6     +1.6 (0.000)
   router gbm S+P (5-fold CV)                30/20          30/20           +60             +0.8     +0.9 (0.023)
   router ridge S (other collections)        30/20          40/20           +60             +0.6     +0.6 (0.047)
   router gbm S (other collections)          80/50         100/80           +30             -0.9     -0.9 (0.018)
   router ridge S+P (other collections)      30/20          30/30           +60             +0.4     +0.5 (0.146)
   router gbm S+P (other collections)        70/40          80/60           +40             -0.9     -0.9 (0.015)
   ORACLE                                    10/10          10/10           +70             +6.7     +6.7 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.087, tag alarm +0.278, top5 vs rest -0.031, NQC-like spread +0.121, WIG-like -0.191, term coverage top1 -0.090
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.071, tag alarm +0.289, top5 vs rest -0.021, NQC-like spread +0.106, WIG-like -0.077, term coverage top1 -0.186, qlen -0.171, avgIDF +0.020, maxIDF -0.010, avgICTF -0.121, avgSCQ -0.022, maxSCQ +0.033, SCS +0.020

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -0.5   -0.0   +0.6
   n=  50  router ridge S+P        -0.8   +0.0   +0.4   P(router > WIG-like @50%) = 60%
   n=  50  router gbm   S+P        -1.9   -0.9   -0.3   P(router > WIG-like @50%) = 17%
   n= 100  WIG-like                 -0.5   -0.0   +0.6
   n= 100  router ridge S+P        -0.3   +0.5   +0.8   P(router > WIG-like @50%) = 85%
   n= 100  router gbm   S+P        -1.3   -0.5   +0.0   P(router > WIG-like @50%) = 29%
   n= 200  WIG-like                 -0.5   -0.0   +0.6
   n= 200  router ridge S+P        +0.2   +1.0   +1.1   P(router > WIG-like @50%) = 100%
   n= 200  router gbm   S+P        -1.0   -0.2   +0.2   P(router > WIG-like @50%) = 46%

## prime_testfull (tag full; n=2801; mean gain +3.9 MRR; helped 30% hurt 19%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.24   rho(gain) +0.06
   avgIDF   rho(quality) +0.10   rho(gain) +0.01
   maxIDF   rho(quality) +0.10   rho(gain) -0.02
   avgICTF  rho(quality) +0.07   rho(gain) +0.01
   avgSCQ   rho(quality) +0.14   rho(gain) -0.02
   maxSCQ   rho(quality) +0.28   rho(gain) -0.04
   SCS      rho(quality) -0.03   rho(gain) +0.05

Budgets (share of questions reranked). random expected point budget: delta 1.0: 80%, delta 0.5: 90%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               70/60          80/60           +20             -1.4     -1.4 (0.001)
   tag alarm                                 50/30          50/40           +50             +0.8     +0.7 (0.083)
   top5 vs rest                              60/40          70/50           +40             -0.3     -0.4 (0.273)
   NQC-like spread                           50/40          60/40           +40             +0.5     +0.4 (0.243)
   WIG-like                                  50/40          60/50           +40             +0.1          -
   term coverage top1                        70/60         100/70           +20             -1.2     -1.2 (0.003)
   pre:qlen                                 100/90         100/100          -10             -2.9     -3.0 (0.000)
   pre:avgIDF                                90/80         100/90            +0             -1.7     -1.8 (0.001)
   pre:maxIDF                               100/70         100/100          +10             -1.4     -1.4 (0.004)
   pre:avgICTF                               90/80         100/90            +0             -1.6     -1.7 (0.001)
   pre:avgSCQ                                80/70          90/70           +10             -1.2     -1.3 (0.005)
   pre:maxSCQ                                80/60         100/70           +20             -1.3     -1.4 (0.002)
   pre:SCS                                   90/80         100/90            +0             -2.3     -2.4 (0.000)
   router ridge S (5-fold CV)                40/30          40/30           +50             +0.6     +0.5 (0.115)
   router gbm S (5-fold CV)                  60/40          70/50           +40             -0.1     -0.2 (0.612)
   router ridge S+P (5-fold CV)              40/30          40/30           +50             +1.1     +1.0 (0.003)
   router gbm S+P (5-fold CV)                40/30          60/40           +50             +0.4     +0.3 (0.428)
   router ridge S (other collections)        40/30          50/30           +50             +0.9     +0.8 (0.007)
   router gbm S (other collections)          40/30          50/40           +50             +0.8     +0.7 (0.050)
   router ridge S+P (other collections)      40/30          40/30           +50             +1.1     +1.0 (0.003)
   router gbm S+P (other collections)        40/30          50/40           +50             +1.0     +0.9 (0.008)
   ORACLE                                    10/10          10/10           +70             +7.8     +7.7 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.023, tag alarm +0.151, top5 vs rest -0.007, NQC-like spread -0.050, WIG-like -0.094, term coverage top1 -0.011
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.015, tag alarm +0.172, top5 vs rest -0.011, NQC-like spread -0.067, WIG-like -0.050, term coverage top1 -0.039, qlen +0.034, avgIDF +0.147, maxIDF -0.080, avgICTF -0.296, avgSCQ -0.079, maxSCQ +0.014, SCS +0.247

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -1.1   +0.1   +1.0
   n=  50  router ridge S+P        -1.8   -0.8   -0.1   P(router > WIG-like @50%) = 20%
   n=  50  router gbm   S+P        -2.1   -1.1   -0.5   P(router > WIG-like @50%) = 4%
   n= 100  WIG-like                 -1.1   +0.1   +1.0
   n= 100  router ridge S+P        -1.5   -0.4   +0.2   P(router > WIG-like @50%) = 32%
   n= 100  router gbm   S+P        -1.9   -1.0   -0.3   P(router > WIG-like @50%) = 1%
   n= 200  WIG-like                 -1.1   +0.1   +0.9
   n= 200  router ridge S+P        -1.0   +0.1   +0.6   P(router > WIG-like @50%) = 56%
   n= 200  router gbm   S+P        -1.9   -0.9   -0.2   P(router > WIG-like @50%) = 2%

## dbpedia_test (tag dbp; n=400; mean gain +19.5 MRR; helped 40% hurt 8%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.22   rho(gain) -0.09
   avgIDF   rho(quality) +0.18   rho(gain) -0.19
   maxIDF   rho(quality) +0.02   rho(gain) -0.14
   avgICTF  rho(quality) +0.16   rho(gain) -0.18
   avgSCQ   rho(quality) +0.25   rho(gain) -0.17
   maxSCQ   rho(quality) +0.11   rho(gain) -0.13
   SCS      rho(quality) +0.20   rho(gain) -0.19

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/90         100/100          +10             -8.5     -0.5 (0.743)
   tag alarm                                100/90         100/90           +10             -7.9     +0.2 (0.895)
   top5 vs rest                             100/100        100/100           +0             -8.2     -0.2 (0.898)
   NQC-like spread                          100/100        100/100           +0             -8.1     -0.0 (0.986)
   WIG-like                                 100/90         100/100          +10             -8.1          -
   term coverage top1                       100/100        100/100           +0             -7.8     +0.2 (0.847)
   pre:qlen                                 100/90         100/100          +10             -8.1     +0.0 (0.995)
   pre:avgIDF                               100/100        100/100           +0             -6.4     +1.6 (0.187)
   pre:maxIDF                               100/100        100/100           +0             -7.8     +0.2 (0.864)
   pre:avgICTF                              100/100        100/100           +0             -7.2     +0.9 (0.493)
   pre:avgSCQ                                90/90         100/90           +10             -7.3     +0.7 (0.554)
   pre:maxSCQ                               100/100        100/100           +0             -7.2     +0.9 (0.510)
   pre:SCS                                  100/90         100/100          +10             -6.5     +1.5 (0.228)
   router ridge S (5-fold CV)               100/90         100/100          +10             -9.5     -1.5 (0.227)
   router gbm S (5-fold CV)                 100/100        100/100           +0             -8.6     -0.5 (0.738)
   router ridge S+P (5-fold CV)             100/90         100/100          +10             -7.8     +0.3 (0.854)
   router gbm S+P (5-fold CV)               100/100        100/100           +0             -8.2     -0.1 (0.930)
   router ridge S (other collections)        90/90         100/90           +10             -6.8     +1.3 (0.091)
   router gbm S (other collections)         100/100        100/100           +0             -7.8     +0.2 (0.839)
   router ridge S+P (other collections)     100/90         100/100          +10             -7.5     +0.6 (0.534)
   router gbm S+P (other collections)       100/100        100/100           +0             -7.7     +0.4 (0.712)
   ORACLE                                    30/30          30/30           +70             +3.1    +11.2 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.115, tag alarm +0.179, top5 vs rest +0.040, NQC-like spread -0.094, WIG-like -0.064, term coverage top1 -0.035
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.065, tag alarm +0.189, top5 vs rest +0.066, NQC-like spread -0.078, WIG-like +0.059, term coverage top1 -0.141, qlen -0.055, avgIDF -0.106, maxIDF -0.080, avgICTF +0.160, avgSCQ -0.041, maxSCQ -0.082, SCS -0.158

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                -11.7   -8.2   -4.5
   n=  50  router ridge S+P       -12.6   -8.3   -4.6   P(router > WIG-like @50%) = 55%
   n=  50  router gbm   S+P       -12.7   -8.4   -4.7   P(router > WIG-like @50%) = 52%
   n= 100  WIG-like                -11.8   -8.2   -4.4
   n= 100  router ridge S+P       -12.4   -8.1   -4.5   P(router > WIG-like @50%) = 54%
   n= 100  router gbm   S+P       -13.0   -8.9   -5.0   P(router > WIG-like @50%) = 27%
   n= 200  WIG-like                -11.7   -8.3   -4.5
   n= 200  router ridge S+P       -12.0   -7.7   -4.1   P(router > WIG-like @50%) = 71%
   n= 200  router gbm   S+P       -13.2   -8.9   -5.1   P(router > WIG-like @50%) = 40%

