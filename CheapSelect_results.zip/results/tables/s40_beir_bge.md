## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.3  random  55.8  diff  +0.5  p=0.3239
   MRR  : tag  65.0  random  64.7  diff  +0.3  p=0.2730

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.7 (p=0.727)        -0.6 (p=0.383)
   40%            -0.7 (p=0.502)        -0.6 (p=0.027)
   50%            +0.3 (p=1.000)        +0.1 (p=0.921)
   15% nat        -1.7 (p=0.381)        -1.4 (p=0.213)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.7  95% CI [-11.7, -3.7]  p=0.000
   MRR  :  -6.0  95% CI [-8.8, -3.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (27%)
   Hit@1:  +0.3  p=1.000
   MRR  :  -0.3  p=0.795

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +4.7/+2.9 (p=0.016)  40%: +5.3/+3.9 (p=0.002)  50%: +4.7/+3.3 (p=0.009)  nat: +1.3/+0.7 (p=0.424)
   vs NQC-like spread      30%: +2.7/+1.0 (p=0.343)  40%: +3.0/+1.8 (p=0.075)  50%: +2.7/+2.0 (p=0.046)  nat: -1.3/-1.4 (p=0.139)
   vs WIG-like             30%: +2.0/+1.1 (p=0.344)  40%: +2.0/+1.3 (p=0.259)  50%: +2.7/+2.2 (p=0.053)  nat: +0.3/-0.3 (p=0.799)
   vs term coverage top1   30%: +2.0/+1.5 (p=0.201)  40%: +2.3/+2.0 (p=0.089)  50%: +2.7/+2.3 (p=0.024)  nat: +0.0/+0.1 (p=0.893)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -6.0  [-8.8, -3.2]  p=0.000
   BM25 margin           -4.6  [-7.2, -2.1]  p=0.000
   top5 vs rest          -6.7  [-9.8, -3.6]  p=0.000
   NQC-like spread       -4.6  [-7.5, -1.8]  p=0.001
   WIG-like              -5.7  [-8.6, -2.9]  p=0.000
   term coverage top1    -6.1  [-8.9, -3.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              65.1    66.1    68.0    69.3    70.5*   70.6*   71.2*   71.0*   71.1*   71.0*   50%
   BM25 margin            65.0    67.5    68.6    69.9*   70.4*   70.9*   71.3*   71.0*   71.1*   71.0*   40%
   top5 vs rest           63.7    64.4    65.0    65.4    67.2    67.3    67.8    68.5    69.8*   71.0*   90%
   NQC-like spread        65.6    66.8    67.0    67.5    68.5    69.4*   70.3*   70.5*   70.8*   71.0*   60%
   WIG-like               65.0    66.4    66.9    68.0    68.3    68.7    69.1    69.5    70.7*   71.0*   90%
   term coverage top1     65.1    65.0    66.5    67.3    68.2    69.7*   69.9*   70.0    70.5*   71.0*   90%
   ORACLE                 70.8*   73.9*   74.0*   74.0*   74.0*   74.0*   74.0*   74.0*   74.0*   71.0*   10%
   random (expected)      64.3    65.1    65.8    66.5    67.3    68.0    68.8    69.5    70.3    71.0*   100%
   (BM25 only 63.6; rerank ALL 71.0)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.9[ -8.8]   -5.0[ -7.5]   -3.0[ -5.3]   -1.7[ -3.4]   -0.5[ -1.6]   -0.4[ -1.2]   +0.1[ -0.3]#  -0.0[ -0.3]#  +0.1[ -0.0]#   70%   (point estimate: 50%)
   BM25 margin           -6.0[ -8.7]   -3.5[ -5.9]   -2.4[ -4.5]   -1.1[ -2.7]   -0.7[ -1.6]   -0.1[ -0.9]#  +0.3[ -0.2]#  +0.0[ -0.3]#  +0.1[ -0.0]#   60%   (point estimate: 50%)
   top5 vs rest          -7.3[-10.3]   -6.6[ -9.5]   -6.0[ -8.8]   -5.6[ -8.4]   -3.9[ -6.3]   -3.7[ -5.9]   -3.2[ -5.3]   -2.5[ -4.3]   -1.3[ -2.7]    100%   (point estimate: 100%)
   NQC-like spread       -5.5[ -8.3]   -4.2[ -6.8]   -4.1[ -6.2]   -3.5[ -5.6]   -2.6[ -4.5]   -1.6[ -3.4]   -0.7[ -1.8]   -0.5[ -1.5]   -0.2[ -0.7]#   90%   (point estimate: 70%)
   WIG-like              -6.0[ -8.9]   -4.6[ -7.3]   -4.1[ -6.5]   -3.0[ -5.1]   -2.7[ -4.7]   -2.3[ -4.1]   -1.9[ -3.5]   -1.5[ -2.8]   -0.3[ -0.8]#   90%   (point estimate: 90%)
   term coverage top1    -5.9[ -8.9]   -6.0[ -8.7]   -4.6[ -6.8]   -3.7[ -5.8]   -2.8[ -4.6]   -1.3[ -2.8]   -1.1[ -2.3]   -1.1[ -2.2]   -0.5[ -1.3]    100%   (point estimate: 90%)
   ORACLE                -0.2[ -2.0]   +2.9[ +1.6]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#   20%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.9[ -8.8]   -5.0[ -7.5]   -3.0[ -5.3]   -1.7[ -3.4]   -0.5[ -1.6]   -0.4[ -1.2]   +0.1[ -0.3]#  -0.0[ -0.3]#  +0.1[ -0.0]#   70%   (point estimate: 60%)
   BM25 margin           -6.0[ -8.7]   -3.5[ -5.9]   -2.4[ -4.5]   -1.1[ -2.7]   -0.7[ -1.6]   -0.1[ -0.9]   +0.3[ -0.2]#  +0.0[ -0.3]#  +0.1[ -0.0]#   70%   (point estimate: 60%)
   top5 vs rest          -7.3[-10.3]   -6.6[ -9.5]   -6.0[ -8.8]   -5.6[ -8.4]   -3.9[ -6.3]   -3.7[ -5.9]   -3.2[ -5.3]   -2.5[ -4.3]   -1.3[ -2.7]    100%   (point estimate: 100%)
   NQC-like spread       -5.5[ -8.3]   -4.2[ -6.8]   -4.1[ -6.2]   -3.5[ -5.6]   -2.6[ -4.5]   -1.6[ -3.4]   -0.7[ -1.8]   -0.5[ -1.5]   -0.2[ -0.7]    100%   (point estimate: 80%)
   WIG-like              -6.0[ -8.9]   -4.6[ -7.3]   -4.1[ -6.5]   -3.0[ -5.1]   -2.7[ -4.7]   -2.3[ -4.1]   -1.9[ -3.5]   -1.5[ -2.8]   -0.3[ -0.8]    100%   (point estimate: 90%)
   term coverage top1    -5.9[ -8.9]   -6.0[ -8.7]   -4.6[ -6.8]   -3.7[ -5.8]   -2.8[ -4.6]   -1.3[ -2.8]   -1.1[ -2.3]   -1.1[ -2.2]   -0.5[ -1.3]    100%   (point estimate: 90%)
   ORACLE                -0.2[ -2.0]   +2.9[ +1.6]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      50% (sd  19)   -1.53 MRR              37%     50%
   tag alarm               100      53% (sd  11)   -1.01 MRR              28%     47%
   tag alarm               200      51% (sd   6)   -0.96 MRR              42%     49%
   BM25 margin              50      48% (sd  18)   -1.24 MRR              42%     52%
   BM25 margin             100      46% (sd  12)   -1.22 MRR              45%     54%
   BM25 margin             200      47% (sd   8)   -1.15 MRR              44%     53%
   top5 vs rest             50      90% (sd  17)   -1.25 MRR              44%     10%
   top5 vs rest            100      94% (sd  12)   -1.03 MRR              40%      6%
   top5 vs rest            200      96% (sd   5)   -0.79 MRR              33%      4%
   NQC-like spread          50      69% (sd  23)   -1.47 MRR              39%     31%
   NQC-like spread         100      71% (sd  14)   -1.17 MRR              31%     29%
   NQC-like spread         200      72% (sd   8)   -0.98 MRR              39%     28%
   WIG-like                 50      78% (sd  25)   -1.44 MRR              44%     22%
   WIG-like                100      82% (sd  16)   -1.10 MRR              34%     18%
   WIG-like                200      87% (sd   7)   -0.86 MRR              26%     13%
   term coverage top1       50      78% (sd  21)   -1.27 MRR              48%     22%
   term coverage top1      100      77% (sd  16)   -1.25 MRR              58%     23%
   term coverage top1      200      83% (sd  10)   -0.82 MRR              34%     17%

## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  43.3  random  44.0  diff  -0.6  p=0.9839
   MRR  : tag  51.7  random  52.2  diff  -0.5  p=0.9558

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.1 (p=0.837)
   40%            -0.3 (p=1.000)        -0.4 (p=0.374)
   50%            -0.6 (p=0.496)        -0.5 (p=0.249)
   2% nat         -0.6 (p=0.498)        -0.4 (p=0.368)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.3  95% CI [-5.0, +4.3]  p=1.000
   MRR  :  -2.1  95% CI [-5.3, +1.1]  p=0.195

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  -0.9  p=0.696
   MRR  :  -1.7  p=0.147

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/+0.1 (p=0.891)  40%: +0.6/+1.0 (p=0.419)  50%: +1.2/+1.3 (p=0.270)  nat: -0.6/-0.4 (p=0.368)
   vs NQC-like spread      30%: +0.3/-0.2 (p=0.874)  40%: -0.6/-0.4 (p=0.764)  50%: +0.6/+0.3 (p=0.775)  nat: -0.6/-0.4 (p=0.368)
   vs WIG-like             30%: -0.3/-0.3 (p=0.745)  40%: -0.3/+0.1 (p=0.909)  50%: +0.0/+0.2 (p=0.875)  nat: -0.6/-0.4 (p=0.368)
   vs term coverage top1   30%: -1.5/-1.3 (p=0.196)  40%: -1.2/-1.0 (p=0.373)  50%: -1.9/-1.4 (p=0.210)  nat: -0.6/-0.4 (p=0.368)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.1  [-5.3, +1.1]  p=0.195
   BM25 margin           -1.7  [-4.9, +1.5]  p=0.307
   top5 vs rest          -1.7  [-4.9, +1.5]  p=0.307
   NQC-like spread       -1.7  [-4.9, +1.5]  p=0.307
   WIG-like              -1.7  [-4.9, +1.5]  p=0.307
   term coverage top1    -1.7  [-4.9, +1.5]  p=0.307

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              51.7*   52.2*   53.0*   53.6*   53.8*   54.1*   53.8*   53.7*   53.7*   53.9*   10%
   BM25 margin            51.9*   52.5*   53.1*   54.0*   54.4*   54.3*   53.7*   53.7*   53.7*   53.9*   10%
   top5 vs rest           51.8*   52.1*   52.8*   52.6*   52.6*   53.5*   53.8*   54.3*   54.6*   53.9*   10%
   NQC-like spread        51.6*   53.3*   53.1*   54.0*   53.5*   54.4*   54.7*   54.4*   54.0*   53.9*   10%
   WIG-like               52.1*   51.6*   53.3*   53.4*   53.7*   54.3*   54.0*   54.0*   53.8*   53.9*   10%
   term coverage top1     52.2*   53.2*   54.3*   54.6*   55.2*   54.1*   53.4*   53.4*   53.5*   53.9*   10%
   ORACLE                 58.4*   60.6*   60.6*   60.6*   60.6*   60.6*   60.6*   60.6*   59.9*   53.9*   10%
   random (expected)      52.3    52.5    52.7    52.8    53.0    53.2    53.3    53.5    53.7    53.9*   100%
   (BM25 only 52.1; rerank ALL 53.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.2[ -5.3]   -1.7[ -4.6]   -0.9[ -3.7]   -0.3[ -2.7]   -0.0[ -2.2]   +0.2[ -1.7]   -0.0[ -1.7]   -0.2[ -1.2]   -0.2[ -0.7]#   90%   (point estimate: 30%)
   BM25 margin           -2.0[ -5.1]   -1.3[ -4.3]   -0.8[ -3.5]   +0.1[ -2.4]   +0.5[ -1.6]   +0.4[ -1.6]   -0.1[ -1.7]   -0.2[ -1.2]   -0.2[ -0.7]#   90%   (point estimate: 30%)
   top5 vs rest          -2.0[ -5.1]   -1.7[ -4.7]   -1.0[ -3.7]   -1.2[ -3.7]   -1.3[ -3.6]   -0.3[ -2.3]   -0.0[ -1.7]   +0.5[ -0.9]#  +0.8[ -0.2]#   80%   (point estimate: 60%)
   NQC-like spread       -2.2[ -5.4]   -0.5[ -3.3]   -0.7[ -3.2]   +0.1[ -2.2]   -0.3[ -2.5]   +0.5[ -1.1]   +0.8[ -0.7]#  +0.5[ -0.8]#  +0.2[ -0.5]#   70%   (point estimate: 20%)
   WIG-like              -1.7[ -4.9]   -2.3[ -5.3]   -0.6[ -3.4]   -0.4[ -3.0]   -0.2[ -2.6]   +0.5[ -1.5]   +0.2[ -1.5]   +0.1[ -1.3]   -0.0[ -0.7]#   90%   (point estimate: 30%)
   term coverage top1    -1.6[ -4.8]   -0.7[ -3.7]   +0.4[ -2.4]   +0.8[ -1.8]   +1.4[ -0.9]#  +0.2[ -1.8]   -0.5[ -2.2]   -0.5[ -2.0]   -0.3[ -1.7]    100%   (point estimate: 20%)
   ORACLE                +4.6[ +2.3]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.1[ +4.1]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.2[ -5.3]   -1.7[ -4.6]   -0.9[ -3.7]   -0.3[ -2.7]   -0.0[ -2.2]   +0.2[ -1.7]   -0.0[ -1.7]   -0.2[ -1.2]   -0.2[ -0.7]    100%   (point estimate: 40%)
   BM25 margin           -2.0[ -5.1]   -1.3[ -4.3]   -0.8[ -3.5]   +0.1[ -2.4]   +0.5[ -1.6]   +0.4[ -1.6]   -0.1[ -1.7]   -0.2[ -1.2]   -0.2[ -0.7]    100%   (point estimate: 40%)
   top5 vs rest          -2.0[ -5.1]   -1.7[ -4.7]   -1.0[ -3.7]   -1.2[ -3.7]   -1.3[ -3.6]   -0.3[ -2.3]   -0.0[ -1.7]   +0.5[ -0.9]   +0.8[ -0.2]#   90%   (point estimate: 60%)
   NQC-like spread       -2.2[ -5.4]   -0.5[ -3.3]   -0.7[ -3.2]   +0.1[ -2.2]   -0.3[ -2.5]   +0.5[ -1.1]   +0.8[ -0.7]   +0.5[ -0.8]   +0.2[ -0.5]    100%   (point estimate: 40%)
   WIG-like              -1.7[ -4.9]   -2.3[ -5.3]   -0.6[ -3.4]   -0.4[ -3.0]   -0.2[ -2.6]   +0.5[ -1.5]   +0.2[ -1.5]   +0.1[ -1.3]   -0.0[ -0.7]    100%   (point estimate: 40%)
   term coverage top1    -1.6[ -4.8]   -0.7[ -3.7]   +0.4[ -2.4]   +0.8[ -1.8]   +1.4[ -0.9]   +0.2[ -1.8]   -0.5[ -2.2]   -0.5[ -2.0]   -0.3[ -1.7]    100%   (point estimate: 30%)
   ORACLE                +4.6[ +2.3]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.1[ +4.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      54% (sd  35)   -0.95 MRR              34%     46%
   tag alarm               100      47% (sd  31)   -1.19 MRR              42%     53%
   tag alarm               200      39% (sd  21)   -1.11 MRR              44%     61%
   BM25 margin              50      56% (sd  35)   -0.68 MRR              30%     44%
   BM25 margin             100      45% (sd  32)   -0.97 MRR              39%     55%
   BM25 margin             200      32% (sd  21)   -0.98 MRR              42%     68%
   top5 vs rest             50      55% (sd  33)   -0.80 MRR              40%     45%
   top5 vs rest            100      50% (sd  27)   -0.94 MRR              44%     50%
   top5 vs rest            200      51% (sd  22)   -1.04 MRR              39%     49%
   NQC-like spread          50      50% (sd  36)   -0.91 MRR              34%     50%
   NQC-like spread         100      44% (sd  30)   -0.79 MRR              37%     56%
   NQC-like spread         200      34% (sd  18)   -0.83 MRR              40%     66%
   WIG-like                 50      57% (sd  35)   -0.72 MRR              30%     43%
   WIG-like                100      48% (sd  29)   -0.70 MRR              30%     52%
   WIG-like                200      41% (sd  23)   -0.73 MRR              36%     59%
   term coverage top1       50      54% (sd  37)   -0.40 MRR              30%     46%
   term coverage top1      100      41% (sd  31)   -0.36 MRR              34%     59%
   term coverage top1      200      27% (sd  20)   -0.75 MRR              42%     73%

## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  28.5  random  26.7  diff  +1.9  p=0.0104
   MRR  : tag  35.9  random  34.6  diff  +1.3  p=0.0169

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.8 (p=0.634)        -0.8 (p=0.434)
   40%            +2.0 (p=0.088)        +1.5 (p=0.080)
   50%            +1.9 (p=0.073)        +1.3 (p=0.077)
   25% nat        -0.6 (p=0.734)        -1.1 (p=0.353)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -11.7  95% CI [-14.7, -8.6]  p=0.000
   MRR  : -12.1  95% CI [-14.5, -9.7]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (52%)
   Hit@1:  +4.2  p=0.001
   MRR  :  +2.5  p=0.015

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.2/-0.2 (p=0.879)  40%: +2.6/+2.0 (p=0.086)  50%: +2.6/+1.9 (p=0.085)  nat: +0.6/+0.0 (p=0.998)
   vs NQC-like spread      30%: +0.3/-0.1 (p=0.950)  40%: +2.8/+2.2 (p=0.049)  50%: +2.3/+1.8 (p=0.105)  nat: +0.2/-0.5 (p=0.598)
   vs WIG-like             30%: +0.9/+0.6 (p=0.535)  40%: +3.2/+2.6 (p=0.016)  50%: +2.6/+2.2 (p=0.045)  nat: +1.1/+0.6 (p=0.569)
   vs term coverage top1   30%: +1.2/+1.2 (p=0.193)  40%: +2.5/+2.5 (p=0.014)  50%: +1.4/+1.5 (p=0.155)  nat: +1.5/+1.2 (p=0.155)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -12.1  [-14.5, -9.7]  p=0.000
   BM25 margin          -11.0  [-13.3, -8.7]  p=0.000
   top5 vs rest         -12.1  [-14.5, -9.7]  p=0.000
   NQC-like spread      -11.5  [-13.8, -9.3]  p=0.000
   WIG-like             -12.6  [-15.0, -10.3]  p=0.000
   term coverage top1   -13.3  [-15.8, -10.9]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              32.8    34.9    37.1    40.6    41.9    43.2    44.1    45.8    47.4    48.0*   100%
   BM25 margin            32.6    35.9    37.9    39.0    40.5    41.8    43.7    45.6    47.0    48.0*   100%
   top5 vs rest           32.4    34.9    37.3    38.6    40.0    41.3    43.3    45.1    46.3    48.0*   100%
   NQC-like spread        33.3    35.9    37.2    38.4    40.1    41.7    43.6    44.8    46.6    48.0*   100%
   WIG-like               32.1    34.1    36.5    38.0    39.7    41.7    43.2    45.1    46.7    48.0*   100%
   term coverage top1     32.1    34.0    35.9    38.1    40.4    42.4    44.6    45.3    46.9    48.0*   100%
   ORACLE                 39.5    46.2    49.5*   50.5*   50.5*   50.5*   50.5*   50.5*   50.5*   48.0*   30%
   random (expected)      32.0    33.8    35.6    37.3    39.1    40.9    42.7    44.4    46.2    48.0*   100%
   (BM25 only 30.3; rerank ALL 48.0)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -15.2[-17.7]  -13.1[-15.5]  -10.9[-13.1]   -7.4[ -9.3]   -6.1[ -7.7]   -4.8[ -6.4]   -3.9[ -5.3]   -2.2[ -3.2]   -0.6[ -1.2]    100%   (point estimate: 90%)
   BM25 margin          -15.4[-17.9]  -12.1[-14.4]  -10.1[-12.2]   -9.0[-11.0]   -7.4[ -9.4]   -6.2[ -7.9]   -4.3[ -5.7]   -2.4[ -3.5]   -1.0[ -1.6]    100%   (point estimate: 90%)
   top5 vs rest         -15.5[-18.1]  -13.1[-15.5]  -10.7[-12.9]   -9.4[-11.6]   -8.0[-10.1]   -6.7[ -8.6]   -4.7[ -6.4]   -2.9[ -4.2]   -1.7[ -2.7]    100%   (point estimate: 100%)
   NQC-like spread      -14.7[-17.2]  -12.1[-14.4]  -10.8[-13.0]   -9.6[-11.8]   -7.9[ -9.9]   -6.3[ -8.1]   -4.4[ -6.0]   -3.2[ -4.5]   -1.4[ -2.3]    100%   (point estimate: 100%)
   WIG-like             -15.9[-18.4]  -13.9[-16.3]  -11.5[-13.9]  -10.0[-12.3]   -8.3[-10.4]   -6.3[ -8.1]   -4.8[ -6.4]   -2.9[ -4.2]   -1.3[ -2.2]    100%   (point estimate: 100%)
   term coverage top1   -15.9[-18.4]  -14.0[-16.3]  -12.1[-14.3]   -9.9[-12.1]   -7.6[ -9.5]   -5.6[ -7.2]   -3.4[ -4.7]   -2.7[ -3.9]   -1.1[ -1.9]    100%   (point estimate: 100%)
   ORACLE                -8.5[-10.4]   -1.8[ -3.1]   +1.5[ +0.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#   30%   (point estimate: 30%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -15.2[-17.7]  -13.1[-15.5]  -10.9[-13.1]   -7.4[ -9.3]   -6.1[ -7.7]   -4.8[ -6.4]   -3.9[ -5.3]   -2.2[ -3.2]   -0.6[ -1.2]    100%   (point estimate: 100%)
   BM25 margin          -15.4[-17.9]  -12.1[-14.4]  -10.1[-12.2]   -9.0[-11.0]   -7.4[ -9.4]   -6.2[ -7.9]   -4.3[ -5.7]   -2.4[ -3.5]   -1.0[ -1.6]    100%   (point estimate: 100%)
   top5 vs rest         -15.5[-18.1]  -13.1[-15.5]  -10.7[-12.9]   -9.4[-11.6]   -8.0[-10.1]   -6.7[ -8.6]   -4.7[ -6.4]   -2.9[ -4.2]   -1.7[ -2.7]    100%   (point estimate: 100%)
   NQC-like spread      -14.7[-17.2]  -12.1[-14.4]  -10.8[-13.0]   -9.6[-11.8]   -7.9[ -9.9]   -6.3[ -8.1]   -4.4[ -6.0]   -3.2[ -4.5]   -1.4[ -2.3]    100%   (point estimate: 100%)
   WIG-like             -15.9[-18.4]  -13.9[-16.3]  -11.5[-13.9]  -10.0[-12.3]   -8.3[-10.4]   -6.3[ -8.1]   -4.8[ -6.4]   -2.9[ -4.2]   -1.3[ -2.2]    100%   (point estimate: 100%)
   term coverage top1   -15.9[-18.4]  -14.0[-16.3]  -12.1[-14.3]   -9.9[-12.1]   -7.6[ -9.5]   -5.6[ -7.2]   -3.4[ -4.7]   -2.7[ -3.9]   -1.1[ -1.9]    100%   (point estimate: 100%)
   ORACLE                -8.5[-10.4]   -1.8[ -3.1]   +1.5[ +0.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#   30%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      90% (sd  10)   -0.96 MRR              24%     10%
   tag alarm               100      92% (sd   7)   -0.71 MRR              15%      8%
   tag alarm               200      93% (sd   6)   -0.60 MRR              14%      7%
   BM25 margin              50      93% (sd   9)   -0.87 MRR              40%      7%
   BM25 margin             100      93% (sd   8)   -0.84 MRR              40%      7%
   BM25 margin             200      95% (sd   6)   -0.60 MRR              40%      5%
   top5 vs rest             50      93% (sd  12)   -1.24 MRR              40%      7%
   top5 vs rest            100      96% (sd   7)   -0.78 MRR              34%      4%
   top5 vs rest            200      98% (sd   5)   -0.49 MRR              22%      2%
   NQC-like spread          50      93% (sd  10)   -1.10 MRR              48%      7%
   NQC-like spread         100      95% (sd   7)   -0.72 MRR              38%      5%
   NQC-like spread         200      97% (sd   5)   -0.47 MRR              29%      3%
   WIG-like                 50      93% (sd  11)   -1.09 MRR              42%      7%
   WIG-like                100      95% (sd   7)   -0.76 MRR              35%      5%
   WIG-like                200      96% (sd   5)   -0.59 MRR              32%      4%
   term coverage top1       50      93% (sd  10)   -0.95 MRR              42%      7%
   term coverage top1      100      95% (sd   7)   -0.69 MRR              42%      5%
   term coverage top1      200      96% (sd   6)   -0.54 MRR              36%      4%

## beir_arguana  (1401 questions; tag alarm fires on 9 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.2  diff  -0.0  p=0.8441
   MRR  : tag  22.0  random  22.1  diff  -0.1  p=0.8013

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.0 (p=0.736)
   40%            -0.1 (p=1.000)        -0.1 (p=0.167)
   50%            +0.0 (p=1.000)        -0.1 (p=0.248)
   1% nat         +0.0 (p=1.000)        +0.0 (p=0.531)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -18.6  95% CI [-20.7, -16.6]  p=0.000
   MRR  : -21.9  95% CI [-23.5, -20.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (17%)
   Hit@1:  +5.6  p=0.000
   MRR  :  +1.6  p=0.005

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.5/+0.9 (p=0.234)  40%: +1.2/+0.9 (p=0.312)  50%: +0.9/+0.5 (p=0.572)  nat: -0.1/-0.1 (p=0.240)
   vs NQC-like spread      30%: +0.6/+0.6 (p=0.340)  40%: +0.7/+0.6 (p=0.406)  50%: +0.6/+0.2 (p=0.809)  nat: +0.0/+0.0 (p=0.691)
   vs WIG-like             30%: +1.5/+0.8 (p=0.288)  40%: +1.6/+1.1 (p=0.179)  50%: +1.6/+1.0 (p=0.264)  nat: +0.0/+0.1 (p=0.361)
   vs term coverage top1   30%: +1.1/+0.5 (p=0.448)  40%: +1.9/+0.8 (p=0.256)  50%: +1.2/+0.3 (p=0.632)  nat: +0.1/+0.0 (p=0.824)

G. each selector reranking 9 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -21.9  [-23.5, -20.3]  p=0.000
   BM25 margin          -22.0  [-23.6, -20.4]  p=0.000
   top5 vs rest         -21.8  [-23.4, -20.2]  p=0.000
   NQC-like spread      -21.9  [-23.5, -20.4]  p=0.000
   WIG-like             -22.0  [-23.6, -20.4]  p=0.000
   term coverage top1   -21.9  [-23.5, -20.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              23.8    26.5    29.1    31.2    33.1    35.2    37.2    39.5    41.8    43.9*   100%
   BM25 margin            23.9    26.7    29.1    31.3    33.2    35.2    37.2    39.5    41.8    43.9*   100%
   top5 vs rest           24.1    26.3    28.1    30.3    32.6    34.7    36.5    38.8    41.3    43.9*   100%
   NQC-like spread        23.5    25.9    28.4    30.7    32.9    35.4    37.6    39.7    41.8    43.9*   100%
   WIG-like               24.2    26.1    28.3    30.1    32.1    34.2    36.2    38.7    41.5    43.9*   100%
   term coverage top1     24.1    26.7    28.6    30.5    32.8    35.2    37.2    39.9    41.9    43.9*   100%
   ORACLE                 30.5    36.0    40.1    43.0    44.9*   46.0*   46.3*   46.3*   46.0*   43.9*   50%
   random (expected)      24.1    26.3    28.5    30.7    32.9    35.1    37.3    39.5    41.7    43.9*   100%
   (BM25 only 21.9; rerank ALL 43.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -20.1[-21.8]  -17.4[-18.9]  -14.9[-16.3]  -12.7[-14.1]  -10.8[-12.1]   -8.7[ -9.9]   -6.7[ -7.8]   -4.4[ -5.3]   -2.1[ -2.7]    100%   (point estimate: 100%)
   BM25 margin          -20.0[-21.7]  -17.3[-18.8]  -14.8[-16.3]  -12.6[-14.0]  -10.8[-12.1]   -8.7[ -9.9]   -6.7[ -7.8]   -4.4[ -5.3]   -2.1[ -2.7]    100%   (point estimate: 100%)
   top5 vs rest         -19.8[-21.3]  -17.6[-19.1]  -15.8[-17.2]  -13.6[-15.0]  -11.3[-12.6]   -9.2[-10.5]   -7.4[ -8.5]   -5.1[ -6.1]   -2.6[ -3.3]    100%   (point estimate: 100%)
   NQC-like spread      -20.4[-22.0]  -18.0[-19.6]  -15.5[-16.9]  -13.2[-14.6]  -11.0[-12.3]   -8.6[ -9.7]   -6.3[ -7.3]   -4.2[ -5.0]   -2.1[ -2.7]    100%   (point estimate: 100%)
   WIG-like             -19.8[-21.3]  -17.8[-19.3]  -15.6[-17.1]  -13.8[-15.2]  -11.8[-13.1]   -9.7[-10.9]   -7.8[ -8.9]   -5.2[ -6.2]   -2.4[ -3.1]    100%   (point estimate: 100%)
   term coverage top1   -19.8[-21.4]  -17.2[-18.7]  -15.4[-16.8]  -13.5[-14.9]  -11.2[-12.5]   -8.7[ -9.8]   -6.7[ -7.7]   -4.0[ -4.8]   -2.1[ -2.6]    100%   (point estimate: 100%)
   ORACLE               -13.4[-14.6]   -7.9[ -8.8]   -3.8[ -4.6]   -0.9[ -1.5]   +1.0[ +0.6]#  +2.1[ +1.8]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.1[ +1.7]#   50%   (point estimate: 40%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -20.1[-21.8]  -17.4[-18.9]  -14.9[-16.3]  -12.7[-14.1]  -10.8[-12.1]   -8.7[ -9.9]   -6.7[ -7.8]   -4.4[ -5.3]   -2.1[ -2.7]    100%   (point estimate: 100%)
   BM25 margin          -20.0[-21.7]  -17.3[-18.8]  -14.8[-16.3]  -12.6[-14.0]  -10.8[-12.1]   -8.7[ -9.9]   -6.7[ -7.8]   -4.4[ -5.3]   -2.1[ -2.7]    100%   (point estimate: 100%)
   top5 vs rest         -19.8[-21.3]  -17.6[-19.1]  -15.8[-17.2]  -13.6[-15.0]  -11.3[-12.6]   -9.2[-10.5]   -7.4[ -8.5]   -5.1[ -6.1]   -2.6[ -3.3]    100%   (point estimate: 100%)
   NQC-like spread      -20.4[-22.0]  -18.0[-19.6]  -15.5[-16.9]  -13.2[-14.6]  -11.0[-12.3]   -8.6[ -9.7]   -6.3[ -7.3]   -4.2[ -5.0]   -2.1[ -2.7]    100%   (point estimate: 100%)
   WIG-like             -19.8[-21.3]  -17.8[-19.3]  -15.6[-17.1]  -13.8[-15.2]  -11.8[-13.1]   -9.7[-10.9]   -7.8[ -8.9]   -5.2[ -6.2]   -2.4[ -3.1]    100%   (point estimate: 100%)
   term coverage top1   -19.8[-21.4]  -17.2[-18.7]  -15.4[-16.8]  -13.5[-14.9]  -11.2[-12.5]   -8.7[ -9.8]   -6.7[ -7.7]   -4.0[ -4.8]   -2.1[ -2.6]    100%   (point estimate: 100%)
   ORACLE               -13.4[-14.6]   -7.9[ -8.8]   -3.8[ -4.6]   -0.9[ -1.5]   +1.0[ +0.6]#  +2.1[ +1.8]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.1[ +1.7]#   50%   (point estimate: 50%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      98% (sd   5)   -0.46 MRR              18%      2%
   tag alarm               100      99% (sd   3)   -0.27 MRR              12%      1%
   tag alarm               200      99% (sd   2)   -0.13 MRR               6%      1%
   BM25 margin              50      98% (sd   4)   -0.39 MRR              16%      2%
   BM25 margin             100      99% (sd   3)   -0.15 MRR               7%      1%
   BM25 margin             200     100% (sd   2)   -0.06 MRR               2%      0%
   top5 vs rest             50      99% (sd   4)   -0.39 MRR              14%      1%
   top5 vs rest            100     100% (sd   1)   -0.05 MRR               2%      0%
   top5 vs rest            200     100% (sd   0)   +0.00 MRR               0%      0%
   NQC-like spread          50      98% (sd   4)   -0.43 MRR              19%      2%
   NQC-like spread         100      99% (sd   3)   -0.23 MRR              10%      1%
   NQC-like spread         200     100% (sd   2)   -0.07 MRR               3%      0%
   WIG-like                 50      98% (sd   4)   -0.41 MRR              16%      2%
   WIG-like                100     100% (sd   2)   -0.13 MRR               5%      0%
   WIG-like                200     100% (sd   0)   +0.00 MRR               0%      0%
   term coverage top1       50      98% (sd   4)   -0.40 MRR              16%      2%
   term coverage top1      100      99% (sd   3)   -0.25 MRR              10%      1%
   term coverage top1      200      99% (sd   2)   -0.13 MRR               6%      1%

## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.3  random  18.9  diff  +0.4  p=0.1462
   MRR  : tag  28.8  random  28.6  diff  +0.2  p=0.2832

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=0.677)        -0.4 (p=0.294)
   40%            +0.1 (p=1.000)        -0.1 (p=0.724)
   50%            +0.2 (p=0.803)        +0.0 (p=0.999)
   12% nat        +0.0 (p=1.000)        +0.2 (p=0.638)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.7  95% CI [-2.9, +1.5]  p=0.583
   MRR  :  -2.0  95% CI [-3.7, -0.4]  p=0.012

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +0.9  p=0.301
   MRR  :  +0.9  p=0.130

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.2/+0.5 (p=0.407)  40%: +1.2/+0.6 (p=0.374)  50%: +1.1/+0.4 (p=0.559)  nat: +0.5/+0.3 (p=0.470)
   vs NQC-like spread      30%: +0.9/+0.2 (p=0.682)  40%: +0.8/+0.1 (p=0.853)  50%: +0.6/+0.0 (p=0.973)  nat: +0.9/+0.6 (p=0.132)
   vs WIG-like             30%: +0.4/-0.3 (p=0.602)  40%: +0.1/-0.7 (p=0.215)  50%: +0.1/-0.5 (p=0.437)  nat: -0.1/-0.3 (p=0.488)
   vs term coverage top1   30%: +0.2/-0.5 (p=0.406)  40%: +0.3/-0.5 (p=0.382)  50%: -0.1/-0.6 (p=0.342)  nat: -0.3/-0.5 (p=0.280)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.0  [-3.7, -0.4]  p=0.012
   BM25 margin           -2.2  [-3.9, -0.7]  p=0.006
   top5 vs rest          -2.3  [-4.0, -0.7]  p=0.006
   NQC-like spread       -2.6  [-4.3, -1.0]  p=0.002
   WIG-like              -1.8  [-3.4, -0.2]  p=0.032
   term coverage top1    -1.5  [-3.1, +0.0]  p=0.053

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              28.9    28.9    29.2    29.5    30.0*   30.3*   30.5*   30.5*   30.6*   30.8*   50%
   BM25 margin            28.5    29.1    29.6*   29.6*   30.0*   30.2*   30.5*   30.5*   30.7*   30.8*   30%
   top5 vs rest           28.4    29.0    28.7    28.9    29.6*   30.4*   30.7*   30.8*   30.5*   30.8*   50%
   NQC-like spread        28.3    28.6    28.9    29.4    30.0*   30.4*   30.6*   30.8*   31.0*   30.8*   50%
   WIG-like               29.0    29.3    29.5*   30.2*   30.5*   31.1*   31.3*   31.0*   30.9*   30.8*   30%
   term coverage top1     29.3*   29.7*   29.6*   30.0*   30.5*   30.4*   30.7*   31.4*   30.9*   30.8*   10%
   ORACLE                 34.6*   36.4*   36.8*   36.8*   36.8*   36.8*   36.8*   36.7*   35.9*   30.8*   10%
   random (expected)      28.6    28.8    29.1    29.3    29.6    29.8    30.1    30.3    30.6    30.8*   100%
   (BM25 only 28.3; rerank ALL 30.8)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.9[ -3.6]   -2.0[ -3.5]   -1.7[ -3.1]   -1.3[ -2.6]   -0.8[ -2.0]   -0.5[ -1.5]   -0.3[ -1.3]   -0.3[ -1.1]   -0.2[ -0.6]#   90%   (point estimate: 50%)
   BM25 margin           -2.3[ -3.9]   -1.8[ -3.3]   -1.3[ -2.6]   -1.2[ -2.4]   -0.8[ -2.0]   -0.6[ -1.7]   -0.3[ -1.2]   -0.3[ -1.0]#  -0.1[ -0.5]#   80%   (point estimate: 50%)
   top5 vs rest          -2.4[ -4.1]   -1.9[ -3.4]   -2.1[ -3.6]   -1.9[ -3.2]   -1.2[ -2.5]   -0.5[ -1.6]   -0.1[ -1.1]   -0.0[ -0.9]#  -0.3[ -1.0]#   80%   (point estimate: 60%)
   NQC-like spread       -2.6[ -4.2]   -2.3[ -3.8]   -1.9[ -3.3]   -1.4[ -2.8]   -0.9[ -2.0]   -0.4[ -1.5]   -0.2[ -1.2]   -0.1[ -0.9]#  +0.2[ -0.4]#   80%   (point estimate: 50%)
   WIG-like              -1.9[ -3.5]   -1.6[ -3.1]   -1.4[ -2.9]   -0.6[ -2.0]   -0.3[ -1.6]   +0.3[ -0.8]#  +0.5[ -0.5]#  +0.1[ -0.7]#  +0.1[ -0.6]#   60%   (point estimate: 40%)
   term coverage top1    -1.5[ -3.0]   -1.1[ -2.6]   -1.2[ -2.6]   -0.8[ -2.0]   -0.3[ -1.3]   -0.4[ -1.3]   -0.1[ -0.9]#  +0.6[ +0.0]#  +0.1[ -0.3]#   70%   (point estimate: 40%)
   ORACLE                +3.7[ +2.6]#  +5.5[ +4.5]#  +5.9[ +4.9]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +5.9[ +4.9]#  +5.1[ +4.1]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.9[ -3.6]   -2.0[ -3.5]   -1.7[ -3.1]   -1.3[ -2.6]   -0.8[ -2.0]   -0.5[ -1.5]   -0.3[ -1.3]   -0.3[ -1.1]   -0.2[ -0.6]    100%   (point estimate: 60%)
   BM25 margin           -2.3[ -3.9]   -1.8[ -3.3]   -1.3[ -2.6]   -1.2[ -2.4]   -0.8[ -2.0]   -0.6[ -1.7]   -0.3[ -1.2]   -0.3[ -1.0]   -0.1[ -0.5]#   90%   (point estimate: 70%)
   top5 vs rest          -2.4[ -4.1]   -1.9[ -3.4]   -2.1[ -3.6]   -1.9[ -3.2]   -1.2[ -2.5]   -0.5[ -1.6]   -0.1[ -1.1]   -0.0[ -0.9]   -0.3[ -1.0]    100%   (point estimate: 60%)
   NQC-like spread       -2.6[ -4.2]   -2.3[ -3.8]   -1.9[ -3.3]   -1.4[ -2.8]   -0.9[ -2.0]   -0.4[ -1.5]   -0.2[ -1.2]   -0.1[ -0.9]   +0.2[ -0.4]#   90%   (point estimate: 60%)
   WIG-like              -1.9[ -3.5]   -1.6[ -3.1]   -1.4[ -2.9]   -0.6[ -2.0]   -0.3[ -1.6]   +0.3[ -0.8]   +0.5[ -0.5]   +0.1[ -0.7]   +0.1[ -0.6]    100%   (point estimate: 50%)
   term coverage top1    -1.5[ -3.0]   -1.1[ -2.6]   -1.2[ -2.6]   -0.8[ -2.0]   -0.3[ -1.3]   -0.4[ -1.3]   -0.1[ -0.9]   +0.6[ +0.0]#  +0.1[ -0.3]#   80%   (point estimate: 50%)
   ORACLE                +3.7[ +2.6]#  +5.5[ +4.5]#  +5.9[ +4.9]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +5.9[ +4.9]#  +5.1[ +4.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      61% (sd  34)   -0.83 MRR              32%     39%
   tag alarm               100      62% (sd  31)   -0.81 MRR              30%     38%
   tag alarm               200      55% (sd  30)   -1.00 MRR              34%     45%
   BM25 margin              50      58% (sd  33)   -0.90 MRR              34%     42%
   BM25 margin             100      53% (sd  29)   -1.00 MRR              38%     47%
   BM25 margin             200      52% (sd  28)   -1.04 MRR              41%     48%
   top5 vs rest             50      61% (sd  35)   -0.99 MRR              41%     39%
   top5 vs rest            100      62% (sd  33)   -0.94 MRR              38%     38%
   top5 vs rest            200      60% (sd  30)   -1.01 MRR              38%     40%
   NQC-like spread          50      61% (sd  35)   -0.94 MRR              38%     39%
   NQC-like spread         100      61% (sd  32)   -0.90 MRR              34%     39%
   NQC-like spread         200      55% (sd  26)   -1.00 MRR              38%     45%
   WIG-like                 50      53% (sd  36)   -0.75 MRR              40%     47%
   WIG-like                100      47% (sd  32)   -0.82 MRR              42%     53%
   WIG-like                200      42% (sd  27)   -0.90 MRR              43%     58%
   term coverage top1       50      54% (sd  32)   -0.51 MRR              31%     46%
   term coverage top1      100      47% (sd  29)   -0.64 MRR              35%     53%
   term coverage top1      200      41% (sd  24)   -0.80 MRR              39%     59%

## POOLED over 5 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  18.8  random  18.3  diff  +0.4  p=0.0172
   MRR  : tag  32.4  random  32.2  diff  +0.2  p=0.0492

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  -0.3 (p=0.373)   MRR  -0.3 (p=0.157)
   40%      Hit@1  +0.3 (p=0.296)   MRR  +0.1 (p=0.494)
   50%      Hit@1  +0.4 (p=0.114)   MRR  +0.2 (p=0.263)
   natural  Hit@1  -0.3 (p=0.376)   MRR  -0.3 (p=0.290)

C. tag alarm vs rerank ALL (pooled)
   Hit@1: -10.0  95% CI [-11.2, -8.8]  p=0.000
   MRR  : -11.7  95% CI [-12.7, -10.8]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +3.1  p=0.000
   MRR  :  +1.1  p=0.002

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.3/+0.7 (p=0.088)  40%: +1.7/+1.3 (p=0.007)  50%: +1.6/+1.0 (p=0.027)  nat: +0.3/+0.0 (p=0.853)
   vs NQC-like spread      30%: +0.8/+0.4 (p=0.336)  40%: +1.2/+0.7 (p=0.052)  50%: +1.1/+0.6 (p=0.137)  nat: +0.1/-0.1 (p=0.719)
   vs WIG-like             30%: +1.0/+0.4 (p=0.311)  40%: +1.4/+0.8 (p=0.062)  50%: +1.3/+0.8 (p=0.069)  nat: +0.1/-0.0 (p=0.975)
   vs term coverage top1   30%: +0.7/+0.3 (p=0.435)  40%: +1.3/+0.7 (p=0.081)  50%: +0.7/+0.3 (p=0.444)  nat: +0.2/+0.1 (p=0.783)
