## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  31.5  random  28.9  diff  +2.6  p=0.0014
   MRR  : tag  38.2  random  36.4  diff  +1.7  p=0.0037

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.9 (p=0.574)        -1.0 (p=0.371)
   40%            +1.1 (p=0.431)        +0.9 (p=0.349)
   50%            +1.7 (p=0.103)        +1.1 (p=0.189)
   25% nat        -0.2 (p=1.000)        -0.8 (p=0.515)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -17.9  95% CI [-21.1, -14.7]  p=0.000
   MRR  : -17.1  95% CI [-19.8, -14.5]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +3.7  p=0.010
   MRR  :  +1.9  p=0.103

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +2.2/+1.2 (p=0.351)  40%: +4.2/+2.9 (p=0.023)  50%: +4.8/+3.4 (p=0.006)  nat: +2.0/+0.9 (p=0.415)
   vs NQC-like spread      30%: +1.2/+0.5 (p=0.686)  40%: +3.4/+2.5 (p=0.043)  50%: +4.2/+3.0 (p=0.012)  nat: +0.8/-0.1 (p=0.937)
   vs WIG-like             30%: +2.2/+1.4 (p=0.239)  40%: +4.3/+3.3 (p=0.010)  50%: +4.5/+3.5 (p=0.007)  nat: +2.2/+1.3 (p=0.264)
   vs term coverage top1   30%: +1.7/+1.3 (p=0.209)  40%: +2.6/+2.3 (p=0.050)  50%: +2.0/+1.7 (p=0.165)  nat: +1.9/+1.4 (p=0.145)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -17.1  [-19.8, -14.5]  p=0.000
   BM25 margin          -16.3  [-18.9, -13.7]  p=0.000
   top5 vs rest         -18.1  [-20.7, -15.4]  p=0.000
   NQC-like spread      -17.0  [-19.7, -14.4]  p=0.000
   WIG-like             -18.4  [-21.0, -15.7]  p=0.000
   term coverage top1   -18.5  [-21.2, -15.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              33.8    37.1    39.9    43.5    46.2    48.3    50.0    51.6    54.3    55.3*   100%
   BM25 margin            33.7    37.3    40.9    42.6    45.1    47.2    49.4    51.7    53.9    55.3*   100%
   top5 vs rest           32.7    35.9    38.8    40.6    42.8    45.2    47.5    50.3    52.9    55.3*   100%
   NQC-like spread        33.5    37.5    39.4    41.1    43.2    45.5    48.2    50.5    53.1    55.3*   100%
   WIG-like               32.6    35.1    38.5    40.2    42.7    45.8    48.0    50.2    52.8    55.3*   100%
   term coverage top1     32.7    35.7    38.6    41.2    44.5    47.2    50.2    51.5    53.7    55.3*   100%
   ORACLE                 39.9    48.3    54.0    56.5*   56.7*   56.7*   56.7*   56.7*   56.7*   55.3*   40%
   random (expected)      32.8    35.3    37.8    40.3    42.8    45.3    47.8    50.3    52.8    55.3*   100%
   (BM25 only 30.3; rerank ALL 55.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.11 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -21.5[-24.3]  -18.2[-20.9]  -15.4[-17.9]  -11.8[-14.0]   -9.1[-11.1]   -7.0[ -8.8]   -5.3[ -6.8]   -3.7[ -4.9]   -1.0[ -1.8]    100%   (point estimate: 90%)
   BM25 margin          -21.6[-24.4]  -18.0[-20.8]  -14.4[-16.8]  -12.7[-15.0]  -10.2[-12.3]   -8.1[-10.0]   -5.9[ -7.4]   -3.6[ -4.8]   -1.4[ -2.2]    100%   (point estimate: 100%)
   top5 vs rest         -22.6[-25.5]  -19.4[-22.1]  -16.5[-19.0]  -14.7[-17.1]  -12.5[-14.9]  -10.1[-12.2]   -7.8[ -9.7]   -5.0[ -6.6]   -2.4[ -3.6]    100%   (point estimate: 100%)
   NQC-like spread      -21.8[-24.5]  -17.8[-20.4]  -15.9[-18.3]  -14.2[-16.8]  -12.1[-14.4]   -9.8[-11.9]   -7.1[ -9.0]   -4.8[ -6.3]   -2.2[ -3.3]    100%   (point estimate: 100%)
   WIG-like             -22.7[-25.4]  -20.2[-23.0]  -16.8[-19.5]  -15.1[-17.7]  -12.6[-14.9]   -9.5[-11.5]   -7.3[ -9.1]   -5.1[ -6.6]   -2.5[ -3.6]    100%   (point estimate: 100%)
   term coverage top1   -22.6[-25.5]  -19.6[-22.4]  -16.7[-19.1]  -14.1[-16.4]  -10.8[-12.8]   -8.1[ -9.9]   -5.1[ -6.7]   -3.8[ -5.1]   -1.6[ -2.4]    100%   (point estimate: 100%)
   ORACLE               -15.4[-17.7]   -7.0[ -8.6]   -1.3[ -2.2]   +1.2[ +0.6]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#   40%   (point estimate: 40%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.11): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      96% (sd   5)   -0.50 MRR              35%      4%
   BM25 margin             100      97% (sd   5)   -0.44 MRR              30%      3%
   top5 vs rest            100      98% (sd   4)   -0.53 MRR              20%      2%
   NQC-like spread         100      96% (sd   6)   -0.96 MRR              35%      4%
   WIG-like                100      99% (sd   3)   -0.28 MRR              10%      1%
   term coverage top1      100      99% (sd   3)   -0.17 MRR              10%      1%

