## mag_testfull  (2665 questions; tag alarm fires on 710 = 27%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  54.3  random  51.0  diff  +3.3  p=0.0001
   MRR  : tag  63.1  random  60.8  diff  +2.3  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.3 (p=0.000)        +1.7 (p=0.000)
   40%            +2.0 (p=0.000)        +1.4 (p=0.000)
   50%            +1.5 (p=0.000)        +1.1 (p=0.001)
   27% nat        +2.1 (p=0.000)        +1.6 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +1.8  95% CI [+0.5, +3.1]  p=0.010
   MRR  :  +2.2  95% CI [+1.3, +3.1]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (37%)
   Hit@1:  +1.3  p=0.034
   MRR  :  +0.8  p=0.055

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.4/+2.1 (p=0.000)  40%: +2.9/+1.5 (p=0.000)  50%: +2.8/+1.5 (p=0.000)  nat: +3.1/+2.0 (p=0.000)
   vs NQC-like spread      30%: +2.6/+1.8 (p=0.000)  40%: +2.5/+1.4 (p=0.000)  50%: +2.6/+1.5 (p=0.000)  nat: +2.8/+1.8 (p=0.000)
   vs WIG-like             30%: +1.4/+0.6 (p=0.113)  40%: +1.4/+0.5 (p=0.275)  50%: +1.7/+0.6 (p=0.161)  nat: +1.3/+0.5 (p=0.160)
   vs term coverage top1   30%: +1.5/+0.8 (p=0.031)  40%: +0.7/+0.2 (p=0.535)  50%: +0.5/+0.1 (p=0.859)  nat: +1.5/+0.8 (p=0.025)

G. each selector reranking 710 questions (27%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +2.2  [+1.3, +3.1]  p=0.000
   BM25 margin           +0.6  [-0.4, +1.6]  p=0.241
   top5 vs rest          +0.3  [-0.7, +1.2]  p=0.615
   NQC-like spread       +0.5  [-0.5, +1.4]  p=0.336
   WIG-like              +1.7  [+0.7, +2.7]  p=0.001
   term coverage top1    +1.4  [+0.4, +2.4]  p=0.006

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              61.9*   62.8*   63.2*   62.9*   62.6*   62.5*   62.0*   61.6*   61.2*   60.9*   10%
   BM25 margin            61.0*   61.2*   61.5*   61.5*   61.6*   61.6*   61.7*   61.5*   61.2*   60.9*   10%
   top5 vs rest           60.8*   60.9*   61.0*   61.3*   61.1*   60.9*   60.7*   60.8*   60.8*   60.9*   10%
   NQC-like spread        60.9*   61.3*   61.4*   61.5*   61.1*   61.0*   60.8*   60.8*   60.8*   60.9*   10%
   WIG-like               62.0*   62.7*   62.6*   62.4*   62.0*   62.0*   62.1*   61.8*   61.4*   60.9*   10%
   term coverage top1     61.7*   62.0*   62.4*   62.6*   62.6*   62.5*   62.2*   62.1*   61.6*   60.9*   10%
   ORACLE                 67.5*   69.1*   69.1*   69.1*   69.1*   69.1*   69.1*   69.1*   67.4*   60.9*   10%
   random (expected)      60.8    60.8    60.8    60.8    60.8    60.8    60.8    60.8    60.9    60.9*   100%
   (BM25 only 60.8; rerank ALL 60.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.22 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +1.1[ -0.1]#  +2.0[ +1.0]#  +2.3[ +1.4]#  +2.0[ +1.3]#  +1.8[ +1.1]#  +1.6[ +1.0]#  +1.1[ +0.7]#  +0.8[ +0.4]#  +0.3[ +0.2]#   10%   (point estimate: 10%)
   BM25 margin           +0.2[ -1.0]#  +0.4[ -0.7]#  +0.6[ -0.4]#  +0.6[ -0.3]#  +0.7[ -0.1]#  +0.8[ +0.1]#  +0.8[ +0.4]#  +0.6[ +0.3]#  +0.3[ +0.2]#   10%   (point estimate: 10%)
   top5 vs rest          -0.1[ -1.2]#  +0.1[ -1.0]#  +0.2[ -0.8]#  +0.5[ -0.4]#  +0.2[ -0.6]#  +0.1[ -0.7]#  -0.2[ -0.7]#  -0.1[ -0.6]#  -0.1[ -0.4]#   10%   (point estimate: 10%)
   NQC-like spread       +0.0[ -1.1]#  +0.5[ -0.5]#  +0.6[ -0.4]#  +0.6[ -0.2]#  +0.2[ -0.5]#  +0.2[ -0.5]#  -0.0[ -0.6]#  -0.1[ -0.5]#  -0.1[ -0.4]#   10%   (point estimate: 10%)
   WIG-like              +1.2[ +0.0]#  +1.9[ +0.9]#  +1.7[ +0.8]#  +1.6[ +0.7]#  +1.2[ +0.4]#  +1.2[ +0.5]#  +1.3[ +0.7]#  +1.0[ +0.4]#  +0.5[ +0.2]#   10%   (point estimate: 10%)
   term coverage top1    +0.8[ -0.4]#  +1.2[ +0.1]#  +1.5[ +0.5]#  +1.8[ +0.9]#  +1.7[ +0.8]#  +1.6[ +0.9]#  +1.4[ +0.7]#  +1.2[ +0.7]#  +0.7[ +0.3]#   10%   (point estimate: 10%)
   ORACLE                +6.6[ +5.8]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.2[ +7.4]#  +6.5[ +5.7]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.22): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      13% (sd   6)   +1.28 MRR               0%     87%
   BM25 margin             100      34% (sd  27)   +0.43 MRR               0%     66%
   top5 vs rest            100      54% (sd  37)   -0.04 MRR               0%     46%
   NQC-like spread         100      38% (sd  31)   +0.05 MRR               0%     62%
   WIG-like                100      24% (sd  31)   +1.03 MRR               0%     76%
   term coverage top1      100      23% (sd  27)   +0.86 MRR               0%     77%

