## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  59.2  random  56.7  diff  +2.5  p=0.0002
   MRR  : tag  68.9  random  66.5  diff  +2.4  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.0 (p=0.235)        +0.9 (p=0.127)
   40%            +0.1 (p=1.000)        +0.7 (p=0.322)
   50%            -0.9 (p=0.382)        +0.0 (p=0.974)
   47% nat        -0.6 (p=0.561)        +0.3 (p=0.681)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -6.0  95% CI [-7.7, -4.3]  p=0.000
   MRR  :  -5.2  95% CI [-6.5, -3.9]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (46%)
   Hit@1:  +1.5  p=0.123
   MRR  :  +1.1  p=0.118

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.1/-0.9 (p=0.183)  40%: -0.9/-1.2 (p=0.085)  50%: -1.3/-1.4 (p=0.041)  nat: -1.3/-1.5 (p=0.041)
   vs NQC-like spread      30%: -0.7/-1.3 (p=0.063)  40%: -1.5/-1.5 (p=0.030)  50%: -1.7/-1.8 (p=0.009)  nat: -2.0/-2.0 (p=0.005)
   vs WIG-like             30%: +0.9/+0.1 (p=0.931)  40%: +0.7/+0.2 (p=0.768)  50%: +0.1/-0.2 (p=0.781)  nat: +0.0/-0.4 (p=0.607)
   vs term coverage top1   30%: +3.9/+3.2 (p=0.000)  40%: +4.1/+3.9 (p=0.000)  50%: +3.3/+3.5 (p=0.000)  nat: +3.0/+3.3 (p=0.000)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -5.2  [-6.5, -3.9]  p=0.000
   BM25 margin           -5.5  [-6.9, -4.1]  p=0.000
   top5 vs rest          -3.7  [-5.0, -2.5]  p=0.000
   NQC-like spread       -3.2  [-4.4, -2.0]  p=0.000
   WIG-like              -4.8  [-6.2, -3.4]  p=0.000
   term coverage top1    -8.5  [-10.0, -7.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              61.9    64.1    66.7    68.4    69.6    70.8    72.0    72.9    74.0*   74.1*   90%
   BM25 margin            61.7    63.8    65.8    67.7    69.5    70.7    72.1    73.4    74.2*   74.1*   90%
   top5 vs rest           62.3    65.1    67.6    69.6    71.0    72.1    72.6    73.5*   73.9*   74.1*   80%
   NQC-like spread        62.2    65.0    68.0    69.9    71.4    72.7    73.2    73.6*   74.0*   74.1*   80%
   WIG-like               62.4    64.9    66.6    68.2    69.8    70.9    72.2    72.7    73.3    74.1*   100%
   term coverage top1     61.2    62.2    63.5    64.5    66.1    67.9    69.6    70.7    72.2    74.1*   100%
   ORACLE                 69.1    75.5*   79.4*   79.7*   79.7*   79.7*   79.7*   79.7*   79.5*   74.1*   20%
   random (expected)      61.3    62.7    64.1    65.6    67.0    68.4    69.8    71.3    72.7    74.1*   100%
   (BM25 only 59.8; rerank ALL 74.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.48 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.3[-14.1]  -10.0[-11.7]   -7.5[ -9.0]   -5.7[ -7.1]   -4.6[ -5.8]   -3.3[ -4.4]   -2.1[ -2.9]   -1.3[ -1.9]   -0.1[ -0.4]#   90%   (point estimate: 80%)
   BM25 margin          -12.4[-14.2]  -10.4[-12.1]   -8.4[-10.0]   -6.4[ -7.9]   -4.6[ -5.8]   -3.5[ -4.6]   -2.1[ -3.0]   -0.7[ -1.3]#  +0.1[ -0.2]#   80%   (point estimate: 80%)
   top5 vs rest         -11.8[-13.6]   -9.0[-10.6]   -6.5[ -8.1]   -4.5[ -5.9]   -3.2[ -4.4]   -2.0[ -3.1]   -1.5[ -2.5]   -0.6[ -1.4]#  -0.2[ -0.7]#   80%   (point estimate: 80%)
   NQC-like spread      -12.0[-13.8]   -9.1[-10.8]   -6.2[ -7.6]   -4.2[ -5.6]   -2.8[ -3.9]   -1.4[ -2.5]   -0.9[ -1.8]   -0.5[ -1.3]#  -0.2[ -0.7]#   80%   (point estimate: 60%)
   WIG-like             -11.7[-13.5]   -9.2[-10.9]   -7.5[ -9.1]   -6.0[ -7.4]   -4.4[ -5.8]   -3.2[ -4.5]   -1.9[ -3.1]   -1.4[ -2.4]   -0.8[ -1.5]#   90%   (point estimate: 80%)
   term coverage top1   -13.0[-14.8]  -12.0[-13.7]  -10.7[-12.3]   -9.7[-11.2]   -8.0[ -9.5]   -6.3[ -7.6]   -4.6[ -5.7]   -3.5[ -4.5]   -1.9[ -2.7]    100%   (point estimate: 100%)
   ORACLE                -5.0[ -6.4]   +1.4[ +0.3]#  +5.2[ +4.4]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.4[ +4.5]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.48): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      78% (sd  14)   -1.67 MRR              20%     22%
   BM25 margin             100      78% (sd   9)   -1.07 MRR              25%     22%
   top5 vs rest            100      70% (sd  18)   -1.67 MRR              55%     30%
   NQC-like spread         100      67% (sd  20)   -1.74 MRR              50%     33%
   WIG-like                100      84% (sd  16)   -1.27 MRR              35%     16%
   term coverage top1      100      96% (sd   6)   -0.87 MRR              40%      4%

