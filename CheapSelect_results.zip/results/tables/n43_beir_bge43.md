## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.3  random  55.8  diff  +0.5  p=0.3239
   MRR  : tag  67.6  random  67.5  diff  +0.2  p=0.3684

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.7 (p=0.727)        -0.6 (p=0.368)
   40%            -0.7 (p=0.502)        -0.7 (p=0.048)
   50%            +0.3 (p=1.000)        -0.3 (p=0.459)
   15% nat        -1.7 (p=0.381)        -1.3 (p=0.133)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.7  95% CI [-11.7, -3.7]  p=0.000
   MRR  :  -5.7  95% CI [-8.1, -3.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (27%)
   Hit@1:  +0.3  p=1.000
   MRR  :  +0.1  p=0.880

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +4.7/+2.1 (p=0.040)  40%: +5.3/+3.1 (p=0.006)  50%: +4.7/+2.6 (p=0.018)  nat: +1.3/+0.4 (p=0.576)
   vs NQC-like spread      30%: +2.7/+0.2 (p=0.867)  40%: +3.0/+0.9 (p=0.329)  50%: +2.7/+1.2 (p=0.200)  nat: -1.3/-1.4 (p=0.046)
   vs WIG-like             30%: +2.0/+0.5 (p=0.568)  40%: +2.0/+0.7 (p=0.508)  50%: +2.7/+1.6 (p=0.082)  nat: +0.3/-0.4 (p=0.606)
   vs term coverage top1   30%: +2.0/+0.5 (p=0.622)  40%: +2.3/+1.0 (p=0.299)  50%: +2.7/+1.7 (p=0.048)  nat: +0.0/-0.4 (p=0.641)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -5.7  [-8.1, -3.3]  p=0.000
   BM25 margin           -4.4  [-6.6, -2.2]  p=0.000
   top5 vs rest          -6.1  [-8.7, -3.5]  p=0.000
   NQC-like spread       -4.2  [-6.6, -1.9]  p=0.000
   WIG-like              -5.2  [-7.7, -2.9]  p=0.000
   term coverage top1    -5.2  [-7.6, -3.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              67.8    68.5    70.0    71.2    72.4*   72.8*   73.3*   73.2*   73.4*   73.3*   50%
   BM25 margin            67.8    69.7    70.6    71.9*   72.7*   73.2*   73.5*   73.3*   73.4*   73.3*   40%
   top5 vs rest           66.8    67.2    67.9    68.1    69.7    70.0    70.5    71.3    72.3*   73.3*   90%
   NQC-like spread        68.1    69.5    69.9    70.3    71.2    72.1*   72.8*   72.9*   73.1*   73.3*   60%
   WIG-like               67.9    69.1    69.5    70.6    70.7    71.2    71.6    72.1    73.0*   73.3*   90%
   term coverage top1     68.1    68.1    69.5    70.2    70.7    72.0    72.2    72.4    72.7*   73.3*   90%
   ORACLE                 72.5*   75.5*   75.7*   75.7*   75.7*   75.7*   75.7*   75.7*   75.7*   73.3*   10%
   random (expected)      67.1    67.8    68.5    69.2    69.9    70.6    71.2    71.9    72.6    73.3*   100%
   (BM25 only 66.4; rerank ALL 73.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.5[ -8.0]   -4.8[ -7.1]   -3.3[ -5.3]   -2.1[ -3.7]   -0.9[ -1.9]   -0.5[ -1.3]   -0.0[ -0.5]#  -0.1[ -0.5]#  +0.1[ -0.0]#   70%   (point estimate: 50%)
   BM25 margin           -5.5[ -7.9]   -3.6[ -5.8]   -2.7[ -4.7]   -1.4[ -2.9]   -0.6[ -1.5]   -0.1[ -0.8]#  +0.2[ -0.4]#  +0.0[ -0.4]#  +0.1[ -0.0]#   60%   (point estimate: 50%)
   top5 vs rest          -6.5[ -9.1]   -6.1[ -8.6]   -5.4[ -7.8]   -5.2[ -7.6]   -3.5[ -5.7]   -3.3[ -5.2]   -2.8[ -4.7]   -2.0[ -3.4]   -1.0[ -2.1]    100%   (point estimate: 90%)
   NQC-like spread       -5.2[ -7.8]   -3.8[ -6.0]   -3.4[ -5.3]   -2.9[ -4.8]   -2.1[ -3.7]   -1.1[ -2.7]   -0.4[ -1.3]   -0.4[ -1.3]   -0.2[ -0.5]#   90%   (point estimate: 70%)
   WIG-like              -5.4[ -7.8]   -4.2[ -6.5]   -3.8[ -5.8]   -2.7[ -4.4]   -2.5[ -4.1]   -2.1[ -3.7]   -1.7[ -3.2]   -1.2[ -2.4]   -0.3[ -0.9]#   90%   (point estimate: 90%)
   term coverage top1    -5.2[ -7.8]   -5.2[ -7.5]   -3.8[ -5.7]   -3.1[ -4.8]   -2.6[ -4.0]   -1.3[ -2.5]   -1.1[ -2.1]   -0.9[ -1.9]   -0.6[ -1.4]    100%   (point estimate: 80%)
   ORACLE                -0.8[ -2.4]   +2.2[ +1.2]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#   20%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.5[ -8.0]   -4.8[ -7.1]   -3.3[ -5.3]   -2.1[ -3.7]   -0.9[ -1.9]   -0.5[ -1.3]   -0.0[ -0.5]   -0.1[ -0.5]   +0.1[ -0.0]#   90%   (point estimate: 70%)
   BM25 margin           -5.5[ -7.9]   -3.6[ -5.8]   -2.7[ -4.7]   -1.4[ -2.9]   -0.6[ -1.5]   -0.1[ -0.8]   +0.2[ -0.4]#  +0.0[ -0.4]#  +0.1[ -0.0]#   70%   (point estimate: 60%)
   top5 vs rest          -6.5[ -9.1]   -6.1[ -8.6]   -5.4[ -7.8]   -5.2[ -7.6]   -3.5[ -5.7]   -3.3[ -5.2]   -2.8[ -4.7]   -2.0[ -3.4]   -1.0[ -2.1]    100%   (point estimate: 100%)
   NQC-like spread       -5.2[ -7.8]   -3.8[ -6.0]   -3.4[ -5.3]   -2.9[ -4.8]   -2.1[ -3.7]   -1.1[ -2.7]   -0.4[ -1.3]   -0.4[ -1.3]   -0.2[ -0.5]    100%   (point estimate: 70%)
   WIG-like              -5.4[ -7.8]   -4.2[ -6.5]   -3.8[ -5.8]   -2.7[ -4.4]   -2.5[ -4.1]   -2.1[ -3.7]   -1.7[ -3.2]   -1.2[ -2.4]   -0.3[ -0.9]    100%   (point estimate: 90%)
   term coverage top1    -5.2[ -7.8]   -5.2[ -7.5]   -3.8[ -5.7]   -3.1[ -4.8]   -2.6[ -4.0]   -1.3[ -2.5]   -1.1[ -2.1]   -0.9[ -1.9]   -0.6[ -1.4]    100%   (point estimate: 100%)
   ORACLE                -0.8[ -2.4]   +2.2[ +1.2]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      52% (sd  17)   -1.45 MRR              42%     48%
   tag alarm               100      56% (sd   9)   -0.87 MRR              33%     44%
   tag alarm               200      54% (sd   6)   -0.94 MRR              41%     46%
   BM25 margin              50      49% (sd  17)   -1.20 MRR              40%     51%
   BM25 margin             100      47% (sd  11)   -1.16 MRR              40%     53%
   BM25 margin             200      49% (sd   6)   -0.96 MRR              34%     51%
   top5 vs rest             50      88% (sd  18)   -1.23 MRR              50%     12%
   top5 vs rest            100      92% (sd  12)   -1.02 MRR              45%      8%
   top5 vs rest            200      95% (sd   5)   -0.89 MRR              46%      5%
   NQC-like spread          50      65% (sd  23)   -1.42 MRR              44%     35%
   NQC-like spread         100      67% (sd  14)   -1.11 MRR              40%     33%
   NQC-like spread         200      66% (sd   7)   -1.07 MRR              42%     34%
   WIG-like                 50      78% (sd  24)   -1.30 MRR              45%     22%
   WIG-like                100      81% (sd  16)   -1.09 MRR              40%     19%
   WIG-like                200      84% (sd   8)   -0.97 MRR              36%     16%
   term coverage top1       50      72% (sd  20)   -1.40 MRR              57%     28%
   term coverage top1      100      78% (sd  16)   -1.06 MRR              54%     22%
   term coverage top1      200      81% (sd  11)   -0.92 MRR              40%     19%

## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  43.3  random  44.0  diff  -0.6  p=0.9839
   MRR  : tag  30.8  random  31.0  diff  -0.1  p=0.8840

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.0 (p=0.866)
   40%            -0.3 (p=1.000)        -0.5 (p=0.032)
   50%            -0.6 (p=0.496)        -0.1 (p=0.653)
   2% nat         -0.6 (p=0.498)        -0.1 (p=0.588)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.3  95% CI [-5.0, +4.3]  p=1.000
   MRR  :  -2.1  95% CI [-3.6, -0.6]  p=0.007

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  -0.9  p=0.696
   MRR  :  -1.2  p=0.012

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/+0.1 (p=0.907)  40%: +0.6/+0.1 (p=0.882)  50%: +1.2/+0.4 (p=0.483)  nat: -0.6/-0.1 (p=0.588)
   vs NQC-like spread      30%: +0.3/-0.2 (p=0.725)  40%: -0.6/-0.5 (p=0.385)  50%: +0.6/-0.3 (p=0.611)  nat: -0.6/-0.1 (p=0.588)
   vs WIG-like             30%: -0.3/-0.0 (p=0.948)  40%: -0.3/-0.2 (p=0.703)  50%: +0.0/-0.0 (p=0.968)  nat: -0.6/-0.1 (p=0.588)
   vs term coverage top1   30%: -1.5/-0.6 (p=0.224)  40%: -1.2/-0.5 (p=0.410)  50%: -1.9/-0.3 (p=0.581)  nat: -0.6/-0.1 (p=0.588)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.1  [-3.6, -0.6]  p=0.007
   BM25 margin           -2.0  [-3.5, -0.5]  p=0.011
   top5 vs rest          -2.0  [-3.5, -0.5]  p=0.011
   NQC-like spread       -2.0  [-3.5, -0.5]  p=0.011
   WIG-like              -2.0  [-3.5, -0.5]  p=0.011
   term coverage top1    -2.0  [-3.5, -0.5]  p=0.011

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              30.8    31.1    31.4    31.8*   32.3*   32.4*   32.2*   32.4*   32.7*   32.9*   40%
   BM25 margin            30.8    31.1    31.4    32.3*   32.4*   32.3*   32.1    32.3*   32.7*   32.9*   80%
   top5 vs rest           30.9    31.3    31.4    31.7    31.9*   32.3*   32.8*   33.0*   33.3*   32.9*   50%
   NQC-like spread        30.9    31.5    31.6    32.3*   32.6*   33.0*   33.2*   33.0*   33.0*   32.9*   40%
   WIG-like               30.9    30.7    31.5    32.0*   32.3*   33.0*   32.9*   32.8*   32.8*   32.9*   40%
   term coverage top1     31.1    31.6*   32.0*   32.2*   32.6*   32.4*   32.6*   32.6*   32.8*   32.9*   20%
   ORACLE                 34.0*   35.3*   36.0*   36.0*   36.0*   36.0*   36.0*   35.9*   35.1*   32.9*   10%
   random (expected)      31.1    31.3    31.5    31.7    31.9    32.1    32.3    32.5    32.7    32.9*   100%
   (BM25 only 30.9; rerank ALL 32.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.1[ -3.6]   -1.7[ -3.2]   -1.4[ -2.8]   -1.1[ -2.4]   -0.6[ -1.5]   -0.5[ -1.4]   -0.7[ -1.5]   -0.5[ -1.2]   -0.2[ -0.7]#   90%   (point estimate: 50%)
   BM25 margin           -2.1[ -3.6]   -1.7[ -3.2]   -1.5[ -2.8]   -0.6[ -1.9]   -0.5[ -1.5]   -0.6[ -1.5]   -0.8[ -1.7]   -0.6[ -1.3]   -0.2[ -0.7]#   90%   (point estimate: 40%)
   top5 vs rest          -2.0[ -3.5]   -1.6[ -3.0]   -1.5[ -2.8]   -1.2[ -2.3]   -0.9[ -2.0]   -0.6[ -1.5]   -0.1[ -0.8]#  +0.1[ -0.5]#  +0.4[ +0.1]#   70%   (point estimate: 50%)
   NQC-like spread       -2.0[ -3.6]   -1.4[ -2.8]   -1.3[ -2.5]   -0.6[ -1.6]   -0.3[ -1.3]   +0.1[ -0.6]#  +0.3[ -0.2]#  +0.1[ -0.2]#  +0.1[ -0.1]#   60%   (point estimate: 40%)
   WIG-like              -2.0[ -3.5]   -2.1[ -3.6]   -1.4[ -2.8]   -0.9[ -2.2]   -0.5[ -1.6]   +0.1[ -0.7]#  +0.1[ -0.6]#  -0.1[ -0.7]#  -0.1[ -0.3]#   60%   (point estimate: 40%)
   term coverage top1    -1.8[ -3.4]   -1.3[ -2.8]   -0.9[ -2.2]   -0.7[ -1.8]   -0.3[ -1.3]   -0.5[ -1.4]   -0.3[ -1.0]#  -0.3[ -0.8]#  -0.1[ -0.6]#   70%   (point estimate: 30%)
   ORACLE                +1.1[ +0.1]#  +2.4[ +1.6]#  +3.1[ +2.3]#  +3.2[ +2.4]#  +3.2[ +2.4]#  +3.2[ +2.4]#  +3.2[ +2.4]#  +3.0[ +2.2]#  +2.2[ +1.4]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.1[ -3.6]   -1.7[ -3.2]   -1.4[ -2.8]   -1.1[ -2.4]   -0.6[ -1.5]   -0.5[ -1.4]   -0.7[ -1.5]   -0.5[ -1.2]   -0.2[ -0.7]    100%   (point estimate: 90%)
   BM25 margin           -2.1[ -3.6]   -1.7[ -3.2]   -1.5[ -2.8]   -0.6[ -1.9]   -0.5[ -1.5]   -0.6[ -1.5]   -0.8[ -1.7]   -0.6[ -1.3]   -0.2[ -0.7]    100%   (point estimate: 90%)
   top5 vs rest          -2.0[ -3.5]   -1.6[ -3.0]   -1.5[ -2.8]   -1.2[ -2.3]   -0.9[ -2.0]   -0.6[ -1.5]   -0.1[ -0.8]   +0.1[ -0.5]   +0.4[ +0.1]#   90%   (point estimate: 70%)
   NQC-like spread       -2.0[ -3.6]   -1.4[ -2.8]   -1.3[ -2.5]   -0.6[ -1.6]   -0.3[ -1.3]   +0.1[ -0.6]   +0.3[ -0.2]#  +0.1[ -0.2]#  +0.1[ -0.1]#   70%   (point estimate: 50%)
   WIG-like              -2.0[ -3.5]   -2.1[ -3.6]   -1.4[ -2.8]   -0.9[ -2.2]   -0.5[ -1.6]   +0.1[ -0.7]   +0.1[ -0.6]   -0.1[ -0.7]   -0.1[ -0.3]#   90%   (point estimate: 60%)
   term coverage top1    -1.8[ -3.4]   -1.3[ -2.8]   -0.9[ -2.2]   -0.7[ -1.8]   -0.3[ -1.3]   -0.5[ -1.4]   -0.3[ -1.0]   -0.3[ -0.8]   -0.1[ -0.6]    100%   (point estimate: 50%)
   ORACLE                +1.1[ +0.1]#  +2.4[ +1.6]#  +3.1[ +2.3]#  +3.2[ +2.4]#  +3.2[ +2.4]#  +3.2[ +2.4]#  +3.2[ +2.4]#  +3.0[ +2.2]#  +2.2[ +1.4]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      57% (sd  32)   -0.95 MRR              32%     43%
   tag alarm               100      52% (sd  28)   -1.09 MRR              43%     48%
   tag alarm               200      50% (sd  19)   -0.97 MRR              36%     50%
   BM25 margin              50      58% (sd  32)   -0.86 MRR              26%     42%
   BM25 margin             100      54% (sd  29)   -0.97 MRR              30%     46%
   BM25 margin             200      49% (sd  22)   -0.90 MRR              30%     51%
   top5 vs rest             50      49% (sd  26)   -0.96 MRR              50%     51%
   top5 vs rest            100      51% (sd  20)   -0.92 MRR              45%     49%
   top5 vs rest            200      52% (sd  14)   -0.89 MRR              42%     48%
   NQC-like spread          50      37% (sd  23)   -1.07 MRR              50%     63%
   NQC-like spread         100      39% (sd  19)   -0.88 MRR              40%     61%
   NQC-like spread         200      38% (sd  11)   -0.87 MRR              34%     62%
   WIG-like                 50      49% (sd  28)   -0.86 MRR              36%     51%
   WIG-like                100      46% (sd  20)   -0.83 MRR              37%     54%
   WIG-like                200      44% (sd  12)   -0.91 MRR              44%     56%
   term coverage top1       50      44% (sd  31)   -0.97 MRR              44%     56%
   term coverage top1      100      41% (sd  23)   -0.86 MRR              34%     59%
   term coverage top1      200      34% (sd  15)   -1.08 MRR              47%     66%

## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  28.5  random  26.7  diff  +1.9  p=0.0104
   MRR  : tag  28.2  random  27.3  diff  +1.0  p=0.0121

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.8 (p=0.634)        -0.6 (p=0.405)
   40%            +2.0 (p=0.088)        +1.2 (p=0.043)
   50%            +1.9 (p=0.073)        +0.9 (p=0.096)
   25% nat        -0.6 (p=0.734)        -0.4 (p=0.620)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -11.7  95% CI [-14.7, -8.6]  p=0.000
   MRR  :  -9.9  95% CI [-11.6, -8.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (52%)
   Hit@1:  +4.2  p=0.001
   MRR  :  +0.4  p=0.603

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.2/+0.6 (p=0.488)  40%: +2.6/+1.8 (p=0.032)  50%: +2.6/+1.8 (p=0.027)  nat: +0.6/+0.7 (p=0.322)
   vs NQC-like spread      30%: +0.3/+0.4 (p=0.615)  40%: +2.8/+2.0 (p=0.019)  50%: +2.3/+1.7 (p=0.033)  nat: +0.2/+0.1 (p=0.925)
   vs WIG-like             30%: +0.9/+0.4 (p=0.646)  40%: +3.2/+1.8 (p=0.035)  50%: +2.6/+1.4 (p=0.082)  nat: +1.1/+0.3 (p=0.734)
   vs term coverage top1   30%: +1.2/+0.8 (p=0.279)  40%: +2.5/+1.5 (p=0.049)  50%: +1.4/+0.8 (p=0.320)  nat: +1.5/+0.9 (p=0.189)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -9.9  [-11.6, -8.2]  p=0.000
   BM25 margin           -9.5  [-11.2, -7.9]  p=0.000
   top5 vs rest         -10.6  [-12.4, -8.8]  p=0.000
   NQC-like spread      -10.0  [-11.7, -8.3]  p=0.000
   WIG-like             -10.1  [-11.8, -8.5]  p=0.000
   term coverage top1   -10.8  [-12.6, -9.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              25.6    27.3    29.1    31.5    32.6    33.7    34.6    35.8    37.4    38.1*   100%
   BM25 margin            25.5    27.8    29.7    30.3    31.7    32.8    34.1    35.9    37.1    38.1*   100%
   top5 vs rest           25.3    26.8    28.5    29.7    30.8    32.1    33.6    35.5    36.6    38.1*   100%
   NQC-like spread        25.5    27.6    28.7    29.6    30.9    32.3    33.9    35.1    36.9    38.1*   100%
   WIG-like               24.9    26.9    28.7    29.8    31.2    32.9    34.2    35.7    37.0    38.1*   100%
   term coverage top1     25.1    26.8    28.3    30.0    31.8    33.1    34.9    35.8    37.2    38.1*   100%
   ORACLE                 30.5    34.7    37.7*   39.5*   39.9*   39.9*   39.9*   39.9*   39.9*   38.1*   30%
   random (expected)      25.1    26.6    28.0    29.5    30.9    32.4    33.8    35.2    36.7    38.1*   100%
   (BM25 only 23.7; rerank ALL 38.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.5[-14.3]  -10.8[-12.6]   -9.0[-10.6]   -6.6[ -7.9]   -5.5[ -6.8]   -4.4[ -5.6]   -3.5[ -4.6]   -2.3[ -3.2]   -0.7[ -1.2]    100%   (point estimate: 90%)
   BM25 margin          -12.6[-14.5]  -10.3[-11.9]   -8.4[ -9.9]   -7.8[ -9.4]   -6.4[ -7.8]   -5.4[ -6.7]   -4.0[ -5.1]   -2.3[ -3.2]   -1.1[ -1.6]    100%   (point estimate: 100%)
   top5 vs rest         -12.8[-14.7]  -11.3[-13.1]   -9.6[-11.3]   -8.4[-10.1]   -7.4[ -8.9]   -6.0[ -7.5]   -4.5[ -5.7]   -2.6[ -3.7]   -1.5[ -2.3]    100%   (point estimate: 100%)
   NQC-like spread      -12.6[-14.6]  -10.6[-12.3]   -9.4[-11.1]   -8.6[-10.2]   -7.2[ -8.8]   -5.8[ -7.2]   -4.3[ -5.5]   -3.1[ -4.2]   -1.2[ -2.0]    100%   (point estimate: 100%)
   WIG-like             -13.2[-15.1]  -11.2[-13.0]   -9.4[-11.1]   -8.4[-10.0]   -6.9[ -8.5]   -5.3[ -6.7]   -4.0[ -5.2]   -2.4[ -3.4]   -1.2[ -1.8]    100%   (point estimate: 100%)
   term coverage top1   -13.0[-14.9]  -11.4[-13.1]   -9.8[-11.4]   -8.1[ -9.6]   -6.3[ -7.8]   -5.0[ -6.3]   -3.3[ -4.4]   -2.3[ -3.2]   -0.9[ -1.6]    100%   (point estimate: 90%)
   ORACLE                -7.6[ -8.9]   -3.4[ -4.4]   -0.5[ -1.2]   +1.3[ +0.8]#  +1.7[ +1.2]#  +1.7[ +1.2]#  +1.7[ +1.2]#  +1.7[ +1.2]#  +1.7[ +1.2]#   40%   (point estimate: 30%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.5[-14.3]  -10.8[-12.6]   -9.0[-10.6]   -6.6[ -7.9]   -5.5[ -6.8]   -4.4[ -5.6]   -3.5[ -4.6]   -2.3[ -3.2]   -0.7[ -1.2]    100%   (point estimate: 100%)
   BM25 margin          -12.6[-14.5]  -10.3[-11.9]   -8.4[ -9.9]   -7.8[ -9.4]   -6.4[ -7.8]   -5.4[ -6.7]   -4.0[ -5.1]   -2.3[ -3.2]   -1.1[ -1.6]    100%   (point estimate: 100%)
   top5 vs rest         -12.8[-14.7]  -11.3[-13.1]   -9.6[-11.3]   -8.4[-10.1]   -7.4[ -8.9]   -6.0[ -7.5]   -4.5[ -5.7]   -2.6[ -3.7]   -1.5[ -2.3]    100%   (point estimate: 100%)
   NQC-like spread      -12.6[-14.6]  -10.6[-12.3]   -9.4[-11.1]   -8.6[-10.2]   -7.2[ -8.8]   -5.8[ -7.2]   -4.3[ -5.5]   -3.1[ -4.2]   -1.2[ -2.0]    100%   (point estimate: 100%)
   WIG-like             -13.2[-15.1]  -11.2[-13.0]   -9.4[-11.1]   -8.4[-10.0]   -6.9[ -8.5]   -5.3[ -6.7]   -4.0[ -5.2]   -2.4[ -3.4]   -1.2[ -1.8]    100%   (point estimate: 100%)
   term coverage top1   -13.0[-14.9]  -11.4[-13.1]   -9.8[-11.4]   -8.1[ -9.6]   -6.3[ -7.8]   -5.0[ -6.3]   -3.3[ -4.4]   -2.3[ -3.2]   -0.9[ -1.6]    100%   (point estimate: 100%)
   ORACLE                -7.6[ -8.9]   -3.4[ -4.4]   -0.5[ -1.2]   +1.3[ +0.8]#  +1.7[ +1.2]#  +1.7[ +1.2]#  +1.7[ +1.2]#  +1.7[ +1.2]#  +1.7[ +1.2]#   40%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      91% (sd  11)   -0.91 MRR              19%      9%
   tag alarm               100      93% (sd   6)   -0.64 MRR               8%      7%
   tag alarm               200      93% (sd   5)   -0.59 MRR              12%      7%
   BM25 margin              50      93% (sd   8)   -0.79 MRR              46%      7%
   BM25 margin             100      95% (sd   6)   -0.60 MRR              40%      5%
   BM25 margin             200      95% (sd   5)   -0.56 MRR              42%      5%
   top5 vs rest             50      94% (sd   8)   -0.87 MRR              41%      6%
   top5 vs rest            100      96% (sd   6)   -0.66 MRR              34%      4%
   top5 vs rest            200      97% (sd   5)   -0.50 MRR              28%      3%
   NQC-like spread          50      94% (sd   8)   -0.85 MRR              50%      6%
   NQC-like spread         100      95% (sd   6)   -0.61 MRR              42%      5%
   NQC-like spread         200      96% (sd   5)   -0.57 MRR              42%      4%
   WIG-like                 50      93% (sd  10)   -0.93 MRR              46%      7%
   WIG-like                100      95% (sd   7)   -0.68 MRR              42%      5%
   WIG-like                200      96% (sd   5)   -0.51 MRR              34%      4%
   term coverage top1       50      92% (sd  10)   -0.87 MRR              32%      8%
   term coverage top1      100      95% (sd   7)   -0.60 MRR              35%      5%
   term coverage top1      200      95% (sd   5)   -0.53 MRR              36%      5%

## beir_arguana  (1401 questions; tag alarm fires on 9 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.2  diff  -0.0  p=0.8441
   MRR  : tag  32.3  random  32.3  diff  -0.0  p=0.5974

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.1 (p=0.361)
   40%            -0.1 (p=1.000)        -0.1 (p=0.120)
   50%            +0.0 (p=1.000)        -0.0 (p=0.248)
   1% nat         +0.0 (p=1.000)        +0.1 (p=0.342)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -18.6  95% CI [-20.7, -16.6]  p=0.000
   MRR  : -21.9  95% CI [-23.4, -20.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (17%)
   Hit@1:  +5.6  p=0.000
   MRR  :  +0.3  p=0.555

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.5/+0.4 (p=0.588)  40%: +1.2/+0.4 (p=0.678)  50%: +0.9/+0.1 (p=0.929)  nat: -0.1/-0.1 (p=0.356)
   vs NQC-like spread      30%: +0.6/+0.2 (p=0.786)  40%: +0.7/+0.1 (p=0.910)  50%: +0.6/-0.2 (p=0.737)  nat: +0.0/+0.1 (p=0.388)
   vs WIG-like             30%: +1.5/+0.3 (p=0.679)  40%: +1.6/+0.4 (p=0.608)  50%: +1.6/+0.3 (p=0.730)  nat: +0.0/+0.1 (p=0.140)
   vs term coverage top1   30%: +1.1/+0.3 (p=0.611)  40%: +1.9/+0.3 (p=0.628)  50%: +1.2/-0.1 (p=0.939)  nat: +0.1/+0.0 (p=0.561)

G. each selector reranking 9 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -21.9  [-23.4, -20.3]  p=0.000
   BM25 margin          -21.9  [-23.5, -20.4]  p=0.000
   top5 vs rest         -21.8  [-23.3, -20.2]  p=0.000
   NQC-like spread      -21.9  [-23.5, -20.4]  p=0.000
   WIG-like             -22.0  [-23.5, -20.4]  p=0.000
   term coverage top1   -21.9  [-23.5, -20.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              34.3    36.9    39.3    41.3    43.2    45.2    47.2    49.4    51.9    54.1*   100%
   BM25 margin            34.3    37.0    39.4    41.4    43.3    45.2    47.2    49.4    51.9    54.1*   100%
   top5 vs rest           34.5    37.0    38.9    41.0    43.1    45.1    47.0    49.1    51.6    54.1*   100%
   NQC-like spread        34.1    36.7    39.2    41.3    43.4    45.9    48.0    50.0    52.0    54.1*   100%
   WIG-like               34.6    36.8    39.0    40.9    42.9    45.0    46.8    49.1    51.7    54.1*   100%
   term coverage top1     34.3    36.9    39.0    41.0    43.3    45.7    47.6    50.3    52.1    54.1*   100%
   ORACLE                 39.7    45.4    49.7    53.0    55.4*   56.7*   56.8*   56.8*   56.5*   54.1*   50%
   random (expected)      34.3    36.5    38.7    40.9    43.1    45.3    47.5    49.7    51.9    54.1*   100%
   (BM25 only 32.1; rerank ALL 54.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -19.8[-21.4]  -17.2[-18.7]  -14.8[-16.3]  -12.8[-14.2]  -10.9[-12.2]   -8.9[-10.2]   -6.9[ -8.0]   -4.7[ -5.6]   -2.2[ -2.9]    100%   (point estimate: 100%)
   BM25 margin          -19.8[-21.4]  -17.1[-18.6]  -14.7[-16.2]  -12.7[-14.1]  -10.9[-12.2]   -8.9[-10.1]   -6.9[ -8.0]   -4.7[ -5.6]   -2.2[ -2.9]    100%   (point estimate: 100%)
   top5 vs rest         -19.6[-21.1]  -17.1[-18.5]  -15.2[-16.6]  -13.2[-14.5]  -11.0[-12.2]   -9.0[-10.1]   -7.1[ -8.2]   -5.0[ -5.9]   -2.6[ -3.2]    100%   (point estimate: 100%)
   NQC-like spread      -20.0[-21.5]  -17.5[-18.9]  -15.0[-16.4]  -12.9[-14.2]  -10.7[-12.0]   -8.2[ -9.3]   -6.1[ -7.0]   -4.1[ -4.8]   -2.1[ -2.7]    100%   (point estimate: 100%)
   WIG-like             -19.5[-21.1]  -17.3[-18.9]  -15.1[-16.5]  -13.2[-14.5]  -11.2[-12.4]   -9.2[-10.4]   -7.4[ -8.4]   -5.0[ -6.0]   -2.5[ -3.1]    100%   (point estimate: 100%)
   term coverage top1   -19.9[-21.4]  -17.2[-18.7]  -15.1[-16.6]  -13.1[-14.4]  -10.9[-12.1]   -8.4[ -9.6]   -6.5[ -7.5]   -3.9[ -4.7]   -2.0[ -2.6]    100%   (point estimate: 100%)
   ORACLE               -14.4[-15.7]   -8.7[ -9.8]   -4.5[ -5.3]   -1.1[ -1.8]   +1.3[ +0.8]#  +2.5[ +2.1]#  +2.7[ +2.3]#  +2.7[ +2.3]#  +2.4[ +2.0]#   50%   (point estimate: 50%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -19.8[-21.4]  -17.2[-18.7]  -14.8[-16.3]  -12.8[-14.2]  -10.9[-12.2]   -8.9[-10.2]   -6.9[ -8.0]   -4.7[ -5.6]   -2.2[ -2.9]    100%   (point estimate: 100%)
   BM25 margin          -19.8[-21.4]  -17.1[-18.6]  -14.7[-16.2]  -12.7[-14.1]  -10.9[-12.2]   -8.9[-10.1]   -6.9[ -8.0]   -4.7[ -5.6]   -2.2[ -2.9]    100%   (point estimate: 100%)
   top5 vs rest         -19.6[-21.1]  -17.1[-18.5]  -15.2[-16.6]  -13.2[-14.5]  -11.0[-12.2]   -9.0[-10.1]   -7.1[ -8.2]   -5.0[ -5.9]   -2.6[ -3.2]    100%   (point estimate: 100%)
   NQC-like spread      -20.0[-21.5]  -17.5[-18.9]  -15.0[-16.4]  -12.9[-14.2]  -10.7[-12.0]   -8.2[ -9.3]   -6.1[ -7.0]   -4.1[ -4.8]   -2.1[ -2.7]    100%   (point estimate: 100%)
   WIG-like             -19.5[-21.1]  -17.3[-18.9]  -15.1[-16.5]  -13.2[-14.5]  -11.2[-12.4]   -9.2[-10.4]   -7.4[ -8.4]   -5.0[ -6.0]   -2.5[ -3.1]    100%   (point estimate: 100%)
   term coverage top1   -19.9[-21.4]  -17.2[-18.7]  -15.1[-16.6]  -13.1[-14.4]  -10.9[-12.1]   -8.4[ -9.6]   -6.5[ -7.5]   -3.9[ -4.7]   -2.0[ -2.6]    100%   (point estimate: 100%)
   ORACLE               -14.4[-15.7]   -8.7[ -9.8]   -4.5[ -5.3]   -1.1[ -1.8]   +1.3[ +0.8]#  +2.5[ +2.1]#  +2.7[ +2.3]#  +2.7[ +2.3]#  +2.4[ +2.0]#   50%   (point estimate: 50%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      98% (sd   5)   -0.44 MRR              16%      2%
   tag alarm               100      99% (sd   3)   -0.26 MRR              11%      1%
   tag alarm               200      99% (sd   2)   -0.14 MRR               6%      1%
   BM25 margin              50      98% (sd   4)   -0.39 MRR              16%      2%
   BM25 margin             100      99% (sd   3)   -0.19 MRR               8%      1%
   BM25 margin             200     100% (sd   1)   -0.05 MRR               2%      0%
   top5 vs rest             50      99% (sd   4)   -0.38 MRR              12%      1%
   top5 vs rest            100     100% (sd   1)   -0.03 MRR               1%      0%
   top5 vs rest            200     100% (sd   0)   +0.00 MRR               0%      0%
   NQC-like spread          50      98% (sd   4)   -0.36 MRR              16%      2%
   NQC-like spread         100      99% (sd   3)   -0.22 MRR              10%      1%
   NQC-like spread         200     100% (sd   1)   -0.02 MRR               1%      0%
   WIG-like                 50      99% (sd   4)   -0.32 MRR              10%      1%
   WIG-like                100     100% (sd   1)   -0.05 MRR               2%      0%
   WIG-like                200     100% (sd   0)   +0.00 MRR               0%      0%
   term coverage top1       50      99% (sd   4)   -0.31 MRR              14%      1%
   term coverage top1      100      99% (sd   4)   -0.30 MRR              13%      1%
   term coverage top1      200     100% (sd   2)   -0.10 MRR               4%      0%

## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.3  random  18.9  diff  +0.4  p=0.1462
   MRR  : tag  15.5  random  15.5  diff  -0.0  p=0.5195

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=0.677)        -0.2 (p=0.171)
   40%            +0.1 (p=1.000)        -0.0 (p=0.777)
   50%            +0.2 (p=0.803)        +0.1 (p=0.671)
   12% nat        +0.0 (p=1.000)        +0.2 (p=0.179)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.7  95% CI [-2.9, +1.5]  p=0.583
   MRR  :  -1.6  95% CI [-2.4, -0.9]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +0.9  p=0.301
   MRR  :  +0.4  p=0.138

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.2/-0.1 (p=0.752)  40%: +1.2/+0.1 (p=0.762)  50%: +1.1/-0.3 (p=0.382)  nat: +0.5/+0.0 (p=0.818)
   vs NQC-like spread      30%: +0.9/-0.1 (p=0.632)  40%: +0.8/-0.1 (p=0.775)  50%: +0.6/-0.1 (p=0.662)  nat: +0.9/+0.2 (p=0.298)
   vs WIG-like             30%: +0.4/-0.4 (p=0.103)  40%: +0.1/-0.4 (p=0.142)  50%: +0.1/-0.3 (p=0.296)  nat: -0.1/-0.3 (p=0.160)
   vs term coverage top1   30%: +0.2/-0.6 (p=0.022)  40%: +0.3/-0.5 (p=0.063)  50%: -0.1/-0.4 (p=0.125)  nat: -0.3/-0.3 (p=0.156)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -1.6  [-2.4, -0.9]  p=0.000
   BM25 margin           -1.9  [-2.6, -1.2]  p=0.000
   top5 vs rest          -1.7  [-2.4, -1.0]  p=0.000
   NQC-like spread       -1.8  [-2.6, -1.1]  p=0.000
   WIG-like              -1.4  [-2.1, -0.7]  p=0.000
   term coverage top1    -1.4  [-2.1, -0.7]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              15.5    15.4    15.6    15.9    16.2    16.4    16.6    16.7    16.8    17.1*   100%
   BM25 margin            15.2    15.5    15.8    16.0    16.1    16.3    16.6    16.6    16.9    17.1*   100%
   top5 vs rest           15.4    15.7    15.7    15.8    16.4    16.7*   16.9*   17.1*   17.1*   17.1*   60%
   NQC-like spread        15.3    15.4    15.7    16.0    16.3    16.6    16.7    16.9*   17.2*   17.1*   80%
   WIG-like               15.7    15.9    16.0    16.3    16.5    16.9*   17.0*   17.0*   17.1*   17.1*   60%
   term coverage top1     15.8    16.0    16.2    16.4    16.6    16.7    16.9*   17.2*   17.1*   17.1*   70%
   ORACLE                 17.9*   19.2*   19.8*   19.8*   19.8*   19.8*   19.8*   19.8*   19.1*   17.1*   10%
   random (expected)      15.5    15.6    15.8    16.0    16.2    16.4    16.6    16.8    16.9    17.1*   100%
   (BM25 only 15.3; rerank ALL 17.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.6[ -2.3]   -1.7[ -2.4]   -1.5[ -2.2]   -1.2[ -1.8]   -0.9[ -1.5]   -0.7[ -1.2]   -0.6[ -1.0]#  -0.4[ -0.8]#  -0.3[ -0.6]#   70%   (point estimate: 50%)
   BM25 margin           -1.9[ -2.6]   -1.7[ -2.4]   -1.3[ -1.9]   -1.2[ -1.8]   -1.0[ -1.6]   -0.9[ -1.3]   -0.5[ -1.0]#  -0.5[ -0.8]#  -0.2[ -0.5]#   70%   (point estimate: 50%)
   top5 vs rest          -1.7[ -2.5]   -1.4[ -2.1]   -1.4[ -2.1]   -1.3[ -1.9]   -0.7[ -1.2]   -0.5[ -1.0]#  -0.3[ -0.7]#  -0.0[ -0.4]#  -0.0[ -0.4]#   60%   (point estimate: 50%)
   NQC-like spread       -1.8[ -2.5]   -1.7[ -2.4]   -1.4[ -2.0]   -1.1[ -1.7]   -0.8[ -1.3]   -0.6[ -1.0]   -0.4[ -0.9]#  -0.2[ -0.6]#  +0.1[ -0.2]#   70%   (point estimate: 50%)
   WIG-like              -1.4[ -2.2]   -1.2[ -1.9]   -1.1[ -1.8]   -0.8[ -1.4]   -0.6[ -1.2]   -0.3[ -0.8]#  -0.1[ -0.6]#  -0.1[ -0.5]#  -0.0[ -0.3]#   60%   (point estimate: 40%)
   term coverage top1    -1.4[ -2.1]   -1.1[ -1.7]   -1.0[ -1.6]   -0.7[ -1.3]   -0.5[ -1.0]   -0.4[ -0.9]#  -0.3[ -0.6]#  +0.1[ -0.2]#  +0.0[ -0.1]#   60%   (point estimate: 30%)
   ORACLE                +0.7[ +0.2]#  +2.1[ +1.6]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.0[ +1.6]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.6[ -2.3]   -1.7[ -2.4]   -1.5[ -2.2]   -1.2[ -1.8]   -0.9[ -1.5]   -0.7[ -1.2]   -0.6[ -1.0]   -0.4[ -0.8]   -0.3[ -0.6]    100%   (point estimate: 80%)
   BM25 margin           -1.9[ -2.6]   -1.7[ -2.4]   -1.3[ -1.9]   -1.2[ -1.8]   -1.0[ -1.6]   -0.9[ -1.3]   -0.5[ -1.0]   -0.5[ -0.8]   -0.2[ -0.5]#   90%   (point estimate: 80%)
   top5 vs rest          -1.7[ -2.5]   -1.4[ -2.1]   -1.4[ -2.1]   -1.3[ -1.9]   -0.7[ -1.2]   -0.5[ -1.0]   -0.3[ -0.7]   -0.0[ -0.4]#  -0.0[ -0.4]#   80%   (point estimate: 60%)
   NQC-like spread       -1.8[ -2.5]   -1.7[ -2.4]   -1.4[ -2.0]   -1.1[ -1.7]   -0.8[ -1.3]   -0.6[ -1.0]   -0.4[ -0.9]   -0.2[ -0.6]   +0.1[ -0.2]#   90%   (point estimate: 70%)
   WIG-like              -1.4[ -2.2]   -1.2[ -1.9]   -1.1[ -1.8]   -0.8[ -1.4]   -0.6[ -1.2]   -0.3[ -0.8]   -0.1[ -0.6]   -0.1[ -0.5]#  -0.0[ -0.3]#   80%   (point estimate: 60%)
   term coverage top1    -1.4[ -2.1]   -1.1[ -1.7]   -1.0[ -1.6]   -0.7[ -1.3]   -0.5[ -1.0]   -0.4[ -0.9]   -0.3[ -0.6]   +0.1[ -0.2]#  +0.0[ -0.1]#   80%   (point estimate: 60%)
   ORACLE                +0.7[ +0.2]#  +2.1[ +1.6]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.7[ +2.2]#  +2.0[ +1.6]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      58% (sd  32)   -0.83 MRR              32%     42%
   tag alarm               100      59% (sd  28)   -0.83 MRR              29%     41%
   tag alarm               200      54% (sd  24)   -0.94 MRR              35%     46%
   BM25 margin              50      55% (sd  31)   -0.93 MRR              38%     45%
   BM25 margin             100      51% (sd  26)   -1.03 MRR              38%     49%
   BM25 margin             200      52% (sd  21)   -0.99 MRR              38%     48%
   top5 vs rest             50      49% (sd  30)   -0.88 MRR              44%     51%
   top5 vs rest            100      48% (sd  26)   -0.86 MRR              39%     52%
   top5 vs rest            200      46% (sd  21)   -0.92 MRR              38%     54%
   NQC-like spread          50      50% (sd  30)   -0.91 MRR              45%     50%
   NQC-like spread         100      51% (sd  26)   -0.88 MRR              38%     49%
   NQC-like spread         200      50% (sd  21)   -0.90 MRR              37%     50%
   WIG-like                 50      45% (sd  31)   -0.77 MRR              42%     55%
   WIG-like                100      41% (sd  27)   -0.84 MRR              44%     59%
   WIG-like                200      37% (sd  22)   -0.91 MRR              45%     63%
   term coverage top1       50      44% (sd  28)   -0.71 MRR              36%     56%
   term coverage top1      100      36% (sd  24)   -0.87 MRR              45%     64%
   term coverage top1      200      33% (sd  20)   -0.92 MRR              41%     67%

## POOLED over 5 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  18.8  random  18.3  diff  +0.4  p=0.0172
   MRR  : tag  29.7  random  29.6  diff  +0.2  p=0.0470

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  -0.3 (p=0.373)   MRR  -0.2 (p=0.119)
   40%      Hit@1  +0.3 (p=0.296)   MRR  +0.1 (p=0.607)
   50%      Hit@1  +0.4 (p=0.114)   MRR  +0.1 (p=0.217)
   natural  Hit@1  -0.3 (p=0.376)   MRR  -0.1 (p=0.583)

C. tag alarm vs rerank ALL (pooled)
   Hit@1: -10.0  95% CI [-11.2, -8.8]  p=0.000
   MRR  : -11.2  95% CI [-12.0, -10.4]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +3.1  p=0.000
   MRR  :  +0.2  p=0.453

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.3/+0.4 (p=0.238)  40%: +1.7/+0.7 (p=0.060)  50%: +1.6/+0.5 (p=0.183)  nat: +0.3/+0.1 (p=0.428)
   vs NQC-like spread      30%: +0.8/+0.1 (p=0.735)  40%: +1.2/+0.4 (p=0.220)  50%: +1.1/+0.3 (p=0.403)  nat: +0.1/-0.0 (p=0.765)
   vs WIG-like             30%: +1.0/+0.1 (p=0.730)  40%: +1.4/+0.4 (p=0.275)  50%: +1.3/+0.4 (p=0.275)  nat: +0.1/-0.0 (p=0.887)
   vs term coverage top1   30%: +0.7/+0.1 (p=0.739)  40%: +1.3/+0.3 (p=0.331)  50%: +0.7/+0.1 (p=0.710)  nat: +0.2/+0.1 (p=0.719)
