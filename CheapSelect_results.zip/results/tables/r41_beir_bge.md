# router41: label-free signals vs pre-retrieval vs trained routers  (deltas [1.0, 0.5] MRR points)

## beir_scifact (tag bge; n=300; mean gain +7.5 MRR; helped 23% hurt 10%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.00   rho(gain) -0.00
   avgIDF   rho(quality) +0.11   rho(gain) -0.09
   maxIDF   rho(quality) +0.10   rho(gain) -0.07
   avgICTF  rho(quality) +0.06   rho(gain) -0.08
   avgSCQ   rho(quality) +0.04   rho(gain) -0.04
   maxSCQ   rho(quality) +0.10   rho(gain) -0.06
   SCS      rho(quality) +0.03   rho(gain) -0.06

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               60/50          70/60           +40             -0.7     +2.1 (0.054)
   tag alarm                                 70/50          70/60           +40             -0.5     +2.2 (0.053)
   top5 vs rest                             100/100        100/100          -10             -3.9     -1.1 (0.244)
   NQC-like spread                           90/70         100/80           +20             -2.6     +0.2 (0.822)
   WIG-like                                  90/90         100/90            +0             -2.7          -
   term coverage top1                       100/90         100/90            +0             -2.8     -0.1 (0.891)
   pre:qlen                                 100/90         100/100           +0             -4.4     -1.7 (0.186)
   pre:avgIDF                               100/90         100/100           +0             -2.8     -0.1 (0.941)
   pre:maxIDF                               100/80         100/100          +10             -2.0     +0.7 (0.618)
   pre:avgICTF                              100/100        100/100          -10             -2.8     -0.1 (0.942)
   pre:avgSCQ                               100/90         100/100           +0             -4.3     -1.6 (0.032)
   pre:maxSCQ                               100/90         100/100           +0             -3.1     -0.3 (0.711)
   pre:SCS                                  100/100        100/100          -10             -3.1     -0.4 (0.759)
   router ridge S (5-fold CV)                70/60          80/60           +30             -1.3     +1.5 (0.142)
   router gbm S (5-fold CV)                 100/100        100/100          -10             -2.8     -0.1 (0.933)
   router ridge S+P (5-fold CV)              90/60         100/70           +30             -1.7     +1.0 (0.325)
   router gbm S+P (5-fold CV)               100/90         100/100           +0             -3.5     -0.8 (0.497)
   router ridge S (other collections)        90/60         100/80           +30             -1.8     +0.9 (0.357)
   router gbm S (other collections)         100/90         100/100           +0             -3.9     -1.2 (0.221)
   router ridge S+P (other collections)      90/80          90/90           +10             -2.5     +0.2 (0.864)
   router gbm S+P (other collections)       100/100        100/100          -10             -3.3     -0.6 (0.634)
   ORACLE                                    20/10          20/10           +80             +3.0     +5.7 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.292, tag alarm +0.025, top5 vs rest -0.067, NQC-like spread -0.001, WIG-like -0.057, term coverage top1 +0.071
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.281, tag alarm +0.033, top5 vs rest -0.089, NQC-like spread -0.027, WIG-like -0.040, term coverage top1 +0.050, qlen +0.033, avgIDF -0.002, maxIDF -0.152, avgICTF +0.045, avgSCQ -0.018, maxSCQ +0.007, SCS +0.070

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -4.1   -2.8   -2.0
   n=  50  router ridge S+P        -4.0   -2.3   -1.2   P(router > WIG-like @50%) = 72%
   n=  50  router gbm   S+P        -4.3   -2.6   -1.3   P(router > WIG-like @50%) = 56%
   n= 100  WIG-like                 -4.1   -2.8   -2.0
   n= 100  router ridge S+P        -3.7   -1.8   -0.7   P(router > WIG-like @50%) = 85%
   n= 100  router gbm   S+P        -4.1   -2.7   -1.6   P(router > WIG-like @50%) = 59%
   n= 200  WIG-like                 -4.0   -2.7   -1.9
   n= 200  router ridge S+P        -3.3   -1.7   -0.4   P(router > WIG-like @50%) = 74%
   n= 200  router gbm   S+P        -3.8   -2.7   -2.0   P(router > WIG-like @50%) = 51%

## beir_nfcorpus (tag bge; n=323; mean gain +1.7 MRR; helped 22% hurt 16%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.02   rho(gain) -0.15
   avgIDF   rho(quality) -0.19   rho(gain) -0.09
   maxIDF   rho(quality) -0.33   rho(gain) -0.01
   avgICTF  rho(quality) -0.25   rho(gain) -0.07
   avgSCQ   rho(quality) +0.51   rho(gain) -0.00
   maxSCQ   rho(quality) +0.36   rho(gain) +0.06
   SCS      rho(quality) -0.21   rho(gain) -0.10

Budgets (share of questions reranked). random expected point budget: delta 1.0: 50%, delta 0.5: 80%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/30         100/40           +20             +0.5     +0.7 (0.554)
   tag alarm                                 90/30         100/40           +20             -0.0     +0.2 (0.871)
   top5 vs rest                              80/60          90/60           -10             -1.3     -1.1 (0.177)
   NQC-like spread                           70/20         100/40           +30             -0.3     -0.1 (0.875)
   WIG-like                                  90/30         100/40           +20             -0.2          -
   term coverage top1                       100/20         100/30           +30             +1.4     +1.6 (0.074)
   pre:qlen                                  90/10         100/20           +40             +1.2     +1.4 (0.189)
   pre:avgIDF                                90/30          90/40           +20             +0.3     +0.5 (0.692)
   pre:maxIDF                               100/80         100/100          -30             -0.4     -0.2 (0.897)
   pre:avgICTF                               80/30         100/50           +20             +0.0     +0.2 (0.854)
   pre:avgSCQ                                80/70          90/80           -20             -1.2     -1.0 (0.175)
   pre:maxSCQ                               100/60         100/100          -10             -2.3     -2.1 (0.017)
   pre:SCS                                   60/30         100/30           +20             +0.4     +0.6 (0.635)
   router ridge S (5-fold CV)               100/30         100/90           +20             +1.0     +1.2 (0.189)
   router gbm S (5-fold CV)                 100/30         100/80           +20             -0.4     -0.2 (0.884)
   router ridge S+P (5-fold CV)              90/10          90/30           +40             +0.9     +1.1 (0.227)
   router gbm S+P (5-fold CV)               100/70         100/80           -20             -1.4     -1.2 (0.286)
   router ridge S (other collections)        60/30          90/30           +20             +0.8     +1.0 (0.285)
   router gbm S (other collections)          70/20          70/20           +30             +1.0     +1.2 (0.370)
   router ridge S+P (other collections)      70/20          80/30           +30             +0.2     +0.4 (0.701)
   router gbm S+P (other collections)        80/30         100/60           +20             -0.9     -0.7 (0.643)
   ORACLE                                    10/10          10/10           +40             +6.7     +6.9 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.015, tag alarm -0.287, top5 vs rest +0.029, NQC-like spread -0.010, WIG-like +0.009, term coverage top1 -0.141
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.117, tag alarm -0.346, top5 vs rest -0.015, NQC-like spread +0.081, WIG-like -0.144, term coverage top1 -0.027, qlen +0.208, avgIDF -0.088, maxIDF +0.025, avgICTF +0.146, avgSCQ +0.134, maxSCQ +0.033, SCS -0.032

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -0.6   -0.2   +0.1
   n=  50  router ridge S+P        -0.5   -0.1   +0.2   P(router > WIG-like @50%) = 66%
   n=  50  router gbm   S+P        -0.7   -0.3   -0.1   P(router > WIG-like @50%) = 52%
   n= 100  WIG-like                 -0.6   -0.2   +0.2
   n= 100  router ridge S+P        -0.3   +0.0   +0.3   P(router > WIG-like @50%) = 62%
   n= 100  router gbm   S+P        -0.7   -0.5   -0.4   P(router > WIG-like @50%) = 41%
   n= 200  WIG-like                 -0.6   -0.3   +0.1
   n= 200  router ridge S+P        +0.1   +0.5   +0.5   P(router > WIG-like @50%) = 70%
   n= 200  router gbm   S+P        -0.5   -0.5   -0.4   P(router > WIG-like @50%) = 48%

## beir_fiqa (tag bge; n=648; mean gain +17.7 MRR; helped 42% hurt 8%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.09   rho(gain) -0.02
   avgIDF   rho(quality) +0.04   rho(gain) -0.03
   maxIDF   rho(quality) +0.03   rho(gain) -0.08
   avgICTF  rho(quality) +0.04   rho(gain) -0.04
   avgSCQ   rho(quality) +0.07   rho(gain) -0.01
   maxSCQ   rho(quality) +0.12   rho(gain) +0.01
   SCS      rho(quality) -0.00   rho(gain) -0.05

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/90         100/100          +10             -7.4     +0.8 (0.422)
   tag alarm                                100/90         100/100          +10             -6.1     +2.2 (0.047)
   top5 vs rest                             100/100        100/100           +0             -8.0     +0.3 (0.764)
   NQC-like spread                          100/100        100/100           +0             -7.9     +0.4 (0.583)
   WIG-like                                 100/100        100/100           +0             -8.3          -
   term coverage top1                       100/100        100/100           +0             -7.6     +0.7 (0.475)
   pre:qlen                                 100/90         100/100          +10             -8.1     +0.2 (0.821)
   pre:avgIDF                               100/100        100/100           +0             -8.8     -0.5 (0.599)
   pre:maxIDF                               100/100        100/100           +0             -7.7     +0.6 (0.565)
   pre:avgICTF                              100/100        100/100           +0             -8.8     -0.5 (0.578)
   pre:avgSCQ                               100/100        100/100           +0             -9.1     -0.8 (0.366)
   pre:maxSCQ                               100/100        100/100           +0             -8.7     -0.4 (0.699)
   pre:SCS                                  100/100        100/100           +0             -8.5     -0.2 (0.840)
   router ridge S (5-fold CV)               100/100        100/100           +0             -7.2     +1.1 (0.212)
   router gbm S (5-fold CV)                 100/100        100/100           +0             -8.7     -0.4 (0.691)
   router ridge S+P (5-fold CV)             100/90         100/100          +10             -8.4     -0.1 (0.942)
   router gbm S+P (5-fold CV)               100/100        100/100           +0             -8.3     +0.0 (0.998)
   router ridge S (other collections)       100/90         100/100          +10             -7.7     +0.6 (0.565)
   router gbm S (other collections)         100/100        100/100           +0             -7.2     +1.1 (0.258)
   router ridge S+P (other collections)     100/100        100/100           +0             -6.6     +1.7 (0.098)
   router gbm S+P (other collections)       100/100        100/100           +0             -7.7     +0.6 (0.482)
   ORACLE                                    30/30          30/30           +70             +2.5    +10.8 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.133, tag alarm +0.111, top5 vs rest -0.098, NQC-like spread -0.025, WIG-like +0.053, term coverage top1 -0.069
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.126, tag alarm +0.116, top5 vs rest -0.109, NQC-like spread -0.006, WIG-like +0.036, term coverage top1 -0.084, qlen -0.114, avgIDF +0.127, maxIDF -0.105, avgICTF +0.118, avgSCQ -0.038, maxSCQ +0.061, SCS -0.232

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                -11.5   -8.3   -4.9
   n=  50  router ridge S+P       -11.8   -8.2   -4.7   P(router > WIG-like @50%) = 59%
   n=  50  router gbm   S+P       -12.1   -8.5   -4.9   P(router > WIG-like @50%) = 45%
   n= 100  WIG-like                -11.5   -8.3   -4.8
   n= 100  router ridge S+P       -11.7   -8.0   -4.5   P(router > WIG-like @50%) = 67%
   n= 100  router gbm   S+P       -11.8   -8.1   -4.7   P(router > WIG-like @50%) = 62%
   n= 200  WIG-like                -11.5   -8.3   -4.8
   n= 200  router ridge S+P       -11.4   -7.8   -4.3   P(router > WIG-like @50%) = 72%
   n= 200  router gbm   S+P       -11.8   -8.1   -4.8   P(router > WIG-like @50%) = 57%

## beir_arguana (tag bge; n=1401; mean gain +22.0 MRR; helped 66% hurt 15%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.01   rho(gain) +0.01
   avgIDF   rho(quality) +0.08   rho(gain) +0.02
   maxIDF   rho(quality) -0.02   rho(gain) +0.02
   avgICTF  rho(quality) +0.07   rho(gain) +0.01
   avgSCQ   rho(quality) +0.05   rho(gain) -0.00
   maxSCQ   rho(quality) +0.06   rho(gain) +0.08
   SCS      rho(quality) +0.09   rho(gain) +0.05

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/100        100/100           +0            -10.8     +1.0 (0.241)
   tag alarm                                100/100        100/100           +0            -10.8     +1.0 (0.271)
   top5 vs rest                             100/100        100/100           +0            -11.3     +0.4 (0.315)
   NQC-like spread                          100/100        100/100           +0            -11.0     +0.8 (0.187)
   WIG-like                                 100/100        100/100           +0            -11.8          -
   term coverage top1                       100/100        100/100           +0            -11.2     +0.6 (0.379)
   pre:qlen                                 100/100        100/100           +0            -11.2     +0.6 (0.432)
   pre:avgIDF                               100/100        100/100           +0            -11.1     +0.7 (0.212)
   pre:maxIDF                               100/100        100/100           +0            -11.1     +0.7 (0.344)
   pre:avgICTF                              100/100        100/100           +0            -11.0     +0.8 (0.142)
   pre:avgSCQ                               100/100        100/100           +0            -11.0     +0.8 (0.205)
   pre:maxSCQ                               100/100        100/100           +0            -12.5     -0.7 (0.258)
   pre:SCS                                  100/100        100/100           +0            -11.4     +0.4 (0.587)
   router ridge S (5-fold CV)               100/100        100/100           +0            -10.3     +1.5 (0.112)
   router gbm S (5-fold CV)                 100/100        100/100           +0            -10.3     +1.5 (0.034)
   router ridge S+P (5-fold CV)             100/100        100/100           +0             -9.7     +2.1 (0.011)
   router gbm S+P (5-fold CV)               100/100        100/100           +0             -8.9     +2.9 (0.000)
   router ridge S (other collections)       100/100        100/100           +0            -10.8     +1.0 (0.217)
   router gbm S (other collections)         100/100        100/100           +0            -10.7     +1.1 (0.103)
   router ridge S+P (other collections)     100/100        100/100           +0            -11.5     +0.3 (0.692)
   router gbm S+P (other collections)       100/100        100/100           +0            -11.0     +0.8 (0.297)
   ORACLE                                    50/40          50/50           +60             +1.0    +12.8 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.055, tag alarm -0.097, top5 vs rest +0.024, NQC-like spread -0.033, WIG-like +0.087, term coverage top1 +0.153
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.065, tag alarm -0.087, top5 vs rest -0.117, NQC-like spread -0.009, WIG-like +0.263, term coverage top1 +0.176, qlen +0.056, avgIDF +0.077, maxIDF -0.001, avgICTF -0.294, avgSCQ -0.072, maxSCQ +0.080, SCS +0.198

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                -15.7  -11.7   -7.7
   n=  50  router ridge S+P       -15.3  -10.7   -6.3   P(router > WIG-like @50%) = 97%
   n=  50  router gbm   S+P       -15.2  -10.7   -6.3   P(router > WIG-like @50%) = 96%
   n= 100  WIG-like                -15.7  -11.7   -7.7
   n= 100  router ridge S+P       -15.1  -10.5   -6.2   P(router > WIG-like @50%) = 99%
   n= 100  router gbm   S+P       -15.0  -10.6   -6.2   P(router > WIG-like @50%) = 100%
   n= 200  WIG-like                -15.7  -11.7   -7.8
   n= 200  router ridge S+P       -14.8  -10.3   -6.0   P(router > WIG-like @50%) = 99%
   n= 200  router gbm   S+P       -14.7  -10.3   -6.0   P(router > WIG-like @50%) = 100%

## beir_scidocs (tag bge; n=1000; mean gain +2.5 MRR; helped 33% hurt 26%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.15   rho(gain) -0.03
   avgIDF   rho(quality) +0.10   rho(gain) +0.02
   maxIDF   rho(quality) +0.05   rho(gain) -0.00
   avgICTF  rho(quality) +0.08   rho(gain) +0.02
   avgSCQ   rho(quality) +0.15   rho(gain) +0.01
   maxSCQ   rho(quality) +0.20   rho(gain) +0.02
   SCS      rho(quality) +0.02   rho(gain) +0.00

Budgets (share of questions reranked). random expected point budget: delta 1.0: 70%, delta 0.5: 90%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               80/50          90/70           +20             -0.8     -0.5 (0.431)
   tag alarm                                 90/50         100/60           +20             -0.8     -0.5 (0.442)
   top5 vs rest                              80/60         100/60           +10             -1.2     -0.9 (0.050)
   NQC-like spread                           80/50          90/60           +20             -0.9     -0.5 (0.211)
   WIG-like                                  60/40         100/50           +30             -0.3          -
   term coverage top1                        70/40          80/50           +30             -0.3     +0.1 (0.917)
   pre:qlen                                  80/60         100/70           +10             -1.4     -1.0 (0.086)
   pre:avgIDF                                90/80         100/90           -10             -1.7     -1.4 (0.019)
   pre:maxIDF                                90/70         100/90            +0             -1.3     -0.9 (0.146)
   pre:avgICTF                               90/80         100/90           -10             -1.9     -1.6 (0.006)
   pre:avgSCQ                               100/90         100/90           -20             -1.6     -1.3 (0.017)
   pre:maxSCQ                                90/80         100/90           -10             -1.5     -1.2 (0.036)
   pre:SCS                                   90/70         100/90            +0             -1.5     -1.2 (0.053)
   router ridge S (5-fold CV)                70/50          90/60           +20             -0.6     -0.3 (0.482)
   router gbm S (5-fold CV)                  60/30         100/50           +40             -0.3     +0.0 (0.999)
   router ridge S+P (5-fold CV)              70/50          80/60           +20             -0.6     -0.3 (0.583)
   router gbm S+P (5-fold CV)                90/70         100/80            +0             -1.5     -1.1 (0.054)
   router ridge S (other collections)        70/40          90/60           +30             -0.5     -0.2 (0.778)
   router gbm S (other collections)          90/50         100/70           +20             -0.9     -0.6 (0.366)
   router ridge S+P (other collections)      80/50          90/60           +20             -0.7     -0.3 (0.550)
   router gbm S+P (other collections)        80/60         100/70           +10             -1.0     -0.7 (0.236)
   ORACLE                                    10/10          10/10           +60             +6.0     +6.3 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.039, tag alarm +0.019, top5 vs rest -0.016, NQC-like spread +0.067, WIG-like -0.098, term coverage top1 -0.038
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.043, tag alarm +0.021, top5 vs rest -0.004, NQC-like spread +0.055, WIG-like -0.135, term coverage top1 -0.015, qlen -0.062, avgIDF +0.101, maxIDF -0.096, avgICTF +0.219, avgSCQ +0.004, maxSCQ +0.025, SCS -0.259

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -1.3   -0.2   +0.5
   n=  50  router ridge S+P        -1.5   -1.0   -0.5   P(router > WIG-like @50%) = 10%
   n=  50  router gbm   S+P        -1.5   -1.0   -0.7   P(router > WIG-like @50%) = 7%
   n= 100  WIG-like                 -1.4   -0.2   +0.4
   n= 100  router ridge S+P        -1.5   -0.9   -0.5   P(router > WIG-like @50%) = 8%
   n= 100  router gbm   S+P        -1.6   -1.2   -0.6   P(router > WIG-like @50%) = 3%
   n= 200  WIG-like                 -1.3   -0.2   +0.5
   n= 200  router ridge S+P        -1.4   -0.9   -0.4   P(router > WIG-like @50%) = 12%
   n= 200  router gbm   S+P        -1.5   -1.1   -0.7   P(router > WIG-like @50%) = 3%

