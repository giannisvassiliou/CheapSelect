## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  53.4  random  52.4  diff  +1.0  p=0.0608
   MRR  : tag  50.5  random  49.9  diff  +0.6  p=0.0316

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=0.743)        -0.3 (p=0.485)
   40%            -1.6 (p=0.065)        -0.7 (p=0.112)
   50%            -2.3 (p=0.012)        -0.8 (p=0.102)
   47% nat        -2.1 (p=0.026)        -0.7 (p=0.141)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -2.5  95% CI [-4.2, -0.9]  p=0.005
   MRR  :  -1.5  95% CI [-2.4, -0.6]  p=0.001

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (46%)
   Hit@1:  +0.2  p=0.828
   MRR  :  -0.8  p=0.079

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.5/-1.1 (p=0.024)  40%: -1.2/-1.1 (p=0.019)  50%: -1.4/-1.4 (p=0.006)  nat: -1.9/-1.5 (p=0.004)
   vs NQC-like spread      30%: -0.7/-1.2 (p=0.012)  40%: -1.5/-1.4 (p=0.004)  50%: -1.6/-1.4 (p=0.006)  nat: -2.1/-1.6 (p=0.001)
   vs WIG-like             30%: -0.9/-1.1 (p=0.023)  40%: -1.5/-1.3 (p=0.011)  50%: -2.0/-1.6 (p=0.003)  nat: -2.2/-1.6 (p=0.002)
   vs term coverage top1   30%: +1.9/+0.5 (p=0.292)  40%: +2.5/+0.8 (p=0.123)  50%: +1.8/+0.8 (p=0.127)  nat: +1.5/+0.6 (p=0.273)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -1.5  [-2.4, -0.6]  p=0.001
   BM25 margin           -0.8  [-1.8, +0.2]  p=0.100
   top5 vs rest          -0.0  [-1.0, +0.9]  p=0.929
   NQC-like spread       +0.0  [-0.9, +1.0]  p=0.935
   WIG-like              +0.1  [-0.9, +1.1]  p=0.810
   term coverage top1    -2.1  [-3.1, -1.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              48.5    49.0    49.9    50.4    50.8    51.6*   51.8*   52.2*   52.4*   52.1*   60%
   BM25 margin            48.9    49.5    50.2    51.1*   51.6*   52.0*   52.2*   52.5*   52.4*   52.1*   40%
   top5 vs rest           49.1    50.2    51.0*   51.5*   52.2*   52.2*   52.2*   52.5*   52.4*   52.1*   30%
   NQC-like spread        48.9    50.2    51.1*   51.8*   52.2*   52.6*   52.4*   52.5*   52.4*   52.1*   30%
   WIG-like               49.2    50.1    51.1*   51.7*   52.4*   52.7*   53.2*   52.9*   52.6*   52.1*   30%
   term coverage top1     48.6    49.0    49.4    49.6    50.0    50.7    51.0    51.1    51.5    52.1*   100%
   ORACLE                 53.9*   56.8*   58.4*   58.9*   58.9*   58.9*   58.9*   58.5*   56.9*   52.1*   10%
   random (expected)      48.4    48.8    49.3    49.7    50.1    50.5    50.9    51.3    51.7    52.1*   100%
   (BM25 only 48.0; rerank ALL 52.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -3.5[ -4.8]   -3.0[ -4.3]   -2.1[ -3.2]   -1.7[ -2.6]   -1.2[ -2.1]   -0.5[ -1.3]   -0.3[ -0.9]#  +0.1[ -0.4]#  +0.3[ +0.0]#   70%   (point estimate: 60%)
   BM25 margin           -3.2[ -4.6]   -2.5[ -3.8]   -1.8[ -3.1]   -0.9[ -2.0]   -0.5[ -1.5]   -0.1[ -1.0]#  +0.1[ -0.5]#  +0.4[ -0.1]#  +0.4[ +0.1]#   60%   (point estimate: 40%)
   top5 vs rest          -3.0[ -4.3]   -1.9[ -3.1]   -1.0[ -2.2]   -0.5[ -1.5]   +0.1[ -0.8]#  +0.2[ -0.7]#  +0.2[ -0.5]#  +0.5[ -0.1]#  +0.4[ -0.0]#   50%   (point estimate: 40%)
   NQC-like spread       -3.2[ -4.5]   -1.9[ -3.1]   -0.9[ -2.1]   -0.3[ -1.3]   +0.1[ -0.8]#  +0.6[ -0.3]#  +0.4[ -0.3]#  +0.4[ -0.2]#  +0.3[ -0.1]#   50%   (point estimate: 30%)
   WIG-like              -2.9[ -4.2]   -2.0[ -3.2]   -1.0[ -2.1]   -0.4[ -1.5]   +0.3[ -0.7]#  +0.7[ -0.3]#  +1.1[ +0.3]#  +0.9[ +0.2]#  +0.5[ +0.0]#   50%   (point estimate: 30%)
   term coverage top1    -3.5[ -4.9]   -3.1[ -4.4]   -2.6[ -3.8]   -2.4[ -3.6]   -2.0[ -3.1]   -1.3[ -2.2]   -1.1[ -1.8]   -1.0[ -1.6]   -0.6[ -1.0]    100%   (point estimate: 80%)
   ORACLE                +1.9[ +0.8]#  +4.7[ +3.9]#  +6.3[ +5.5]#  +6.8[ +6.0]#  +6.8[ +6.0]#  +6.8[ +6.0]#  +6.8[ +6.0]#  +6.5[ +5.7]#  +4.8[ +4.1]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -3.5[ -4.8]   -3.0[ -4.3]   -2.1[ -3.2]   -1.7[ -2.6]   -1.2[ -2.1]   -0.5[ -1.3]   -0.3[ -0.9]   +0.1[ -0.4]#  +0.3[ +0.0]#   80%   (point estimate: 60%)
   BM25 margin           -3.2[ -4.6]   -2.5[ -3.8]   -1.8[ -3.1]   -0.9[ -2.0]   -0.5[ -1.5]   -0.1[ -1.0]   +0.1[ -0.5]   +0.4[ -0.1]#  +0.4[ +0.1]#   80%   (point estimate: 50%)
   top5 vs rest          -3.0[ -4.3]   -1.9[ -3.1]   -1.0[ -2.2]   -0.5[ -1.5]   +0.1[ -0.8]   +0.2[ -0.7]   +0.2[ -0.5]   +0.5[ -0.1]#  +0.4[ -0.0]#   80%   (point estimate: 50%)
   NQC-like spread       -3.2[ -4.5]   -1.9[ -3.1]   -0.9[ -2.1]   -0.3[ -1.3]   +0.1[ -0.8]   +0.6[ -0.3]#  +0.4[ -0.3]#  +0.4[ -0.2]#  +0.3[ -0.1]#   60%   (point estimate: 40%)
   WIG-like              -2.9[ -4.2]   -2.0[ -3.2]   -1.0[ -2.1]   -0.4[ -1.5]   +0.3[ -0.7]   +0.7[ -0.3]#  +1.1[ +0.3]#  +0.9[ +0.2]#  +0.5[ +0.0]#   60%   (point estimate: 40%)
   term coverage top1    -3.5[ -4.9]   -3.1[ -4.4]   -2.6[ -3.8]   -2.4[ -3.6]   -2.0[ -3.1]   -1.3[ -2.2]   -1.1[ -1.8]   -1.0[ -1.6]   -0.6[ -1.0]    100%   (point estimate: 100%)
   ORACLE                +1.9[ +0.8]#  +4.7[ +3.9]#  +6.3[ +5.5]#  +6.8[ +6.0]#  +6.8[ +6.0]#  +6.8[ +6.0]#  +6.8[ +6.0]#  +6.5[ +5.7]#  +4.8[ +4.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      58% (sd  28)   -1.04 MRR              42%     42%
   tag alarm               100      58% (sd  25)   -0.93 MRR              40%     42%
   tag alarm               200      56% (sd  22)   -1.02 MRR              44%     44%
   BM25 margin              50      58% (sd  28)   -0.67 MRR              26%     42%
   BM25 margin             100      51% (sd  27)   -0.91 MRR              33%     49%
   BM25 margin             200      50% (sd  21)   -0.83 MRR              34%     50%
   top5 vs rest             50      51% (sd  33)   -0.88 MRR              38%     49%
   top5 vs rest            100      46% (sd  28)   -0.87 MRR              42%     54%
   top5 vs rest            200      40% (sd  22)   -0.94 MRR              48%     60%
   NQC-like spread          50      47% (sd  32)   -0.98 MRR              34%     53%
   NQC-like spread         100      44% (sd  27)   -0.92 MRR              35%     56%
   NQC-like spread         200      40% (sd  23)   -0.92 MRR              40%     60%
   WIG-like                 50      51% (sd  34)   -0.74 MRR              36%     49%
   WIG-like                100      40% (sd  27)   -0.97 MRR              44%     60%
   WIG-like                200      41% (sd  21)   -0.65 MRR              42%     59%
   term coverage top1       50      77% (sd  28)   -0.96 MRR              36%     23%
   term coverage top1      100      76% (sd  28)   -1.01 MRR              35%     24%
   term coverage top1      200      74% (sd  27)   -1.11 MRR              44%     26%

## mag_testfull  (2665 questions; tag alarm fires on 710 = 27%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  54.3  random  51.0  diff  +3.3  p=0.0001
   MRR  : tag  60.2  random  58.5  diff  +1.8  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.3 (p=0.000)        +1.6 (p=0.000)
   40%            +2.0 (p=0.000)        +1.2 (p=0.000)
   50%            +1.5 (p=0.000)        +0.9 (p=0.000)
   27% nat        +2.1 (p=0.000)        +1.5 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +1.8  95% CI [+0.5, +3.1]  p=0.010
   MRR  :  +3.3  95% CI [+2.6, +4.1]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (37%)
   Hit@1:  +1.3  p=0.034
   MRR  :  +0.9  p=0.008

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.4/+1.3 (p=0.000)  40%: +2.9/+0.6 (p=0.077)  50%: +2.8/+0.5 (p=0.169)  nat: +3.1/+1.2 (p=0.001)
   vs NQC-like spread      30%: +2.6/+1.2 (p=0.001)  40%: +2.5/+0.7 (p=0.040)  50%: +2.6/+0.7 (p=0.046)  nat: +2.8/+1.2 (p=0.001)
   vs WIG-like             30%: +1.4/+0.1 (p=0.659)  40%: +1.4/-0.2 (p=0.463)  50%: +1.7/-0.2 (p=0.474)  nat: +1.3/+0.2 (p=0.557)
   vs term coverage top1   30%: +1.5/+0.3 (p=0.382)  40%: +0.7/-0.2 (p=0.425)  50%: +0.5/-0.5 (p=0.110)  nat: +1.5/+0.3 (p=0.250)

G. each selector reranking 710 questions (27%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +3.3  [+2.6, +4.1]  p=0.000
   BM25 margin           +1.8  [+1.0, +2.6]  p=0.000
   top5 vs rest          +2.1  [+1.4, +2.9]  p=0.000
   NQC-like spread       +2.1  [+1.4, +2.9]  p=0.000
   WIG-like              +3.1  [+2.3, +3.9]  p=0.000
   term coverage top1    +3.0  [+2.2, +3.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              59.7*   60.2*   60.2*   59.6*   59.2*   58.8*   58.2*   57.7*   57.2*   56.9*   10%
   BM25 margin            59.0*   58.7*   58.7*   58.4*   58.3*   58.1*   57.9*   57.5*   57.2*   56.9*   10%
   top5 vs rest           59.0*   58.9*   58.9*   59.0*   58.7*   58.3*   57.9*   57.7*   57.2*   56.9*   10%
   NQC-like spread        59.1*   59.2*   59.1*   58.9*   58.5*   58.2*   57.9*   57.5*   57.2*   56.9*   10%
   WIG-like               59.9*   60.4*   60.1*   59.9*   59.4*   59.1*   59.0*   58.5*   57.9*   56.9*   10%
   term coverage top1     59.6*   59.7*   60.0*   59.9*   59.7*   59.4*   58.9*   58.5*   57.7*   56.9*   10%
   ORACLE                 63.9*   65.2*   65.3*   65.3*   65.3*   65.3*   65.3*   64.7*   62.3*   56.9*   10%
   random (expected)      58.8*   58.6*   58.4*   58.2*   58.0*   57.8*   57.6*   57.4*   57.2*   56.9*   10%
   (BM25 only 59.0; rerank ALL 56.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +2.7[ +1.8]#  +3.2[ +2.4]#  +3.3[ +2.5]#  +2.7[ +2.0]#  +2.2[ +1.7]#  +1.8[ +1.3]#  +1.2[ +0.8]#  +0.7[ +0.5]#  +0.3[ +0.2]#   10%   (point estimate: 10%)
   BM25 margin           +2.1[ +1.1]#  +1.8[ +0.9]#  +1.7[ +0.9]#  +1.4[ +0.7]#  +1.3[ +0.7]#  +1.2[ +0.6]#  +1.0[ +0.5]#  +0.6[ +0.3]#  +0.3[ +0.1]#   10%   (point estimate: 10%)
   top5 vs rest          +2.1[ +1.2]#  +1.9[ +1.1]#  +2.0[ +1.2]#  +2.1[ +1.4]#  +1.7[ +1.1]#  +1.3[ +0.8]#  +1.0[ +0.5]#  +0.7[ +0.3]#  +0.3[ +0.1]#   10%   (point estimate: 10%)
   NQC-like spread       +2.2[ +1.2]#  +2.3[ +1.5]#  +2.1[ +1.4]#  +2.0[ +1.3]#  +1.6[ +1.0]#  +1.3[ +0.8]#  +1.0[ +0.5]#  +0.6[ +0.3]#  +0.2[ -0.0]#   10%   (point estimate: 10%)
   WIG-like              +2.9[ +2.0]#  +3.4[ +2.6]#  +3.1[ +2.4]#  +2.9[ +2.2]#  +2.5[ +1.8]#  +2.2[ +1.6]#  +2.1[ +1.6]#  +1.5[ +1.1]#  +1.0[ +0.7]#   10%   (point estimate: 10%)
   term coverage top1    +2.7[ +1.7]#  +2.8[ +1.9]#  +3.0[ +2.2]#  +2.9[ +2.2]#  +2.7[ +2.1]#  +2.5[ +1.9]#  +2.0[ +1.5]#  +1.6[ +1.1]#  +0.7[ +0.5]#   10%   (point estimate: 10%)
   ORACLE                +7.0[ +6.3]#  +8.3[ +7.6]#  +8.3[ +7.7]#  +8.3[ +7.7]#  +8.3[ +7.7]#  +8.3[ +7.7]#  +8.3[ +7.7]#  +7.7[ +7.1]#  +5.3[ +4.7]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +2.7[ +1.8]#  +3.2[ +2.4]#  +3.3[ +2.5]#  +2.7[ +2.0]#  +2.2[ +1.7]#  +1.8[ +1.3]#  +1.2[ +0.8]#  +0.7[ +0.5]#  +0.3[ +0.2]#   10%   (point estimate: 10%)
   BM25 margin           +2.1[ +1.1]#  +1.8[ +0.9]#  +1.7[ +0.9]#  +1.4[ +0.7]#  +1.3[ +0.7]#  +1.2[ +0.6]#  +1.0[ +0.5]#  +0.6[ +0.3]#  +0.3[ +0.1]#   10%   (point estimate: 10%)
   top5 vs rest          +2.1[ +1.2]#  +1.9[ +1.1]#  +2.0[ +1.2]#  +2.1[ +1.4]#  +1.7[ +1.1]#  +1.3[ +0.8]#  +1.0[ +0.5]#  +0.7[ +0.3]#  +0.3[ +0.1]#   10%   (point estimate: 10%)
   NQC-like spread       +2.2[ +1.2]#  +2.3[ +1.5]#  +2.1[ +1.4]#  +2.0[ +1.3]#  +1.6[ +1.0]#  +1.3[ +0.8]#  +1.0[ +0.5]#  +0.6[ +0.3]#  +0.2[ -0.0]#   10%   (point estimate: 10%)
   WIG-like              +2.9[ +2.0]#  +3.4[ +2.6]#  +3.1[ +2.4]#  +2.9[ +2.2]#  +2.5[ +1.8]#  +2.2[ +1.6]#  +2.1[ +1.6]#  +1.5[ +1.1]#  +1.0[ +0.7]#   10%   (point estimate: 10%)
   term coverage top1    +2.7[ +1.7]#  +2.8[ +1.9]#  +3.0[ +2.2]#  +2.9[ +2.2]#  +2.7[ +2.1]#  +2.5[ +1.9]#  +2.0[ +1.5]#  +1.6[ +1.1]#  +0.7[ +0.5]#   10%   (point estimate: 10%)
   ORACLE                +7.0[ +6.3]#  +8.3[ +7.6]#  +8.3[ +7.7]#  +8.3[ +7.7]#  +8.3[ +7.7]#  +8.3[ +7.7]#  +8.3[ +7.7]#  +7.7[ +7.1]#  +5.3[ +4.7]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      18% (sd  20)   +2.57 MRR               0%     82%
   tag alarm               100      13% (sd  13)   +2.68 MRR               0%     87%
   tag alarm               200      10% (sd   1)   +2.74 MRR               0%     90%
   BM25 margin              50      26% (sd  28)   +1.71 MRR               0%     74%
   BM25 margin             100      19% (sd  21)   +1.87 MRR               0%     81%
   BM25 margin             200      11% (sd   7)   +2.03 MRR               0%     89%
   top5 vs rest             50      34% (sd  34)   +1.61 MRR               0%     66%
   top5 vs rest            100      19% (sd  22)   +1.94 MRR               0%     81%
   top5 vs rest            200      12% (sd  11)   +2.08 MRR               0%     88%
   NQC-like spread          50      34% (sd  34)   +1.64 MRR               0%     66%
   NQC-like spread         100      19% (sd  22)   +1.97 MRR               0%     81%
   NQC-like spread         200      12% (sd   9)   +2.11 MRR               0%     88%
   WIG-like                 50      22% (sd  27)   +2.69 MRR               0%     78%
   WIG-like                100      12% (sd  11)   +2.91 MRR               0%     88%
   WIG-like                200      10% (sd   4)   +2.93 MRR               0%     90%
   term coverage top1       50      17% (sd  20)   +2.60 MRR               0%     83%
   term coverage top1      100      14% (sd  14)   +2.68 MRR               0%     86%
   term coverage top1      200      10% (sd   3)   +2.70 MRR               0%     90%

## prime_testfull  (2801 questions; tag alarm fires on 1563 = 56%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  22.6  random  20.4  diff  +2.3  p=0.0001
   MRR  : tag  30.4  random  28.9  diff  +1.5  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.9 (p=0.036)        +0.5 (p=0.069)
   40%            +1.0 (p=0.046)        +0.6 (p=0.066)
   50%            +0.8 (p=0.145)        +0.6 (p=0.124)
   56% nat        +0.3 (p=0.657)        +0.5 (p=0.213)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +2.8  95% CI [+1.7, +4.0]  p=0.000
   MRR  :  +1.0  95% CI [+0.3, +1.8]  p=0.007

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (55%)
   Hit@1:  -0.4  p=0.506
   MRR  :  -0.6  p=0.087

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/-0.0 (p=0.893)  40%: +1.1/+0.4 (p=0.316)  50%: +1.6/+0.8 (p=0.044)  nat: +1.1/+0.6 (p=0.127)
   vs NQC-like spread      30%: +0.1/-0.0 (p=0.916)  40%: +0.6/+0.2 (p=0.591)  50%: +0.8/+0.4 (p=0.269)  nat: +0.4/+0.3 (p=0.358)
   vs WIG-like             30%: -0.5/-0.5 (p=0.182)  40%: +0.2/-0.1 (p=0.792)  50%: +0.6/+0.2 (p=0.512)  nat: +0.3/+0.2 (p=0.614)
   vs term coverage top1   30%: +0.2/+0.1 (p=0.719)  40%: +1.1/+0.6 (p=0.104)  50%: +1.2/+0.7 (p=0.063)  nat: +0.9/+0.6 (p=0.126)

G. each selector reranking 1563 questions (56%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +1.0  [+0.3, +1.8]  p=0.007
   BM25 margin           +0.5  [-0.2, +1.3]  p=0.168
   top5 vs rest          +0.5  [-0.3, +1.3]  p=0.246
   NQC-like spread       +0.7  [-0.1, +1.5]  p=0.082
   WIG-like              +0.9  [+0.1, +1.6]  p=0.033
   term coverage top1    +0.4  [-0.3, +1.2]  p=0.256

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              28.7*   29.1*   29.6*   30.1*   30.4*   30.3*   30.4*   30.1*   29.9*   29.3*   10%
   BM25 margin            28.6*   28.9*   29.0*   29.5*   29.8*   30.0*   30.0*   30.1*   29.8*   29.3*   10%
   top5 vs rest           28.7*   29.1*   29.6*   29.7*   29.7*   29.7*   29.7*   29.4*   29.2*   29.3*   10%
   NQC-like spread        28.6*   29.0*   29.6*   29.9*   30.0*   29.9*   29.7*   29.5*   29.4*   29.3*   10%
   WIG-like               29.1*   29.7*   30.1*   30.2*   30.2*   30.3*   30.5*   30.2*   29.9*   29.3*   10%
   term coverage top1     28.8*   29.4*   29.5*   29.5*   29.7*   29.6*   29.7*   29.8*   29.6*   29.3*   10%
   ORACLE                 34.6*   37.2*   37.5*   37.5*   37.5*   37.5*   37.5*   37.4*   35.2*   29.3*   10%
   random (expected)      28.5    28.6    28.7    28.8    28.9    28.9    29.0    29.1    29.2    29.3*   100%
   (BM25 only 28.4; rerank ALL 29.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.6[ -1.7]   -0.2[ -1.2]   +0.3[ -0.7]#  +0.8[ -0.1]#  +1.1[ +0.3]#  +1.0[ +0.3]#  +1.0[ +0.4]#  +0.8[ +0.3]#  +0.6[ +0.2]#   30%   (point estimate: 10%)
   BM25 margin           -0.7[ -1.8]   -0.4[ -1.4]   -0.3[ -1.2]   +0.2[ -0.7]#  +0.5[ -0.3]#  +0.6[ -0.1]#  +0.6[ +0.0]#  +0.8[ +0.3]#  +0.5[ +0.2]#   40%   (point estimate: 10%)
   top5 vs rest          -0.6[ -1.6]   -0.2[ -1.3]   +0.3[ -0.7]#  +0.4[ -0.5]#  +0.4[ -0.5]#  +0.3[ -0.4]#  +0.4[ -0.3]#  +0.0[ -0.5]#  -0.1[ -0.5]#   30%   (point estimate: 10%)
   NQC-like spread       -0.7[ -1.7]   -0.3[ -1.3]   +0.3[ -0.6]#  +0.6[ -0.3]#  +0.7[ -0.1]#  +0.6[ -0.2]#  +0.4[ -0.3]#  +0.2[ -0.3]#  +0.1[ -0.3]#   30%   (point estimate: 10%)
   WIG-like              -0.3[ -1.3]   +0.4[ -0.6]#  +0.7[ -0.3]#  +0.9[ -0.0]#  +0.9[ +0.0]#  +0.9[ +0.2]#  +1.2[ +0.6]#  +0.8[ +0.3]#  +0.6[ +0.3]#   20%   (point estimate: 10%)
   term coverage top1    -0.5[ -1.6]   +0.0[ -1.0]#  +0.1[ -0.8]#  +0.2[ -0.7]#  +0.4[ -0.4]#  +0.2[ -0.4]#  +0.4[ -0.2]#  +0.4[ -0.1]#  +0.2[ -0.1]#   20%   (point estimate: 10%)
   ORACLE                +5.3[ +4.5]#  +7.9[ +7.1]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +5.9[ +5.2]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.6[ -1.7]   -0.2[ -1.2]   +0.3[ -0.7]   +0.8[ -0.1]#  +1.1[ +0.3]#  +1.0[ +0.3]#  +1.0[ +0.4]#  +0.8[ +0.3]#  +0.6[ +0.2]#   40%   (point estimate: 20%)
   BM25 margin           -0.7[ -1.8]   -0.4[ -1.4]   -0.3[ -1.2]   +0.2[ -0.7]   +0.5[ -0.3]#  +0.6[ -0.1]#  +0.6[ +0.0]#  +0.8[ +0.3]#  +0.5[ +0.2]#   50%   (point estimate: 20%)
   top5 vs rest          -0.6[ -1.6]   -0.2[ -1.3]   +0.3[ -0.7]   +0.4[ -0.5]#  +0.4[ -0.5]#  +0.3[ -0.4]#  +0.4[ -0.3]#  +0.0[ -0.5]   -0.1[ -0.5]    100%   (point estimate: 20%)
   NQC-like spread       -0.7[ -1.7]   -0.3[ -1.3]   +0.3[ -0.6]   +0.6[ -0.3]#  +0.7[ -0.1]#  +0.6[ -0.2]#  +0.4[ -0.3]#  +0.2[ -0.3]#  +0.1[ -0.3]#   40%   (point estimate: 20%)
   WIG-like              -0.3[ -1.3]   +0.4[ -0.6]   +0.7[ -0.3]#  +0.9[ -0.0]#  +0.9[ +0.0]#  +0.9[ +0.2]#  +1.2[ +0.6]#  +0.8[ +0.3]#  +0.6[ +0.3]#   30%   (point estimate: 10%)
   term coverage top1    -0.5[ -1.6]   +0.0[ -1.0]   +0.1[ -0.8]   +0.2[ -0.7]   +0.4[ -0.4]#  +0.2[ -0.4]#  +0.4[ -0.2]#  +0.4[ -0.1]#  +0.2[ -0.1]#   50%   (point estimate: 20%)
   ORACLE                +5.3[ +4.5]#  +7.9[ +7.1]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +8.1[ +7.4]#  +5.9[ +5.2]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      44% (sd  35)   +0.05 MRR               0%     56%
   tag alarm               100      35% (sd  29)   +0.06 MRR               0%     65%
   tag alarm               200      25% (sd  21)   -0.07 MRR               0%     75%
   BM25 margin              50      50% (sd  35)   -0.04 MRR               0%     50%
   BM25 margin             100      37% (sd  31)   -0.20 MRR               0%     63%
   BM25 margin             200      32% (sd  25)   -0.21 MRR               4%     68%
   top5 vs rest             50      59% (sd  40)   -0.18 MRR               0%     41%
   top5 vs rest            100      49% (sd  37)   -0.19 MRR               0%     51%
   top5 vs rest            200      37% (sd  34)   -0.28 MRR               0%     63%
   NQC-like spread          50      49% (sd  37)   -0.17 MRR               0%     51%
   NQC-like spread         100      40% (sd  34)   -0.22 MRR               0%     60%
   NQC-like spread         200      33% (sd  30)   -0.26 MRR               2%     67%
   WIG-like                 50      46% (sd  36)   +0.24 MRR               0%     54%
   WIG-like                100      33% (sd  31)   +0.15 MRR               0%     67%
   WIG-like                200      22% (sd  22)   +0.04 MRR               0%     78%
   term coverage top1       50      49% (sd  36)   -0.06 MRR               0%     51%
   term coverage top1      100      50% (sd  35)   -0.04 MRR               0%     50%
   term coverage top1      200      33% (sd  30)   -0.19 MRR               0%     67%

## dbpedia_test  (400 questions; tag alarm fires on 68 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  48.5  random  46.4  diff  +2.1  p=0.0216
   MRR  : tag  35.3  random  35.0  diff  +0.3  p=0.2217

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.0 (p=0.201)        +0.2 (p=0.781)
   40%            +0.5 (p=0.826)        -0.1 (p=0.811)
   50%            +0.0 (p=1.000)        +0.3 (p=0.496)
   17% nat        +1.2 (p=0.541)        +0.7 (p=0.283)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -16.0  95% CI [-20.2, -11.8]  p=0.000
   MRR  : -11.2  95% CI [-12.9, -9.4]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (55%)
   Hit@1:  +2.8  p=0.172
   MRR  :  -0.0  p=0.949

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.8/+0.4 (p=0.627)  40%: +3.8/+0.5 (p=0.551)  50%: +2.5/+0.6 (p=0.507)  nat: +3.2/+0.6 (p=0.335)
   vs NQC-like spread      30%: +4.5/+0.5 (p=0.515)  40%: +4.0/+0.7 (p=0.368)  50%: +2.2/+0.1 (p=0.867)  nat: +3.0/+0.7 (p=0.222)
   vs WIG-like             30%: +0.8/-0.3 (p=0.690)  40%: +1.0/+0.1 (p=0.940)  50%: +1.5/+0.3 (p=0.672)  nat: +1.2/+0.2 (p=0.770)
   vs term coverage top1   30%: +0.5/+0.0 (p=0.985)  40%: +0.5/+0.2 (p=0.808)  50%: -1.0/+0.1 (p=0.848)  nat: +0.8/+0.2 (p=0.623)

G. each selector reranking 68 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -11.2  [-12.9, -9.4]  p=0.000
   BM25 margin          -11.8  [-13.6, -10.1]  p=0.000
   top5 vs rest         -11.7  [-13.4, -10.0]  p=0.000
   NQC-like spread      -11.8  [-13.6, -10.1]  p=0.000
   WIG-like             -11.3  [-13.1, -9.6]  p=0.000
   term coverage top1   -11.4  [-13.1, -9.7]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              34.3    35.9    36.9    38.3    39.8    41.2    42.8    44.2    45.5    46.4*   100%
   BM25 margin            34.0    35.0    36.8    38.4    39.5    41.2    42.7    44.2    45.3    46.4*   100%
   top5 vs rest           34.0    35.1    36.6    37.8    39.2    40.8    42.2    43.9    45.4    46.4*   100%
   NQC-like spread        33.7    34.9    36.5    37.6    39.7    41.1    42.5    44.1    45.4    46.4*   100%
   WIG-like               34.3    35.5    37.2    38.2    39.5    40.8    42.2    43.8    45.1    46.4*   100%
   term coverage top1     34.2    35.5    36.9    38.1    39.7    41.1    42.8    44.1    45.0    46.4*   100%
   ORACLE                 37.7    41.0    43.7    45.6    46.9*   47.7*   47.9*   47.9*   47.8*   46.4*   50%
   random (expected)      34.0    35.4    36.8    38.2    39.5    40.9    42.3    43.7    45.1    46.4*   100%
   (BM25 only 32.7; rerank ALL 46.4)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.1[-13.8]  -10.6[-12.3]   -9.5[-11.0]   -8.1[ -9.7]   -6.6[ -8.1]   -5.2[ -6.6]   -3.7[ -4.9]   -2.2[ -3.2]   -0.9[ -1.5]    100%   (point estimate: 90%)
   BM25 margin          -12.5[-14.2]  -11.4[-13.2]   -9.7[-11.3]   -8.0[ -9.6]   -6.9[ -8.4]   -5.3[ -6.6]   -3.7[ -5.0]   -2.3[ -3.2]   -1.2[ -1.9]    100%   (point estimate: 100%)
   top5 vs rest         -12.5[-14.2]  -11.4[-13.1]   -9.8[-11.5]   -8.6[-10.2]   -7.2[ -8.7]   -5.7[ -7.0]   -4.2[ -5.4]   -2.5[ -3.5]   -1.0[ -1.6]    100%   (point estimate: 100%)
   NQC-like spread      -12.7[-14.5]  -11.5[-13.2]  -10.0[-11.7]   -8.9[-10.5]   -6.8[ -8.3]   -5.3[ -6.6]   -3.9[ -5.1]   -2.3[ -3.3]   -1.0[ -1.7]    100%   (point estimate: 100%)
   WIG-like             -12.1[-13.9]  -11.0[-12.7]   -9.2[-10.8]   -8.2[ -9.8]   -6.9[ -8.5]   -5.6[ -7.0]   -4.3[ -5.5]   -2.6[ -3.5]   -1.4[ -2.1]    100%   (point estimate: 100%)
   term coverage top1   -12.3[-14.0]  -10.9[-12.6]   -9.5[-11.1]   -8.3[ -9.8]   -6.8[ -8.2]   -5.3[ -6.6]   -3.6[ -4.7]   -2.3[ -3.2]   -1.5[ -2.2]    100%   (point estimate: 100%)
   ORACLE                -8.7[-10.0]   -5.4[ -6.5]   -2.8[ -3.6]   -0.9[ -1.5]   +0.4[ -0.1]#  +1.2[ +0.7]#  +1.4[ +1.0]#  +1.4[ +1.0]#  +1.4[ +0.9]#   50%   (point estimate: 40%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.1[-13.8]  -10.6[-12.3]   -9.5[-11.0]   -8.1[ -9.7]   -6.6[ -8.1]   -5.2[ -6.6]   -3.7[ -4.9]   -2.2[ -3.2]   -0.9[ -1.5]    100%   (point estimate: 100%)
   BM25 margin          -12.5[-14.2]  -11.4[-13.2]   -9.7[-11.3]   -8.0[ -9.6]   -6.9[ -8.4]   -5.3[ -6.6]   -3.7[ -5.0]   -2.3[ -3.2]   -1.2[ -1.9]    100%   (point estimate: 100%)
   top5 vs rest         -12.5[-14.2]  -11.4[-13.1]   -9.8[-11.5]   -8.6[-10.2]   -7.2[ -8.7]   -5.7[ -7.0]   -4.2[ -5.4]   -2.5[ -3.5]   -1.0[ -1.6]    100%   (point estimate: 100%)
   NQC-like spread      -12.7[-14.5]  -11.5[-13.2]  -10.0[-11.7]   -8.9[-10.5]   -6.8[ -8.3]   -5.3[ -6.6]   -3.9[ -5.1]   -2.3[ -3.3]   -1.0[ -1.7]    100%   (point estimate: 100%)
   WIG-like             -12.1[-13.9]  -11.0[-12.7]   -9.2[-10.8]   -8.2[ -9.8]   -6.9[ -8.5]   -5.6[ -7.0]   -4.3[ -5.5]   -2.6[ -3.5]   -1.4[ -2.1]    100%   (point estimate: 100%)
   term coverage top1   -12.3[-14.0]  -10.9[-12.6]   -9.5[-11.1]   -8.3[ -9.8]   -6.8[ -8.2]   -5.3[ -6.6]   -3.6[ -4.7]   -2.3[ -3.2]   -1.5[ -2.2]    100%   (point estimate: 100%)
   ORACLE                -8.7[-10.0]   -5.4[ -6.5]   -2.8[ -3.6]   -0.9[ -1.5]   +0.4[ -0.1]#  +1.2[ +0.7]#  +1.4[ +1.0]#  +1.4[ +1.0]#  +1.4[ +0.9]#   50%   (point estimate: 50%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      93% (sd   7)   -0.76 MRR              30%      7%
   tag alarm               100      95% (sd   6)   -0.58 MRR              31%      5%
   tag alarm               200      95% (sd   5)   -0.62 MRR              39%      5%
   BM25 margin              50      94% (sd   7)   -0.71 MRR              45%      6%
   BM25 margin             100      95% (sd   6)   -0.61 MRR              46%      5%
   BM25 margin             200      96% (sd   5)   -0.53 MRR              38%      4%
   top5 vs rest             50      95% (sd   7)   -0.66 MRR              36%      5%
   top5 vs rest            100      96% (sd   5)   -0.49 MRR              38%      4%
   top5 vs rest            200      96% (sd   5)   -0.56 MRR              42%      4%
   NQC-like spread          50      93% (sd   8)   -0.80 MRR              44%      7%
   NQC-like spread         100      95% (sd   5)   -0.57 MRR              38%      5%
   NQC-like spread         200      95% (sd   5)   -0.63 MRR              45%      5%
   WIG-like                 50      96% (sd   6)   -0.58 MRR              34%      4%
   WIG-like                100      97% (sd   5)   -0.43 MRR              27%      3%
   WIG-like                200      99% (sd   3)   -0.18 MRR              10%      1%
   term coverage top1       50      96% (sd   6)   -0.62 MRR              38%      4%
   term coverage top1      100      97% (sd   5)   -0.37 MRR              24%      3%
   term coverage top1      200      98% (sd   4)   -0.26 MRR              16%      2%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  15%  MRR  32.5 | vs BM25 margin: +2.1 (p=0.014)  vs top5 vs rest: -1.2 (p=0.403)  vs NQC-like spread: -0.9 (p=0.547)  vs WIG-like: -1.0 (p=0.369)  vs term coverage top1: -0.5 (p=0.585)
   list           n= 105  fires  16%  MRR  32.4 | vs BM25 margin: -1.8 (p=0.193)  vs top5 vs rest: +0.9 (p=0.428)  vs NQC-like spread: +1.4 (p=0.236)  vs WIG-like: +1.0 (p=0.397)  vs term coverage top1: +1.4 (p=0.194)
   question       n= 125  fires  22%  MRR  24.2 | vs BM25 margin: +2.0 (p=0.117)  vs top5 vs rest: +1.6 (p=0.116)  vs NQC-like spread: +1.1 (p=0.172)  vs WIG-like: -0.7 (p=0.504)  vs term coverage top1: -0.7 (p=0.432)
   named entity   n=  86  fires  12%  MRR  57.5 | vs BM25 margin: +0.4 (p=0.759)  vs top5 vs rest: +0.4 (p=0.738)  vs NQC-like spread: +0.7 (p=0.569)  vs WIG-like: +1.5 (p=0.048)  vs term coverage top1: +0.8 (p=0.094)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR +0.2  [-1.2, +1.6]  p=0.774  (n=211)

## POOLED over 4 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  42.0  random  39.6  diff  +2.4  p=0.0001
   MRR  : tag  45.6  random  44.3  diff  +1.3  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +1.2 (p=0.000)   MRR  +0.7 (p=0.000)
   40%      Hit@1  +0.7 (p=0.020)   MRR  +0.5 (p=0.009)
   50%      Hit@1  +0.3 (p=0.316)   MRR  +0.4 (p=0.049)
   natural  Hit@1  +0.5 (p=0.202)   MRR  +0.6 (p=0.005)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  +0.3  95% CI [-0.5, +1.1]  p=0.503
   MRR  :  +0.6  95% CI [+0.2, +1.1]  p=0.006

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +0.5  p=0.162
   MRR  :  -0.1  p=0.652

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.4/+0.2 (p=0.280)  40%: +1.4/+0.1 (p=0.559)  50%: +1.4/+0.2 (p=0.416)  nat: +1.3/+0.3 (p=0.106)
   vs NQC-like spread      30%: +1.0/+0.2 (p=0.425)  40%: +1.0/+0.1 (p=0.793)  50%: +1.0/+0.1 (p=0.676)  nat: +0.8/+0.2 (p=0.245)
   vs WIG-like             30%: +0.2/-0.4 (p=0.056)  40%: +0.3/-0.4 (p=0.064)  50%: +0.5/-0.3 (p=0.139)  nat: +0.1/-0.2 (p=0.287)
   vs term coverage top1   30%: +1.1/+0.2 (p=0.214)  40%: +1.2/+0.3 (p=0.134)  50%: +1.0/+0.3 (p=0.225)  nat: +1.2/+0.5 (p=0.022)
