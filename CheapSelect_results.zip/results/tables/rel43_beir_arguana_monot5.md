## beir_arguana  (1401 questions; tag alarm fires on 9 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.1  diff  -0.0  p=1.0000
   MRR  : tag  21.9  random  21.9  diff  +0.0  p=0.4325

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.0 (p=0.938)
   40%            +0.0 (p=1.000)        -0.0 (p=0.767)
   50%            +0.0 (p=1.000)        -0.0 (p=0.875)
   1% nat         +0.0 (p=1.000)        +0.0 (p=0.394)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.1  95% CI [-5.2, -3.1]  p=0.000
   MRR  :  -0.6  95% CI [-1.9, +0.7]  p=0.369

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (21%)
   Hit@1:  +2.6  p=0.000
   MRR  :  +1.2  p=0.003

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.4/-0.8 (p=0.134)  40%: -0.3/-0.7 (p=0.212)  50%: -0.9/-1.2 (p=0.053)  nat: +0.0/-0.0 (p=0.834)
   vs NQC-like spread      30%: -0.1/-0.3 (p=0.413)  40%: -0.1/-0.6 (p=0.198)  50%: -0.8/-1.0 (p=0.023)  nat: +0.0/+0.0 (p=0.389)
   vs WIG-like             30%: +0.4/-0.8 (p=0.087)  40%: +0.4/-0.7 (p=0.215)  50%: -0.1/-1.2 (p=0.027)  nat: +0.0/+0.0 (p=0.688)
   vs term coverage top1   30%: +0.1/-0.3 (p=0.381)  40%: +0.3/-0.6 (p=0.213)  50%: +0.0/-0.9 (p=0.064)  nat: -0.1/+0.0 (p=0.935)

G. each selector reranking 9 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.6  [-1.9, +0.7]  p=0.369
   BM25 margin           -0.6  [-1.9, +0.7]  p=0.345
   top5 vs rest          -0.6  [-1.9, +0.7]  p=0.377
   NQC-like spread       -0.6  [-1.9, +0.7]  p=0.341
   WIG-like              -0.6  [-1.9, +0.7]  p=0.351
   term coverage top1    -0.6  [-1.9, +0.7]  p=0.359

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              22.0*   21.9*   22.1*   22.0*   21.5    21.5    21.8*   21.7    22.1*   22.5*   90%
   BM25 margin            22.1*   21.9*   22.1*   22.0*   21.5    21.5    21.7    21.7    22.1*   22.5*   90%
   top5 vs rest           22.4*   22.7*   22.8*   22.7*   22.7*   22.6*   22.4*   22.5*   22.6*   22.5*   10%
   NQC-like spread        21.9*   22.1*   22.4*   22.5*   22.5*   22.5*   22.6*   22.7*   22.6*   22.5*   10%
   WIG-like               22.3*   22.9*   22.8*   22.6*   22.7*   22.8*   22.6*   22.7*   22.6*   22.5*   10%
   term coverage top1     21.9*   22.2*   22.4*   22.5*   22.4*   22.6*   22.4*   22.4*   22.6*   22.5*   10%
   ORACLE                 27.2*   29.5*   30.7*   30.9*   30.9*   30.9*   30.3*   28.9*   26.6*   22.5*   10%
   random (expected)      22.0    22.0    22.1    22.2    22.2    22.3    22.3    22.4    22.5    22.5*   100%
   (BM25 only 21.9; rerank ALL 22.5)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.45 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.5[ -1.8]   -0.6[ -1.8]   -0.5[ -1.6]   -0.6[ -1.6]   -1.0[ -2.1]   -1.0[ -1.9]   -0.8[ -1.5]   -0.8[ -1.4]   -0.4[ -0.8]    100%   (point estimate: 90%)
   BM25 margin           -0.5[ -1.7]   -0.7[ -1.8]   -0.5[ -1.6]   -0.6[ -1.6]   -1.0[ -2.1]   -1.0[ -1.9]   -0.8[ -1.6]   -0.8[ -1.4]   -0.4[ -0.8]    100%   (point estimate: 90%)
   top5 vs rest          -0.1[ -1.3]   +0.2[ -0.9]   +0.3[ -0.7]   +0.2[ -0.8]   +0.2[ -0.7]   +0.1[ -0.7]   -0.1[ -0.7]   -0.0[ -0.6]   +0.0[ -0.3]#   90%   (point estimate: 10%)
   NQC-like spread       -0.7[ -1.9]   -0.5[ -1.7]   -0.1[ -1.2]   -0.0[ -1.0]   +0.0[ -0.9]   +0.0[ -0.8]   +0.1[ -0.7]   +0.2[ -0.4]#  +0.1[ -0.3]#   80%   (point estimate: 30%)
   WIG-like              -0.2[ -1.4]   +0.4[ -0.7]   +0.3[ -0.8]   +0.1[ -0.9]   +0.2[ -0.7]   +0.2[ -0.6]   +0.1[ -0.6]   +0.2[ -0.4]#  +0.1[ -0.2]#   80%   (point estimate: 10%)
   term coverage top1    -0.6[ -1.8]   -0.4[ -1.5]   -0.1[ -1.2]   -0.0[ -1.1]   -0.1[ -1.1]   +0.1[ -0.7]   -0.1[ -0.9]   -0.1[ -0.8]   +0.1[ -0.4]#   90%   (point estimate: 20%)
   ORACLE                +4.7[ +3.8]#  +7.0[ +6.2]#  +8.1[ +7.4]#  +8.4[ +7.7]#  +8.4[ +7.7]#  +8.3[ +7.6]#  +7.7[ +7.0]#  +6.3[ +5.6]#  +4.0[ +3.4]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.45): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      74% (sd  37)   -0.33 MRR              35%     26%
   BM25 margin             100      72% (sd  35)   -0.38 MRR              45%     28%
   top5 vs rest            100      70% (sd  32)   -0.03 MRR              10%     30%
   NQC-like spread         100      64% (sd  36)   -0.20 MRR              25%     36%
   WIG-like                100      49% (sd  39)   -0.08 MRR              10%     51%
   term coverage top1      100      56% (sd  39)   -0.37 MRR              45%     44%

