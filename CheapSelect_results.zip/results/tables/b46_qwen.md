# budgets46: grid includes b = 0; delta = 1.0 MRR point(s)

pair | gain | random(exp) | WIG pt/NI | tag pt/NI | margin pt/NI | NQC pt/NI | top5 pt/NI | termcov pt/NI | oracle pt
mag_testfull:qwen8b | +10.4 | 100 | 90/100 | 60/70 | 70/70 | 90/90 | 90/100 | 80/100 | 20
prime_testfull:qwen8b | +10.8 | 100 | 80/90 | 80/90 | 90/90 | 80/100 | 80/100 | 90/100 | 20
amazon_testfull:qwen8b | +9.8 | 90 | 60/100 | 90/90 | 80/90 | 70/80 | 70/90 | 90/100 | 10
dbpedia_test:qwen8b | +22.9 | 100 | 90/100 | 90/100 | 90/100 | 100/100 | 100/100 | 100/100 | 30
beir_scifact:qwen8b | +10.7 | 100 | 90/100 | 70/80 | 70/70 | 80/100 | 100/100 | 90/100 | 20
beir_nfcorpus:qwen8b | +7.3 | 90 | 80/90 | 90/100 | 90/100 | 70/100 | 80/90 | 100/100 | 10
beir_scidocs:qwen8b | +10.3 | 100 | 100/100 | 90/100 | 90/90 | 90/100 | 100/100 | 80/90 | 20
