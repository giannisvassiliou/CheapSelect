## beir_scifact  (300 questions; tag alarm fires on 57 = 19%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  54.3  random  52.1  diff  +2.2  p=0.0251
   MRR  : tag  64.6  random  63.0  diff  +1.5  p=0.0234

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -2.7 (p=0.169)        -1.6 (p=0.160)
   40%            -2.7 (p=0.116)        -1.7 (p=0.094)
   50%            -1.3 (p=0.341)        -1.3 (p=0.118)
   19% nat        -0.7 (p=0.862)        -0.6 (p=0.637)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -9.7  95% CI [-14.0, -5.3]  p=0.000
   MRR  :  -7.5  95% CI [-10.6, -4.4]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (35%)
   Hit@1:  +0.3  p=1.000
   MRR  :  -0.8  p=0.498

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +5.0/+3.6 (p=0.010)  40%: +6.3/+4.6 (p=0.000)  50%: +9.0/+5.9 (p=0.000)  nat: +2.7/+1.6 (p=0.243)
   vs NQC-like spread      30%: +2.7/+1.6 (p=0.259)  40%: +4.7/+3.1 (p=0.032)  50%: +7.0/+4.3 (p=0.005)  nat: +2.0/+0.7 (p=0.609)
   vs WIG-like             30%: +6.3/+4.0 (p=0.007)  40%: +7.0/+4.2 (p=0.008)  50%: +8.3/+4.8 (p=0.003)  nat: +4.7/+2.7 (p=0.043)
   vs term coverage top1   30%: +0.3/-0.4 (p=0.777)  40%: +3.0/+1.1 (p=0.460)  50%: +4.3/+1.9 (p=0.186)  nat: +0.7/-0.1 (p=0.952)

G. each selector reranking 57 questions (19%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -7.5  [-10.6, -4.4]  p=0.000
   BM25 margin           -6.9  [-10.1, -3.6]  p=0.000
   top5 vs rest          -9.1  [-12.4, -5.8]  p=0.000
   NQC-like spread       -8.1  [-11.5, -4.8]  p=0.000
   WIG-like             -10.1  [-13.7, -6.6]  p=0.000
   term coverage top1    -7.4  [-10.4, -4.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              64.5    64.8    66.6    68.4    70.6*   71.6*   72.5*   72.3*   72.1*   72.1*   50%
   BM25 margin            63.0    65.5    68.1    70.1*   71.9*   72.5*   72.9*   72.0*   72.1*   72.1*   40%
   top5 vs rest           61.7    62.7    63.0    63.7    64.7    67.6    67.2    68.8    69.7    72.1*   100%
   NQC-like spread        62.4    64.1    64.9    65.3    66.3    67.6    68.6    69.8    71.0*   72.1*   90%
   WIG-like               61.6    61.9    62.6    64.2    65.8    66.5    67.8    68.6    70.2    72.1*   100%
   term coverage top1     62.8    65.2    66.9    67.3    68.7    71.1*   71.4*   71.3*   71.6*   72.1*   60%
   ORACLE                 69.2    74.4*   76.3*   76.3*   76.3*   76.3*   76.3*   76.3*   76.2*   72.1*   20%
   random (expected)      62.1    63.2    64.3    65.4    66.5    67.6    68.7    69.8    71.0    72.1*   100%
   (BM25 only 60.9; rerank ALL 72.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.5[-10.9]   -7.2[-10.4]   -5.5[ -8.4]   -3.7[ -6.3]   -1.5[ -3.8]   -0.5[ -2.3]   +0.4[ -0.9]#  +0.2[ -0.4]#  +0.0[ +0.0]#   70%   (point estimate: 60%)
   BM25 margin           -9.1[-12.6]   -6.5[ -9.8]   -3.9[ -6.9]   -2.0[ -4.5]   -0.2[ -2.4]   +0.4[ -1.4]   +0.8[ -0.3]#  -0.1[ -0.5]#  +0.0[ +0.0]#   70%   (point estimate: 50%)
   top5 vs rest         -10.4[-14.0]   -9.4[-12.7]   -9.1[-12.3]   -8.3[-11.3]   -7.4[-10.1]   -4.5[ -6.8]   -4.9[ -6.9]   -3.3[ -5.1]   -2.3[ -4.0]    100%   (point estimate: 100%)
   NQC-like spread       -9.7[-13.4]   -8.0[-11.5]   -7.1[-10.4]   -6.8[ -9.5]   -5.8[ -8.3]   -4.5[ -6.7]   -3.4[ -5.3]   -2.2[ -3.9]   -1.1[ -2.4]    100%   (point estimate: 100%)
   WIG-like             -10.5[-14.2]  -10.1[-13.8]   -9.5[-12.7]   -7.9[-10.9]   -6.3[ -9.1]   -5.5[ -8.0]   -4.3[ -6.4]   -3.5[ -5.4]   -1.8[ -3.3]    100%   (point estimate: 100%)
   term coverage top1    -9.2[-12.7]   -6.9[-10.0]   -5.1[ -7.8]   -4.8[ -7.2]   -3.4[ -5.5]   -0.9[ -2.3]   -0.6[ -1.7]   -0.7[ -1.7]   -0.5[ -1.2]    100%   (point estimate: 60%)
   ORACLE                -2.9[ -5.5]   +2.4[ +0.6]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.1[ +2.6]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.5[-10.9]   -7.2[-10.4]   -5.5[ -8.4]   -3.7[ -6.3]   -1.5[ -3.8]   -0.5[ -2.3]   +0.4[ -0.9]   +0.2[ -0.4]#  +0.0[ +0.0]#   80%   (point estimate: 60%)
   BM25 margin           -9.1[-12.6]   -6.5[ -9.8]   -3.9[ -6.9]   -2.0[ -4.5]   -0.2[ -2.4]   +0.4[ -1.4]   +0.8[ -0.3]#  -0.1[ -0.5]   +0.0[ +0.0]#   90%   (point estimate: 50%)
   top5 vs rest         -10.4[-14.0]   -9.4[-12.7]   -9.1[-12.3]   -8.3[-11.3]   -7.4[-10.1]   -4.5[ -6.8]   -4.9[ -6.9]   -3.3[ -5.1]   -2.3[ -4.0]    100%   (point estimate: 100%)
   NQC-like spread       -9.7[-13.4]   -8.0[-11.5]   -7.1[-10.4]   -6.8[ -9.5]   -5.8[ -8.3]   -4.5[ -6.7]   -3.4[ -5.3]   -2.2[ -3.9]   -1.1[ -2.4]    100%   (point estimate: 100%)
   WIG-like             -10.5[-14.2]  -10.1[-13.8]   -9.5[-12.7]   -7.9[-10.9]   -6.3[ -9.1]   -5.5[ -8.0]   -4.3[ -6.4]   -3.5[ -5.4]   -1.8[ -3.3]    100%   (point estimate: 100%)
   term coverage top1    -9.2[-12.7]   -6.9[-10.0]   -5.1[ -7.8]   -4.8[ -7.2]   -3.4[ -5.5]   -0.9[ -2.3]   -0.6[ -1.7]   -0.7[ -1.7]   -0.5[ -1.2]    100%   (point estimate: 90%)
   ORACLE                -2.9[ -5.5]   +2.4[ +0.6]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.2[ +2.7]#  +4.1[ +2.6]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      62% (sd  19)   -1.26 MRR              36%     38%
   tag alarm               100      60% (sd  12)   -1.00 MRR              39%     40%
   tag alarm               200      59% (sd   7)   -0.78 MRR              38%     41%
   BM25 margin              50      56% (sd  20)   -1.08 MRR              33%     44%
   BM25 margin             100      52% (sd  13)   -0.83 MRR              36%     48%
   BM25 margin             200      49% (sd   6)   -0.84 MRR              43%     51%
   top5 vs rest             50      95% (sd   9)   -0.89 MRR              26%      5%
   top5 vs rest            100      98% (sd   5)   -0.44 MRR              14%      2%
   top5 vs rest            200     100% (sd   1)   -0.02 MRR               0%      0%
   NQC-like spread          50      91% (sd  15)   -1.17 MRR              42%      9%
   NQC-like spread         100      94% (sd   8)   -0.88 MRR              41%      6%
   NQC-like spread         200      94% (sd   5)   -0.97 MRR              48%      6%
   WIG-like                 50      94% (sd  11)   -1.02 MRR              32%      6%
   WIG-like                100      98% (sd   4)   -0.55 MRR              24%      2%
   WIG-like                200     100% (sd   2)   -0.10 MRR               3%      0%
   term coverage top1       50      76% (sd  21)   -1.28 MRR              27%     24%
   term coverage top1      100      75% (sd  15)   -0.94 MRR              35%     25%
   term coverage top1      200      73% (sd  13)   -1.03 MRR              43%     27%

## beir_nfcorpus  (323 questions; tag alarm fires on 18 = 6%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  42.7  random  41.7  diff  +1.1  p=0.0450
   MRR  : tag  52.2  random  51.2  diff  +1.0  p=0.0087

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.3 (p=0.630)
   40%            +1.2 (p=0.289)        +0.8 (p=0.228)
   50%            +0.0 (p=1.000)        +0.3 (p=0.644)
   6% nat         +0.3 (p=1.000)        +0.4 (p=0.571)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -1.9  95% CI [-6.2, +2.8]  p=0.499
   MRR  :  -2.5  95% CI [-5.7, +0.9]  p=0.147

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  -0.9  p=0.698
   MRR  :  -1.3  p=0.259

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +5.6/+3.8 (p=0.003)  40%: +7.1/+4.8 (p=0.000)  50%: +6.2/+4.4 (p=0.000)  nat: +1.5/+1.5 (p=0.030)
   vs NQC-like spread      30%: +5.6/+3.7 (p=0.003)  40%: +6.5/+4.5 (p=0.001)  50%: +5.9/+4.3 (p=0.000)  nat: +1.5/+1.6 (p=0.019)
   vs WIG-like             30%: +3.7/+2.7 (p=0.023)  40%: +3.7/+2.8 (p=0.030)  50%: +2.5/+2.8 (p=0.027)  nat: +2.2/+1.5 (p=0.037)
   vs term coverage top1   30%: +1.2/+0.6 (p=0.666)  40%: +2.2/+1.1 (p=0.376)  50%: +0.0/-0.1 (p=0.935)  nat: +0.6/+0.4 (p=0.631)

G. each selector reranking 18 questions (6%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.5  [-5.7, +0.9]  p=0.147
   BM25 margin           -2.8  [-6.2, +0.5]  p=0.100
   top5 vs rest          -3.9  [-7.3, -0.6]  p=0.022
   NQC-like spread       -4.0  [-7.4, -0.7]  p=0.018
   WIG-like              -3.9  [-7.3, -0.6]  p=0.018
   term coverage top1    -2.8  [-6.2, +0.6]  p=0.103

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              52.4*   53.5*   54.5*   55.2*   55.3*   55.2*   55.1*   55.0*   54.3*   54.7*   10%
   BM25 margin            52.0*   53.0*   54.2*   54.4*   55.1*   55.1*   55.0*   54.8*   54.3*   54.7*   10%
   top5 vs rest           50.4    50.6    50.7    50.5    50.9    51.4    53.1*   53.9*   54.2*   54.7*   70%
   NQC-like spread        49.5    50.5    50.8    50.8    51.1    52.3    53.6*   54.4*   54.5*   54.7*   70%
   WIG-like               50.2    50.6    51.8    52.5*   52.6*   52.2    53.1*   53.4*   54.2*   54.7*   70%
   term coverage top1     52.6*   52.9*   53.9*   54.1*   55.4*   55.1*   55.1*   54.4*   54.2*   54.7*   10%
   ORACLE                 58.4*   61.2*   61.4*   61.4*   61.4*   61.4*   61.4*   61.4*   60.0*   54.7*   10%
   random (expected)      51.3    51.7    52.1    52.4    52.8    53.2    53.5    53.9    54.3    54.7*   100%
   (BM25 only 51.0; rerank ALL 54.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.3[ -5.4]   -1.2[ -4.0]   -0.2[ -2.8]   +0.6[ -1.7]   +0.7[ -1.4]   +0.6[ -1.2]   +0.4[ -1.1]   +0.4[ -1.0]   -0.3[ -1.3]    100%   (point estimate: 30%)
   BM25 margin           -2.6[ -5.8]   -1.6[ -4.6]   -0.5[ -3.2]   -0.2[ -2.6]   +0.4[ -1.6]   +0.5[ -1.4]   +0.3[ -1.2]   +0.1[ -1.3]   -0.3[ -1.3]    100%   (point estimate: 30%)
   top5 vs rest          -4.2[ -7.3]   -4.0[ -7.0]   -3.9[ -6.7]   -4.2[ -6.8]   -3.8[ -6.2]   -3.2[ -5.5]   -1.5[ -3.5]   -0.7[ -2.0]   -0.5[ -1.4]    100%   (point estimate: 80%)
   NQC-like spread       -5.1[ -8.2]   -4.1[ -7.0]   -3.9[ -6.7]   -3.9[ -6.4]   -3.6[ -5.9]   -2.3[ -4.5]   -1.0[ -2.8]   -0.3[ -1.5]   -0.2[ -1.1]    100%   (point estimate: 80%)
   WIG-like              -4.4[ -7.6]   -4.0[ -6.9]   -2.9[ -5.5]   -2.2[ -4.6]   -2.1[ -4.4]   -2.4[ -4.5]   -1.6[ -3.5]   -1.2[ -2.9]   -0.4[ -1.4]    100%   (point estimate: 90%)
   term coverage top1    -2.0[ -5.0]   -1.8[ -4.7]   -0.7[ -3.3]   -0.5[ -2.8]   +0.8[ -1.2]   +0.5[ -1.3]   +0.5[ -1.0]#  -0.3[ -1.6]   -0.5[ -1.5]    100%   (point estimate: 30%)
   ORACLE                +3.7[ +1.5]#  +6.5[ +4.8]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +5.3[ +3.6]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.3[ -5.4]   -1.2[ -4.0]   -0.2[ -2.8]   +0.6[ -1.7]   +0.7[ -1.4]   +0.6[ -1.2]   +0.4[ -1.1]   +0.4[ -1.0]   -0.3[ -1.3]    100%   (point estimate: 30%)
   BM25 margin           -2.6[ -5.8]   -1.6[ -4.6]   -0.5[ -3.2]   -0.2[ -2.6]   +0.4[ -1.6]   +0.5[ -1.4]   +0.3[ -1.2]   +0.1[ -1.3]   -0.3[ -1.3]    100%   (point estimate: 30%)
   top5 vs rest          -4.2[ -7.3]   -4.0[ -7.0]   -3.9[ -6.7]   -4.2[ -6.8]   -3.8[ -6.2]   -3.2[ -5.5]   -1.5[ -3.5]   -0.7[ -2.0]   -0.5[ -1.4]    100%   (point estimate: 90%)
   NQC-like spread       -5.1[ -8.2]   -4.1[ -7.0]   -3.9[ -6.7]   -3.9[ -6.4]   -3.6[ -5.9]   -2.3[ -4.5]   -1.0[ -2.8]   -0.3[ -1.5]   -0.2[ -1.1]    100%   (point estimate: 80%)
   WIG-like              -4.4[ -7.6]   -4.0[ -6.9]   -2.9[ -5.5]   -2.2[ -4.6]   -2.1[ -4.4]   -2.4[ -4.5]   -1.6[ -3.5]   -1.2[ -2.9]   -0.4[ -1.4]    100%   (point estimate: 90%)
   term coverage top1    -2.0[ -5.0]   -1.8[ -4.7]   -0.7[ -3.3]   -0.5[ -2.8]   +0.8[ -1.2]   +0.5[ -1.3]   +0.5[ -1.0]   -0.3[ -1.6]   -0.5[ -1.5]    100%   (point estimate: 50%)
   ORACLE                +3.7[ +1.5]#  +6.5[ +4.8]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +6.7[ +5.0]#  +5.3[ +3.6]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      49% (sd  33)   -0.66 MRR              34%     51%
   tag alarm               100      38% (sd  28)   -0.92 MRR              40%     62%
   tag alarm               200      29% (sd  15)   -1.02 MRR              48%     71%
   BM25 margin              50      52% (sd  34)   -0.98 MRR              32%     48%
   BM25 margin             100      43% (sd  29)   -1.15 MRR              44%     57%
   BM25 margin             200      33% (sd  17)   -1.56 MRR              50%     67%
   top5 vs rest             50      76% (sd  26)   -1.39 MRR              38%     24%
   top5 vs rest            100      82% (sd  18)   -1.16 MRR              39%     18%
   top5 vs rest            200      82% (sd   9)   -1.05 MRR              44%     18%
   NQC-like spread          50      72% (sd  26)   -1.55 MRR              40%     28%
   NQC-like spread         100      76% (sd  17)   -1.06 MRR              30%     24%
   NQC-like spread         200      75% (sd   8)   -0.90 MRR              40%     25%
   WIG-like                 50      78% (sd  26)   -1.27 MRR              44%     22%
   WIG-like                100      81% (sd  21)   -1.13 MRR              39%     19%
   WIG-like                200      83% (sd  13)   -1.11 MRR              40%     17%
   term coverage top1       50      54% (sd  34)   -0.84 MRR              32%     46%
   term coverage top1      100      47% (sd  29)   -0.75 MRR              33%     53%
   term coverage top1      200      34% (sd  18)   -1.18 MRR              44%     66%

## beir_fiqa  (648 questions; tag alarm fires on 199 = 31%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  37.0  random  36.2  diff  +0.9  p=0.1861
   MRR  : tag  47.1  random  46.3  diff  +0.8  p=0.1137

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -2.2 (p=0.139)        -1.4 (p=0.189)
   40%            -2.5 (p=0.072)        -1.7 (p=0.083)
   50%            -0.3 (p=0.893)        -0.0 (p=0.990)
   31% nat        -2.5 (p=0.091)        -1.6 (p=0.135)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -5.9  95% CI [-9.0, -2.8]  p=0.000
   MRR  :  -5.1  95% CI [-7.4, -2.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (51%)
   Hit@1:  +1.1  p=0.464
   MRR  :  +1.0  p=0.290

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/-0.1 (p=0.903)  40%: +1.2/+0.8 (p=0.433)  50%: +3.1/+1.8 (p=0.047)  nat: +0.0/-0.3 (p=0.776)
   vs NQC-like spread      30%: +0.2/-0.1 (p=0.916)  40%: +0.5/+0.3 (p=0.773)  50%: +2.8/+2.1 (p=0.025)  nat: +0.0/-0.2 (p=0.875)
   vs WIG-like             30%: +1.1/+1.2 (p=0.219)  40%: +1.4/+1.3 (p=0.205)  50%: +3.9/+2.9 (p=0.004)  nat: +0.5/+0.7 (p=0.496)
   vs term coverage top1   30%: +0.3/+0.3 (p=0.738)  40%: -0.2/-0.3 (p=0.723)  50%: +0.9/+0.2 (p=0.809)  nat: -0.2/-0.2 (p=0.855)

G. each selector reranking 199 questions (31%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -5.1  [-7.4, -2.8]  p=0.000
   BM25 margin           -3.5  [-5.8, -1.2]  p=0.003
   top5 vs rest          -4.8  [-7.2, -2.4]  p=0.000
   NQC-like spread       -4.9  [-7.3, -2.6]  p=0.000
   WIG-like              -5.8  [-8.0, -3.5]  p=0.000
   term coverage top1    -4.9  [-7.1, -2.7]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              45.0    46.5    47.3    48.3    50.4*   51.2*   52.4*   52.6*   52.3*   52.2*   50%
   BM25 margin            45.0    46.9    48.7    50.0    50.4*   52.0*   52.3*   53.1*   52.3*   52.2*   50%
   top5 vs rest           44.9    46.2    47.4    47.5    48.6    48.9    50.1    50.5    51.6*   52.2*   90%
   NQC-like spread        45.0    46.6    47.4    48.0    48.3    50.2    50.3    51.5*   51.5*   52.2*   80%
   WIG-like               44.1    45.2    46.1    47.0    47.5    48.5    49.9    50.8    51.2    52.2*   100%
   term coverage top1     45.1    46.0    47.0    48.6    50.2    50.6    51.4*   51.6*   52.0*   52.2*   70%
   ORACLE                 52.2*   57.3*   58.9*   59.0*   59.0*   59.0*   59.0*   59.0*   58.1*   52.2*   10%
   random (expected)      44.5    45.4    46.2    47.1    47.9    48.8    49.6    50.5    51.3    52.2*   100%
   (BM25 only 43.7; rerank ALL 52.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.2[ -9.8]   -5.7[ -8.3]   -4.9[ -7.3]   -3.9[ -6.0]   -1.8[ -3.6]   -1.0[ -2.5]   +0.2[ -0.9]#  +0.4[ -0.5]#  +0.1[ -0.4]#   70%   (point estimate: 60%)
   BM25 margin           -7.2[ -9.9]   -5.3[ -7.8]   -3.5[ -5.8]   -2.2[ -4.3]   -1.8[ -3.7]   -0.2[ -1.8]   +0.1[ -1.2]   +0.9[ -0.1]#  +0.1[ -0.6]#   80%   (point estimate: 60%)
   top5 vs rest          -7.3[-10.0]   -6.0[ -8.6]   -4.8[ -7.3]   -4.7[ -6.9]   -3.5[ -5.6]   -3.3[ -5.1]   -2.1[ -3.6]   -1.7[ -3.1]   -0.6[ -1.5]    100%   (point estimate: 90%)
   NQC-like spread       -7.2[ -9.9]   -5.6[ -8.2]   -4.8[ -7.2]   -4.2[ -6.4]   -3.9[ -5.9]   -2.0[ -3.7]   -1.9[ -3.4]   -0.7[ -1.9]   -0.7[ -1.6]    100%   (point estimate: 80%)
   WIG-like              -8.0[-10.7]   -7.0[ -9.5]   -6.0[ -8.4]   -5.2[ -7.4]   -4.7[ -6.8]   -3.7[ -5.3]   -2.3[ -3.7]   -1.4[ -2.6]   -1.0[ -1.9]    100%   (point estimate: 100%)
   term coverage top1    -7.1[ -9.7]   -6.2[ -8.8]   -5.2[ -7.5]   -3.6[ -5.6]   -2.0[ -3.8]   -1.6[ -3.2]   -0.7[ -1.9]   -0.6[ -1.5]   -0.2[ -0.7]#   90%   (point estimate: 70%)
   ORACLE                +0.0[ -2.0]   +5.2[ +3.7]#  +6.7[ +5.3]#  +6.8[ +5.4]#  +6.8[ +5.4]#  +6.8[ +5.4]#  +6.8[ +5.4]#  +6.8[ +5.4]#  +5.9[ +4.5]#   20%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.2[ -9.8]   -5.7[ -8.3]   -4.9[ -7.3]   -3.9[ -6.0]   -1.8[ -3.6]   -1.0[ -2.5]   +0.2[ -0.9]   +0.4[ -0.5]#  +0.1[ -0.4]#   80%   (point estimate: 70%)
   BM25 margin           -7.2[ -9.9]   -5.3[ -7.8]   -3.5[ -5.8]   -2.2[ -4.3]   -1.8[ -3.7]   -0.2[ -1.8]   +0.1[ -1.2]   +0.9[ -0.1]#  +0.1[ -0.6]    100%   (point estimate: 60%)
   top5 vs rest          -7.3[-10.0]   -6.0[ -8.6]   -4.8[ -7.3]   -4.7[ -6.9]   -3.5[ -5.6]   -3.3[ -5.1]   -2.1[ -3.6]   -1.7[ -3.1]   -0.6[ -1.5]    100%   (point estimate: 100%)
   NQC-like spread       -7.2[ -9.9]   -5.6[ -8.2]   -4.8[ -7.2]   -4.2[ -6.4]   -3.9[ -5.9]   -2.0[ -3.7]   -1.9[ -3.4]   -0.7[ -1.9]   -0.7[ -1.6]    100%   (point estimate: 100%)
   WIG-like              -8.0[-10.7]   -7.0[ -9.5]   -6.0[ -8.4]   -5.2[ -7.4]   -4.7[ -6.8]   -3.7[ -5.3]   -2.3[ -3.7]   -1.4[ -2.6]   -1.0[ -1.9]    100%   (point estimate: 100%)
   term coverage top1    -7.1[ -9.7]   -6.2[ -8.8]   -5.2[ -7.5]   -3.6[ -5.6]   -2.0[ -3.8]   -1.6[ -3.2]   -0.7[ -1.9]   -0.6[ -1.5]   -0.2[ -0.7]    100%   (point estimate: 90%)
   ORACLE                +0.0[ -2.0]   +5.2[ +3.7]#  +6.7[ +5.3]#  +6.8[ +5.4]#  +6.8[ +5.4]#  +6.8[ +5.4]#  +6.8[ +5.4]#  +6.8[ +5.4]#  +5.9[ +4.5]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      65% (sd  23)   -1.19 MRR              42%     35%
   tag alarm               100      66% (sd  17)   -0.82 MRR              39%     34%
   tag alarm               200      63% (sd  11)   -0.87 MRR              46%     37%
   BM25 margin              50      65% (sd  26)   -1.19 MRR              34%     35%
   BM25 margin             100      60% (sd  23)   -1.26 MRR              36%     40%
   BM25 margin             200      60% (sd  14)   -0.75 MRR              28%     40%
   top5 vs rest             50      79% (sd  26)   -1.65 MRR              42%     21%
   top5 vs rest            100      84% (sd  17)   -1.27 MRR              42%     16%
   top5 vs rest            200      87% (sd  13)   -1.12 MRR              37%     13%
   NQC-like spread          50      78% (sd  26)   -1.50 MRR              32%     22%
   NQC-like spread         100      81% (sd  22)   -1.32 MRR              29%     19%
   NQC-like spread         200      81% (sd  17)   -1.27 MRR              36%     19%
   WIG-like                 50      83% (sd  25)   -1.58 MRR              52%     17%
   WIG-like                100      90% (sd  14)   -0.94 MRR              48%     10%
   WIG-like                200      92% (sd  11)   -0.87 MRR              42%      8%
   term coverage top1       50      71% (sd  27)   -1.57 MRR              30%     29%
   term coverage top1      100      74% (sd  21)   -1.16 MRR              33%     26%
   term coverage top1      200      69% (sd  16)   -1.31 MRR              46%     31%

## beir_arguana  (1401 questions; tag alarm fires on 12 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.3  diff  -0.2  p=0.9990
   MRR  : tag  24.7  random  24.8  diff  -0.1  p=0.9674

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.1 (p=0.501)        -0.1 (p=0.275)
   40%            -0.1 (p=1.000)        -0.1 (p=0.072)
   50%            -0.1 (p=1.000)        -0.0 (p=0.745)
   1% nat         +0.0 (p=1.000)        -0.0 (p=0.659)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -18.6  95% CI [-20.7, -16.6]  p=0.000
   MRR  : -19.1  95% CI [-20.7, -17.4]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (19%)
   Hit@1:  +5.9  p=0.000
   MRR  :  +1.9  p=0.000

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.1/+1.0 (p=0.201)  40%: +1.4/+1.5 (p=0.065)  50%: +1.4/+1.5 (p=0.064)  nat: -0.1/-0.2 (p=0.075)
   vs NQC-like spread      30%: +0.7/+0.6 (p=0.431)  40%: +1.1/+1.2 (p=0.107)  50%: +1.3/+1.5 (p=0.058)  nat: -0.1/-0.2 (p=0.047)
   vs WIG-like             30%: +2.0/+1.5 (p=0.033)  40%: +1.9/+1.5 (p=0.052)  50%: +1.6/+1.3 (p=0.095)  nat: +0.0/+0.1 (p=0.197)
   vs term coverage top1   30%: +1.5/+1.4 (p=0.029)  40%: +2.2/+2.1 (p=0.002)  50%: +1.9/+1.9 (p=0.008)  nat: +0.0/-0.0 (p=0.417)

G. each selector reranking 12 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -19.1  [-20.7, -17.4]  p=0.000
   BM25 margin          -19.1  [-20.7, -17.4]  p=0.000
   top5 vs rest         -18.9  [-20.6, -17.3]  p=0.000
   NQC-like spread      -18.9  [-20.6, -17.2]  p=0.000
   WIG-like             -19.2  [-20.8, -17.5]  p=0.000
   term coverage top1   -19.1  [-20.7, -17.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              26.7    28.8    31.3    33.5    35.5    36.6    38.8    40.9    42.6    43.8*   100%
   BM25 margin            26.9    29.0    31.4    33.6    35.5    36.6    38.8    40.9    42.6    43.8*   100%
   top5 vs rest           26.7    29.1    30.3    32.0    33.9    35.5    37.5    39.6    41.4    43.8*   100%
   NQC-like spread        26.9    29.2    30.7    32.2    33.9    35.8    37.7    39.6    41.4    43.8*   100%
   WIG-like               25.6    27.9    29.7    32.0    34.1    36.4    38.2    40.3    42.1    43.8*   100%
   term coverage top1     26.4    28.2    29.8    31.3    33.6    35.8    37.7    40.3    42.2    43.8*   100%
   ORACLE                 33.2    38.6    42.5    45.1*   46.7*   47.4*   47.4*   47.4*   46.4*   43.8*   40%
   random (expected)      26.6    28.5    30.4    32.3    34.2    36.1    38.1    40.0    41.9    43.8*   100%
   (BM25 only 24.7; rerank ALL 43.8)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -17.1[-18.7]  -15.0[-16.5]  -12.5[-14.0]  -10.3[-11.7]   -8.3[ -9.6]   -7.2[ -8.4]   -5.0[ -6.0]   -2.9[ -3.7]   -1.2[ -1.8]    100%   (point estimate: 100%)
   BM25 margin          -16.9[-18.5]  -14.8[-16.3]  -12.4[-13.9]  -10.2[-11.6]   -8.3[ -9.6]   -7.2[ -8.4]   -5.0[ -6.0]   -2.9[ -3.7]   -1.2[ -1.8]    100%   (point estimate: 100%)
   top5 vs rest         -17.1[-18.8]  -14.7[-16.3]  -13.5[-15.0]  -11.8[-13.2]   -9.9[-11.1]   -8.3[ -9.4]   -6.3[ -7.3]   -4.2[ -5.0]   -2.4[ -3.1]    100%   (point estimate: 100%)
   NQC-like spread      -16.8[-18.6]  -14.6[-16.1]  -13.1[-14.6]  -11.6[-13.0]   -9.8[-11.1]   -8.0[ -9.1]   -6.1[ -7.1]   -4.2[ -5.0]   -2.4[ -3.1]    100%   (point estimate: 100%)
   WIG-like             -18.1[-19.8]  -15.9[-17.5]  -14.0[-15.6]  -11.8[-13.2]   -9.7[-10.9]   -7.4[ -8.5]   -5.6[ -6.5]   -3.5[ -4.2]   -1.7[ -2.2]    100%   (point estimate: 100%)
   term coverage top1   -17.4[-19.1]  -15.6[-17.1]  -13.9[-15.4]  -12.4[-13.9]  -10.2[-11.5]   -8.0[ -9.2]   -6.0[ -7.1]   -3.5[ -4.3]   -1.5[ -2.1]    100%   (point estimate: 100%)
   ORACLE               -10.6[-11.8]   -5.2[ -6.1]   -1.3[ -2.0]   +1.3[ +0.7]#  +2.9[ +2.4]#  +3.6[ +3.2]#  +3.6[ +3.2]#  +3.6[ +3.1]#  +2.6[ +2.2]#   40%   (point estimate: 40%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -17.1[-18.7]  -15.0[-16.5]  -12.5[-14.0]  -10.3[-11.7]   -8.3[ -9.6]   -7.2[ -8.4]   -5.0[ -6.0]   -2.9[ -3.7]   -1.2[ -1.8]    100%   (point estimate: 100%)
   BM25 margin          -16.9[-18.5]  -14.8[-16.3]  -12.4[-13.9]  -10.2[-11.6]   -8.3[ -9.6]   -7.2[ -8.4]   -5.0[ -6.0]   -2.9[ -3.7]   -1.2[ -1.8]    100%   (point estimate: 100%)
   top5 vs rest         -17.1[-18.8]  -14.7[-16.3]  -13.5[-15.0]  -11.8[-13.2]   -9.9[-11.1]   -8.3[ -9.4]   -6.3[ -7.3]   -4.2[ -5.0]   -2.4[ -3.1]    100%   (point estimate: 100%)
   NQC-like spread      -16.8[-18.6]  -14.6[-16.1]  -13.1[-14.6]  -11.6[-13.0]   -9.8[-11.1]   -8.0[ -9.1]   -6.1[ -7.1]   -4.2[ -5.0]   -2.4[ -3.1]    100%   (point estimate: 100%)
   WIG-like             -18.1[-19.8]  -15.9[-17.5]  -14.0[-15.6]  -11.8[-13.2]   -9.7[-10.9]   -7.4[ -8.5]   -5.6[ -6.5]   -3.5[ -4.2]   -1.7[ -2.2]    100%   (point estimate: 100%)
   term coverage top1   -17.4[-19.1]  -15.6[-17.1]  -13.9[-15.4]  -12.4[-13.9]  -10.2[-11.5]   -8.0[ -9.2]   -6.0[ -7.1]   -3.5[ -4.3]   -1.5[ -2.1]    100%   (point estimate: 100%)
   ORACLE               -10.6[-11.8]   -5.2[ -6.1]   -1.3[ -2.0]   +1.3[ +0.7]#  +2.9[ +2.4]#  +3.6[ +3.2]#  +3.6[ +3.2]#  +3.6[ +3.1]#  +2.6[ +2.2]#   40%   (point estimate: 40%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      94% (sd   8)   -0.83 MRR              42%      6%
   tag alarm               100      96% (sd   6)   -0.56 MRR              35%      4%
   tag alarm               200      97% (sd   5)   -0.44 MRR              32%      3%
   BM25 margin              50      94% (sd   8)   -0.86 MRR              42%      6%
   BM25 margin             100      96% (sd   6)   -0.62 MRR              38%      4%
   BM25 margin             200      97% (sd   4)   -0.36 MRR              27%      3%
   top5 vs rest             50      98% (sd   5)   -0.41 MRR              14%      2%
   top5 vs rest            100     100% (sd   2)   -0.10 MRR               4%      0%
   top5 vs rest            200     100% (sd   1)   -0.01 MRR               0%      0%
   NQC-like spread          50      98% (sd   5)   -0.47 MRR              16%      2%
   NQC-like spread         100      99% (sd   3)   -0.19 MRR               6%      1%
   NQC-like spread         200     100% (sd   1)   -0.01 MRR               0%      0%
   WIG-like                 50      97% (sd   6)   -0.52 MRR              24%      3%
   WIG-like                100      97% (sd   5)   -0.54 MRR              27%      3%
   WIG-like                200      99% (sd   3)   -0.14 MRR               8%      1%
   term coverage top1       50      97% (sd   6)   -0.61 MRR              24%      3%
   term coverage top1      100      98% (sd   5)   -0.45 MRR              21%      2%
   term coverage top1      200      99% (sd   3)   -0.19 MRR               8%      1%

## beir_scidocs  (1000 questions; tag alarm fires on 129 = 13%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  23.8  random  23.4  diff  +0.4  p=0.2342
   MRR  : tag  36.4  random  36.3  diff  +0.1  p=0.4214

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.7 (p=0.297)        +0.4 (p=0.391)
   40%            +0.0 (p=1.000)        -0.0 (p=0.927)
   50%            +0.2 (p=0.817)        +0.2 (p=0.580)
   13% nat        +0.8 (p=0.239)        +0.5 (p=0.260)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +2.9  95% CI [+0.4, +5.3]  p=0.022
   MRR  :  +3.3  95% CI [+1.4, +5.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (49%)
   Hit@1:  -0.9  p=0.354
   MRR  :  -0.6  p=0.331

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -1.3/-1.1 (p=0.081)  40%: -1.4/-1.2 (p=0.087)  50%: -1.2/-1.2 (p=0.118)  nat: +0.0/-0.1 (p=0.883)
   vs NQC-like spread      30%: -0.8/-0.7 (p=0.290)  40%: -0.9/-0.7 (p=0.312)  50%: -1.0/-1.0 (p=0.152)  nat: +0.1/+0.1 (p=0.863)
   vs WIG-like             30%: -0.3/-0.8 (p=0.235)  40%: -1.1/-1.1 (p=0.102)  50%: -0.3/-0.6 (p=0.457)  nat: -0.4/-0.6 (p=0.235)
   vs term coverage top1   30%: -0.6/-0.7 (p=0.273)  40%: -0.8/-0.9 (p=0.196)  50%: +0.2/-0.1 (p=0.885)  nat: +0.0/-0.2 (p=0.693)

G. each selector reranking 129 questions (13%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +3.3  [+1.4, +5.2]  p=0.000
   BM25 margin           +2.7  [+0.9, +4.6]  p=0.004
   top5 vs rest          +3.3  [+1.4, +5.3]  p=0.000
   NQC-like spread       +3.2  [+1.3, +5.1]  p=0.001
   WIG-like              +3.9  [+2.0, +5.8]  p=0.000
   term coverage top1    +3.5  [+1.6, +5.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              36.4*   35.9*   35.7*   35.2*   35.0*   34.6*   34.6*   34.6*   33.9*   33.1*   10%
   BM25 margin            36.2*   35.8*   35.3*   35.2*   34.8*   34.4*   34.7*   34.5*   34.0*   33.1*   10%
   top5 vs rest           36.5*   36.6*   36.8*   36.4*   36.2*   35.5*   34.7*   34.5*   33.6*   33.1*   10%
   NQC-like spread        36.3*   36.8*   36.3*   35.9*   36.1*   35.7*   34.8*   34.3*   33.6*   33.1*   10%
   WIG-like               37.2*   36.6*   36.5*   36.3*   35.6*   34.7*   34.7*   34.2*   33.8*   33.1*   10%
   term coverage top1     37.0*   36.5*   36.4*   36.0*   35.1*   34.7*   34.4*   34.2*   33.3*   33.1*   10%
   ORACLE                 42.7*   44.2*   44.5*   44.5*   44.5*   44.5*   44.2*   43.3*   40.4*   33.1*   10%
   random (expected)      36.4*   36.1*   35.7*   35.3*   35.0*   34.6*   34.2*   33.9*   33.5*   33.1*   10%
   (BM25 only 36.8; rerank ALL 33.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +3.3[ +1.5]#  +2.8[ +1.0]#  +2.5[ +0.9]#  +2.1[ +0.5]#  +1.9[ +0.5]#  +1.5[ +0.3]#  +1.5[ +0.5]#  +1.5[ +0.7]#  +0.8[ +0.3]#   10%   (point estimate: 10%)
   BM25 margin           +3.1[ +1.1]#  +2.7[ +0.9]#  +2.2[ +0.6]#  +2.1[ +0.6]#  +1.7[ +0.4]#  +1.3[ +0.1]#  +1.6[ +0.6]#  +1.4[ +0.6]#  +0.9[ +0.3]#   10%   (point estimate: 10%)
   top5 vs rest          +3.4[ +1.4]#  +3.5[ +1.6]#  +3.7[ +1.9]#  +3.2[ +1.6]#  +3.1[ +1.6]#  +2.4[ +1.1]#  +1.6[ +0.4]#  +1.3[ +0.4]#  +0.5[ -0.2]#   10%   (point estimate: 10%)
   NQC-like spread       +3.2[ +1.2]#  +3.7[ +1.8]#  +3.2[ +1.4]#  +2.8[ +1.1]#  +2.9[ +1.4]#  +2.6[ +1.3]#  +1.6[ +0.4]#  +1.1[ +0.2]#  +0.5[ -0.2]#   10%   (point estimate: 10%)
   WIG-like              +4.1[ +2.1]#  +3.5[ +1.5]#  +3.4[ +1.6]#  +3.2[ +1.6]#  +2.5[ +1.0]#  +1.6[ +0.3]#  +1.6[ +0.4]#  +1.1[ +0.1]#  +0.7[ +0.0]#   10%   (point estimate: 10%)
   term coverage top1    +3.8[ +1.9]#  +3.4[ +1.6]#  +3.3[ +1.6]#  +2.9[ +1.4]#  +2.0[ +0.7]#  +1.6[ +0.4]#  +1.3[ +0.4]#  +1.1[ +0.4]#  +0.1[ -0.3]#   10%   (point estimate: 10%)
   ORACLE                +9.6[ +8.2]# +11.1[ +9.7]# +11.4[+10.0]# +11.4[+10.0]# +11.4[+10.0]# +11.3[+10.0]# +11.1[ +9.7]# +10.1[ +8.7]#  +7.2[ +5.9]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +3.3[ +1.5]#  +2.8[ +1.0]#  +2.5[ +0.9]#  +2.1[ +0.5]#  +1.9[ +0.5]#  +1.5[ +0.3]#  +1.5[ +0.5]#  +1.5[ +0.7]#  +0.8[ +0.3]#   10%   (point estimate: 10%)
   BM25 margin           +3.1[ +1.1]#  +2.7[ +0.9]#  +2.2[ +0.6]#  +2.1[ +0.6]#  +1.7[ +0.4]#  +1.3[ +0.1]#  +1.6[ +0.6]#  +1.4[ +0.6]#  +0.9[ +0.3]#   10%   (point estimate: 10%)
   top5 vs rest          +3.4[ +1.4]#  +3.5[ +1.6]#  +3.7[ +1.9]#  +3.2[ +1.6]#  +3.1[ +1.6]#  +2.4[ +1.1]#  +1.6[ +0.4]#  +1.3[ +0.4]#  +0.5[ -0.2]#   10%   (point estimate: 10%)
   NQC-like spread       +3.2[ +1.2]#  +3.7[ +1.8]#  +3.2[ +1.4]#  +2.8[ +1.1]#  +2.9[ +1.4]#  +2.6[ +1.3]#  +1.6[ +0.4]#  +1.1[ +0.2]#  +0.5[ -0.2]#   10%   (point estimate: 10%)
   WIG-like              +4.1[ +2.1]#  +3.5[ +1.5]#  +3.4[ +1.6]#  +3.2[ +1.6]#  +2.5[ +1.0]#  +1.6[ +0.3]#  +1.6[ +0.4]#  +1.1[ +0.1]#  +0.7[ +0.0]#   10%   (point estimate: 10%)
   term coverage top1    +3.8[ +1.9]#  +3.4[ +1.6]#  +3.3[ +1.6]#  +2.9[ +1.4]#  +2.0[ +0.7]#  +1.6[ +0.4]#  +1.3[ +0.4]#  +1.1[ +0.4]#  +0.1[ -0.3]#   10%   (point estimate: 10%)
   ORACLE                +9.6[ +8.2]# +11.1[ +9.7]# +11.4[+10.0]# +11.4[+10.0]# +11.4[+10.0]# +11.3[+10.0]# +11.1[ +9.7]# +10.1[ +8.7]#  +7.2[ +5.9]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      31% (sd  33)   +2.57 MRR               0%     69%
   tag alarm               100      22% (sd  25)   +2.91 MRR               0%     78%
   tag alarm               200      12% (sd  10)   +3.21 MRR               0%     88%
   BM25 margin              50      31% (sd  33)   +2.36 MRR               0%     69%
   BM25 margin             100      21% (sd  24)   +2.71 MRR               0%     79%
   BM25 margin             200      12% (sd   9)   +2.99 MRR               0%     88%
   top5 vs rest             50      31% (sd  35)   +2.67 MRR               0%     69%
   top5 vs rest            100      23% (sd  30)   +2.98 MRR               0%     77%
   top5 vs rest            200      12% (sd  12)   +3.35 MRR               0%     88%
   NQC-like spread          50      36% (sd  38)   +2.35 MRR               0%     64%
   NQC-like spread         100      20% (sd  27)   +2.84 MRR               0%     80%
   NQC-like spread         200      13% (sd  14)   +3.15 MRR               0%     87%
   WIG-like                 50      38% (sd  37)   +2.78 MRR               0%     62%
   WIG-like                100      22% (sd  29)   +3.43 MRR               0%     78%
   WIG-like                200      11% (sd  10)   +3.90 MRR               0%     89%
   term coverage top1       50      32% (sd  35)   +2.86 MRR               0%     68%
   term coverage top1      100      20% (sd  25)   +3.36 MRR               0%     80%
   term coverage top1      200      11% (sd  10)   +3.72 MRR               0%     89%

## POOLED over 5 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  21.3  random  20.8  diff  +0.5  p=0.0228
   MRR  : tag  37.5  random  37.2  diff  +0.3  p=0.0286

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  -0.5 (p=0.180)   MRR  -0.3 (p=0.243)
   40%      Hit@1  -0.6 (p=0.071)   MRR  -0.4 (p=0.062)
   50%      Hit@1  -0.1 (p=0.665)   MRR  -0.0 (p=0.812)
   natural  Hit@1  -0.2 (p=0.515)   MRR  -0.2 (p=0.506)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -8.3  95% CI [-9.6, -7.0]  p=0.000
   MRR  :  -8.1  95% CI [-9.2, -7.1]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +2.2  p=0.000
   MRR  :  +0.6  p=0.114

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.0/+0.7 (p=0.110)  40%: +1.5/+1.2 (p=0.007)  50%: +2.0/+1.4 (p=0.002)  nat: +0.3/+0.1 (p=0.618)
   vs NQC-like spread      30%: +0.8/+0.5 (p=0.242)  40%: +1.2/+1.0 (p=0.023)  50%: +1.8/+1.4 (p=0.002)  nat: +0.3/+0.1 (p=0.644)
   vs WIG-like             30%: +1.7/+1.1 (p=0.005)  40%: +1.6/+1.1 (p=0.013)  50%: +2.1/+1.5 (p=0.001)  nat: +0.5/+0.3 (p=0.181)
   vs term coverage top1   30%: +0.6/+0.4 (p=0.264)  40%: +1.0/+0.7 (p=0.074)  50%: +1.3/+0.9 (p=0.028)  nat: +0.1/-0.1 (p=0.769)
