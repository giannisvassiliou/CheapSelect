## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  28.5  random  26.7  diff  +1.9  p=0.0101
   MRR  : tag  35.9  random  34.6  diff  +1.3  p=0.0184

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.8 (p=0.634)        -0.8 (p=0.434)
   40%            +2.0 (p=0.088)        +1.5 (p=0.080)
   50%            +1.9 (p=0.073)        +1.3 (p=0.077)
   25% nat        -0.6 (p=0.734)        -1.1 (p=0.353)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -11.7  95% CI [-14.7, -8.6]  p=0.000
   MRR  : -12.1  95% CI [-14.5, -9.7]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (52%)
   Hit@1:  +4.2  p=0.001
   MRR  :  +2.5  p=0.015

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.2/-0.2 (p=0.879)  40%: +2.6/+2.0 (p=0.086)  50%: +2.6/+1.9 (p=0.085)  nat: +0.6/+0.0 (p=0.998)
   vs NQC-like spread      30%: +0.3/-0.1 (p=0.950)  40%: +2.8/+2.2 (p=0.049)  50%: +2.3/+1.8 (p=0.105)  nat: +0.2/-0.5 (p=0.598)
   vs WIG-like             30%: +0.9/+0.6 (p=0.535)  40%: +3.2/+2.6 (p=0.016)  50%: +2.6/+2.2 (p=0.045)  nat: +1.1/+0.6 (p=0.569)
   vs term coverage top1   30%: +1.2/+1.2 (p=0.193)  40%: +2.5/+2.5 (p=0.014)  50%: +1.4/+1.5 (p=0.155)  nat: +1.5/+1.2 (p=0.155)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -12.1  [-14.5, -9.7]  p=0.000
   BM25 margin          -11.0  [-13.3, -8.7]  p=0.000
   top5 vs rest         -12.1  [-14.5, -9.7]  p=0.000
   NQC-like spread      -11.5  [-13.8, -9.3]  p=0.000
   WIG-like             -12.6  [-15.0, -10.3]  p=0.000
   term coverage top1   -13.3  [-15.8, -10.9]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              32.8    34.9    37.1    40.6    41.9    43.2    44.1    45.8    47.4    48.0*   100%
   BM25 margin            32.6    35.9    37.9    39.0    40.5    41.8    43.7    45.6    47.0    48.0*   100%
   top5 vs rest           32.4    34.9    37.3    38.6    40.0    41.3    43.3    45.1    46.3    48.0*   100%
   NQC-like spread        33.3    35.9    37.2    38.4    40.1    41.7    43.6    44.8    46.6    48.0*   100%
   WIG-like               32.1    34.1    36.5    38.0    39.7    41.7    43.2    45.1    46.7    48.0*   100%
   term coverage top1     32.1    34.0    35.9    38.1    40.4    42.4    44.6    45.3    46.9    48.0*   100%
   ORACLE                 39.5    46.2    49.5*   50.5*   50.5*   50.5*   50.5*   50.5*   50.5*   48.0*   30%
   random (expected)      32.0    33.8    35.6    37.3    39.1    40.9    42.7    44.4    46.2    48.0*   100%
   (BM25 only 30.3; rerank ALL 48.0)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.96 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -15.2[-17.7]  -13.1[-15.5]  -10.9[-13.1]   -7.4[ -9.3]   -6.1[ -7.7]   -4.8[ -6.4]   -3.9[ -5.3]   -2.2[ -3.2]   -0.6[ -1.2]    100%   (point estimate: 90%)
   BM25 margin          -15.4[-17.9]  -12.1[-14.4]  -10.1[-12.2]   -9.0[-11.0]   -7.4[ -9.4]   -6.2[ -7.9]   -4.3[ -5.7]   -2.4[ -3.5]   -1.0[ -1.6]    100%   (point estimate: 100%)
   top5 vs rest         -15.5[-18.1]  -13.1[-15.5]  -10.7[-12.9]   -9.4[-11.6]   -8.0[-10.1]   -6.7[ -8.6]   -4.7[ -6.4]   -2.9[ -4.2]   -1.7[ -2.7]    100%   (point estimate: 100%)
   NQC-like spread      -14.7[-17.2]  -12.1[-14.4]  -10.8[-13.0]   -9.6[-11.8]   -7.9[ -9.9]   -6.3[ -8.1]   -4.4[ -6.0]   -3.2[ -4.5]   -1.4[ -2.3]    100%   (point estimate: 100%)
   WIG-like             -15.9[-18.4]  -13.9[-16.3]  -11.5[-13.9]  -10.0[-12.3]   -8.3[-10.4]   -6.3[ -8.1]   -4.8[ -6.4]   -2.9[ -4.2]   -1.3[ -2.2]    100%   (point estimate: 100%)
   term coverage top1   -15.9[-18.4]  -14.0[-16.3]  -12.1[-14.3]   -9.9[-12.1]   -7.6[ -9.5]   -5.6[ -7.2]   -3.4[ -4.7]   -2.7[ -3.9]   -1.1[ -1.9]    100%   (point estimate: 100%)
   ORACLE                -8.5[-10.4]   -1.8[ -3.1]   +1.5[ +0.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#  +2.5[ +1.7]#   30%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.96): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      92% (sd   9)   -0.79 MRR              20%      8%
   BM25 margin             100      94% (sd   7)   -0.70 MRR              40%      6%
   top5 vs rest            100      96% (sd   7)   -0.80 MRR              30%      4%
   NQC-like spread         100      94% (sd   9)   -1.00 MRR              45%      6%
   WIG-like                100      98% (sd   4)   -0.30 MRR              20%      2%
   term coverage top1      100      96% (sd   6)   -0.50 MRR              35%      4%

