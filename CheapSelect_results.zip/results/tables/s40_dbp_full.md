## dbpedia_test  (400 questions; tag alarm fires on 68 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  48.2  random  46.7  diff  +1.5  p=0.0676
   MRR  : tag  59.2  random  57.3  diff  +1.9  p=0.0040

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.2 (p=0.508)        +1.8 (p=0.126)
   40%            +0.8 (p=0.689)        +1.1 (p=0.223)
   50%            +0.5 (p=0.822)        +0.7 (p=0.455)
   17% nat        +0.5 (p=0.879)        +1.5 (p=0.264)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -17.8  95% CI [-22.2, -13.2]  p=0.000
   MRR  : -14.3  95% CI [-17.6, -11.0]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +0.8  p=0.798
   MRR  :  +0.0  p=0.984

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +2.8/+2.1 (p=0.114)  40%: +2.8/+1.7 (p=0.267)  50%: +1.5/+0.4 (p=0.810)  nat: +0.8/+1.2 (p=0.361)
   vs NQC-like spread      30%: +2.5/+2.1 (p=0.129)  40%: +4.0/+2.4 (p=0.099)  50%: +1.8/+0.2 (p=0.892)  nat: +0.5/+0.9 (p=0.489)
   vs WIG-like             30%: +1.0/+0.7 (p=0.630)  40%: +2.0/+1.1 (p=0.414)  50%: +1.2/+0.2 (p=0.896)  nat: +1.5/+1.3 (p=0.264)
   vs term coverage top1   30%: +2.2/+1.4 (p=0.247)  40%: +2.8/+1.5 (p=0.231)  50%: +1.0/-0.1 (p=0.963)  nat: +1.5/+1.6 (p=0.148)

G. each selector reranking 68 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -14.3  [-17.6, -11.0]  p=0.000
   BM25 margin          -15.7  [-19.3, -12.3]  p=0.000
   top5 vs rest         -15.5  [-18.9, -12.0]  p=0.000
   NQC-like spread      -15.2  [-18.6, -11.8]  p=0.000
   WIG-like             -15.6  [-19.0, -12.3]  p=0.000
   term coverage top1   -15.8  [-19.3, -12.5]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              57.2    60.2    62.4    64.3    65.6    67.4    69.8    71.7    73.1*   73.5*   90%
   BM25 margin            56.4    58.3    60.6    63.1    64.9    66.9    69.2    71.1    72.6*   73.5*   90%
   top5 vs rest           56.2    58.5    60.3    62.6    65.2    66.5    67.8    70.7    71.8    73.5*   100%
   NQC-like spread        56.3    58.7    60.3    61.8    65.4    67.6    69.0    70.9    71.9    73.5*   100%
   WIG-like               56.6    58.0    61.8    63.1    65.4    66.9    69.0    71.4    72.5    73.5*   100%
   term coverage top1     56.4    58.0    61.0    62.8    65.6    68.1    69.4    71.1    72.0    73.5*   100%
   ORACLE                 63.2    70.3    75.0*   76.6*   76.6*   76.6*   76.6*   76.6*   76.6*   73.5*   30%
   random (expected)      55.9    57.9    59.8    61.8    63.7    65.7    67.6    69.6    71.5    73.5*   100%
   (BM25 only 54.0; rerank ALL 73.5)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -16.2[-19.8]  -13.2[-16.6]  -11.0[-14.0]   -9.2[-11.8]   -7.9[-10.3]   -6.0[ -8.2]   -3.6[ -5.5]   -1.8[ -3.3]   -0.4[ -1.0]    100%   (point estimate: 90%)
   BM25 margin          -17.0[-20.7]  -15.2[-18.4]  -12.8[-15.8]  -10.3[-13.0]   -8.5[-11.1]   -6.5[ -8.7]   -4.3[ -6.2]   -2.4[ -3.9]   -0.8[ -1.7]    100%   (point estimate: 90%)
   top5 vs rest         -17.3[-20.9]  -14.9[-18.3]  -13.1[-16.3]  -10.9[-13.8]   -8.2[-10.7]   -6.9[ -9.1]   -5.6[ -7.7]   -2.8[ -4.4]   -1.6[ -2.9]    100%   (point estimate: 100%)
   NQC-like spread      -17.2[-20.9]  -14.8[-18.2]  -13.1[-16.3]  -11.6[-14.6]   -8.1[-10.5]   -5.9[ -8.0]   -4.5[ -6.4]   -2.6[ -4.1]   -1.5[ -2.7]    100%   (point estimate: 100%)
   WIG-like             -16.8[-20.3]  -15.5[-18.9]  -11.7[-14.5]  -10.3[-13.1]   -8.1[-10.6]   -6.5[ -8.8]   -4.5[ -6.3]   -2.0[ -3.3]   -1.0[ -1.9]    100%   (point estimate: 90%)
   term coverage top1   -17.1[-20.6]  -15.4[-18.8]  -12.5[-15.3]  -10.7[-13.4]   -7.8[-10.2]   -5.3[ -7.4]   -4.0[ -5.8]   -2.3[ -3.8]   -1.5[ -2.6]    100%   (point estimate: 100%)
   ORACLE               -10.3[-13.1]   -3.2[ -5.2]   +1.6[ +0.1]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#   30%   (point estimate: 30%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -16.2[-19.8]  -13.2[-16.6]  -11.0[-14.0]   -9.2[-11.8]   -7.9[-10.3]   -6.0[ -8.2]   -3.6[ -5.5]   -1.8[ -3.3]   -0.4[ -1.0]    100%   (point estimate: 90%)
   BM25 margin          -17.0[-20.7]  -15.2[-18.4]  -12.8[-15.8]  -10.3[-13.0]   -8.5[-11.1]   -6.5[ -8.7]   -4.3[ -6.2]   -2.4[ -3.9]   -0.8[ -1.7]    100%   (point estimate: 100%)
   top5 vs rest         -17.3[-20.9]  -14.9[-18.3]  -13.1[-16.3]  -10.9[-13.8]   -8.2[-10.7]   -6.9[ -9.1]   -5.6[ -7.7]   -2.8[ -4.4]   -1.6[ -2.9]    100%   (point estimate: 100%)
   NQC-like spread      -17.2[-20.9]  -14.8[-18.2]  -13.1[-16.3]  -11.6[-14.6]   -8.1[-10.5]   -5.9[ -8.0]   -4.5[ -6.4]   -2.6[ -4.1]   -1.5[ -2.7]    100%   (point estimate: 100%)
   WIG-like             -16.8[-20.3]  -15.5[-18.9]  -11.7[-14.5]  -10.3[-13.1]   -8.1[-10.6]   -6.5[ -8.8]   -4.5[ -6.3]   -2.0[ -3.3]   -1.0[ -1.9]    100%   (point estimate: 100%)
   term coverage top1   -17.1[-20.6]  -15.4[-18.8]  -12.5[-15.3]  -10.7[-13.4]   -7.8[-10.2]   -5.3[ -7.4]   -4.0[ -5.8]   -2.3[ -3.8]   -1.5[ -2.6]    100%   (point estimate: 100%)
   ORACLE               -10.3[-13.1]   -3.2[ -5.2]   +1.6[ +0.1]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#   30%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      88% (sd  10)   -1.08 MRR              32%     12%
   tag alarm               100      90% (sd   7)   -0.81 MRR              24%     10%
   tag alarm               200      90% (sd   5)   -0.71 MRR              20%     10%
   BM25 margin              50      92% (sd  10)   -0.90 MRR              20%      8%
   BM25 margin             100      92% (sd   7)   -0.95 MRR              28%      8%
   BM25 margin             200      92% (sd   5)   -0.84 MRR              32%      8%
   top5 vs rest             50      95% (sd   8)   -0.93 MRR              36%      5%
   top5 vs rest            100      97% (sd   6)   -0.59 MRR              26%      3%
   top5 vs rest            200      98% (sd   4)   -0.49 MRR              20%      2%
   NQC-like spread          50      93% (sd  11)   -1.07 MRR              38%      7%
   NQC-like spread         100      95% (sd   7)   -0.88 MRR              38%      5%
   NQC-like spread         200      97% (sd   5)   -0.61 MRR              26%      3%
   WIG-like                 50      93% (sd   9)   -0.89 MRR              36%      7%
   WIG-like                100      93% (sd   7)   -0.86 MRR              44%      7%
   WIG-like                200      94% (sd   5)   -0.74 MRR              42%      6%
   term coverage top1       50      93% (sd  11)   -0.98 MRR              35%      7%
   term coverage top1      100      95% (sd   8)   -0.74 MRR              34%      5%
   term coverage top1      200      96% (sd   5)   -0.52 MRR              22%      4%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  15%  MRR  55.7 | vs BM25 margin: +2.8 (p=0.291)  vs top5 vs rest: -1.1 (p=0.721)  vs NQC-like spread: +0.0 (p=0.998)  vs WIG-like: +0.5 (p=0.868)  vs term coverage top1: -0.9 (p=0.772)
   list           n= 105  fires  16%  MRR  62.2 | vs BM25 margin: -1.8 (p=0.539)  vs top5 vs rest: +3.7 (p=0.176)  vs NQC-like spread: +3.5 (p=0.235)  vs WIG-like: +4.3 (p=0.092)  vs term coverage top1: +4.8 (p=0.033)
   question       n= 125  fires  22%  MRR  46.2 | vs BM25 margin: +4.8 (p=0.075)  vs top5 vs rest: +2.1 (p=0.405)  vs NQC-like spread: +1.0 (p=0.693)  vs WIG-like: -0.2 (p=0.941)  vs term coverage top1: +1.4 (p=0.507)
   named entity   n=  86  fires  12%  MRR  77.7 | vs BM25 margin: -0.8 (p=0.619)  vs top5 vs rest: -1.0 (p=0.561)  vs NQC-like spread: -1.6 (p=0.323)  vs WIG-like: +0.7 (p=0.566)  vs term coverage top1: +0.3 (p=1.000)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR +0.2  [-2.6, +3.0]  p=0.903  (n=211)

