## prime_testfull  (2801 questions; tag alarm fires on 1563 = 56%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  26.5  random  23.9  diff  +2.6  p=0.0001
   MRR  : tag  35.5  random  33.1  diff  +2.4  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.7 (p=0.000)        +1.4 (p=0.000)
   40%            +1.4 (p=0.008)        +1.4 (p=0.000)
   50%            +2.0 (p=0.001)        +2.1 (p=0.000)
   56% nat        +1.6 (p=0.006)        +1.8 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.4  95% CI [-0.7, +1.5]  p=0.521
   MRR  :  -0.7  95% CI [-1.5, +0.1]  p=0.085

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (53%)
   Hit@1:  +1.3  p=0.021
   MRR  :  +0.8  p=0.067

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.0/+0.0 (p=0.969)  40%: +0.7/+0.6 (p=0.136)  50%: +1.1/+1.1 (p=0.009)  nat: +0.6/+0.7 (p=0.060)
   vs NQC-like spread      30%: +0.0/+0.0 (p=0.985)  40%: -0.1/+0.0 (p=0.932)  50%: +0.1/+0.3 (p=0.458)  nat: -0.3/-0.0 (p=0.908)
   vs WIG-like             30%: +0.4/+0.1 (p=0.853)  40%: +0.6/+0.2 (p=0.569)  50%: +0.9/+0.7 (p=0.074)  nat: +0.6/+0.5 (p=0.182)
   vs term coverage top1   30%: +1.3/+1.1 (p=0.016)  40%: +1.6/+1.5 (p=0.002)  50%: +2.1/+2.0 (p=0.000)  nat: +1.5/+1.6 (p=0.000)

G. each selector reranking 1563 questions (56%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.7  [-1.5, +0.1]  p=0.085
   BM25 margin           -2.5  [-3.4, -1.7]  p=0.000
   top5 vs rest          -1.5  [-2.3, -0.6]  p=0.002
   NQC-like spread       -0.7  [-1.6, +0.2]  p=0.132
   WIG-like              -1.3  [-2.2, -0.4]  p=0.008
   term coverage top1    -2.3  [-3.2, -1.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              30.5    31.5    32.7    33.8    35.2    35.5*   36.0*   36.2*   36.4*   36.2*   60%
   BM25 margin            29.9    30.6    31.3    32.4    33.2    34.2    35.0    35.9*   36.2*   36.2*   80%
   top5 vs rest           30.1    31.3    32.7    33.2    34.2    35.1    35.5*   35.8*   35.9*   36.2*   70%
   NQC-like spread        30.0    31.4    32.7    33.8    35.0    35.6*   35.7*   35.7*   36.1*   36.2*   60%
   WIG-like               30.4    31.4    32.6    33.6    34.5    35.2    36.0*   36.2*   36.4*   36.2*   70%
   term coverage top1     29.8    30.7    31.6    32.4    33.2    33.9    34.5    35.3    35.8*   36.2*   90%
   ORACLE                 37.6*   41.6*   42.4*   42.4*   42.4*   42.4*   42.4*   42.4*   41.9*   36.2*   10%
   random (expected)      29.8    30.5    31.3    32.0    32.7    33.4    34.1    34.8    35.5    36.2*   100%
   (BM25 only 29.1; rerank ALL 36.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.72 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.7[ -6.9]   -4.7[ -5.8]   -3.5[ -4.6]   -2.4[ -3.4]   -1.0[ -1.8]   -0.7[ -1.5]   -0.2[ -0.9]   -0.0[ -0.5]#  +0.2[ -0.2]#   80%   (point estimate: 70%)
   BM25 margin           -6.3[ -7.5]   -5.6[ -6.8]   -4.9[ -6.0]   -3.8[ -4.8]   -3.0[ -3.9]   -2.0[ -2.7]   -1.2[ -1.9]   -0.3[ -0.8]   -0.0[ -0.3]#   90%   (point estimate: 80%)
   top5 vs rest          -6.1[ -7.3]   -4.9[ -6.0]   -3.5[ -4.6]   -3.0[ -4.1]   -2.0[ -3.0]   -1.1[ -2.0]   -0.7[ -1.4]   -0.4[ -1.1]   -0.3[ -0.8]    100%   (point estimate: 70%)
   NQC-like spread       -6.2[ -7.4]   -4.8[ -6.0]   -3.5[ -4.6]   -2.4[ -3.4]   -1.3[ -2.2]   -0.6[ -1.5]   -0.5[ -1.2]   -0.5[ -1.1]   -0.1[ -0.5]#   90%   (point estimate: 60%)
   WIG-like              -5.8[ -7.1]   -4.8[ -5.9]   -3.6[ -4.7]   -2.6[ -3.7]   -1.7[ -2.7]   -1.0[ -1.9]   -0.2[ -0.9]   -0.1[ -0.7]#  +0.2[ -0.2]#   80%   (point estimate: 70%)
   term coverage top1    -6.4[ -7.7]   -5.5[ -6.6]   -4.6[ -5.7]   -3.8[ -4.9]   -3.0[ -3.9]   -2.3[ -3.1]   -1.7[ -2.4]   -0.9[ -1.5]   -0.4[ -0.8]    100%   (point estimate: 90%)
   ORACLE                +1.4[ +0.6]#  +5.4[ +4.7]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +5.7[ +5.0]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.72): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      64% (sd  20)   -0.95 MRR              55%     36%
   BM25 margin             100      82% (sd  19)   -0.67 MRR              20%     18%
   top5 vs rest            100      72% (sd  30)   -1.38 MRR              40%     28%
   NQC-like spread         100      70% (sd  36)   -1.76 MRR              35%     30%
   WIG-like                100      67% (sd  23)   -1.06 MRR              55%     33%
   term coverage top1      100      86% (sd  19)   -0.82 MRR              30%     14%

