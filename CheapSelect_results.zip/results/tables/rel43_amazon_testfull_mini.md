## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  53.4  random  52.4  diff  +1.0  p=0.0608
   MRR  : tag  63.5  random  62.5  diff  +1.0  p=0.0198

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=0.743)        -0.3 (p=0.554)
   40%            -1.6 (p=0.065)        -1.1 (p=0.095)
   50%            -2.3 (p=0.012)        -1.3 (p=0.062)
   47% nat        -2.1 (p=0.026)        -1.2 (p=0.078)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -2.5  95% CI [-4.2, -0.9]  p=0.005
   MRR  :  -2.1  95% CI [-3.3, -0.8]  p=0.002

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +0.3  p=0.771
   MRR  :  -0.4  p=0.504

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.5/-1.0 (p=0.140)  40%: -1.2/-1.3 (p=0.050)  50%: -1.4/-1.5 (p=0.038)  nat: -1.9/-1.9 (p=0.008)
   vs NQC-like spread      30%: -0.7/-1.2 (p=0.062)  40%: -1.5/-1.6 (p=0.016)  50%: -1.6/-1.7 (p=0.015)  nat: -2.1/-2.0 (p=0.003)
   vs WIG-like             30%: -0.9/-1.4 (p=0.045)  40%: -1.5/-1.8 (p=0.013)  50%: -2.0/-2.0 (p=0.007)  nat: -2.2/-2.2 (p=0.002)
   vs term coverage top1   30%: +1.9/+1.6 (p=0.023)  40%: +2.5/+2.2 (p=0.002)  50%: +1.8/+2.0 (p=0.007)  nat: +1.5/+1.7 (p=0.017)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.1  [-3.3, -0.8]  p=0.002
   BM25 margin           -0.9  [-2.2, +0.5]  p=0.201
   top5 vs rest          -0.2  [-1.5, +1.1]  p=0.745
   NQC-like spread       -0.0  [-1.3, +1.2]  p=0.939
   WIG-like              +0.2  [-1.2, +1.5]  p=0.828
   term coverage top1    -3.8  [-5.3, -2.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              60.7    61.5    62.8    63.4    64.0    65.0*   65.4*   65.9*   66.2*   65.6*   60%
   BM25 margin            60.9    62.2    63.2    64.5*   65.3*   65.7*   66.1*   66.5*   66.3*   65.6*   40%
   top5 vs rest           61.2    62.8    63.8    64.8*   65.5*   65.6*   65.7*   65.9*   66.0*   65.6*   40%
   NQC-like spread        61.1    62.8    64.1*   65.1*   65.7*   66.2*   65.8*   65.9*   66.0*   65.6*   30%
   WIG-like               61.6    62.9    64.3*   65.2*   66.0*   66.0*   66.5*   66.2*   65.8*   65.6*   30%
   term coverage top1     60.2    60.9    61.3    61.3    62.0    62.8    63.5    63.8    64.5    65.6*   100%
   ORACLE                 68.4*   73.3*   74.7*   74.7*   74.7*   74.7*   74.7*   74.7*   72.7*   65.6*   10%
   random (expected)      60.4    61.0    61.6    62.2    62.7    63.3    63.9    64.5    65.0    65.6*   100%
   (BM25 only 59.8; rerank ALL 65.6)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.31 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.9[ -6.7]   -4.1[ -5.8]   -2.8[ -4.3]   -2.2[ -3.5]   -1.6[ -2.8]   -0.6[ -1.6]   -0.2[ -1.1]#  +0.3[ -0.3]#  +0.6[ +0.3]#   70%   (point estimate: 60%)
   BM25 margin           -4.7[ -6.6]   -3.4[ -5.2]   -2.5[ -4.0]   -1.1[ -2.5]   -0.4[ -1.7]   +0.0[ -1.1]#  +0.5[ -0.4]#  +0.9[ +0.2]#  +0.6[ +0.3]#   60%   (point estimate: 40%)
   top5 vs rest          -4.4[ -6.3]   -2.8[ -4.5]   -1.8[ -3.3]   -0.8[ -2.3]   -0.2[ -1.4]   -0.1[ -1.3]#  +0.1[ -0.8]#  +0.3[ -0.5]#  +0.4[ -0.2]#   60%   (point estimate: 40%)
   NQC-like spread       -4.5[ -6.4]   -2.9[ -4.5]   -1.6[ -3.1]   -0.5[ -2.0]   +0.0[ -1.2]#  +0.6[ -0.5]#  +0.2[ -0.8]#  +0.3[ -0.5]#  +0.4[ -0.1]#   50%   (point estimate: 40%)
   WIG-like              -4.0[ -5.9]   -2.7[ -4.4]   -1.3[ -2.9]   -0.4[ -1.8]   +0.4[ -1.0]#  +0.4[ -0.8]#  +0.9[ -0.2]#  +0.6[ -0.4]#  +0.2[ -0.5]#   50%   (point estimate: 40%)
   term coverage top1    -5.4[ -7.3]   -4.8[ -6.5]   -4.3[ -6.0]   -4.4[ -5.9]   -3.6[ -5.0]   -2.8[ -4.1]   -2.1[ -3.3]   -1.8[ -2.8]   -1.1[ -1.9]    100%   (point estimate: 90%)
   ORACLE                +2.8[ +1.3]#  +7.7[ +6.5]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +7.1[ +6.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.31): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      61% (sd  21)   -0.95 MRR              30%     39%
   BM25 margin             100      56% (sd  21)   -0.51 MRR              15%     44%
   top5 vs rest            100      47% (sd  24)   -1.11 MRR              40%     53%
   NQC-like spread         100      64% (sd  31)   -0.73 MRR              30%     36%
   WIG-like                100      38% (sd  27)   -1.75 MRR              50%     62%
   term coverage top1      100      84% (sd  23)   -1.27 MRR              35%     16%

