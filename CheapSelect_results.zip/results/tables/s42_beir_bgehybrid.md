## beir_scifact  (300 questions; tag alarm fires on 52 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.7  random  55.9  diff  +0.8  p=0.2533
   MRR  : tag  67.3  random  66.7  diff  +0.6  p=0.1727

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=1.000)        -0.3 (p=0.737)
   40%            -1.3 (p=0.293)        -0.7 (p=0.298)
   50%            +0.0 (p=1.000)        +0.3 (p=0.577)
   17% nat        -1.7 (p=0.421)        -0.3 (p=0.769)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -8.3  95% CI [-12.7, -4.3]  p=0.000
   MRR  :  -5.4  95% CI [-8.4, -2.6]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (33%)
   Hit@1:  +3.7  p=0.019
   MRR  :  +2.5  p=0.024

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +4.3/+2.1 (p=0.090)  40%: +3.7/+2.2 (p=0.096)  50%: +3.7/+2.2 (p=0.095)  nat: +1.0/+0.3 (p=0.803)
   vs NQC-like spread      30%: +2.7/+0.5 (p=0.725)  40%: +3.0/+1.2 (p=0.405)  50%: +3.7/+1.7 (p=0.234)  nat: +1.0/+0.1 (p=0.920)
   vs WIG-like             30%: +3.7/+2.0 (p=0.034)  40%: +3.3/+2.1 (p=0.038)  50%: +4.0/+2.2 (p=0.046)  nat: +1.0/+0.7 (p=0.365)
   vs term coverage top1   30%: +1.3/-0.1 (p=0.961)  40%: +0.7/-0.1 (p=0.939)  50%: -0.3/-0.7 (p=0.539)  nat: -1.3/-1.1 (p=0.309)

G. each selector reranking 52 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -5.4  [-8.4, -2.6]  p=0.000
   BM25 margin           -5.1  [-7.9, -2.5]  p=0.000
   top5 vs rest          -5.7  [-8.8, -2.7]  p=0.001
   NQC-like spread       -5.6  [-8.5, -2.6]  p=0.000
   WIG-like              -6.2  [-9.3, -3.2]  p=0.000
   term coverage top1    -4.3  [-7.1, -1.6]  p=0.003

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              66.8    67.9    68.8    69.7    70.7    71.0    71.2*   71.5    72.2*   72.7*   90%
   BM25 margin            66.8    68.4    69.1    70.4    70.4    70.6    71.0    71.8*   72.2*   72.7*   80%
   top5 vs rest           66.6    67.1    66.7    67.5    68.4    69.4    70.8    71.2*   72.7*   72.7*   80%
   NQC-like spread        66.9    67.5    68.3    68.5    69.0    69.9    70.5    71.2*   71.5*   72.7*   80%
   WIG-like               66.2    67.0    66.8    67.7    68.5    69.0    70.1    71.6*   72.3*   72.7*   80%
   term coverage top1     67.8    68.6    68.9    69.8    71.4*   71.5*   72.0*   72.1    72.3*   72.7*   90%
   ORACLE                 72.6*   76.1*   76.4*   76.4*   76.4*   76.4*   76.4*   76.4*   76.3*   72.7*   10%
   random (expected)      66.1    66.9    67.6    68.3    69.1    69.8    70.5    71.3    72.0    72.7*   100%
   (BM25 only 65.4; rerank ALL 72.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.9[ -9.0]   -4.8[ -7.5]   -3.9[ -6.3]   -3.0[ -5.2]   -2.1[ -4.0]   -1.8[ -3.5]   -1.5[ -3.1]   -1.2[ -2.4]   -0.5[ -1.3]    100%   (point estimate: 90%)
   BM25 margin           -5.9[ -8.9]   -4.4[ -6.8]   -3.6[ -6.1]   -2.3[ -4.4]   -2.4[ -4.4]   -2.1[ -4.0]   -1.8[ -3.5]   -0.9[ -2.0]   -0.6[ -1.4]    100%   (point estimate: 80%)
   top5 vs rest          -6.2[ -9.4]   -5.6[ -8.8]   -6.0[ -9.1]   -5.2[ -8.0]   -4.3[ -6.9]   -3.3[ -5.5]   -2.0[ -3.9]   -1.5[ -3.3]   +0.0[ -1.3]    100%   (point estimate: 90%)
   NQC-like spread       -5.8[ -9.0]   -5.2[ -8.3]   -4.4[ -7.1]   -4.2[ -6.7]   -3.7[ -6.1]   -2.9[ -5.0]   -2.2[ -4.0]   -1.5[ -3.2]   -1.2[ -2.5]    100%   (point estimate: 100%)
   WIG-like              -6.6[ -9.7]   -5.7[ -8.6]   -5.9[ -8.9]   -5.1[ -7.7]   -4.3[ -6.8]   -3.7[ -6.1]   -2.7[ -4.7]   -1.1[ -2.8]   -0.5[ -1.4]    100%   (point estimate: 90%)
   term coverage top1    -4.9[ -8.0]   -4.1[ -6.9]   -3.8[ -6.3]   -2.9[ -4.8]   -1.4[ -2.8]   -1.2[ -2.5]   -0.7[ -1.7]   -0.7[ -1.5]   -0.4[ -1.1]    100%   (point estimate: 70%)
   ORACLE                -0.2[ -2.3]   +3.4[ +2.0]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.6[ +2.2]#   20%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.9[ -9.0]   -4.8[ -7.5]   -3.9[ -6.3]   -3.0[ -5.2]   -2.1[ -4.0]   -1.8[ -3.5]   -1.5[ -3.1]   -1.2[ -2.4]   -0.5[ -1.3]    100%   (point estimate: 90%)
   BM25 margin           -5.9[ -8.9]   -4.4[ -6.8]   -3.6[ -6.1]   -2.3[ -4.4]   -2.4[ -4.4]   -2.1[ -4.0]   -1.8[ -3.5]   -0.9[ -2.0]   -0.6[ -1.4]    100%   (point estimate: 100%)
   top5 vs rest          -6.2[ -9.4]   -5.6[ -8.8]   -6.0[ -9.1]   -5.2[ -8.0]   -4.3[ -6.9]   -3.3[ -5.5]   -2.0[ -3.9]   -1.5[ -3.3]   +0.0[ -1.3]    100%   (point estimate: 90%)
   NQC-like spread       -5.8[ -9.0]   -5.2[ -8.3]   -4.4[ -7.1]   -4.2[ -6.7]   -3.7[ -6.1]   -2.9[ -5.0]   -2.2[ -4.0]   -1.5[ -3.2]   -1.2[ -2.5]    100%   (point estimate: 100%)
   WIG-like              -6.6[ -9.7]   -5.7[ -8.6]   -5.9[ -8.9]   -5.1[ -7.7]   -4.3[ -6.8]   -3.7[ -6.1]   -2.7[ -4.7]   -1.1[ -2.8]   -0.5[ -1.4]    100%   (point estimate: 90%)
   term coverage top1    -4.9[ -8.0]   -4.1[ -6.9]   -3.8[ -6.3]   -2.9[ -4.8]   -1.4[ -2.8]   -1.2[ -2.5]   -0.7[ -1.7]   -0.7[ -1.5]   -0.4[ -1.1]    100%   (point estimate: 90%)
   ORACLE                -0.2[ -2.3]   +3.4[ +2.0]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.7[ +2.3]#  +3.6[ +2.2]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      79% (sd  23)   -1.31 MRR              48%     21%
   tag alarm               100      81% (sd  19)   -1.22 MRR              38%     19%
   tag alarm               200      84% (sd  11)   -1.13 MRR              42%     16%
   BM25 margin              50      78% (sd  24)   -1.35 MRR              46%     22%
   BM25 margin             100      82% (sd  19)   -1.22 MRR              40%     18%
   BM25 margin             200      84% (sd   9)   -1.11 MRR              44%     16%
   top5 vs rest             50      80% (sd  21)   -1.57 MRR              46%     20%
   top5 vs rest            100      85% (sd  12)   -0.96 MRR              36%     15%
   top5 vs rest            200      87% (sd   6)   -0.79 MRR              34%     13%
   NQC-like spread          50      85% (sd  24)   -1.29 MRR              43%     15%
   NQC-like spread         100      89% (sd  17)   -1.10 MRR              42%     11%
   NQC-like spread         200      95% (sd  10)   -0.87 MRR              30%      5%
   WIG-like                 50      82% (sd  24)   -1.56 MRR              36%     18%
   WIG-like                100      86% (sd  11)   -1.05 MRR              38%     14%
   WIG-like                200      86% (sd   6)   -1.05 MRR              45%     14%
   term coverage top1       50      72% (sd  25)   -1.21 MRR              34%     28%
   term coverage top1      100      72% (sd  17)   -1.03 MRR              40%     28%
   term coverage top1      200      70% (sd  13)   -1.05 MRR              44%     30%

## beir_nfcorpus  (323 questions; tag alarm fires on 13 = 4%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  46.4  random  46.4  diff  +0.1  p=0.5876
   MRR  : tag  55.6  random  55.3  diff  +0.2  p=0.2404

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.6 (p=0.725)        -0.1 (p=0.849)
   40%            -0.3 (p=1.000)        +0.1 (p=0.834)
   50%            -0.3 (p=1.000)        -0.1 (p=0.823)
   4% nat         -0.6 (p=0.727)        -0.0 (p=0.945)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +1.2  95% CI [-3.4, +6.2]  p=0.700
   MRR  :  -0.2  95% CI [-3.6, +3.3]  p=0.925

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (49%)
   Hit@1:  +1.5  p=0.379
   MRR  :  +1.1  p=0.297

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -2.5/-1.0 (p=0.445)  40%: -1.5/-0.6 (p=0.633)  50%: -2.2/-1.4 (p=0.310)  nat: +0.0/+0.2 (p=0.739)
   vs NQC-like spread      30%: -3.1/-1.7 (p=0.157)  40%: -4.0/-2.7 (p=0.040)  50%: -4.3/-3.1 (p=0.018)  nat: -1.2/-0.6 (p=0.315)
   vs WIG-like             30%: -1.5/-0.8 (p=0.486)  40%: -2.5/-1.6 (p=0.169)  50%: -2.2/-1.8 (p=0.145)  nat: +0.9/+0.6 (p=0.291)
   vs term coverage top1   30%: -3.7/-2.9 (p=0.002)  40%: -3.7/-2.5 (p=0.012)  50%: -3.4/-2.6 (p=0.020)  nat: -0.6/-0.2 (p=0.736)

G. each selector reranking 13 questions (4%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.2  [-3.6, +3.3]  p=0.925
   BM25 margin           -0.1  [-3.6, +3.4]  p=0.946
   top5 vs rest          -0.3  [-3.8, +3.2]  p=0.860
   NQC-like spread       +0.4  [-3.0, +3.8]  p=0.825
   WIG-like              -0.8  [-4.3, +2.7]  p=0.673
   term coverage top1    +0.0  [-3.5, +3.6]  p=0.986

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              55.7*   55.2*   54.8*   54.9*   55.0*   55.8*   55.4*   55.6*   56.0*   55.7*   10%
   BM25 margin            55.1*   54.9*   54.9*   54.8*   55.1*   55.2*   55.1*   55.6*   55.6*   55.7*   10%
   top5 vs rest           56.2*   56.3*   55.8*   55.5*   56.5*   56.1*   57.0*   56.7*   56.5*   55.7*   10%
   NQC-like spread        56.6*   56.3*   56.5*   57.6*   58.1*   57.5*   57.2*   57.0*   56.4*   55.7*   10%
   WIG-like               55.8*   55.9*   55.6*   56.5*   56.8*   57.0*   57.3*   57.2*   56.5*   55.7*   10%
   term coverage top1     56.4*   56.9*   57.7*   57.4*   57.6*   57.7*   56.3*   56.2*   55.3*   55.7*   10%
   ORACLE                 62.2*   64.0*   64.0*   64.0*   64.0*   64.0*   64.0*   64.0*   62.1*   55.7*   10%
   random (expected)      55.4    55.4    55.4    55.5    55.5    55.6    55.6    55.7    55.7    55.7*   100%
   (BM25 only 55.3; rerank ALL 55.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.0[ -3.4]   -0.6[ -3.6]   -1.0[ -3.9]   -0.8[ -3.5]   -0.7[ -3.1]   +0.1[ -2.0]   -0.3[ -2.0]   -0.2[ -1.5]   +0.3[ -0.7]#   90%   (point estimate: 10%)
   BM25 margin           -0.7[ -4.0]   -0.9[ -4.0]   -0.9[ -3.8]   -1.0[ -3.7]   -0.6[ -3.1]   -0.6[ -2.7]   -0.7[ -2.4]   -0.2[ -1.6]   -0.1[ -1.1]    100%   (point estimate: 10%)
   top5 vs rest          +0.5[ -3.0]   +0.5[ -2.7]   +0.0[ -3.1]   -0.2[ -3.0]   +0.7[ -1.9]   +0.4[ -1.8]   +1.3[ -0.4]#  +0.9[ -0.3]#  +0.7[ -0.2]#   70%   (point estimate: 10%)
   NQC-like spread       +0.9[ -2.5]   +0.6[ -2.6]   +0.8[ -2.3]   +1.8[ -0.8]#  +2.4[ +0.2]#  +1.7[ -0.2]#  +1.4[ -0.4]#  +1.2[ -0.1]#  +0.7[ +0.1]#   40%   (point estimate: 10%)
   WIG-like              +0.0[ -3.3]   +0.2[ -2.8]   -0.1[ -2.8]   +0.7[ -1.9]   +1.0[ -1.4]   +1.3[ -0.9]#  +1.6[ -0.2]#  +1.5[ +0.3]#  +0.8[ -0.2]#   60%   (point estimate: 10%)
   term coverage top1    +0.7[ -2.8]   +1.1[ -1.9]   +1.9[ -0.7]#  +1.6[ -0.9]#  +1.8[ -0.4]#  +2.0[ +0.0]#  +0.5[ -1.1]   +0.4[ -1.1]   -0.5[ -1.7]    100%   (point estimate: 10%)
   ORACLE                +6.5[ +4.1]#  +8.2[ +6.1]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +6.4[ +4.3]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.0[ -3.4]   -0.6[ -3.6]   -1.0[ -3.9]   -0.8[ -3.5]   -0.7[ -3.1]   +0.1[ -2.0]   -0.3[ -2.0]   -0.2[ -1.5]   +0.3[ -0.7]    100%   (point estimate: 60%)
   BM25 margin           -0.7[ -4.0]   -0.9[ -4.0]   -0.9[ -3.8]   -1.0[ -3.7]   -0.6[ -3.1]   -0.6[ -2.7]   -0.7[ -2.4]   -0.2[ -1.6]   -0.1[ -1.1]    100%   (point estimate: 80%)
   top5 vs rest          +0.5[ -3.0]   +0.5[ -2.7]   +0.0[ -3.1]   -0.2[ -3.0]   +0.7[ -1.9]   +0.4[ -1.8]   +1.3[ -0.4]#  +0.9[ -0.3]#  +0.7[ -0.2]#   70%   (point estimate: 10%)
   NQC-like spread       +0.9[ -2.5]   +0.6[ -2.6]   +0.8[ -2.3]   +1.8[ -0.8]   +2.4[ +0.2]#  +1.7[ -0.2]#  +1.4[ -0.4]#  +1.2[ -0.1]#  +0.7[ +0.1]#   50%   (point estimate: 10%)
   WIG-like              +0.0[ -3.3]   +0.2[ -2.8]   -0.1[ -2.8]   +0.7[ -1.9]   +1.0[ -1.4]   +1.3[ -0.9]   +1.6[ -0.2]#  +1.5[ +0.3]#  +0.8[ -0.2]#   70%   (point estimate: 10%)
   term coverage top1    +0.7[ -2.8]   +1.1[ -1.9]   +1.9[ -0.7]   +1.6[ -0.9]   +1.8[ -0.4]#  +2.0[ +0.0]#  +0.5[ -1.1]   +0.4[ -1.1]   -0.5[ -1.7]    100%   (point estimate: 10%)
   ORACLE                +6.5[ +4.1]#  +8.2[ +6.1]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +8.3[ +6.2]#  +6.4[ +4.3]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      53% (sd  35)   -0.44 MRR              18%     47%
   tag alarm               100      49% (sd  34)   -0.55 MRR              26%     51%
   tag alarm               200      43% (sd  29)   -0.74 MRR              35%     57%
   BM25 margin              50      58% (sd  36)   -0.58 MRR              24%     42%
   BM25 margin             100      60% (sd  33)   -0.62 MRR              26%     40%
   BM25 margin             200      51% (sd  31)   -0.97 MRR              38%     49%
   top5 vs rest             50      41% (sd  32)   +0.41 MRR               2%     59%
   top5 vs rest            100      32% (sd  27)   +0.38 MRR              12%     68%
   top5 vs rest            200      19% (sd  18)   +0.32 MRR              24%     81%
   NQC-like spread          50      29% (sd  28)   +0.79 MRR               2%     71%
   NQC-like spread         100      28% (sd  26)   +1.00 MRR               5%     72%
   NQC-like spread         200      14% (sd  11)   +0.87 MRR              20%     86%
   WIG-like                 50      38% (sd  31)   +0.31 MRR              12%     62%
   WIG-like                100      28% (sd  22)   +0.34 MRR              14%     72%
   WIG-like                200      20% (sd  16)   +0.14 MRR              32%     80%
   term coverage top1       50      37% (sd  35)   +0.58 MRR               1%     63%
   term coverage top1      100      24% (sd  25)   +0.85 MRR               4%     76%
   term coverage top1      200      13% (sd  13)   +0.56 MRR              26%     87%

## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  35.5  random  34.8  diff  +0.7  p=0.1945
   MRR  : tag  45.4  random  44.7  diff  +0.7  p=0.0946

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.9 (p=0.467)        -0.5 (p=0.565)
   40%            +0.0 (p=1.000)        +0.1 (p=0.867)
   50%            -0.6 (p=0.638)        -0.3 (p=0.636)
   25% nat        -0.2 (p=1.000)        +0.2 (p=0.807)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.9  95% CI [-10.8, -4.9]  p=0.000
   MRR  :  -6.8  95% CI [-9.0, -4.7]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +2.8  p=0.022
   MRR  :  +1.8  p=0.043

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.8/+0.4 (p=0.668)  40%: +1.7/+0.9 (p=0.381)  50%: +1.4/+0.5 (p=0.615)  nat: +0.8/+0.5 (p=0.562)
   vs NQC-like spread      30%: +0.5/+0.3 (p=0.765)  40%: +1.2/+0.7 (p=0.503)  50%: +0.9/+0.4 (p=0.688)  nat: +0.8/+0.5 (p=0.599)
   vs WIG-like             30%: +0.2/+0.1 (p=0.940)  40%: +0.0/-0.1 (p=0.913)  50%: +0.3/+0.2 (p=0.847)  nat: +0.3/+0.4 (p=0.632)
   vs term coverage top1   30%: -1.2/-1.2 (p=0.108)  40%: -1.1/-1.1 (p=0.200)  50%: -0.5/-0.6 (p=0.483)  nat: -1.1/-0.8 (p=0.325)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -6.8  [-9.0, -4.7]  p=0.000
   BM25 margin           -7.0  [-9.3, -4.7]  p=0.000
   top5 vs rest          -7.3  [-9.6, -5.1]  p=0.000
   NQC-like spread       -7.3  [-9.5, -5.0]  p=0.000
   WIG-like              -7.2  [-9.4, -5.1]  p=0.000
   term coverage top1    -6.0  [-8.0, -4.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              43.8    45.2    45.9    46.9    48.1    49.4    50.2    50.8    51.2    52.2*   100%
   BM25 margin            43.5    44.7    46.4    46.8    48.4    49.0    50.1    50.2    51.7*   52.2*   90%
   top5 vs rest           43.5    44.2    45.5    46.0    47.5    47.8    49.7    50.2    51.7*   52.2*   90%
   NQC-like spread        43.6    44.8    45.6    46.2    47.7    49.1    50.2    51.1    51.9*   52.2*   90%
   WIG-like               43.4    44.6    45.8    47.0    47.9    48.8    50.0    51.0    52.2*   52.2*   90%
   term coverage top1     44.3    45.8    47.1    48.0    48.7    50.5    51.1*   51.7*   52.3*   52.2*   70%
   ORACLE                 50.7*   55.3*   56.6*   56.7*   56.7*   56.7*   56.7*   56.7*   56.4*   52.2*   10%
   random (expected)      43.3    44.3    45.2    46.2    47.2    48.3    49.3    50.2    51.2    52.2*   100%
   (BM25 only 42.3; rerank ALL 52.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.4[-10.8]   -7.0[ -9.1]   -6.4[ -8.4]   -5.3[ -7.3]   -4.2[ -5.8]   -2.8[ -4.3]   -2.0[ -3.3]   -1.4[ -2.5]   -1.1[ -1.9]    100%   (point estimate: 100%)
   BM25 margin           -8.8[-11.2]   -7.5[ -9.7]   -5.9[ -7.9]   -5.5[ -7.4]   -3.8[ -5.5]   -3.2[ -4.8]   -2.2[ -3.6]   -2.1[ -3.3]   -0.6[ -1.3]    100%   (point estimate: 90%)
   top5 vs rest          -8.8[-11.2]   -8.1[-10.3]   -6.8[ -8.8]   -6.2[ -8.3]   -4.7[ -6.7]   -4.4[ -6.2]   -2.6[ -3.9]   -2.1[ -3.3]   -0.5[ -1.3]    100%   (point estimate: 90%)
   NQC-like spread       -8.7[-11.0]   -7.4[ -9.7]   -6.7[ -8.7]   -6.0[ -8.0]   -4.6[ -6.4]   -3.2[ -4.8]   -2.0[ -3.3]   -1.2[ -2.3]   -0.3[ -1.0]#   90%   (point estimate: 90%)
   WIG-like              -8.8[-11.2]   -7.6[ -9.8]   -6.5[ -8.6]   -5.2[ -7.2]   -4.4[ -6.1]   -3.4[ -4.9]   -2.2[ -3.5]   -1.3[ -2.4]   -0.1[ -0.8]#   90%   (point estimate: 90%)
   term coverage top1    -8.0[-10.3]   -6.5[ -8.7]   -5.1[ -7.1]   -4.2[ -5.9]   -3.5[ -5.1]   -1.7[ -3.0]   -1.1[ -2.3]   -0.6[ -1.5]   +0.1[ -0.5]#   90%   (point estimate: 80%)
   ORACLE                -1.6[ -3.2]   +3.0[ +1.9]#  +4.3[ +3.3]#  +4.5[ +3.5]#  +4.5[ +3.5]#  +4.5[ +3.5]#  +4.5[ +3.5]#  +4.5[ +3.5]#  +4.2[ +3.2]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.4[-10.8]   -7.0[ -9.1]   -6.4[ -8.4]   -5.3[ -7.3]   -4.2[ -5.8]   -2.8[ -4.3]   -2.0[ -3.3]   -1.4[ -2.5]   -1.1[ -1.9]    100%   (point estimate: 100%)
   BM25 margin           -8.8[-11.2]   -7.5[ -9.7]   -5.9[ -7.9]   -5.5[ -7.4]   -3.8[ -5.5]   -3.2[ -4.8]   -2.2[ -3.6]   -2.1[ -3.3]   -0.6[ -1.3]    100%   (point estimate: 100%)
   top5 vs rest          -8.8[-11.2]   -8.1[-10.3]   -6.8[ -8.8]   -6.2[ -8.3]   -4.7[ -6.7]   -4.4[ -6.2]   -2.6[ -3.9]   -2.1[ -3.3]   -0.5[ -1.3]    100%   (point estimate: 100%)
   NQC-like spread       -8.7[-11.0]   -7.4[ -9.7]   -6.7[ -8.7]   -6.0[ -8.0]   -4.6[ -6.4]   -3.2[ -4.8]   -2.0[ -3.3]   -1.2[ -2.3]   -0.3[ -1.0]    100%   (point estimate: 90%)
   WIG-like              -8.8[-11.2]   -7.6[ -9.8]   -6.5[ -8.6]   -5.2[ -7.2]   -4.4[ -6.1]   -3.4[ -4.9]   -2.2[ -3.5]   -1.3[ -2.4]   -0.1[ -0.8]    100%   (point estimate: 90%)
   term coverage top1    -8.0[-10.3]   -6.5[ -8.7]   -5.1[ -7.1]   -4.2[ -5.9]   -3.5[ -5.1]   -1.7[ -3.0]   -1.1[ -2.3]   -0.6[ -1.5]   +0.1[ -0.5]    100%   (point estimate: 90%)
   ORACLE                -1.6[ -3.2]   +3.0[ +1.9]#  +4.3[ +3.3]#  +4.5[ +3.5]#  +4.5[ +3.5]#  +4.5[ +3.5]#  +4.5[ +3.5]#  +4.5[ +3.5]#  +4.2[ +3.2]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      88% (sd  18)   -1.05 MRR              44%     12%
   tag alarm               100      90% (sd  14)   -0.94 MRR              43%     10%
   tag alarm               200      91% (sd  11)   -0.88 MRR              44%      9%
   BM25 margin              50      85% (sd  19)   -1.29 MRR              30%     15%
   BM25 margin             100      87% (sd  15)   -1.10 MRR              24%     13%
   BM25 margin             200      90% (sd   8)   -0.77 MRR              14%     10%
   top5 vs rest             50      85% (sd  20)   -1.42 MRR              33%     15%
   top5 vs rest            100      88% (sd  11)   -1.06 MRR              26%     12%
   top5 vs rest            200      90% (sd   7)   -0.77 MRR              16%     10%
   NQC-like spread          50      83% (sd  18)   -1.22 MRR              44%     17%
   NQC-like spread         100      83% (sd  14)   -1.16 MRR              48%     17%
   NQC-like spread         200      85% (sd  10)   -0.96 MRR              44%     15%
   WIG-like                 50      83% (sd  19)   -1.21 MRR              40%     17%
   WIG-like                100      84% (sd  12)   -1.02 MRR              47%     16%
   WIG-like                200      86% (sd   7)   -0.72 MRR              38%     14%
   term coverage top1       50      71% (sd  23)   -1.62 MRR              50%     29%
   term coverage top1      100      76% (sd  17)   -1.12 MRR              40%     24%
   term coverage top1      200      76% (sd  11)   -0.85 MRR              39%     24%

## beir_arguana  (1401 questions; tag alarm fires on 10 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.2  random   0.3  diff  -0.1  p=0.8712
   MRR  : tag  25.4  random  25.5  diff  -0.1  p=0.8795

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.1 (p=0.206)
   40%            -0.1 (p=1.000)        -0.0 (p=0.602)
   50%            -0.2 (p=0.246)        -0.1 (p=0.169)
   1% nat         +0.1 (p=1.000)        +0.0 (p=0.893)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -18.5  95% CI [-20.6, -16.5]  p=0.000
   MRR  : -18.6  95% CI [-20.2, -17.0]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (19%)
   Hit@1:  +7.3  p=0.000
   MRR  :  +3.3  p=0.000

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.4/-0.1 (p=0.863)  40%: +1.6/-0.2 (p=0.781)  50%: +1.2/-0.5 (p=0.474)  nat: +0.0/-0.1 (p=0.126)
   vs NQC-like spread      30%: +1.1/-0.0 (p=0.999)  40%: +1.3/+0.3 (p=0.706)  50%: +1.5/+0.4 (p=0.557)  nat: -0.1/-0.1 (p=0.219)
   vs WIG-like             30%: +1.2/-0.1 (p=0.804)  40%: +1.6/-0.2 (p=0.780)  50%: +1.5/-0.4 (p=0.542)  nat: +0.1/+0.1 (p=0.111)
   vs term coverage top1   30%: +0.9/-0.3 (p=0.672)  40%: +2.1/+0.3 (p=0.613)  50%: +1.3/-0.2 (p=0.800)  nat: +0.1/-0.0 (p=0.973)

G. each selector reranking 10 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -18.6  [-20.2, -17.0]  p=0.000
   BM25 margin          -18.6  [-20.2, -17.0]  p=0.000
   top5 vs rest         -18.5  [-20.0, -16.9]  p=0.000
   NQC-like spread      -18.5  [-20.1, -16.9]  p=0.000
   WIG-like             -18.7  [-20.3, -17.1]  p=0.000
   term coverage top1   -18.6  [-20.2, -17.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              26.9    28.4    30.5    32.5    34.2    35.6    37.7    39.7    41.5    44.0*   100%
   BM25 margin            26.9    28.5    30.4    32.6    34.3    35.6    37.7    39.7    41.5    44.0*   100%
   top5 vs rest           27.5    29.4    30.6    32.7    34.7    36.6    38.5    40.0    42.3    44.0*   100%
   NQC-like spread        27.0    28.7    30.5    32.3    33.7    35.6    37.5    39.3    41.6    44.0*   100%
   WIG-like               26.6    28.6    30.6    32.7    34.6    36.6    38.7    41.1    42.7    44.0*   100%
   term coverage top1     27.1    29.1    30.8    32.2    34.3    36.5    38.2    40.7    42.3    44.0*   100%
   ORACLE                 33.6    38.8    42.6    45.1*   46.7*   47.5*   47.5*   47.5*   46.7*   44.0*   40%
   random (expected)      27.2    29.1    31.0    32.8    34.7    36.6    38.4    40.3    42.2    44.0*   100%
   (BM25 only 25.4; rerank ALL 44.0)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -17.1[-18.7]  -15.6[-17.1]  -13.5[-15.0]  -11.5[-12.8]   -9.8[-11.1]   -8.5[ -9.6]   -6.4[ -7.4]   -4.4[ -5.3]   -2.5[ -3.2]    100%   (point estimate: 100%)
   BM25 margin          -17.2[-18.7]  -15.6[-17.1]  -13.6[-15.0]  -11.5[-12.7]   -9.7[-11.0]   -8.4[ -9.5]   -6.4[ -7.4]   -4.3[ -5.2]   -2.5[ -3.2]    100%   (point estimate: 100%)
   top5 vs rest         -16.6[-18.1]  -14.6[-16.1]  -13.4[-14.8]  -11.3[-12.7]   -9.3[-10.6]   -7.4[ -8.5]   -5.5[ -6.5]   -4.0[ -4.8]   -1.7[ -2.2]    100%   (point estimate: 100%)
   NQC-like spread      -17.0[-18.5]  -15.3[-16.8]  -13.5[-15.0]  -11.8[-13.2]  -10.3[-11.6]   -8.4[ -9.7]   -6.5[ -7.6]   -4.7[ -5.5]   -2.4[ -3.0]    100%   (point estimate: 100%)
   WIG-like             -17.4[-18.9]  -15.5[-17.0]  -13.4[-14.8]  -11.3[-12.7]   -9.5[-10.6]   -7.5[ -8.6]   -5.3[ -6.3]   -2.9[ -3.6]   -1.3[ -1.8]    100%   (point estimate: 100%)
   term coverage top1   -16.9[-18.5]  -14.9[-16.3]  -13.3[-14.7]  -11.8[-13.1]   -9.7[-10.9]   -7.5[ -8.7]   -5.9[ -6.9]   -3.4[ -4.2]   -1.7[ -2.3]    100%   (point estimate: 100%)
   ORACLE               -10.5[-11.6]   -5.3[ -6.2]   -1.5[ -2.2]   +1.1[ +0.5]#  +2.7[ +2.2]#  +3.4[ +3.0]#  +3.5[ +3.0]#  +3.5[ +3.0]#  +2.7[ +2.2]#   40%   (point estimate: 40%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -17.1[-18.7]  -15.6[-17.1]  -13.5[-15.0]  -11.5[-12.8]   -9.8[-11.1]   -8.5[ -9.6]   -6.4[ -7.4]   -4.4[ -5.3]   -2.5[ -3.2]    100%   (point estimate: 100%)
   BM25 margin          -17.2[-18.7]  -15.6[-17.1]  -13.6[-15.0]  -11.5[-12.7]   -9.7[-11.0]   -8.4[ -9.5]   -6.4[ -7.4]   -4.3[ -5.2]   -2.5[ -3.2]    100%   (point estimate: 100%)
   top5 vs rest         -16.6[-18.1]  -14.6[-16.1]  -13.4[-14.8]  -11.3[-12.7]   -9.3[-10.6]   -7.4[ -8.5]   -5.5[ -6.5]   -4.0[ -4.8]   -1.7[ -2.2]    100%   (point estimate: 100%)
   NQC-like spread      -17.0[-18.5]  -15.3[-16.8]  -13.5[-15.0]  -11.8[-13.2]  -10.3[-11.6]   -8.4[ -9.7]   -6.5[ -7.6]   -4.7[ -5.5]   -2.4[ -3.0]    100%   (point estimate: 100%)
   WIG-like             -17.4[-18.9]  -15.5[-17.0]  -13.4[-14.8]  -11.3[-12.7]   -9.5[-10.6]   -7.5[ -8.6]   -5.3[ -6.3]   -2.9[ -3.6]   -1.3[ -1.8]    100%   (point estimate: 100%)
   term coverage top1   -16.9[-18.5]  -14.9[-16.3]  -13.3[-14.7]  -11.8[-13.1]   -9.7[-10.9]   -7.5[ -8.7]   -5.9[ -6.9]   -3.4[ -4.2]   -1.7[ -2.3]    100%   (point estimate: 100%)
   ORACLE               -10.5[-11.6]   -5.3[ -6.2]   -1.5[ -2.2]   +1.1[ +0.5]#  +2.7[ +2.2]#  +3.4[ +3.0]#  +3.5[ +3.0]#  +3.5[ +3.0]#  +2.7[ +2.2]#   40%   (point estimate: 40%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      98% (sd   4)   -0.41 MRR              16%      2%
   tag alarm               100      99% (sd   2)   -0.14 MRR               6%      1%
   tag alarm               200     100% (sd   1)   -0.05 MRR               2%      0%
   BM25 margin              50      98% (sd   5)   -0.48 MRR              16%      2%
   BM25 margin             100      99% (sd   2)   -0.17 MRR               6%      1%
   BM25 margin             200     100% (sd   1)   -0.03 MRR               1%      0%
   top5 vs rest             50      97% (sd   6)   -0.52 MRR              22%      3%
   top5 vs rest            100      99% (sd   3)   -0.19 MRR              10%      1%
   top5 vs rest            200      99% (sd   3)   -0.14 MRR               8%      1%
   NQC-like spread          50      98% (sd   4)   -0.51 MRR              20%      2%
   NQC-like spread         100      99% (sd   3)   -0.22 MRR               9%      1%
   NQC-like spread         200     100% (sd   1)   -0.02 MRR               1%      0%
   WIG-like                 50      95% (sd   7)   -0.69 MRR              37%      5%
   WIG-like                100      95% (sd   6)   -0.65 MRR              41%      5%
   WIG-like                200      97% (sd   5)   -0.46 MRR              32%      3%
   term coverage top1       50      97% (sd   6)   -0.62 MRR              27%      3%
   term coverage top1      100      98% (sd   4)   -0.35 MRR              18%      2%
   term coverage top1      200      99% (sd   3)   -0.20 MRR              10%      1%

## beir_scidocs  (1000 questions; tag alarm fires on 132 = 13%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  22.2  random  21.9  diff  +0.3  p=0.3028
   MRR  : tag  34.1  random  33.9  diff  +0.2  p=0.3171

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.9 (p=0.136)        -0.3 (p=0.371)
   40%            -0.4 (p=0.479)        -0.2 (p=0.415)
   50%            +0.3 (p=0.627)        +0.3 (p=0.402)
   13% nat        +0.1 (p=1.000)        +0.0 (p=0.942)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +1.4  95% CI [-0.8, +3.7]  p=0.257
   MRR  :  +1.8  95% CI [+0.1, +3.5]  p=0.039

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  -0.8  p=0.390
   MRR  :  -0.4  p=0.518

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.4/-0.6 (p=0.394)  40%: +0.4/-0.2 (p=0.782)  50%: +0.7/-0.1 (p=0.909)  nat: -0.3/-0.5 (p=0.245)
   vs NQC-like spread      30%: -0.4/-0.5 (p=0.418)  40%: -0.2/-0.4 (p=0.537)  50%: +0.4/-0.1 (p=0.919)  nat: -0.6/-0.6 (p=0.174)
   vs WIG-like             30%: -0.6/-0.6 (p=0.310)  40%: -0.4/-0.5 (p=0.472)  50%: -0.3/-0.1 (p=0.900)  nat: +0.0/-0.3 (p=0.478)
   vs term coverage top1   30%: -0.7/-0.7 (p=0.255)  40%: -0.4/-0.4 (p=0.509)  50%: +0.1/-0.0 (p=0.985)  nat: -0.6/-0.5 (p=0.289)

G. each selector reranking 132 questions (13%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +1.8  [+0.1, +3.5]  p=0.039
   BM25 margin           +1.8  [+0.0, +3.5]  p=0.046
   top5 vs rest          +2.3  [+0.6, +4.1]  p=0.008
   NQC-like spread       +2.4  [+0.7, +4.1]  p=0.005
   WIG-like              +2.1  [+0.4, +3.8]  p=0.015
   term coverage top1    +2.3  [+0.6, +3.9]  p=0.007

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              34.2*   33.6*   33.6*   33.7*   33.9*   33.2*   33.0*   32.4*   32.1*   32.3*   10%
   BM25 margin            33.8*   33.8*   34.0*   34.0*   33.6*   33.3*   33.2*   32.4*   32.0*   32.3*   10%
   top5 vs rest           34.8*   34.5*   34.2*   33.9*   34.0*   33.6*   33.5*   33.1*   32.4*   32.3*   10%
   NQC-like spread        34.9*   34.6*   34.2*   34.2*   34.0*   33.8*   33.6*   33.3*   32.9*   32.3*   10%
   WIG-like               34.3*   34.0*   34.2*   34.2*   34.0*   33.3*   33.4*   33.5*   33.0*   32.3*   10%
   term coverage top1     34.6*   34.4*   34.4*   34.2*   33.9*   33.7*   33.3*   32.8*   32.7*   32.3*   10%
   ORACLE                 39.9*   41.1*   41.2*   41.2*   41.2*   41.2*   41.2*   40.7*   38.8*   32.3*   10%
   random (expected)      34.0*   33.8*   33.6*   33.4*   33.2*   33.0*   32.9*   32.7*   32.5*   32.3*   10%
   (BM25 only 34.2; rerank ALL 32.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +1.9[ +0.3]#  +1.3[ -0.3]#  +1.4[ -0.1]#  +1.5[ +0.1]#  +1.6[ +0.4]#  +0.9[ -0.2]#  +0.7[ -0.2]#  +0.1[ -0.8]#  -0.1[ -0.7]#   10%   (point estimate: 10%)
   BM25 margin           +1.5[ -0.2]#  +1.5[ -0.1]#  +1.7[ +0.3]#  +1.7[ +0.3]#  +1.4[ +0.1]#  +1.0[ -0.1]#  +0.9[ -0.1]#  +0.1[ -0.7]#  -0.3[ -0.8]#   10%   (point estimate: 10%)
   top5 vs rest          +2.6[ +0.8]#  +2.2[ +0.5]#  +1.9[ +0.3]#  +1.7[ +0.2]#  +1.7[ +0.4]#  +1.3[ +0.1]#  +1.2[ +0.2]#  +0.8[ +0.0]#  +0.1[ -0.4]#   10%   (point estimate: 10%)
   NQC-like spread       +2.6[ +0.9]#  +2.3[ +0.8]#  +1.9[ +0.3]#  +1.9[ +0.5]#  +1.7[ +0.3]#  +1.5[ +0.2]#  +1.4[ +0.3]#  +1.0[ +0.1]#  +0.6[ -0.0]#   10%   (point estimate: 10%)
   WIG-like              +2.1[ +0.4]#  +1.7[ +0.1]#  +1.9[ +0.4]#  +1.9[ +0.5]#  +1.7[ +0.4]#  +1.0[ -0.2]#  +1.1[ +0.1]#  +1.3[ +0.4]#  +0.7[ +0.1]#   10%   (point estimate: 10%)
   term coverage top1    +2.3[ +0.7]#  +2.1[ +0.6]#  +2.1[ +0.7]#  +1.9[ +0.6]#  +1.6[ +0.5]#  +1.4[ +0.4]#  +1.0[ +0.2]#  +0.5[ -0.2]#  +0.4[ -0.1]#   10%   (point estimate: 10%)
   ORACLE                +7.6[ +6.4]#  +8.8[ +7.7]#  +9.0[ +7.8]#  +9.0[ +7.8]#  +9.0[ +7.8]#  +9.0[ +7.8]#  +8.9[ +7.7]#  +8.4[ +7.2]#  +6.5[ +5.4]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +1.9[ +0.3]#  +1.3[ -0.3]#  +1.4[ -0.1]#  +1.5[ +0.1]#  +1.6[ +0.4]#  +0.9[ -0.2]#  +0.7[ -0.2]#  +0.1[ -0.8]   -0.1[ -0.7]    100%   (point estimate: 10%)
   BM25 margin           +1.5[ -0.2]#  +1.5[ -0.1]#  +1.7[ +0.3]#  +1.7[ +0.3]#  +1.4[ +0.1]#  +1.0[ -0.1]#  +0.9[ -0.1]#  +0.1[ -0.7]   -0.3[ -0.8]    100%   (point estimate: 10%)
   top5 vs rest          +2.6[ +0.8]#  +2.2[ +0.5]#  +1.9[ +0.3]#  +1.7[ +0.2]#  +1.7[ +0.4]#  +1.3[ +0.1]#  +1.2[ +0.2]#  +0.8[ +0.0]#  +0.1[ -0.4]#   10%   (point estimate: 10%)
   NQC-like spread       +2.6[ +0.9]#  +2.3[ +0.8]#  +1.9[ +0.3]#  +1.9[ +0.5]#  +1.7[ +0.3]#  +1.5[ +0.2]#  +1.4[ +0.3]#  +1.0[ +0.1]#  +0.6[ -0.0]#   10%   (point estimate: 10%)
   WIG-like              +2.1[ +0.4]#  +1.7[ +0.1]#  +1.9[ +0.4]#  +1.9[ +0.5]#  +1.7[ +0.4]#  +1.0[ -0.2]#  +1.1[ +0.1]#  +1.3[ +0.4]#  +0.7[ +0.1]#   10%   (point estimate: 10%)
   term coverage top1    +2.3[ +0.7]#  +2.1[ +0.6]#  +2.1[ +0.7]#  +1.9[ +0.6]#  +1.6[ +0.5]#  +1.4[ +0.4]#  +1.0[ +0.2]#  +0.5[ -0.2]#  +0.4[ -0.1]#   10%   (point estimate: 10%)
   ORACLE                +7.6[ +6.4]#  +8.8[ +7.7]#  +9.0[ +7.8]#  +9.0[ +7.8]#  +9.0[ +7.8]#  +9.0[ +7.8]#  +8.9[ +7.7]#  +8.4[ +7.2]#  +6.5[ +5.4]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      45% (sd  39)   +1.10 MRR               0%     55%
   tag alarm               100      39% (sd  37)   +1.26 MRR               0%     61%
   tag alarm               200      23% (sd  30)   +1.52 MRR               0%     77%
   BM25 margin              50      43% (sd  39)   +0.95 MRR               0%     57%
   BM25 margin             100      30% (sd  34)   +1.16 MRR               0%     70%
   BM25 margin             200      25% (sd  31)   +1.23 MRR               0%     75%
   top5 vs rest             50      46% (sd  39)   +1.49 MRR               0%     54%
   top5 vs rest            100      31% (sd  34)   +1.95 MRR               0%     69%
   top5 vs rest            200      16% (sd  20)   +2.34 MRR               0%     84%
   NQC-like spread          50      35% (sd  36)   +1.91 MRR               0%     65%
   NQC-like spread         100      22% (sd  27)   +2.23 MRR               0%     78%
   NQC-like spread         200      16% (sd  19)   +2.42 MRR               0%     84%
   WIG-like                 50      40% (sd  36)   +1.52 MRR               0%     60%
   WIG-like                100      23% (sd  27)   +1.78 MRR               0%     77%
   WIG-like                200      14% (sd  16)   +1.94 MRR               0%     86%
   term coverage top1       50      33% (sd  33)   +1.71 MRR               0%     67%
   term coverage top1      100      24% (sd  28)   +1.88 MRR               0%     76%
   term coverage top1      200      12% (sd  11)   +2.07 MRR               0%     88%

## POOLED over 5 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  21.1  random  20.9  diff  +0.2  p=0.1192
   MRR  : tag  37.4  random  37.2  diff  +0.2  p=0.0717

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  -0.5 (p=0.084)   MRR  -0.2 (p=0.364)
   40%      Hit@1  -0.3 (p=0.336)   MRR  -0.1 (p=0.585)
   50%      Hit@1  -0.1 (p=0.637)   MRR  -0.0 (p=0.885)
   natural  Hit@1  -0.2 (p=0.643)   MRR  +0.0 (p=0.933)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -8.6  95% CI [-9.9, -7.4]  p=0.000
   MRR  :  -8.3  95% CI [-9.3, -7.3]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +3.5  p=0.000
   MRR  :  +1.8  p=0.000

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +0.7/-0.0 (p=0.926)  40%: +1.2/+0.1 (p=0.721)  50%: +1.0/-0.1 (p=0.867)  nat: +0.1/-0.1 (p=0.748)
   vs NQC-like spread      30%: +0.3/-0.2 (p=0.582)  40%: +0.5/-0.0 (p=0.939)  50%: +0.8/+0.1 (p=0.846)  nat: -0.1/-0.2 (p=0.452)
   vs WIG-like             30%: +0.5/-0.1 (p=0.739)  40%: +0.6/-0.2 (p=0.620)  50%: +0.7/-0.1 (p=0.760)  nat: +0.2/+0.1 (p=0.503)
   vs term coverage top1   30%: -0.3/-0.8 (p=0.027)  40%: +0.2/-0.4 (p=0.212)  50%: +0.1/-0.5 (p=0.209)  nat: -0.5/-0.4 (p=0.076)
