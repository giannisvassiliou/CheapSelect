## mag_testfull  (1000 questions; tag alarm fires on 262 = 26%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.4  random  52.3  diff  +5.1  p=0.0001
   MRR  : tag  66.0  random  62.2  diff  +3.8  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.7 (p=0.007)        +2.0 (p=0.005)
   40%            +2.2 (p=0.018)        +1.4 (p=0.031)
   50%            +1.4 (p=0.110)        +1.1 (p=0.065)
   26% nat        +2.9 (p=0.004)        +2.2 (p=0.002)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -3.8  95% CI [-6.1, -1.5]  p=0.002
   MRR  :  -3.9  95% CI [-5.5, -2.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (37%)
   Hit@1:  +3.3  p=0.003
   MRR  :  +1.9  p=0.012

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +4.2/+2.8 (p=0.001)  40%: +3.7/+2.4 (p=0.002)  50%: +3.9/+2.8 (p=0.000)  nat: +3.9/+2.8 (p=0.001)
   vs NQC-like spread      30%: +2.7/+1.8 (p=0.018)  40%: +1.7/+0.9 (p=0.222)  50%: +1.6/+1.3 (p=0.058)  nat: +3.0/+2.0 (p=0.008)
   vs WIG-like             30%: +1.9/+1.4 (p=0.059)  40%: +2.0/+1.4 (p=0.066)  50%: +2.1/+1.7 (p=0.019)  nat: +1.8/+1.2 (p=0.082)
   vs term coverage top1   30%: +2.8/+1.6 (p=0.044)  40%: +1.5/+0.5 (p=0.527)  50%: +1.3/+0.6 (p=0.434)  nat: +2.9/+1.8 (p=0.012)

G. each selector reranking 262 questions (26%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -3.9  [-5.5, -2.2]  p=0.000
   BM25 margin           -6.1  [-7.9, -4.3]  p=0.000
   top5 vs rest          -6.6  [-8.4, -4.9]  p=0.000
   NQC-like spread       -5.9  [-7.6, -4.1]  p=0.000
   WIG-like              -5.1  [-6.9, -3.4]  p=0.000
   term coverage top1    -5.7  [-7.6, -3.9]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              62.9    65.1    66.3    67.0    68.1    69.2*   69.9*   70.3*   70.3*   69.9*   60%
   BM25 margin            61.2    62.5    64.2    65.6    67.0    68.2    69.8*   70.5*   70.3*   69.9*   70%
   top5 vs rest           60.6    62.2    63.5    64.7    65.3    66.4    67.6    68.5    69.1    69.9*   100%
   NQC-like spread        60.6    62.9    64.5    66.1    66.9    67.2    67.7    68.8    69.5*   69.9*   90%
   WIG-like               62.2    63.9    64.9    65.6    66.4    66.8    67.9    68.7    69.0    69.9*   100%
   term coverage top1     61.2    63.3    64.7    66.6    67.5    68.0    68.4    69.2*   69.3*   69.9*   80%
   ORACLE                 68.0    73.3*   74.7*   74.7*   74.7*   74.7*   74.7*   74.7*   74.6*   69.9*   20%
   random (expected)      60.5    61.6    62.6    63.6    64.7    65.7    66.7    67.8    68.8    69.9*   100%
   (BM25 only 59.5; rerank ALL 69.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.0[ -8.9]   -4.8[ -6.5]   -3.6[ -5.2]   -2.8[ -4.3]   -1.7[ -3.0]   -0.6[ -1.7]   +0.1[ -0.7]#  +0.4[ -0.0]#  +0.5[ +0.1]#   70%   (point estimate: 60%)
   BM25 margin           -8.6[-10.6]   -7.4[ -9.3]   -5.6[ -7.3]   -4.3[ -5.9]   -2.8[ -4.2]   -1.7[ -2.8]   -0.0[ -0.9]#  +0.6[ +0.1]#  +0.5[ +0.1]#   70%   (point estimate: 70%)
   top5 vs rest          -9.3[-11.4]   -7.7[ -9.7]   -6.3[ -8.2]   -5.2[ -6.8]   -4.5[ -6.1]   -3.4[ -4.8]   -2.3[ -3.4]   -1.4[ -2.3]   -0.7[ -1.3]    100%   (point estimate: 90%)
   NQC-like spread       -9.2[-11.4]   -7.0[ -8.9]   -5.4[ -7.1]   -3.7[ -5.3]   -3.0[ -4.4]   -2.7[ -3.9]   -2.2[ -3.2]   -1.1[ -1.9]   -0.3[ -0.9]#   90%   (point estimate: 90%)
   WIG-like              -7.6[ -9.7]   -5.9[ -7.8]   -4.9[ -6.7]   -4.2[ -5.8]   -3.4[ -4.9]   -3.1[ -4.5]   -2.0[ -3.2]   -1.1[ -2.1]   -0.9[ -1.6]    100%   (point estimate: 90%)
   term coverage top1    -8.6[-10.7]   -6.5[ -8.4]   -5.1[ -6.9]   -3.3[ -4.8]   -2.3[ -3.8]   -1.8[ -3.2]   -1.4[ -2.6]   -0.7[ -1.7]   -0.5[ -1.2]    100%   (point estimate: 80%)
   ORACLE                -1.8[ -3.3]   +3.4[ +2.4]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.7[ +3.8]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.0[ -8.9]   -4.8[ -6.5]   -3.6[ -5.2]   -2.8[ -4.3]   -1.7[ -3.0]   -0.6[ -1.7]   +0.1[ -0.7]   +0.4[ -0.0]#  +0.5[ +0.1]#   80%   (point estimate: 70%)
   BM25 margin           -8.6[-10.6]   -7.4[ -9.3]   -5.6[ -7.3]   -4.3[ -5.9]   -2.8[ -4.2]   -1.7[ -2.8]   -0.0[ -0.9]   +0.6[ +0.1]#  +0.5[ +0.1]#   80%   (point estimate: 70%)
   top5 vs rest          -9.3[-11.4]   -7.7[ -9.7]   -6.3[ -8.2]   -5.2[ -6.8]   -4.5[ -6.1]   -3.4[ -4.8]   -2.3[ -3.4]   -1.4[ -2.3]   -0.7[ -1.3]    100%   (point estimate: 100%)
   NQC-like spread       -9.2[-11.4]   -7.0[ -8.9]   -5.4[ -7.1]   -3.7[ -5.3]   -3.0[ -4.4]   -2.7[ -3.9]   -2.2[ -3.2]   -1.1[ -1.9]   -0.3[ -0.9]    100%   (point estimate: 90%)
   WIG-like              -7.6[ -9.7]   -5.9[ -7.8]   -4.9[ -6.7]   -4.2[ -5.8]   -3.4[ -4.9]   -3.1[ -4.5]   -2.0[ -3.2]   -1.1[ -2.1]   -0.9[ -1.6]    100%   (point estimate: 100%)
   term coverage top1    -8.6[-10.7]   -6.5[ -8.4]   -5.1[ -6.9]   -3.3[ -4.8]   -2.3[ -3.8]   -1.8[ -3.2]   -1.4[ -2.6]   -0.7[ -1.7]   -0.5[ -1.2]    100%   (point estimate: 100%)
   ORACLE                -1.8[ -3.3]   +3.4[ +2.4]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.9[ +3.9]#  +4.7[ +3.8]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      62% (sd  22)   -1.04 MRR              32%     38%
   tag alarm               100      58% (sd  18)   -1.18 MRR              35%     42%
   tag alarm               200      61% (sd  12)   -0.88 MRR              28%     39%
   BM25 margin              50      66% (sd  17)   -1.16 MRR              44%     34%
   BM25 margin             100      65% (sd  15)   -1.17 MRR              46%     35%
   BM25 margin             200      67% (sd   9)   -0.72 MRR              34%     33%
   top5 vs rest             50      83% (sd  21)   -1.44 MRR              42%     17%
   top5 vs rest            100      86% (sd  16)   -1.15 MRR              36%     14%
   top5 vs rest            200      89% (sd  11)   -0.92 MRR              31%     11%
   NQC-like spread          50      79% (sd  24)   -1.49 MRR              47%     21%
   NQC-like spread         100      84% (sd  16)   -0.95 MRR              42%     16%
   NQC-like spread         200      85% (sd  11)   -0.90 MRR              45%     15%
   WIG-like                 50      82% (sd  25)   -1.37 MRR              38%     18%
   WIG-like                100      85% (sd  19)   -1.13 MRR              36%     15%
   WIG-like                200      87% (sd  15)   -1.03 MRR              40%     13%
   term coverage top1       50      76% (sd  28)   -1.57 MRR              38%     24%
   term coverage top1      100      76% (sd  22)   -1.38 MRR              42%     24%
   term coverage top1      200      77% (sd  19)   -1.27 MRR              46%     23%

## prime_testfull  (1000 questions; tag alarm fires on 546 = 55%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  29.3  random  25.8  diff  +3.5  p=0.0001
   MRR  : tag  38.6  random  35.2  diff  +3.4  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +3.3 (p=0.000)        +2.9 (p=0.000)
   40%            +3.3 (p=0.000)        +3.2 (p=0.000)
   50%            +2.8 (p=0.005)        +3.1 (p=0.000)
   55% nat        +3.3 (p=0.002)        +3.4 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.4  95% CI [-2.4, +1.6]  p=0.765
   MRR  :  -1.5  95% CI [-3.0, +0.0]  p=0.049

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +1.5  p=0.175
   MRR  :  +0.9  p=0.270

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +2.0/+1.6 (p=0.039)  40%: +2.7/+2.4 (p=0.005)  50%: +2.1/+1.8 (p=0.017)  nat: +2.3/+2.2 (p=0.003)
   vs NQC-like spread      30%: +1.2/+1.0 (p=0.191)  40%: +1.3/+1.1 (p=0.152)  50%: +1.0/+0.8 (p=0.270)  nat: +1.5/+1.3 (p=0.053)
   vs WIG-like             30%: +1.5/+1.4 (p=0.075)  40%: +2.5/+2.1 (p=0.010)  50%: +2.4/+2.0 (p=0.013)  nat: +1.9/+1.6 (p=0.051)
   vs term coverage top1   30%: +0.9/+0.6 (p=0.441)  40%: +2.4/+2.0 (p=0.018)  50%: +2.3/+2.3 (p=0.005)  nat: +2.3/+2.3 (p=0.007)

G. each selector reranking 546 questions (55%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -1.5  [-3.0, +0.0]  p=0.049
   BM25 margin           -4.9  [-6.6, -3.3]  p=0.000
   top5 vs rest          -3.7  [-5.4, -2.0]  p=0.000
   NQC-like spread       -2.9  [-4.6, -1.2]  p=0.001
   WIG-like              -3.1  [-4.7, -1.4]  p=0.000
   term coverage top1    -3.8  [-5.4, -2.2]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              31.0    32.6    34.6    36.5    37.8    38.1    38.4    39.3*   39.8*   40.1*   80%
   BM25 margin            30.1    30.5    31.7    33.3    34.8    36.4    37.7    38.9    39.8*   40.1*   90%
   top5 vs rest           30.1    31.7    32.9    34.2    36.0    37.2    38.5    39.1*   39.4*   40.1*   80%
   NQC-like spread        30.1    31.6    33.6    35.4    37.0    37.9    38.5    39.3*   39.6*   40.1*   80%
   WIG-like               31.0    32.2    33.2    34.5    35.8    37.3    38.7    39.4*   40.0*   40.1*   80%
   term coverage top1     30.7    32.4    34.0    34.6    35.5    37.1    37.6    38.1    39.2    40.1*   100%
   ORACLE                 38.6*   44.0*   45.8*   46.0*   46.0*   46.0*   46.0*   46.0*   45.7*   40.1*   10%
   random (expected)      30.3    31.4    32.5    33.6    34.7    35.8    36.8    37.9    39.0    40.1*   100%
   (BM25 only 29.3; rerank ALL 40.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -9.0[-11.3]   -7.5[ -9.6]   -5.5[ -7.5]   -3.5[ -5.3]   -2.3[ -3.7]   -2.0[ -3.4]   -1.6[ -2.8]   -0.8[ -1.7]   -0.3[ -0.9]#   90%   (point estimate: 80%)
   BM25 margin          -10.0[-12.4]   -9.6[-11.9]   -8.4[-10.5]   -6.8[ -8.6]   -5.3[ -7.0]   -3.7[ -5.2]   -2.4[ -3.6]   -1.2[ -2.2]   -0.3[ -0.9]#   90%   (point estimate: 90%)
   top5 vs rest         -10.0[-12.4]   -8.4[-10.7]   -7.1[ -9.3]   -5.9[ -7.9]   -4.1[ -5.8]   -2.9[ -4.5]   -1.6[ -2.9]   -0.9[ -2.1]   -0.7[ -1.5]    100%   (point estimate: 80%)
   NQC-like spread      -10.0[-12.4]   -8.4[-10.7]   -6.5[ -8.6]   -4.7[ -6.6]   -3.1[ -4.7]   -2.2[ -3.8]   -1.6[ -2.9]   -0.8[ -1.9]   -0.4[ -1.3]    100%   (point estimate: 80%)
   WIG-like              -9.1[-11.4]   -7.9[-10.1]   -6.8[ -8.9]   -5.6[ -7.5]   -4.3[ -6.1]   -2.8[ -4.4]   -1.4[ -2.8]   -0.6[ -1.8]   -0.1[ -0.8]#   90%   (point estimate: 80%)
   term coverage top1    -9.4[-11.7]   -7.6[ -9.8]   -6.1[ -8.1]   -5.5[ -7.3]   -4.6[ -6.3]   -3.0[ -4.6]   -2.4[ -3.7]   -2.0[ -3.0]   -0.9[ -1.6]    100%   (point estimate: 90%)
   ORACLE                -1.5[ -3.1]   +3.9[ +2.7]#  +5.8[ +4.7]#  +6.0[ +4.9]#  +6.0[ +4.9]#  +6.0[ +4.9]#  +6.0[ +4.9]#  +6.0[ +4.9]#  +5.6[ +4.5]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -9.0[-11.3]   -7.5[ -9.6]   -5.5[ -7.5]   -3.5[ -5.3]   -2.3[ -3.7]   -2.0[ -3.4]   -1.6[ -2.8]   -0.8[ -1.7]   -0.3[ -0.9]    100%   (point estimate: 90%)
   BM25 margin          -10.0[-12.4]   -9.6[-11.9]   -8.4[-10.5]   -6.8[ -8.6]   -5.3[ -7.0]   -3.7[ -5.2]   -2.4[ -3.6]   -1.2[ -2.2]   -0.3[ -0.9]    100%   (point estimate: 90%)
   top5 vs rest         -10.0[-12.4]   -8.4[-10.7]   -7.1[ -9.3]   -5.9[ -7.9]   -4.1[ -5.8]   -2.9[ -4.5]   -1.6[ -2.9]   -0.9[ -2.1]   -0.7[ -1.5]    100%   (point estimate: 100%)
   NQC-like spread      -10.0[-12.4]   -8.4[-10.7]   -6.5[ -8.6]   -4.7[ -6.6]   -3.1[ -4.7]   -2.2[ -3.8]   -1.6[ -2.9]   -0.8[ -1.9]   -0.4[ -1.3]    100%   (point estimate: 90%)
   WIG-like              -9.1[-11.4]   -7.9[-10.1]   -6.8[ -8.9]   -5.6[ -7.5]   -4.3[ -6.1]   -2.8[ -4.4]   -1.4[ -2.8]   -0.6[ -1.8]   -0.1[ -0.8]    100%   (point estimate: 90%)
   term coverage top1    -9.4[-11.7]   -7.6[ -9.8]   -6.1[ -8.1]   -5.5[ -7.3]   -4.6[ -6.3]   -3.0[ -4.6]   -2.4[ -3.7]   -2.0[ -3.0]   -0.9[ -1.6]    100%   (point estimate: 100%)
   ORACLE                -1.5[ -3.1]   +3.9[ +2.7]#  +5.8[ +4.7]#  +6.0[ +4.9]#  +6.0[ +4.9]#  +6.0[ +4.9]#  +6.0[ +4.9]#  +6.0[ +4.9]#  +5.6[ +4.5]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      77% (sd  25)   -1.41 MRR              34%     23%
   tag alarm               100      79% (sd  20)   -1.12 MRR              32%     21%
   tag alarm               200      78% (sd  19)   -1.16 MRR              36%     22%
   BM25 margin              50      82% (sd  20)   -1.51 MRR              46%     18%
   BM25 margin             100      84% (sd  14)   -1.15 MRR              44%     16%
   BM25 margin             200      85% (sd  10)   -0.92 MRR              42%     15%
   top5 vs rest             50      80% (sd  23)   -1.58 MRR              38%     20%
   top5 vs rest            100      84% (sd  20)   -1.29 MRR              37%     16%
   top5 vs rest            200      85% (sd  13)   -1.01 MRR              42%     15%
   NQC-like spread          50      79% (sd  24)   -1.51 MRR              31%     21%
   NQC-like spread         100      81% (sd  19)   -1.19 MRR              33%     19%
   NQC-like spread         200      81% (sd  17)   -1.16 MRR              39%     19%
   WIG-like                 50      78% (sd  24)   -1.57 MRR              34%     22%
   WIG-like                100      79% (sd  20)   -1.37 MRR              37%     21%
   WIG-like                200      80% (sd  14)   -1.08 MRR              37%     20%
   term coverage top1       50      86% (sd  22)   -1.38 MRR              38%     14%
   term coverage top1      100      91% (sd  13)   -0.89 MRR              32%      9%
   term coverage top1      200      92% (sd  11)   -0.85 MRR              40%      8%

## dbpedia_test  (400 questions; tag alarm fires on 68 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  49.5  random  47.4  diff  +2.1  p=0.0245
   MRR  : tag  60.1  random  57.9  diff  +2.3  p=0.0009

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.2 (p=0.531)        +1.8 (p=0.151)
   40%            +0.5 (p=0.857)        +0.8 (p=0.403)
   50%            +0.2 (p=1.000)        +0.5 (p=0.560)
   17% nat        +1.5 (p=0.470)        +2.3 (p=0.106)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -20.8  95% CI [-25.5, -16.0]  p=0.000
   MRR  : -16.8  95% CI [-20.2, -13.4]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (52%)
   Hit@1:  -1.0  p=0.726
   MRR  :  -1.1  p=0.477

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.0/+2.1 (p=0.134)  40%: +3.0/+1.8 (p=0.256)  50%: +1.8/+0.6 (p=0.714)  nat: +2.5/+2.5 (p=0.059)
   vs NQC-like spread      30%: +3.8/+2.5 (p=0.080)  40%: +4.8/+2.7 (p=0.085)  50%: +2.2/+0.5 (p=0.748)  nat: +1.5/+1.6 (p=0.231)
   vs WIG-like             30%: +1.0/-0.1 (p=0.943)  40%: +1.2/+0.0 (p=0.991)  50%: +1.0/-0.4 (p=0.758)  nat: +1.8/+1.0 (p=0.412)
   vs term coverage top1   30%: +1.2/+0.6 (p=0.643)  40%: +1.8/+0.6 (p=0.655)  50%: +0.8/-0.4 (p=0.804)  nat: +2.2/+1.9 (p=0.115)

G. each selector reranking 68 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -16.8  [-20.2, -13.4]  p=0.000
   BM25 margin          -19.1  [-22.7, -15.5]  p=0.000
   top5 vs rest         -19.3  [-22.8, -15.8]  p=0.000
   NQC-like spread      -18.4  [-21.9, -14.9]  p=0.000
   WIG-like             -17.8  [-21.3, -14.4]  p=0.000
   term coverage top1   -18.7  [-22.1, -15.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              57.9    61.1    63.4    65.8    67.9    69.9    72.6    74.6    76.6*   76.9*   90%
   BM25 margin            56.9    58.9    61.7    64.9    67.4    69.9    71.9    73.9    76.1*   76.9*   90%
   top5 vs rest           56.0    58.3    61.3    64.0    67.3    69.1    70.8    73.6    75.5    76.9*   100%
   NQC-like spread        56.2    58.9    60.9    63.0    67.4    69.8    71.7    74.0    75.7    76.9*   100%
   WIG-like               57.3    59.5    63.5    65.8    68.3    70.1    72.3    75.2    76.1*   76.9*   90%
   term coverage top1     57.0    59.2    62.8    65.2    68.3    70.5    72.1    74.0    75.3    76.9*   100%
   ORACLE                 63.4    71.2    76.5*   79.2*   79.4*   79.4*   79.4*   79.4*   79.4*   76.9*   30%
   random (expected)      56.3    58.6    60.8    63.1    65.4    67.7    70.0    72.3    74.6    76.9*   100%
   (BM25 only 54.0; rerank ALL 76.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -19.0[-22.6]  -15.9[-19.1]  -13.5[-16.5]  -11.1[-13.8]   -9.0[-11.6]   -7.0[ -9.4]   -4.3[ -6.3]   -2.3[ -4.0]   -0.3[ -1.1]    100%   (point estimate: 90%)
   BM25 margin          -20.0[-23.6]  -18.0[-21.3]  -15.3[-18.3]  -12.0[-14.9]   -9.5[-12.4]   -7.0[ -9.3]   -5.0[ -7.1]   -3.1[ -4.8]   -0.8[ -1.8]    100%   (point estimate: 90%)
   top5 vs rest         -20.9[-24.6]  -18.6[-22.0]  -15.6[-18.8]  -12.9[-15.8]   -9.6[-12.2]   -7.8[-10.2]   -6.1[ -8.3]   -3.3[ -4.8]   -1.4[ -2.5]    100%   (point estimate: 100%)
   NQC-like spread      -20.7[-24.5]  -18.0[-21.4]  -16.0[-19.1]  -13.9[-16.9]   -9.6[-12.1]   -7.2[ -9.4]   -5.2[ -7.2]   -2.9[ -4.4]   -1.2[ -2.3]    100%   (point estimate: 100%)
   WIG-like             -19.6[-23.1]  -17.4[-20.6]  -13.4[-16.4]  -11.2[-14.0]   -8.6[-11.1]   -6.8[ -9.1]   -4.6[ -6.5]   -1.8[ -3.0]   -0.8[ -1.6]    100%   (point estimate: 90%)
   term coverage top1   -19.9[-23.5]  -17.7[-21.1]  -14.1[-17.0]  -11.7[-14.5]   -8.7[-11.1]   -6.4[ -8.7]   -4.8[ -6.8]   -2.9[ -4.5]   -1.6[ -2.9]    100%   (point estimate: 100%)
   ORACLE               -13.5[-16.5]   -5.7[ -7.9]   -0.4[ -1.9]   +2.3[ +1.2]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#   40%   (point estimate: 30%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -19.0[-22.6]  -15.9[-19.1]  -13.5[-16.5]  -11.1[-13.8]   -9.0[-11.6]   -7.0[ -9.4]   -4.3[ -6.3]   -2.3[ -4.0]   -0.3[ -1.1]    100%   (point estimate: 90%)
   BM25 margin          -20.0[-23.6]  -18.0[-21.3]  -15.3[-18.3]  -12.0[-14.9]   -9.5[-12.4]   -7.0[ -9.3]   -5.0[ -7.1]   -3.1[ -4.8]   -0.8[ -1.8]    100%   (point estimate: 100%)
   top5 vs rest         -20.9[-24.6]  -18.6[-22.0]  -15.6[-18.8]  -12.9[-15.8]   -9.6[-12.2]   -7.8[-10.2]   -6.1[ -8.3]   -3.3[ -4.8]   -1.4[ -2.5]    100%   (point estimate: 100%)
   NQC-like spread      -20.7[-24.5]  -18.0[-21.4]  -16.0[-19.1]  -13.9[-16.9]   -9.6[-12.1]   -7.2[ -9.4]   -5.2[ -7.2]   -2.9[ -4.4]   -1.2[ -2.3]    100%   (point estimate: 100%)
   WIG-like             -19.6[-23.1]  -17.4[-20.6]  -13.4[-16.4]  -11.2[-14.0]   -8.6[-11.1]   -6.8[ -9.1]   -4.6[ -6.5]   -1.8[ -3.0]   -0.8[ -1.6]    100%   (point estimate: 100%)
   term coverage top1   -19.9[-23.5]  -17.7[-21.1]  -14.1[-17.0]  -11.7[-14.5]   -8.7[-11.1]   -6.4[ -8.7]   -4.8[ -6.8]   -2.9[ -4.5]   -1.6[ -2.9]    100%   (point estimate: 100%)
   ORACLE               -13.5[-16.5]   -5.7[ -7.9]   -0.4[ -1.9]   +2.3[ +1.2]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#  +2.5[ +1.4]#   40%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      91% (sd   9)   -0.89 MRR              22%      9%
   tag alarm               100      91% (sd   7)   -0.74 MRR              17%      9%
   tag alarm               200      91% (sd   4)   -0.53 MRR              11%      9%
   BM25 margin              50      93% (sd   8)   -0.83 MRR              16%      7%
   BM25 margin             100      92% (sd   6)   -0.84 MRR              26%      8%
   BM25 margin             200      92% (sd   5)   -0.91 MRR              35%      8%
   top5 vs rest             50      94% (sd   7)   -0.92 MRR              43%      6%
   top5 vs rest            100      97% (sd   5)   -0.53 MRR              32%      3%
   top5 vs rest            200      97% (sd   4)   -0.53 MRR              26%      3%
   NQC-like spread          50      93% (sd   9)   -1.03 MRR              40%      7%
   NQC-like spread         100      94% (sd   7)   -0.86 MRR              43%      6%
   NQC-like spread         200      95% (sd   5)   -0.77 MRR              44%      5%
   WIG-like                 50      92% (sd   9)   -0.88 MRR              24%      8%
   WIG-like                100      91% (sd   7)   -0.87 MRR              33%      9%
   WIG-like                200      92% (sd   5)   -0.83 MRR              30%      8%
   term coverage top1       50      96% (sd   7)   -0.73 MRR              29%      4%
   term coverage top1      100      97% (sd   6)   -0.55 MRR              24%      3%
   term coverage top1      200      98% (sd   5)   -0.36 MRR              16%      2%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  15%  MRR  55.2 | vs BM25 margin: +3.8 (p=0.148)  vs top5 vs rest: -2.6 (p=0.317)  vs NQC-like spread: -2.1 (p=0.421)  vs WIG-like: -1.2 (p=0.661)  vs term coverage top1: -2.3 (p=0.445)
   list           n= 105  fires  16%  MRR  62.5 | vs BM25 margin: -2.1 (p=0.508)  vs top5 vs rest: +5.3 (p=0.062)  vs NQC-like spread: +2.9 (p=0.340)  vs WIG-like: +2.9 (p=0.233)  vs term coverage top1: +5.9 (p=0.020)
   question       n= 125  fires  22%  MRR  47.6 | vs BM25 margin: +6.1 (p=0.033)  vs top5 vs rest: +4.7 (p=0.074)  vs NQC-like spread: +3.6 (p=0.175)  vs WIG-like: -0.5 (p=0.851)  vs term coverage top1: +1.1 (p=0.641)
   named entity   n=  86  fires  12%  MRR  80.3 | vs BM25 margin: +0.5 (p=0.846)  vs top5 vs rest: +0.7 (p=0.757)  vs NQC-like spread: +0.7 (p=0.757)  vs WIG-like: +3.0 (p=0.124)  vs term coverage top1: +2.2 (p=0.248)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR +0.9  [-2.3, +4.2]  p=0.589  (n=211)

## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.0  random  56.3  diff  +0.7  p=0.2515
   MRR  : tag  65.5  random  65.2  diff  +0.3  p=0.3174

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.3 (p=1.000)        +0.3 (p=0.716)
   40%            -1.0 (p=0.379)        -1.0 (p=0.065)
   50%            -0.3 (p=1.000)        -0.4 (p=0.430)
   15% nat        -1.3 (p=0.502)        -1.4 (p=0.188)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -10.0  95% CI [-14.3, -6.0]  p=0.000
   MRR  :  -8.8  95% CI [-11.8, -5.9]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (29%)
   Hit@1:  +3.3  p=0.076
   MRR  :  +2.7  p=0.031

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +4.3/+2.8 (p=0.028)  40%: +4.0/+3.0 (p=0.039)  50%: +3.7/+2.9 (p=0.042)  nat: +1.3/+0.6 (p=0.512)
   vs NQC-like spread      30%: +1.0/+0.1 (p=0.959)  40%: +0.7/-0.2 (p=0.875)  50%: +0.7/+0.7 (p=0.576)  nat: -1.0/-1.3 (p=0.198)
   vs WIG-like             30%: +1.0/-0.1 (p=0.926)  40%: +0.3/-0.4 (p=0.780)  50%: +1.3/+0.8 (p=0.559)  nat: +0.3/-0.4 (p=0.678)
   vs term coverage top1   30%: +0.3/-0.1 (p=0.943)  40%: -0.3/-0.4 (p=0.785)  50%: +0.7/+0.5 (p=0.660)  nat: -0.7/-1.0 (p=0.337)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -8.8  [-11.8, -5.9]  p=0.000
   BM25 margin           -7.4  [-10.2, -4.7]  p=0.000
   top5 vs rest          -9.4  [-12.6, -6.4]  p=0.000
   NQC-like spread       -7.5  [-10.5, -4.7]  p=0.000
   WIG-like              -8.4  [-11.4, -5.5]  p=0.000
   term coverage top1    -7.8  [-10.9, -4.9]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              65.4    66.6    68.9    69.7    71.5    72.6    73.6    74.1*   74.2*   74.3*   80%
   BM25 margin            65.4    67.6    68.6    70.7    71.9    73.2    74.0*   74.0*   74.2*   74.3*   70%
   top5 vs rest           64.4    65.0    66.1    66.8    68.6    69.4    70.1    71.7    73.1*   74.3*   90%
   NQC-like spread        66.0    67.8    68.8    69.9    70.8    71.7    72.9    73.6*   73.8*   74.3*   80%
   WIG-like               65.2    67.3    69.0    70.1    70.7    71.2    71.8    72.4    73.8*   74.3*   90%
   term coverage top1     65.7    67.5    69.0    70.1    71.0    72.3    73.1    73.2    73.6*   74.3*   90%
   ORACLE                 71.7    75.6*   76.3*   76.3*   76.3*   76.3*   76.3*   76.3*   76.3*   74.3*   20%
   random (expected)      64.6    65.7    66.8    67.9    68.9    70.0    71.1    72.1    73.2    74.3*   100%
   (BM25 only 63.6; rerank ALL 74.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.8[-11.9]   -7.7[-10.6]   -5.4[ -8.2]   -4.6[ -6.9]   -2.8[ -4.5]   -1.7[ -2.9]   -0.7[ -1.3]   -0.2[ -0.5]#  -0.1[ -0.2]#   80%   (point estimate: 70%)
   BM25 margin           -8.9[-12.0]   -6.7[ -9.5]   -5.6[ -8.2]   -3.6[ -5.7]   -2.4[ -3.9]   -1.1[ -1.8]   -0.3[ -0.6]#  -0.2[ -0.5]#  -0.1[ -0.2]#   70%   (point estimate: 70%)
   top5 vs rest          -9.8[-13.0]   -9.3[-12.4]   -8.2[-11.4]   -7.5[-10.4]   -5.7[ -8.3]   -4.9[ -7.4]   -4.2[ -6.4]   -2.6[ -4.5]   -1.2[ -2.6]    100%   (point estimate: 100%)
   NQC-like spread       -8.3[-11.4]   -6.5[ -9.1]   -5.5[ -7.8]   -4.4[ -6.6]   -3.5[ -5.3]   -2.6[ -4.3]   -1.4[ -2.8]   -0.7[ -1.9]   -0.5[ -1.2]    100%   (point estimate: 80%)
   WIG-like              -9.1[-12.1]   -7.0[ -9.9]   -5.3[ -7.8]   -4.2[ -6.2]   -3.5[ -5.6]   -3.1[ -5.0]   -2.4[ -4.3]   -1.9[ -3.4]   -0.5[ -1.6]    100%   (point estimate: 90%)
   term coverage top1    -8.6[-11.7]   -6.8[ -9.7]   -5.3[ -7.8]   -4.2[ -6.3]   -3.3[ -5.2]   -2.0[ -3.7]   -1.2[ -2.5]   -1.1[ -2.3]   -0.6[ -1.5]    100%   (point estimate: 90%)
   ORACLE                -2.6[ -4.5]   +1.3[ +0.2]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.8[-11.9]   -7.7[-10.6]   -5.4[ -8.2]   -4.6[ -6.9]   -2.8[ -4.5]   -1.7[ -2.9]   -0.7[ -1.3]   -0.2[ -0.5]#  -0.1[ -0.2]#   80%   (point estimate: 80%)
   BM25 margin           -8.9[-12.0]   -6.7[ -9.5]   -5.6[ -8.2]   -3.6[ -5.7]   -2.4[ -3.9]   -1.1[ -1.8]   -0.3[ -0.6]   -0.2[ -0.5]   -0.1[ -0.2]#   90%   (point estimate: 70%)
   top5 vs rest          -9.8[-13.0]   -9.3[-12.4]   -8.2[-11.4]   -7.5[-10.4]   -5.7[ -8.3]   -4.9[ -7.4]   -4.2[ -6.4]   -2.6[ -4.5]   -1.2[ -2.6]    100%   (point estimate: 100%)
   NQC-like spread       -8.3[-11.4]   -6.5[ -9.1]   -5.5[ -7.8]   -4.4[ -6.6]   -3.5[ -5.3]   -2.6[ -4.3]   -1.4[ -2.8]   -0.7[ -1.9]   -0.5[ -1.2]    100%   (point estimate: 100%)
   WIG-like              -9.1[-12.1]   -7.0[ -9.9]   -5.3[ -7.8]   -4.2[ -6.2]   -3.5[ -5.6]   -3.1[ -5.0]   -2.4[ -4.3]   -1.9[ -3.4]   -0.5[ -1.6]    100%   (point estimate: 100%)
   term coverage top1    -8.6[-11.7]   -6.8[ -9.7]   -5.3[ -7.8]   -4.2[ -6.3]   -3.3[ -5.2]   -2.0[ -3.7]   -1.2[ -2.5]   -1.1[ -2.3]   -0.6[ -1.5]    100%   (point estimate: 100%)
   ORACLE                -2.6[ -4.5]   +1.3[ +0.2]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#  +2.0[ +1.1]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      66% (sd  13)   -1.37 MRR              40%     34%
   tag alarm               100      70% (sd   7)   -0.86 MRR              25%     30%
   tag alarm               200      69% (sd   5)   -0.83 MRR              24%     31%
   BM25 margin              50      63% (sd  12)   -1.19 MRR              45%     37%
   BM25 margin             100      64% (sd   7)   -0.87 MRR              41%     36%
   BM25 margin             200      66% (sd   5)   -0.76 MRR              30%     34%
   top5 vs rest             50      91% (sd  13)   -1.28 MRR              48%      9%
   top5 vs rest            100      94% (sd   7)   -0.89 MRR              46%      6%
   top5 vs rest            200      96% (sd   5)   -0.71 MRR              34%      4%
   NQC-like spread          50      80% (sd  20)   -1.39 MRR              40%     20%
   NQC-like spread         100      80% (sd  12)   -1.15 MRR              44%     20%
   NQC-like spread         200      81% (sd   8)   -1.16 MRR              43%     19%
   WIG-like                 50      86% (sd  19)   -1.25 MRR              33%     14%
   WIG-like                100      90% (sd  10)   -0.95 MRR              30%     10%
   WIG-like                200      91% (sd   5)   -0.95 MRR              34%      9%
   term coverage top1       50      80% (sd  17)   -1.27 MRR              48%     20%
   term coverage top1      100      82% (sd  13)   -1.18 MRR              49%     18%
   term coverage top1      200      85% (sd   8)   -0.91 MRR              34%     15%

## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  43.7  random  44.1  diff  -0.5  p=0.9668
   MRR  : tag  52.0  random  52.3  diff  -0.3  p=0.8925

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.1 (p=1.000)
   40%            -0.6 (p=0.504)        -0.4 (p=0.504)
   50%            +0.3 (p=1.000)        +0.1 (p=0.753)
   2% nat         -0.3 (p=1.000)        -0.1 (p=1.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.7  95% CI [-12.4, -3.1]  p=0.002
   MRR  :  -7.4  95% CI [-10.7, -4.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +0.9  p=0.686
   MRR  :  +0.4  p=0.724

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.9/+0.7 (p=0.545)  40%: +1.2/+0.9 (p=0.488)  50%: +2.5/+1.4 (p=0.288)  nat: -0.3/-0.1 (p=1.000)
   vs NQC-like spread      30%: +2.5/+0.6 (p=0.604)  40%: +0.9/-0.0 (p=0.990)  50%: +2.5/+0.9 (p=0.473)  nat: -0.3/-0.1 (p=1.000)
   vs WIG-like             30%: +0.6/+0.2 (p=0.882)  40%: -0.3/+0.1 (p=0.964)  50%: +0.6/+0.4 (p=0.760)  nat: -0.3/-0.1 (p=1.000)
   vs term coverage top1   30%: +0.9/-0.1 (p=0.961)  40%: -0.3/-0.7 (p=0.568)  50%: -0.9/-1.3 (p=0.230)  nat: -0.3/-0.1 (p=1.000)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -7.4  [-10.7, -4.3]  p=0.000
   BM25 margin           -7.3  [-10.5, -4.2]  p=0.000
   top5 vs rest          -7.3  [-10.5, -4.2]  p=0.000
   NQC-like spread       -7.3  [-10.5, -4.2]  p=0.000
   WIG-like              -7.3  [-10.5, -4.2]  p=0.000
   term coverage top1    -7.3  [-10.5, -4.2]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              52.0    53.4    55.2    55.9    57.0    57.3    57.6    58.2*   58.8*   59.5*   80%
   BM25 margin            52.1    53.6    55.3    56.4    56.9    57.4    57.6    58.2*   58.8*   59.5*   80%
   top5 vs rest           52.0    53.1    54.6    55.1    55.6    56.5    57.6    59.0*   59.5*   59.5*   80%
   NQC-like spread        51.6    54.1    54.7    55.9    56.2    57.6    58.6*   58.9*   59.0*   59.5*   70%
   WIG-like               52.1    52.6    55.1    55.9    56.6    57.8*   58.5*   58.8*   59.6*   59.5*   60%
   term coverage top1     52.7    53.7    55.3    56.6    58.3*   57.9*   58.3*   58.1    58.4*   59.5*   90%
   ORACLE                 59.4*   63.0*   63.3*   63.3*   63.3*   63.3*   63.3*   63.3*   63.3*   59.5*   10%
   random (expected)      52.9    53.6    54.3    55.1    55.8    56.5    57.3    58.0    58.7    59.5*   100%
   (BM25 only 52.1; rerank ALL 59.5)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.5[-10.7]   -6.0[ -9.0]   -4.2[ -6.8]   -3.5[ -6.0]   -2.4[ -4.6]   -2.2[ -4.2]   -1.8[ -3.4]   -1.2[ -2.5]   -0.7[ -1.4]    100%   (point estimate: 90%)
   BM25 margin           -7.4[-10.5]   -5.8[ -8.7]   -4.2[ -6.8]   -3.1[ -5.5]   -2.6[ -4.7]   -2.1[ -4.0]   -1.8[ -3.4]   -1.2[ -2.5]   -0.7[ -1.4]    100%   (point estimate: 90%)
   top5 vs rest          -7.5[-10.5]   -6.3[ -9.3]   -4.9[ -7.5]   -4.4[ -6.9]   -3.8[ -6.1]   -3.0[ -5.1]   -1.8[ -3.5]   -0.5[ -1.6]   +0.1[ -0.7]#   90%   (point estimate: 80%)
   NQC-like spread       -7.8[-10.9]   -5.4[ -8.1]   -4.8[ -7.3]   -3.5[ -5.8]   -3.3[ -5.2]   -1.9[ -3.4]   -0.9[ -2.0]   -0.5[ -1.4]   -0.4[ -1.0]    100%   (point estimate: 70%)
   WIG-like              -7.3[-10.5]   -6.8[ -9.8]   -4.4[ -7.1]   -3.6[ -6.1]   -2.8[ -5.0]   -1.6[ -3.6]   -1.0[ -2.5]   -0.6[ -1.9]   +0.1[ -0.5]#   90%   (point estimate: 80%)
   term coverage top1    -6.8[-10.0]   -5.8[ -8.5]   -4.2[ -6.7]   -2.8[ -5.2]   -1.2[ -3.2]   -1.6[ -3.4]   -1.2[ -2.7]   -1.3[ -2.7]   -1.0[ -2.2]    100%   (point estimate: 100%)
   ORACLE                -0.0[ -2.1]   +3.6[ +2.1]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#   20%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.5[-10.7]   -6.0[ -9.0]   -4.2[ -6.8]   -3.5[ -6.0]   -2.4[ -4.6]   -2.2[ -4.2]   -1.8[ -3.4]   -1.2[ -2.5]   -0.7[ -1.4]    100%   (point estimate: 100%)
   BM25 margin           -7.4[-10.5]   -5.8[ -8.7]   -4.2[ -6.8]   -3.1[ -5.5]   -2.6[ -4.7]   -2.1[ -4.0]   -1.8[ -3.4]   -1.2[ -2.5]   -0.7[ -1.4]    100%   (point estimate: 100%)
   top5 vs rest          -7.5[-10.5]   -6.3[ -9.3]   -4.9[ -7.5]   -4.4[ -6.9]   -3.8[ -6.1]   -3.0[ -5.1]   -1.8[ -3.5]   -0.5[ -1.6]   +0.1[ -0.7]    100%   (point estimate: 90%)
   NQC-like spread       -7.8[-10.9]   -5.4[ -8.1]   -4.8[ -7.3]   -3.5[ -5.8]   -3.3[ -5.2]   -1.9[ -3.4]   -0.9[ -2.0]   -0.5[ -1.4]   -0.4[ -1.0]    100%   (point estimate: 90%)
   WIG-like              -7.3[-10.5]   -6.8[ -9.8]   -4.4[ -7.1]   -3.6[ -6.1]   -2.8[ -5.0]   -1.6[ -3.6]   -1.0[ -2.5]   -0.6[ -1.9]   +0.1[ -0.5]    100%   (point estimate: 90%)
   term coverage top1    -6.8[-10.0]   -5.8[ -8.5]   -4.2[ -6.7]   -2.8[ -5.2]   -1.2[ -3.2]   -1.6[ -3.4]   -1.2[ -2.7]   -1.3[ -2.7]   -1.0[ -2.2]    100%   (point estimate: 100%)
   ORACLE                -0.0[ -2.1]   +3.6[ +2.1]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#  +3.9[ +2.5]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      79% (sd  24)   -1.48 MRR              42%     21%
   tag alarm               100      83% (sd  17)   -1.30 MRR              40%     17%
   tag alarm               200      88% (sd  10)   -1.02 MRR              35%     12%
   BM25 margin              50      79% (sd  24)   -1.45 MRR              46%     21%
   BM25 margin             100      85% (sd  16)   -1.07 MRR              32%     15%
   BM25 margin             200      88% (sd  10)   -1.03 MRR              38%     12%
   top5 vs rest             50      75% (sd  22)   -1.63 MRR              40%     25%
   top5 vs rest            100      78% (sd  13)   -1.15 MRR              28%     22%
   top5 vs rest            200      80% (sd   5)   -0.75 MRR              30%     20%
   NQC-like spread          50      79% (sd  21)   -1.10 MRR              26%     21%
   NQC-like spread         100      76% (sd  14)   -1.10 MRR              34%     24%
   NQC-like spread         200      74% (sd   8)   -1.04 MRR              46%     26%
   WIG-like                 50      73% (sd  25)   -1.50 MRR              39%     27%
   WIG-like                100      74% (sd  15)   -1.10 MRR              39%     26%
   WIG-like                200      74% (sd  10)   -1.00 MRR              44%     26%
   term coverage top1       50      73% (sd  28)   -1.41 MRR              42%     27%
   term coverage top1      100      76% (sd  19)   -0.96 MRR              39%     24%
   term coverage top1      200      73% (sd  17)   -1.15 MRR              49%     27%

## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.8  random  19.7  diff  +0.1  p=0.4774
   MRR  : tag  29.6  random  29.6  diff  +0.0  p=0.4820

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.7 (p=0.285)        -0.6 (p=0.185)
   40%            +0.1 (p=1.000)        -0.1 (p=0.812)
   50%            -0.3 (p=0.651)        -0.2 (p=0.558)
   12% nat        -0.1 (p=1.000)        +0.2 (p=0.716)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.5  95% CI [-9.9, -5.1]  p=0.000
   MRR  :  -9.1  95% CI [-10.9, -7.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +0.7  p=0.475
   MRR  :  +0.3  p=0.636

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.4/+0.6 (p=0.372)  40%: +1.9/+1.0 (p=0.171)  50%: +1.9/+0.8 (p=0.311)  nat: +0.5/+0.2 (p=0.688)
   vs NQC-like spread      30%: +0.8/+0.1 (p=0.859)  40%: +1.1/+0.4 (p=0.629)  50%: +1.4/+0.6 (p=0.433)  nat: +0.6/+0.3 (p=0.437)
   vs WIG-like             30%: +1.0/+0.1 (p=0.846)  40%: +0.7/-0.4 (p=0.603)  50%: +0.7/-0.2 (p=0.782)  nat: +0.2/-0.1 (p=0.858)
   vs term coverage top1   30%: -0.6/-1.0 (p=0.148)  40%: -0.5/-0.9 (p=0.189)  50%: -0.9/-1.1 (p=0.106)  nat: -0.4/-0.5 (p=0.301)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -9.1  [-10.9, -7.2]  p=0.000
   BM25 margin           -9.2  [-11.0, -7.4]  p=0.000
   top5 vs rest          -9.2  [-11.1, -7.4]  p=0.000
   NQC-like spread       -9.4  [-11.3, -7.5]  p=0.000
   WIG-like              -9.0  [-10.8, -7.1]  p=0.000
   term coverage top1    -8.5  [-10.3, -6.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              29.6    30.1    31.6    32.7    33.8    35.0    36.0    36.8    38.0    38.6*   100%
   BM25 margin            29.1    30.9    32.2    32.8    34.0    35.1    36.5    36.9    38.3*   38.6*   90%
   top5 vs rest           29.0    30.8    31.0    31.7    33.0    34.4    35.5    36.4    37.4    38.6*   100%
   NQC-like spread        29.1    30.1    31.5    32.4    33.2    34.5    35.3    36.7    37.9    38.6*   100%
   WIG-like               29.5    30.3    31.5    33.1    34.0    35.3    36.2    36.7    37.5    38.6*   100%
   term coverage top1     30.0    31.3    32.6    33.6    34.9    35.7    36.5    38.1*   38.3*   38.6*   80%
   ORACLE                 36.5    40.3*   41.9*   42.4*   42.4*   42.4*   42.4*   42.4*   42.3*   38.6*   20%
   random (expected)      29.4    30.4    31.4    32.4    33.5    34.5    35.5    36.6    37.6    38.6*   100%
   (BM25 only 28.3; rerank ALL 38.6)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -9.0[-10.9]   -8.6[-10.4]   -7.0[ -8.7]   -5.9[ -7.4]   -4.8[ -6.2]   -3.6[ -4.8]   -2.6[ -3.7]   -1.9[ -2.7]   -0.7[ -1.1]    100%   (point estimate: 90%)
   BM25 margin           -9.6[-11.5]   -7.8[ -9.6]   -6.4[ -8.1]   -5.8[ -7.4]   -4.6[ -6.0]   -3.5[ -4.7]   -2.1[ -3.2]   -1.7[ -2.6]   -0.4[ -0.8]#   90%   (point estimate: 90%)
   top5 vs rest          -9.6[-11.4]   -7.9[ -9.6]   -7.6[ -9.3]   -6.9[ -8.6]   -5.6[ -7.0]   -4.2[ -5.5]   -3.2[ -4.3]   -2.2[ -3.1]   -1.2[ -1.9]    100%   (point estimate: 100%)
   NQC-like spread       -9.5[-11.4]   -8.5[-10.3]   -7.1[ -8.7]   -6.2[ -7.7]   -5.4[ -6.8]   -4.2[ -5.4]   -3.3[ -4.4]   -1.9[ -2.8]   -0.7[ -1.3]    100%   (point estimate: 90%)
   WIG-like              -9.2[-11.0]   -8.3[-10.1]   -7.1[ -8.8]   -5.5[ -7.1]   -4.6[ -6.0]   -3.3[ -4.6]   -2.4[ -3.5]   -1.9[ -2.8]   -1.1[ -1.8]    100%   (point estimate: 100%)
   term coverage top1    -8.6[-10.5]   -7.3[ -9.1]   -6.0[ -7.6]   -5.0[ -6.5]   -3.7[ -5.0]   -2.9[ -4.1]   -2.2[ -3.2]   -0.5[ -1.2]   -0.4[ -0.9]#   90%   (point estimate: 80%)
   ORACLE                -2.2[ -3.3]   +1.7[ +0.8]#  +3.3[ +2.5]#  +3.7[ +3.0]#  +3.8[ +3.0]#  +3.8[ +3.0]#  +3.8[ +3.0]#  +3.8[ +3.0]#  +3.7[ +2.9]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -9.0[-10.9]   -8.6[-10.4]   -7.0[ -8.7]   -5.9[ -7.4]   -4.8[ -6.2]   -3.6[ -4.8]   -2.6[ -3.7]   -1.9[ -2.7]   -0.7[ -1.1]    100%   (point estimate: 100%)
   BM25 margin           -9.6[-11.5]   -7.8[ -9.6]   -6.4[ -8.1]   -5.8[ -7.4]   -4.6[ -6.0]   -3.5[ -4.7]   -2.1[ -3.2]   -1.7[ -2.6]   -0.4[ -0.8]    100%   (point estimate: 90%)
   top5 vs rest          -9.6[-11.4]   -7.9[ -9.6]   -7.6[ -9.3]   -6.9[ -8.6]   -5.6[ -7.0]   -4.2[ -5.5]   -3.2[ -4.3]   -2.2[ -3.1]   -1.2[ -1.9]    100%   (point estimate: 100%)
   NQC-like spread       -9.5[-11.4]   -8.5[-10.3]   -7.1[ -8.7]   -6.2[ -7.7]   -5.4[ -6.8]   -4.2[ -5.4]   -3.3[ -4.4]   -1.9[ -2.8]   -0.7[ -1.3]    100%   (point estimate: 100%)
   WIG-like              -9.2[-11.0]   -8.3[-10.1]   -7.1[ -8.8]   -5.5[ -7.1]   -4.6[ -6.0]   -3.3[ -4.6]   -2.4[ -3.5]   -1.9[ -2.8]   -1.1[ -1.8]    100%   (point estimate: 100%)
   term coverage top1    -8.6[-10.5]   -7.3[ -9.1]   -6.0[ -7.6]   -5.0[ -6.5]   -3.7[ -5.0]   -2.9[ -4.1]   -2.2[ -3.2]   -0.5[ -1.2]   -0.4[ -0.9]    100%   (point estimate: 90%)
   ORACLE                -2.2[ -3.3]   +1.7[ +0.8]#  +3.3[ +2.5]#  +3.7[ +3.0]#  +3.8[ +3.0]#  +3.8[ +3.0]#  +3.8[ +3.0]#  +3.8[ +3.0]#  +3.7[ +2.9]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      89% (sd  15)   -0.96 MRR              22%     11%
   tag alarm               100      89% (sd  10)   -0.92 MRR              22%     11%
   tag alarm               200      90% (sd   7)   -0.79 MRR              16%     10%
   BM25 margin              50      84% (sd  17)   -1.29 MRR              40%     16%
   BM25 margin             100      86% (sd  11)   -1.01 MRR              34%     14%
   BM25 margin             200      90% (sd   7)   -0.63 MRR              18%     10%
   top5 vs rest             50      88% (sd  18)   -1.44 MRR              48%     12%
   top5 vs rest            100      93% (sd  10)   -0.81 MRR              39%      7%
   top5 vs rest            200      96% (sd   7)   -0.49 MRR              28%      4%
   NQC-like spread          50      90% (sd  16)   -1.02 MRR              23%     10%
   NQC-like spread         100      92% (sd  10)   -0.73 MRR              16%      8%
   NQC-like spread         200      94% (sd   7)   -0.60 MRR              12%      6%
   WIG-like                 50      88% (sd  17)   -1.20 MRR              52%     12%
   WIG-like                100      90% (sd  15)   -1.02 MRR              48%     10%
   WIG-like                200      93% (sd  10)   -0.81 MRR              50%      7%
   term coverage top1       50      82% (sd  18)   -1.12 MRR              28%     18%
   term coverage top1      100      84% (sd  16)   -0.95 MRR              22%     16%
   term coverage top1      200      84% (sd  10)   -0.74 MRR              16%     16%

## amazon_testfull  (500 questions; tag alarm fires on 219 = 44%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.6  random  56.1  diff  +1.5  p=0.1229
   MRR  : tag  66.9  random  65.5  diff  +1.4  p=0.0471

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.0 (p=0.502)        +1.2 (p=0.195)
   40%            +0.2 (p=1.000)        +0.5 (p=0.659)
   50%            -1.0 (p=0.620)        -0.6 (p=0.605)
   44% nat        -0.4 (p=0.906)        +0.0 (p=0.997)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -3.6  95% CI [-6.8, -0.4]  p=0.036
   MRR  :  -4.0  95% CI [-6.4, -1.8]  p=0.001

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (46%)
   Hit@1:  +2.2  p=0.218
   MRR  :  +1.6  p=0.197

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.6/-1.3 (p=0.281)  40%: -1.2/-1.7 (p=0.165)  50%: -0.4/-1.1 (p=0.415)  nat: -1.4/-1.6 (p=0.206)
   vs NQC-like spread      30%: -1.0/-1.5 (p=0.202)  40%: -0.8/-1.4 (p=0.267)  50%: -1.2/-1.7 (p=0.190)  nat: -1.2/-1.7 (p=0.188)
   vs WIG-like             30%: -1.0/-0.8 (p=0.505)  40%: -1.2/-1.0 (p=0.483)  50%: -1.4/-0.8 (p=0.533)  nat: -2.0/-1.4 (p=0.312)
   vs term coverage top1   30%: +3.0/+2.8 (p=0.019)  40%: +3.2/+3.3 (p=0.009)  50%: +1.8/+2.2 (p=0.072)  nat: +2.0/+2.4 (p=0.051)

G. each selector reranking 219 questions (44%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -4.0  [-6.4, -1.8]  p=0.001
   BM25 margin           -4.0  [-6.6, -1.5]  p=0.002
   top5 vs rest          -2.4  [-4.9, +0.1]  p=0.062
   NQC-like spread       -2.3  [-4.8, +0.1]  p=0.061
   WIG-like              -2.7  [-5.3, -0.1]  p=0.045
   term coverage top1    -6.4  [-9.1, -3.7]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              62.7    64.6    66.5    67.0    67.7    67.5    69.0    69.8*   71.3*   70.9*   80%
   BM25 margin            63.2    64.1    65.3    66.5    68.3    69.4*   69.2    70.9*   71.2*   70.9*   80%
   top5 vs rest           63.3    65.6    67.8    68.7*   68.8*   69.8*   70.5*   71.3*   71.3*   70.9*   40%
   NQC-like spread        62.9    66.0    68.0    68.4*   69.4*   69.9*   70.8*   71.7*   71.6*   70.9*   40%
   WIG-like               63.7    65.4    67.3    68.0    68.5*   70.5*   70.5*   70.3*   70.4*   70.9*   50%
   term coverage top1     62.0    62.5    63.7    63.7    65.5    67.6    67.4    69.0    70.2*   70.9*   90%
   ORACLE                 70.0*   75.5*   77.7*   77.8*   77.8*   77.8*   77.8*   77.8*   77.4*   70.9*   10%
   random (expected)      62.1    63.1    64.1    65.1    66.1    67.0    68.0    69.0    70.0    70.9*   100%
   (BM25 only 61.2; rerank ALL 70.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.3[-11.3]   -6.3[ -9.3]   -4.4[ -7.2]   -3.9[ -6.3]   -3.2[ -5.5]   -3.4[ -5.3]   -1.9[ -3.4]   -1.1[ -2.3]   +0.3[ -0.2]#   90%   (point estimate: 90%)
   BM25 margin           -7.8[-10.9]   -6.9[ -9.9]   -5.6[ -8.6]   -4.5[ -7.1]   -2.6[ -5.0]   -1.6[ -3.7]   -1.7[ -3.3]   -0.1[ -1.2]   +0.3[ +0.0]#   90%   (point estimate: 80%)
   top5 vs rest          -7.7[-10.8]   -5.3[ -8.2]   -3.2[ -5.8]   -2.2[ -4.7]   -2.2[ -4.5]   -1.2[ -3.3]   -0.4[ -2.2]   +0.3[ -1.1]   +0.4[ -0.6]#   90%   (point estimate: 70%)
   NQC-like spread       -8.1[-11.1]   -4.9[ -7.7]   -2.9[ -5.6]   -2.6[ -5.1]   -1.5[ -3.8]   -1.1[ -3.1]   -0.2[ -2.0]   +0.8[ -0.6]#  +0.6[ -0.3]#   80%   (point estimate: 70%)
   WIG-like              -7.3[-10.2]   -5.5[ -8.4]   -3.6[ -6.3]   -3.0[ -5.7]   -2.4[ -4.9]   -0.4[ -2.7]   -0.4[ -2.4]   -0.6[ -2.3]   -0.5[ -1.6]    100%   (point estimate: 60%)
   term coverage top1    -8.9[-12.1]   -8.4[-11.3]   -7.2[-10.0]   -7.2[ -9.8]   -5.5[ -7.9]   -3.3[ -5.5]   -3.6[ -5.4]   -1.9[ -3.4]   -0.7[ -1.8]    100%   (point estimate: 90%)
   ORACLE                -0.9[ -3.2]   +4.5[ +2.7]#  +6.8[ +5.1]#  +6.8[ +5.2]#  +6.8[ +5.2]#  +6.8[ +5.2]#  +6.8[ +5.2]#  +6.8[ +5.2]#  +6.4[ +4.8]#   20%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.3[-11.3]   -6.3[ -9.3]   -4.4[ -7.2]   -3.9[ -6.3]   -3.2[ -5.5]   -3.4[ -5.3]   -1.9[ -3.4]   -1.1[ -2.3]   +0.3[ -0.2]#   90%   (point estimate: 90%)
   BM25 margin           -7.8[-10.9]   -6.9[ -9.9]   -5.6[ -8.6]   -4.5[ -7.1]   -2.6[ -5.0]   -1.6[ -3.7]   -1.7[ -3.3]   -0.1[ -1.2]   +0.3[ +0.0]#   90%   (point estimate: 80%)
   top5 vs rest          -7.7[-10.8]   -5.3[ -8.2]   -3.2[ -5.8]   -2.2[ -4.7]   -2.2[ -4.5]   -1.2[ -3.3]   -0.4[ -2.2]   +0.3[ -1.1]   +0.4[ -0.6]    100%   (point estimate: 70%)
   NQC-like spread       -8.1[-11.1]   -4.9[ -7.7]   -2.9[ -5.6]   -2.6[ -5.1]   -1.5[ -3.8]   -1.1[ -3.1]   -0.2[ -2.0]   +0.8[ -0.6]   +0.6[ -0.3]#   90%   (point estimate: 70%)
   WIG-like              -7.3[-10.2]   -5.5[ -8.4]   -3.6[ -6.3]   -3.0[ -5.7]   -2.4[ -4.9]   -0.4[ -2.7]   -0.4[ -2.4]   -0.6[ -2.3]   -0.5[ -1.6]    100%   (point estimate: 100%)
   term coverage top1    -8.9[-12.1]   -8.4[-11.3]   -7.2[-10.0]   -7.2[ -9.8]   -5.5[ -7.9]   -3.3[ -5.5]   -3.6[ -5.4]   -1.9[ -3.4]   -0.7[ -1.8]    100%   (point estimate: 100%)
   ORACLE                -0.9[ -3.2]   +4.5[ +2.7]#  +6.8[ +5.1]#  +6.8[ +5.2]#  +6.8[ +5.2]#  +6.8[ +5.2]#  +6.8[ +5.2]#  +6.8[ +5.2]#  +6.4[ +4.8]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      76% (sd  22)   -1.39 MRR              54%     24%
   tag alarm               100      80% (sd  14)   -1.00 MRR              51%     20%
   tag alarm               200      82% (sd   7)   -0.77 MRR              46%     18%
   BM25 margin              50      72% (sd  21)   -1.31 MRR              40%     28%
   BM25 margin             100      72% (sd  17)   -1.35 MRR              48%     28%
   BM25 margin             200      74% (sd  11)   -0.94 MRR              38%     26%
   top5 vs rest             50      66% (sd  29)   -1.47 MRR              40%     34%
   top5 vs rest            100      65% (sd  24)   -1.27 MRR              44%     35%
   top5 vs rest            200      66% (sd  17)   -0.99 MRR              44%     34%
   NQC-like spread          50      67% (sd  27)   -1.13 MRR              40%     33%
   NQC-like spread         100      62% (sd  24)   -1.33 MRR              49%     38%
   NQC-like spread         200      63% (sd  17)   -0.92 MRR              43%     37%
   WIG-like                 50      74% (sd  31)   -1.62 MRR              30%     26%
   WIG-like                100      75% (sd  26)   -1.39 MRR              32%     25%
   WIG-like                200      77% (sd  21)   -1.13 MRR              32%     23%
   term coverage top1       50      87% (sd  21)   -1.40 MRR              30%     13%
   term coverage top1      100      90% (sd  13)   -1.07 MRR              24%     10%
   term coverage top1      200      92% (sd   7)   -0.87 MRR              32%      8%

## POOLED over 7 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  41.2  random  38.9  diff  +2.3  p=0.0001
   MRR  : tag  50.4  random  48.5  diff  +1.9  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +1.4 (p=0.000)   MRR  +1.3 (p=0.000)
   40%      Hit@1  +1.2 (p=0.002)   MRR  +1.0 (p=0.000)
   50%      Hit@1  +0.8 (p=0.038)   MRR  +0.8 (p=0.004)
   natural  Hit@1  +1.3 (p=0.002)   MRR  +1.4 (p=0.000)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -6.0  95% CI [-7.2, -4.9]  p=0.000
   MRR  :  -6.2  95% CI [-7.1, -5.4]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +1.7  p=0.001
   MRR  :  +1.0  p=0.007

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +2.3/+1.4 (p=0.000)  40%: +2.3/+1.5 (p=0.000)  50%: +2.3/+1.4 (p=0.000)  nat: +1.6/+1.2 (p=0.000)
   vs NQC-like spread      30%: +1.5/+0.7 (p=0.037)  40%: +1.3/+0.6 (p=0.101)  50%: +1.2/+0.5 (p=0.130)  nat: +1.0/+0.7 (p=0.035)
   vs WIG-like             30%: +1.1/+0.5 (p=0.136)  40%: +1.1/+0.6 (p=0.134)  50%: +1.2/+0.7 (p=0.051)  nat: +0.8/+0.5 (p=0.126)
   vs term coverage top1   30%: +1.2/+0.6 (p=0.081)  40%: +1.2/+0.7 (p=0.066)  50%: +0.8/+0.6 (p=0.129)  nat: +1.4/+1.1 (p=0.001)
