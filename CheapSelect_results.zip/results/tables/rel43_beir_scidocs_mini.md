## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.4  random  18.8  diff  +0.6  p=0.0764
   MRR  : tag  28.8  random  28.5  diff  +0.3  p=0.1093

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.0 (p=0.965)
   40%            +0.6 (p=0.212)        +0.3 (p=0.214)
   50%            -0.2 (p=0.789)        -0.1 (p=0.725)
   12% nat        +0.0 (p=1.000)        +0.3 (p=0.472)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.3  95% CI [-2.5, +1.8]  p=0.848
   MRR  :  -1.1  95% CI [-2.6, +0.4]  p=0.165

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +0.2  p=0.897
   MRR  :  +0.6  p=0.332

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.6/+0.5 (p=0.292)  40%: +2.0/+0.8 (p=0.194)  50%: +1.4/+0.3 (p=0.605)  nat: +0.7/+0.4 (p=0.263)
   vs NQC-like spread      30%: +1.8/+0.7 (p=0.153)  40%: +1.5/+0.5 (p=0.321)  50%: +1.4/+0.5 (p=0.373)  nat: +0.8/+0.5 (p=0.163)
   vs WIG-like             30%: +1.1/+0.1 (p=0.891)  40%: +0.8/-0.2 (p=0.669)  50%: +0.3/-0.5 (p=0.380)  nat: +0.8/+0.3 (p=0.496)
   vs term coverage top1   30%: +1.0/+0.0 (p=0.980)  40%: +1.3/+0.2 (p=0.762)  50%: +0.2/-0.6 (p=0.313)  nat: +0.2/-0.2 (p=0.646)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -1.1  [-2.6, +0.4]  p=0.165
   BM25 margin           -1.3  [-2.8, +0.1]  p=0.082
   top5 vs rest          -1.5  [-3.0, +0.1]  p=0.065
   NQC-like spread       -1.6  [-3.1, -0.0]  p=0.043
   WIG-like              -1.3  [-2.8, +0.2]  p=0.091
   term coverage top1    -0.9  [-2.4, +0.6]  p=0.246

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              28.8*   28.9*   28.9*   29.0*   29.1*   29.5*   29.5*   29.5*   29.8*   29.9*   10%
   BM25 margin            28.5*   28.8*   28.9*   28.6    29.2*   29.4*   29.4*   29.6*   29.8*   29.9*   50%
   top5 vs rest           28.4*   28.7*   28.4    28.2    28.8*   29.2*   29.5*   29.6*   29.5*   29.9*   50%
   NQC-like spread        28.3    28.5*   28.2    28.4    28.6    28.9*   29.4*   29.6*   29.7*   29.9*   60%
   WIG-like               28.6*   28.6*   28.8*   29.2*   29.6*   29.9*   30.1*   29.7*   29.6*   29.9*   10%
   term coverage top1     29.1*   29.2*   28.9*   28.8*   29.7*   29.8*   30.0*   30.4*   30.0*   29.9*   10%
   ORACLE                 33.9*   35.2*   35.5*   35.5*   35.5*   35.5*   35.5*   35.5*   34.7*   29.9*   10%
   random (expected)      28.5    28.6    28.8    28.9    29.1    29.3    29.4    29.6    29.7    29.9*   100%
   (BM25 only 28.3; rerank ALL 29.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.6 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.1[ -2.5]   -1.0[ -2.4]   -1.0[ -2.3]   -0.9[ -2.1]   -0.8[ -1.9]   -0.4[ -1.4]   -0.4[ -1.2]   -0.3[ -0.9]   -0.1[ -0.4]#   90%   (point estimate: 60%)
   BM25 margin           -1.4[ -2.8]   -1.1[ -2.5]   -1.0[ -2.2]   -1.3[ -2.4]   -0.7[ -1.8]   -0.5[ -1.5]   -0.5[ -1.3]   -0.3[ -0.9]   -0.1[ -0.4]#   90%   (point estimate: 60%)
   top5 vs rest          -1.5[ -3.0]   -1.2[ -2.6]   -1.5[ -2.9]   -1.7[ -3.0]   -1.1[ -2.3]   -0.7[ -1.7]   -0.4[ -1.4]   -0.3[ -1.1]   -0.4[ -0.9]    100%   (point estimate: 70%)
   NQC-like spread       -1.6[ -3.1]   -1.4[ -2.9]   -1.7[ -3.1]   -1.5[ -2.7]   -1.3[ -2.5]   -1.0[ -2.0]   -0.5[ -1.3]   -0.3[ -1.0]   -0.2[ -0.8]    100%   (point estimate: 70%)
   WIG-like              -1.3[ -2.8]   -1.2[ -2.7]   -1.1[ -2.5]   -0.7[ -2.0]   -0.3[ -1.5]   -0.0[ -1.1]   +0.2[ -0.8]   -0.2[ -1.0]   -0.3[ -1.0]    100%   (point estimate: 50%)
   term coverage top1    -0.8[ -2.3]   -0.7[ -2.1]   -1.0[ -2.3]   -1.1[ -2.2]   -0.2[ -1.2]   -0.1[ -0.9]   +0.1[ -0.6]   +0.5[ -0.1]#  +0.2[ -0.2]#   80%   (point estimate: 50%)
   ORACLE                +4.0[ +3.1]#  +5.3[ +4.4]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +4.8[ +3.9]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.6): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      68% (sd  28)   -0.46 MRR              25%     32%
   BM25 margin             100      59% (sd  29)   -0.73 MRR              35%     41%
   top5 vs rest            100      66% (sd  33)   -0.75 MRR              40%     34%
   NQC-like spread         100      80% (sd  24)   -0.48 MRR              25%     20%
   WIG-like                100      76% (sd  29)   -0.19 MRR              15%     24%
   term coverage top1      100      66% (sd  28)   -0.07 MRR              20%     34%

