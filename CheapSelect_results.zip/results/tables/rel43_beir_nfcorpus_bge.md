## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  43.3  random  44.0  diff  -0.6  p=0.9826
   MRR  : tag  51.7  random  52.2  diff  -0.5  p=0.9554

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.1 (p=0.837)
   40%            -0.3 (p=1.000)        -0.4 (p=0.374)
   50%            -0.6 (p=0.496)        -0.5 (p=0.249)
   2% nat         -0.6 (p=0.498)        -0.4 (p=0.368)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.3  95% CI [-5.0, +4.3]  p=1.000
   MRR  :  -2.1  95% CI [-5.3, +1.1]  p=0.195

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  -0.9  p=0.696
   MRR  :  -1.7  p=0.147

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/+0.1 (p=0.891)  40%: +0.6/+1.0 (p=0.419)  50%: +1.2/+1.3 (p=0.270)  nat: -0.6/-0.4 (p=0.368)
   vs NQC-like spread      30%: +0.3/-0.2 (p=0.874)  40%: -0.6/-0.4 (p=0.764)  50%: +0.6/+0.3 (p=0.775)  nat: -0.6/-0.4 (p=0.368)
   vs WIG-like             30%: -0.3/-0.3 (p=0.745)  40%: -0.3/+0.1 (p=0.909)  50%: +0.0/+0.2 (p=0.875)  nat: -0.6/-0.4 (p=0.368)
   vs term coverage top1   30%: -1.5/-1.3 (p=0.196)  40%: -1.2/-1.0 (p=0.373)  50%: -1.9/-1.4 (p=0.210)  nat: -0.6/-0.4 (p=0.368)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.1  [-5.3, +1.1]  p=0.195
   BM25 margin           -1.7  [-4.9, +1.5]  p=0.307
   top5 vs rest          -1.7  [-4.9, +1.5]  p=0.307
   NQC-like spread       -1.7  [-4.9, +1.5]  p=0.307
   WIG-like              -1.7  [-4.9, +1.5]  p=0.307
   term coverage top1    -1.7  [-4.9, +1.5]  p=0.307

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              51.7*   52.2*   53.0*   53.6*   53.8*   54.1*   53.8*   53.7*   53.7*   53.9*   10%
   BM25 margin            51.9*   52.5*   53.1*   54.0*   54.4*   54.3*   53.7*   53.7*   53.7*   53.9*   10%
   top5 vs rest           51.8*   52.1*   52.8*   52.6*   52.6*   53.5*   53.8*   54.3*   54.6*   53.9*   10%
   NQC-like spread        51.6*   53.3*   53.1*   54.0*   53.5*   54.4*   54.7*   54.4*   54.0*   53.9*   10%
   WIG-like               52.1*   51.6*   53.3*   53.4*   53.7*   54.3*   54.0*   54.0*   53.8*   53.9*   10%
   term coverage top1     52.2*   53.2*   54.3*   54.6*   55.2*   54.1*   53.4*   53.4*   53.5*   53.9*   10%
   ORACLE                 58.4*   60.6*   60.6*   60.6*   60.6*   60.6*   60.6*   60.6*   59.9*   53.9*   10%
   random (expected)      52.3    52.5    52.7    52.8    53.0    53.2    53.3    53.5    53.7    53.9*   100%
   (BM25 only 52.1; rerank ALL 53.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.08 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.2[ -5.3]   -1.7[ -4.6]   -0.9[ -3.7]   -0.3[ -2.7]   -0.0[ -2.2]   +0.2[ -1.7]   -0.0[ -1.7]   -0.2[ -1.2]   -0.2[ -0.7]#   90%   (point estimate: 30%)
   BM25 margin           -2.0[ -5.1]   -1.3[ -4.3]   -0.8[ -3.5]   +0.1[ -2.4]   +0.5[ -1.6]   +0.4[ -1.6]   -0.1[ -1.7]   -0.2[ -1.2]   -0.2[ -0.7]#   90%   (point estimate: 30%)
   top5 vs rest          -2.0[ -5.1]   -1.7[ -4.7]   -1.0[ -3.7]   -1.2[ -3.7]   -1.3[ -3.6]   -0.3[ -2.3]   -0.0[ -1.7]   +0.5[ -0.9]#  +0.8[ -0.2]#   80%   (point estimate: 60%)
   NQC-like spread       -2.2[ -5.4]   -0.5[ -3.3]   -0.7[ -3.2]   +0.1[ -2.2]   -0.3[ -2.5]   +0.5[ -1.1]   +0.8[ -0.7]#  +0.5[ -0.8]#  +0.2[ -0.5]#   70%   (point estimate: 20%)
   WIG-like              -1.7[ -4.9]   -2.3[ -5.3]   -0.6[ -3.4]   -0.4[ -3.0]   -0.2[ -2.6]   +0.5[ -1.5]   +0.2[ -1.5]   +0.1[ -1.3]   -0.0[ -0.7]#   90%   (point estimate: 30%)
   term coverage top1    -1.6[ -4.8]   -0.7[ -3.7]   +0.4[ -2.4]   +0.8[ -1.8]   +1.4[ -0.9]#  +0.2[ -1.8]   -0.5[ -2.2]   -0.5[ -2.0]   -0.3[ -1.7]    100%   (point estimate: 20%)
   ORACLE                +4.6[ +2.3]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.7[ +4.7]#  +6.1[ +4.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.08): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      60% (sd  27)   -0.32 MRR              15%     40%
   BM25 margin             100      40% (sd  33)   -1.13 MRR              40%     60%
   top5 vs rest            100      47% (sd  30)   -1.08 MRR              40%     53%
   NQC-like spread         100      41% (sd  25)   -0.64 MRR              35%     59%
   WIG-like                100      38% (sd  27)   -1.21 MRR              40%     62%
   term coverage top1      100      50% (sd  36)   -0.38 MRR              30%     50%

