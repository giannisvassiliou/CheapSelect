## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.7  random  55.7  diff  +1.0  p=0.1558
   MRR  : tag  65.3  random  64.8  diff  +0.5  p=0.1691

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.2 (p=0.710)
   40%            -0.3 (p=1.000)        -0.4 (p=0.164)
   50%            +0.0 (p=1.000)        -0.3 (p=0.454)
   15% nat        -1.3 (p=0.473)        -1.4 (p=0.181)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -6.7  95% CI [-10.7, -3.0]  p=0.001
   MRR  :  -6.4  95% CI [-9.2, -3.6]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (27%)
   Hit@1:  +1.3  p=0.481
   MRR  :  +1.7  p=0.099

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.3/+2.3 (p=0.035)  40%: +3.0/+2.3 (p=0.066)  50%: +2.7/+1.9 (p=0.138)  nat: +1.3/+0.7 (p=0.432)
   vs NQC-like spread      30%: +2.0/+0.5 (p=0.655)  40%: +2.0/+0.4 (p=0.656)  50%: +1.0/+0.4 (p=0.682)  nat: -0.3/-0.9 (p=0.321)
   vs WIG-like             30%: +1.0/+0.1 (p=0.913)  40%: +1.0/+0.2 (p=0.876)  50%: +1.3/+0.9 (p=0.395)  nat: +0.7/-0.1 (p=0.896)
   vs term coverage top1   30%: +1.0/+0.7 (p=0.569)  40%: +0.0/-0.0 (p=0.991)  50%: +0.0/+0.1 (p=0.917)  nat: -1.0/-0.8 (p=0.361)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -6.4  [-9.2, -3.6]  p=0.000
   BM25 margin           -5.0  [-7.6, -2.5]  p=0.000
   top5 vs rest          -7.0  [-10.0, -4.1]  p=0.000
   NQC-like spread       -5.4  [-8.3, -2.7]  p=0.000
   WIG-like              -6.2  [-9.1, -3.5]  p=0.000
   term coverage top1    -5.6  [-8.4, -2.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              65.4    66.4    68.0    68.5    69.6    70.3    71.3*   71.5*   71.7*   71.7*   70%
   BM25 margin            65.2    66.8    67.8    68.9    69.9    70.9    71.5*   71.5*   71.7*   71.7*   70%
   top5 vs rest           63.9    64.7    65.7    66.1    67.7    68.4    68.4    69.4    70.7*   71.7*   90%
   NQC-like spread        65.6    66.7    67.5    68.0    69.2    69.8    70.6*   71.1*   71.4*   71.7*   70%
   WIG-like               64.9    67.0    67.9    68.3    68.6    69.1    69.6    70.0    71.5*   71.7*   90%
   term coverage top1     65.3    66.5    67.4    68.5    69.5    70.3*   70.5*   70.6    71.2*   71.7*   90%
   ORACLE                 70.8*   73.9*   74.3*   74.3*   74.3*   74.3*   74.3*   74.3*   74.3*   71.7*   10%
   random (expected)      64.4    65.2    66.0    66.8    67.6    68.4    69.3    70.1    70.9    71.7*   100%
   (BM25 only 63.6; rerank ALL 71.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.43 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -6.4[ -9.2]   -5.3[ -8.1]   -3.7[ -6.2]   -3.2[ -5.2]   -2.1[ -3.6]   -1.4[ -2.6]   -0.4[ -1.1]#  -0.2[ -0.8]#  +0.0[ -0.2]#   70%   (point estimate: 70%)
   BM25 margin           -6.6[ -9.4]   -4.9[ -7.5]   -3.9[ -6.1]   -2.8[ -4.6]   -1.8[ -3.0]   -0.8[ -1.6]   -0.2[ -0.8]#  -0.2[ -0.8]#  +0.0[ -0.2]#   70%   (point estimate: 60%)
   top5 vs rest          -7.8[-10.9]   -7.0[ -9.8]   -6.0[ -8.8]   -5.6[ -8.3]   -4.0[ -6.5]   -3.3[ -5.6]   -3.3[ -5.4]   -2.3[ -4.1]   -1.1[ -2.4]    100%   (point estimate: 90%)
   NQC-like spread       -6.1[ -9.2]   -5.0[ -7.7]   -4.2[ -6.7]   -3.7[ -5.9]   -2.5[ -4.4]   -1.9[ -3.6]   -1.1[ -2.4]   -0.6[ -1.6]   -0.3[ -0.8]#   90%   (point estimate: 70%)
   WIG-like              -6.9[ -9.9]   -4.7[ -7.3]   -3.8[ -6.3]   -3.4[ -5.5]   -3.1[ -5.0]   -2.6[ -4.5]   -2.1[ -3.9]   -1.8[ -3.1]   -0.2[ -0.9]#   90%   (point estimate: 90%)
   term coverage top1    -6.4[ -9.3]   -5.3[ -8.0]   -4.3[ -6.7]   -3.2[ -5.2]   -2.2[ -4.0]   -1.4[ -3.0]   -1.2[ -2.5]   -1.1[ -2.3]   -0.5[ -1.3]#   90%   (point estimate: 60%)
   ORACLE                -0.9[ -2.7]   +2.2[ +1.0]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.43): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      64% (sd  10)   -1.12 MRR              30%     36%
   BM25 margin             100      55% (sd  11)   -1.48 MRR              40%     45%
   top5 vs rest            100      92% (sd  10)   -1.04 MRR              20%      8%
   NQC-like spread         100      69% (sd  11)   -1.53 MRR              45%     31%
   WIG-like                100      72% (sd  20)   -2.10 MRR              55%     28%
   term coverage top1      100      71% (sd  18)   -1.67 MRR              40%     29%

