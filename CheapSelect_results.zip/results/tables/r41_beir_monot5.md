# router41: label-free signals vs pre-retrieval vs trained routers  (deltas [1.0, 0.5] MRR points)

## beir_scifact (tag monot5; n=300; mean gain +8.1 MRR; helped 25% hurt 8%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.00   rho(gain) -0.07
   avgIDF   rho(quality) +0.11   rho(gain) -0.03
   maxIDF   rho(quality) +0.10   rho(gain) +0.01
   avgICTF  rho(quality) +0.06   rho(gain) -0.02
   avgSCQ   rho(quality) +0.04   rho(gain) -0.02
   maxSCQ   rho(quality) +0.10   rho(gain) -0.01
   SCS      rho(quality) +0.03   rho(gain) -0.04

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               70/60          90/70           +30             -1.8     +1.3 (0.210)
   tag alarm                                 80/70          90/70           +20             -2.1     +0.9 (0.403)
   top5 vs rest                             100/100        100/100          -10             -4.0     -0.9 (0.300)
   NQC-like spread                           90/80         100/90           +10             -2.5     +0.5 (0.290)
   WIG-like                                  90/90         100/90            +0             -3.1          -
   term coverage top1                       100/90         100/100           +0             -2.2     +0.8 (0.348)
   pre:qlen                                 100/90         100/90            +0             -4.2     -1.1 (0.344)
   pre:avgIDF                               100/90         100/100           +0             -4.0     -0.9 (0.467)
   pre:maxIDF                               100/100        100/100          -10             -3.4     -0.4 (0.777)
   pre:avgICTF                              100/90         100/90            +0             -4.1     -1.0 (0.444)
   pre:avgSCQ                               100/90         100/100           +0             -5.4     -2.3 (0.003)
   pre:maxSCQ                               100/90         100/100           +0             -4.2     -1.2 (0.174)
   pre:SCS                                  100/90         100/90            +0             -3.9     -0.8 (0.526)
   router ridge S (5-fold CV)                80/80          90/80           +10             -2.4     +0.7 (0.465)
   router ridge S+P (5-fold CV)             100/80         100/90           +10             -2.1     +1.0 (0.312)
   router ridge S (other collections)        90/80         100/90           +10             -1.9     +1.1 (0.188)
   router ridge S+P (other collections)      90/80          90/90           +10             -1.9     +1.1 (0.149)
   ORACLE                                    20/10          20/20           +80             +2.6     +5.7 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.217, tag alarm +0.037, top5 vs rest -0.085, NQC-like spread -0.015, WIG-like +0.007, term coverage top1 -0.042
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.208, tag alarm +0.031, top5 vs rest -0.088, NQC-like spread -0.101, WIG-like -0.030, term coverage top1 -0.011, qlen +0.052, avgIDF +0.011, maxIDF -0.049, avgICTF +0.092, avgSCQ +0.100, maxSCQ +0.022, SCS +0.008

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -3.8   -3.1   -2.3
   n=  50  router ridge S+P        -4.8   -3.2   -1.7   P(router > WIG-like @50%) = 48%
   n= 100  WIG-like                 -3.8   -3.2   -2.3
   n= 100  router ridge S+P        -4.6   -2.8   -1.3   P(router > WIG-like @50%) = 68%
   n= 200  WIG-like                 -3.5   -2.9   -2.1
   n= 200  router ridge S+P        -4.1   -2.4   -1.0   P(router > WIG-like @50%) = 69%

## beir_nfcorpus (tag monot5; n=323; mean gain +7.2 MRR; helped 24% hurt 10%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.02   rho(gain) -0.16
   avgIDF   rho(quality) -0.19   rho(gain) -0.11
   maxIDF   rho(quality) -0.33   rho(gain) -0.03
   avgICTF  rho(quality) -0.25   rho(gain) -0.09
   avgSCQ   rho(quality) +0.51   rho(gain) -0.03
   maxSCQ   rho(quality) +0.36   rho(gain) +0.07
   SCS      rho(quality) -0.21   rho(gain) -0.12

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/90         100/100           +0             -1.9     -0.3 (0.794)
   tag alarm                                100/90         100/100           +0             -1.9     -0.3 (0.793)
   top5 vs rest                              90/80         100/90           +10             -3.1     -1.5 (0.057)
   NQC-like spread                           90/70         100/90           +20             -2.5     -0.9 (0.281)
   WIG-like                                  90/60         100/70           +30             -1.6          -
   term coverage top1                       100/70         100/80           +20             -0.8     +0.8 (0.321)
   pre:qlen                                  90/70          90/70           +20             -1.1     +0.5 (0.614)
   pre:avgIDF                                90/70          90/90           +20             -2.2     -0.6 (0.620)
   pre:maxIDF                               100/90         100/100           +0             -2.9     -1.3 (0.349)
   pre:avgICTF                               90/80         100/80           +10             -2.2     -0.6 (0.651)
   pre:avgSCQ                                90/80          90/80           +10             -3.9     -2.3 (0.006)
   pre:maxSCQ                               100/100        100/100          -10             -5.1     -3.5 (0.000)
   pre:SCS                                   90/70         100/70           +20             -1.8     -0.2 (0.862)
   router ridge S (5-fold CV)               100/50         100/90           +40             -0.3     +1.3 (0.117)
   router ridge S+P (5-fold CV)              80/50          90/50           +40             -0.4     +1.3 (0.149)
   router ridge S (other collections)        90/50         100/90           +40             -0.5     +1.1 (0.192)
   router ridge S+P (other collections)     100/50         100/70           +40             -0.7     +0.9 (0.269)
   ORACLE                                    20/10          20/10           +80             +3.5     +5.1 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.013, tag alarm -0.349, top5 vs rest +0.189, NQC-like spread -0.102, WIG-like -0.182, term coverage top1 -0.070
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.101, tag alarm -0.433, top5 vs rest +0.118, NQC-like spread +0.039, WIG-like -0.414, term coverage top1 +0.030, qlen +0.194, avgIDF -0.105, maxIDF -0.033, avgICTF +0.141, avgSCQ +0.105, maxSCQ +0.150, SCS -0.043

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -3.7   -1.6   -0.4
   n=  50  router ridge S+P        -3.2   -1.7   -0.7   P(router > WIG-like @50%) = 60%
   n= 100  WIG-like                 -3.7   -1.6   -0.3
   n= 100  router ridge S+P        -2.6   -1.2   -0.2   P(router > WIG-like @50%) = 76%
   n= 200  WIG-like                 -3.7   -1.7   -0.3
   n= 200  router ridge S+P        -2.2   -0.7   +0.1   P(router > WIG-like @50%) = 83%

## beir_fiqa (tag monot5; n=648; mean gain +25.0 MRR; helped 45% hurt 4%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.09   rho(gain) -0.03
   avgIDF   rho(quality) +0.04   rho(gain) -0.02
   maxIDF   rho(quality) +0.03   rho(gain) -0.08
   avgICTF  rho(quality) +0.04   rho(gain) -0.03
   avgSCQ   rho(quality) +0.07   rho(gain) +0.01
   maxSCQ   rho(quality) +0.12   rho(gain) +0.02
   SCS      rho(quality) -0.00   rho(gain) -0.04

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/100        100/100           +0            -10.2     +2.4 (0.049)
   tag alarm                                100/100        100/100           +0             -9.1     +3.5 (0.007)
   top5 vs rest                             100/100        100/100           +0            -12.5     +0.0 (0.968)
   NQC-like spread                          100/100        100/100           +0            -12.1     +0.4 (0.651)
   WIG-like                                 100/100        100/100           +0            -12.6          -
   term coverage top1                       100/100        100/100           +0            -10.8     +1.7 (0.146)
   pre:qlen                                 100/100        100/100           +0            -11.5     +1.1 (0.372)
   pre:avgIDF                               100/100        100/100           +0            -12.8     -0.3 (0.811)
   pre:maxIDF                               100/100        100/100           +0            -10.7     +1.8 (0.136)
   pre:avgICTF                              100/100        100/100           +0            -13.0     -0.5 (0.681)
   pre:avgSCQ                               100/100        100/100           +0            -12.5     +0.1 (0.938)
   pre:maxSCQ                               100/100        100/100           +0            -13.2     -0.6 (0.544)
   pre:SCS                                  100/100        100/100           +0            -12.4     +0.2 (0.887)
   router ridge S (5-fold CV)               100/100        100/100           +0            -10.6     +1.9 (0.137)
   router ridge S+P (5-fold CV)             100/100        100/100           +0            -10.3     +2.2 (0.087)
   router ridge S (other collections)       100/100        100/100           +0            -12.1     +0.5 (0.642)
   router ridge S+P (other collections)     100/100        100/100           +0            -12.3     +0.2 (0.819)
   ORACLE                                    40/40          40/40           +60             +1.4    +14.0 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.165, tag alarm +0.144, top5 vs rest +0.005, NQC-like spread -0.120, WIG-like +0.110, term coverage top1 -0.099
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.160, tag alarm +0.143, top5 vs rest +0.008, NQC-like spread -0.118, WIG-like +0.077, term coverage top1 -0.083, qlen -0.010, avgIDF +0.166, maxIDF -0.244, avgICTF +0.236, avgSCQ -0.095, maxSCQ +0.068, SCS -0.188

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                -16.8  -12.6   -7.3
   n=  50  router ridge S+P       -16.6  -11.4   -6.6   P(router > WIG-like @50%) = 87%
   n= 100  WIG-like                -16.8  -12.6   -7.3
   n= 100  router ridge S+P       -16.5  -11.2   -6.2   P(router > WIG-like @50%) = 98%
   n= 200  WIG-like                -16.8  -12.6   -7.3
   n= 200  router ridge S+P       -15.8  -10.7   -5.9   P(router > WIG-like @50%) = 98%

## beir_arguana (tag monot5; n=1401; mean gain +0.6 MRR; helped 38% hurt 43%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.01   rho(gain) +0.11
   avgIDF   rho(quality) +0.08   rho(gain) -0.04
   maxIDF   rho(quality) -0.02   rho(gain) -0.03
   avgICTF  rho(quality) +0.07   rho(gain) -0.04
   avgSCQ   rho(quality) +0.05   rho(gain) -0.04
   maxSCQ   rho(quality) +0.06   rho(gain) -0.00
   SCS      rho(quality) +0.09   rho(gain) +0.05

Budgets (share of questions reranked). random expected point budget: delta 1.0: 10%, delta 0.5: 20%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/60         100/90           -50             -1.0     -1.2 (0.029)
   tag alarm                                 90/60         100/90           -50             -1.0     -1.2 (0.028)
   top5 vs rest                              20/10          90/10            +0             +0.2     -0.0 (0.889)
   NQC-like spread                           50/10          80/20            +0             +0.0     -0.2 (0.628)
   WIG-like                                  20/10          80/10            +0             +0.2          -
   term coverage top1                        60/10          90/20            +0             -0.1     -0.4 (0.437)
   pre:qlen                                  80/40          90/70           -30             -0.6     -0.8 (0.151)
   pre:avgIDF                                60/10          90/10            +0             -0.2     -0.4 (0.290)
   pre:maxIDF                                70/10          90/10            +0             -0.1     -0.4 (0.425)
   pre:avgICTF                               60/10          90/20            +0             -0.2     -0.4 (0.303)
   pre:avgSCQ                                80/10          80/10            +0             -0.0     -0.2 (0.555)
   pre:maxSCQ                                70/10          70/60            +0             -0.6     -0.9 (0.042)
   pre:SCS                                   70/10          90/60            +0             -0.5     -0.7 (0.110)
   router ridge S (5-fold CV)                60/10         100/10            +0             -0.1     -0.3 (0.288)
   router ridge S+P (5-fold CV)              40/10         100/30            +0             +0.2     -0.1 (0.872)
   router ridge S (other collections)        90/10         100/90            +0             -0.5     -0.7 (0.199)
   router ridge S+P (other collections)      80/40         100/60           -30             -0.6     -0.8 (0.139)
   ORACLE                                    10/10          10/10            +0             +8.4     +8.2 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.098, tag alarm -0.003, top5 vs rest +0.078, NQC-like spread -0.038, WIG-like -0.040, term coverage top1 +0.077
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.093, tag alarm -0.003, top5 vs rest -0.001, NQC-like spread -0.056, WIG-like +0.053, term coverage top1 +0.077, qlen -0.039, avgIDF +0.007, maxIDF +0.000, avgICTF -0.045, avgSCQ -0.022, maxSCQ +0.030, SCS +0.043

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 +0.3   +0.3   +0.1
   n=  50  router ridge S+P        -0.4   -0.2   -0.1   P(router > WIG-like @50%) = 17%
   n= 100  WIG-like                 +0.3   +0.2   +0.1
   n= 100  router ridge S+P        -0.2   -0.1   -0.1   P(router > WIG-like @50%) = 25%
   n= 200  WIG-like                 +0.3   +0.2   +0.1
   n= 200  router ridge S+P        -0.1   -0.0   +0.0   P(router > WIG-like @50%) = 27%

## beir_scidocs (tag monot5; n=1000; mean gain +5.1 MRR; helped 37% hurt 20%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.15   rho(gain) -0.07
   avgIDF   rho(quality) +0.10   rho(gain) +0.03
   maxIDF   rho(quality) +0.05   rho(gain) +0.04
   avgICTF  rho(quality) +0.08   rho(gain) +0.04
   avgSCQ   rho(quality) +0.15   rho(gain) -0.02
   maxSCQ   rho(quality) +0.20   rho(gain) -0.01
   SCS      rho(quality) +0.02   rho(gain) +0.01

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/80         100/90           +10             -2.3     -0.9 (0.198)
   tag alarm                                 90/80         100/90           +10             -2.5     -1.0 (0.107)
   top5 vs rest                              90/80         100/90           +10             -2.8     -1.3 (0.007)
   NQC-like spread                           90/80          90/90           +10             -2.7     -1.3 (0.003)
   WIG-like                                  90/60         100/70           +30             -1.4          -
   term coverage top1                        80/50         100/70           +40             -0.8     +0.6 (0.214)
   pre:qlen                                 100/70         100/90           +20             -2.1     -0.6 (0.294)
   pre:avgIDF                                90/90         100/90            +0             -3.4     -2.0 (0.001)
   pre:maxIDF                               100/100        100/100          -10             -2.9     -1.5 (0.016)
   pre:avgICTF                              100/90         100/100           +0             -3.5     -2.1 (0.001)
   pre:avgSCQ                               100/90         100/100           +0             -2.8     -1.4 (0.015)
   pre:maxSCQ                               100/90         100/100           +0             -3.0     -1.5 (0.008)
   pre:SCS                                  100/90         100/100           +0             -3.0     -1.6 (0.006)
   router ridge S (5-fold CV)                80/60         100/60           +30             -1.3     +0.1 (0.724)
   router ridge S+P (5-fold CV)              90/60          90/80           +30             -1.2     +0.2 (0.625)
   router ridge S (other collections)        80/60          90/80           +30             -1.5     -0.1 (0.876)
   router ridge S+P (other collections)      90/60         100/70           +30             -1.7     -0.2 (0.585)
   ORACLE                                    10/10          10/10           +80             +4.7     +6.1 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.014, tag alarm -0.011, top5 vs rest -0.020, NQC-like spread +0.071, WIG-like -0.090, term coverage top1 -0.078
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.021, tag alarm -0.014, top5 vs rest -0.008, NQC-like spread +0.051, WIG-like -0.126, term coverage top1 -0.040, qlen -0.067, avgIDF +0.085, maxIDF -0.024, avgICTF +0.243, avgSCQ +0.020, maxSCQ +0.019, SCS -0.312

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -3.0   -1.4   -0.3
   n=  50  router ridge S+P        -3.2   -2.1   -1.1   P(router > WIG-like @50%) = 14%
   n= 100  WIG-like                 -3.0   -1.4   -0.3
   n= 100  router ridge S+P        -3.1   -2.0   -1.0   P(router > WIG-like @50%) = 11%
   n= 200  WIG-like                 -3.0   -1.4   -0.3
   n= 200  router ridge S+P        -3.1   -1.9   -0.9   P(router > WIG-like @50%) = 18%

