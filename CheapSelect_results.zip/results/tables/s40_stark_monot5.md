## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  59.2  random  56.7  diff  +2.5  p=0.0002
   MRR  : tag  68.9  random  66.5  diff  +2.4  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.0 (p=0.235)        +0.9 (p=0.127)
   40%            +0.1 (p=1.000)        +0.7 (p=0.322)
   50%            -0.9 (p=0.382)        +0.0 (p=0.974)
   47% nat        -0.6 (p=0.561)        +0.3 (p=0.681)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -6.0  95% CI [-7.7, -4.3]  p=0.000
   MRR  :  -5.2  95% CI [-6.5, -3.9]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (46%)
   Hit@1:  +1.5  p=0.123
   MRR  :  +1.1  p=0.118

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.1/-0.9 (p=0.183)  40%: -0.9/-1.2 (p=0.085)  50%: -1.3/-1.4 (p=0.041)  nat: -1.3/-1.5 (p=0.041)
   vs NQC-like spread      30%: -0.7/-1.3 (p=0.063)  40%: -1.5/-1.5 (p=0.030)  50%: -1.7/-1.8 (p=0.009)  nat: -2.0/-2.0 (p=0.005)
   vs WIG-like             30%: +0.9/+0.1 (p=0.931)  40%: +0.7/+0.2 (p=0.768)  50%: +0.1/-0.2 (p=0.781)  nat: +0.0/-0.4 (p=0.607)
   vs term coverage top1   30%: +3.9/+3.2 (p=0.000)  40%: +4.1/+3.9 (p=0.000)  50%: +3.3/+3.5 (p=0.000)  nat: +3.0/+3.3 (p=0.000)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -5.2  [-6.5, -3.9]  p=0.000
   BM25 margin           -5.5  [-6.9, -4.1]  p=0.000
   top5 vs rest          -3.7  [-5.0, -2.5]  p=0.000
   NQC-like spread       -3.2  [-4.4, -2.0]  p=0.000
   WIG-like              -4.8  [-6.2, -3.4]  p=0.000
   term coverage top1    -8.5  [-10.0, -7.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              61.9    64.1    66.7    68.4    69.6    70.8    72.0    72.9    74.0*   74.1*   90%
   BM25 margin            61.7    63.8    65.8    67.7    69.5    70.7    72.1    73.4    74.2*   74.1*   90%
   top5 vs rest           62.3    65.1    67.6    69.6    71.0    72.1    72.6    73.5*   73.9*   74.1*   80%
   NQC-like spread        62.2    65.0    68.0    69.9    71.4    72.7    73.2    73.6*   74.0*   74.1*   80%
   WIG-like               62.4    64.9    66.6    68.2    69.8    70.9    72.2    72.7    73.3    74.1*   100%
   term coverage top1     61.2    62.2    63.5    64.5    66.1    67.9    69.6    70.7    72.2    74.1*   100%
   ORACLE                 69.1    75.5*   79.4*   79.7*   79.7*   79.7*   79.7*   79.7*   79.5*   74.1*   20%
   random (expected)      61.3    62.7    64.1    65.6    67.0    68.4    69.8    71.3    72.7    74.1*   100%
   (BM25 only 59.8; rerank ALL 74.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.3[-14.1]  -10.0[-11.7]   -7.5[ -9.0]   -5.7[ -7.1]   -4.6[ -5.8]   -3.3[ -4.4]   -2.1[ -2.9]   -1.3[ -1.9]   -0.1[ -0.4]#   90%   (point estimate: 90%)
   BM25 margin          -12.4[-14.2]  -10.4[-12.1]   -8.4[-10.0]   -6.4[ -7.9]   -4.6[ -5.8]   -3.5[ -4.6]   -2.1[ -3.0]   -0.7[ -1.3]   +0.1[ -0.2]#   90%   (point estimate: 80%)
   top5 vs rest         -11.8[-13.6]   -9.0[-10.6]   -6.5[ -8.1]   -4.5[ -5.9]   -3.2[ -4.4]   -2.0[ -3.1]   -1.5[ -2.5]   -0.6[ -1.4]   -0.2[ -0.7]#   90%   (point estimate: 80%)
   NQC-like spread      -12.0[-13.8]   -9.1[-10.8]   -6.2[ -7.6]   -4.2[ -5.6]   -2.8[ -3.9]   -1.4[ -2.5]   -0.9[ -1.8]   -0.5[ -1.3]   -0.2[ -0.7]#   90%   (point estimate: 70%)
   WIG-like             -11.7[-13.5]   -9.2[-10.9]   -7.5[ -9.1]   -6.0[ -7.4]   -4.4[ -5.8]   -3.2[ -4.5]   -1.9[ -3.1]   -1.4[ -2.4]   -0.8[ -1.5]    100%   (point estimate: 90%)
   term coverage top1   -13.0[-14.8]  -12.0[-13.7]  -10.7[-12.3]   -9.7[-11.2]   -8.0[ -9.5]   -6.3[ -7.6]   -4.6[ -5.7]   -3.5[ -4.5]   -1.9[ -2.7]    100%   (point estimate: 100%)
   ORACLE                -5.0[ -6.4]   +1.4[ +0.3]#  +5.2[ +4.4]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.4[ +4.5]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.3[-14.1]  -10.0[-11.7]   -7.5[ -9.0]   -5.7[ -7.1]   -4.6[ -5.8]   -3.3[ -4.4]   -2.1[ -2.9]   -1.3[ -1.9]   -0.1[ -0.4]#   90%   (point estimate: 90%)
   BM25 margin          -12.4[-14.2]  -10.4[-12.1]   -8.4[-10.0]   -6.4[ -7.9]   -4.6[ -5.8]   -3.5[ -4.6]   -2.1[ -3.0]   -0.7[ -1.3]   +0.1[ -0.2]#   90%   (point estimate: 90%)
   top5 vs rest         -11.8[-13.6]   -9.0[-10.6]   -6.5[ -8.1]   -4.5[ -5.9]   -3.2[ -4.4]   -2.0[ -3.1]   -1.5[ -2.5]   -0.6[ -1.4]   -0.2[ -0.7]    100%   (point estimate: 90%)
   NQC-like spread      -12.0[-13.8]   -9.1[-10.8]   -6.2[ -7.6]   -4.2[ -5.6]   -2.8[ -3.9]   -1.4[ -2.5]   -0.9[ -1.8]   -0.5[ -1.3]   -0.2[ -0.7]    100%   (point estimate: 90%)
   WIG-like             -11.7[-13.5]   -9.2[-10.9]   -7.5[ -9.1]   -6.0[ -7.4]   -4.4[ -5.8]   -3.2[ -4.5]   -1.9[ -3.1]   -1.4[ -2.4]   -0.8[ -1.5]    100%   (point estimate: 100%)
   term coverage top1   -13.0[-14.8]  -12.0[-13.7]  -10.7[-12.3]   -9.7[-11.2]   -8.0[ -9.5]   -6.3[ -7.6]   -4.6[ -5.7]   -3.5[ -4.5]   -1.9[ -2.7]    100%   (point estimate: 100%)
   ORACLE                -5.0[ -6.4]   +1.4[ +0.3]#  +5.2[ +4.4]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.4[ +4.5]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      80% (sd  17)   -1.40 MRR              52%     20%
   tag alarm               100      83% (sd  11)   -0.94 MRR              44%     17%
   tag alarm               200      85% (sd   8)   -0.72 MRR              37%     15%
   BM25 margin              50      79% (sd  18)   -1.40 MRR              32%     21%
   BM25 margin             100      80% (sd  13)   -1.10 MRR              26%     20%
   BM25 margin             200      81% (sd   8)   -0.82 MRR              20%     19%
   top5 vs rest             50      79% (sd  23)   -1.37 MRR              34%     21%
   top5 vs rest            100      77% (sd  18)   -1.21 MRR              40%     23%
   top5 vs rest            200      78% (sd  15)   -1.09 MRR              38%     22%
   NQC-like spread          50      76% (sd  24)   -1.47 MRR              34%     24%
   NQC-like spread         100      79% (sd  20)   -1.02 MRR              28%     21%
   NQC-like spread         200      74% (sd  17)   -1.14 MRR              44%     26%
   WIG-like                 50      83% (sd  23)   -1.58 MRR              36%     17%
   WIG-like                100      83% (sd  18)   -1.39 MRR              40%     17%
   WIG-like                200      88% (sd  14)   -0.98 MRR              30%     12%
   term coverage top1       50      94% (sd  11)   -0.99 MRR              32%      6%
   term coverage top1      100      97% (sd   7)   -0.56 MRR              22%      3%
   term coverage top1      200      98% (sd   5)   -0.35 MRR              14%      2%

## mag_testfull  (2665 questions; tag alarm fires on 710 = 27%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.2  random  53.0  diff  +4.2  p=0.0001
   MRR  : tag  66.0  random  62.8  diff  +3.2  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.7 (p=0.000)        +2.3 (p=0.000)
   40%            +2.1 (p=0.000)        +1.7 (p=0.000)
   50%            +1.7 (p=0.000)        +1.4 (p=0.000)
   27% nat        +2.9 (p=0.000)        +2.4 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -3.0  95% CI [-4.5, -1.6]  p=0.000
   MRR  :  -2.3  95% CI [-3.3, -1.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (38%)
   Hit@1:  +3.8  p=0.000
   MRR  :  +2.4  p=0.000

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.2/+2.2 (p=0.000)  40%: +3.2/+2.0 (p=0.000)  50%: +3.2/+2.2 (p=0.000)  nat: +3.1/+2.3 (p=0.000)
   vs NQC-like spread      30%: +2.1/+1.5 (p=0.002)  40%: +2.1/+1.4 (p=0.002)  50%: +2.7/+1.9 (p=0.000)  nat: +2.7/+1.8 (p=0.000)
   vs WIG-like             30%: +1.1/+0.8 (p=0.063)  40%: +1.4/+1.0 (p=0.029)  50%: +1.7/+1.2 (p=0.010)  nat: +1.1/+0.8 (p=0.048)
   vs term coverage top1   30%: +1.5/+0.8 (p=0.072)  40%: +1.0/+0.4 (p=0.434)  50%: +0.5/+0.0 (p=0.940)  nat: +1.8/+1.1 (p=0.012)

G. each selector reranking 710 questions (27%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.3  [-3.3, -1.3]  p=0.000
   BM25 margin           -4.7  [-5.9, -3.7]  p=0.000
   top5 vs rest          -4.6  [-5.7, -3.5]  p=0.000
   NQC-like spread       -4.1  [-5.2, -3.0]  p=0.000
   WIG-like              -3.1  [-4.2, -2.0]  p=0.000
   term coverage top1    -3.4  [-4.5, -2.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              62.9    65.1    66.1    66.7    67.3    67.8*   68.3*   68.5*   68.4*   68.3*   60%
   BM25 margin            61.9    62.7    63.8    64.9    65.9    67.0    67.8*   68.3*   68.4*   68.3*   70%
   top5 vs rest           61.9    63.0    63.9    64.6    65.1    65.4    65.8    66.5    67.5    68.3*   100%
   NQC-like spread        62.0    63.3    64.7    65.2    65.4    65.8    66.2    66.9    67.8    68.3*   100%
   WIG-like               63.1    64.7    65.3    65.6    66.1    66.8    67.2    67.9*   68.2*   68.3*   80%
   term coverage top1     62.7    64.0    65.3    66.3    67.3    67.5*   67.8*   68.3*   68.5*   68.3*   60%
   ORACLE                 69.1*   73.7*   74.4*   74.4*   74.4*   74.4*   74.4*   74.4*   73.9*   68.3*   10%
   random (expected)      61.5    62.3    63.0    63.8    64.5    65.3    66.0    66.8    67.5    68.3*   100%
   (BM25 only 60.8; rerank ALL 68.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.4[ -6.6]   -3.2[ -4.3]   -2.2[ -3.2]   -1.6[ -2.6]   -1.0[ -1.8]   -0.5[ -1.2]   +0.0[ -0.5]#  +0.2[ -0.0]#  +0.1[ +0.0]#   70%   (point estimate: 50%)
   BM25 margin           -6.4[ -7.7]   -5.6[ -6.8]   -4.5[ -5.6]   -3.4[ -4.4]   -2.4[ -3.2]   -1.3[ -2.0]   -0.5[ -1.0]#  +0.1[ -0.3]#  +0.1[ -0.1]#   70%   (point estimate: 70%)
   top5 vs rest          -6.4[ -7.7]   -5.3[ -6.5]   -4.4[ -5.5]   -3.7[ -4.6]   -3.2[ -4.1]   -2.9[ -3.7]   -2.5[ -3.3]   -1.8[ -2.4]   -0.8[ -1.1]    100%   (point estimate: 90%)
   NQC-like spread       -6.3[ -7.6]   -5.0[ -6.2]   -3.6[ -4.7]   -3.1[ -4.0]   -2.9[ -3.7]   -2.5[ -3.3]   -2.1[ -2.8]   -1.4[ -2.0]   -0.5[ -0.9]#   90%   (point estimate: 90%)
   WIG-like              -5.1[ -6.4]   -3.6[ -4.7]   -3.0[ -4.1]   -2.6[ -3.6]   -2.2[ -3.1]   -1.5[ -2.4]   -1.1[ -1.8]   -0.4[ -1.0]   -0.1[ -0.6]#   90%   (point estimate: 80%)
   term coverage top1    -5.6[ -6.8]   -4.3[ -5.4]   -3.0[ -4.0]   -2.0[ -3.0]   -1.0[ -1.9]   -0.8[ -1.6]   -0.5[ -1.3]   -0.0[ -0.6]#  +0.2[ -0.2]#   80%   (point estimate: 60%)
   ORACLE                +0.8[ -0.1]#  +5.4[ +4.8]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +5.6[ +5.0]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.4[ -6.6]   -3.2[ -4.3]   -2.2[ -3.2]   -1.6[ -2.6]   -1.0[ -1.8]   -0.5[ -1.2]   +0.0[ -0.5]   +0.2[ -0.0]#  +0.1[ +0.0]#   80%   (point estimate: 70%)
   BM25 margin           -6.4[ -7.7]   -5.6[ -6.8]   -4.5[ -5.6]   -3.4[ -4.4]   -2.4[ -3.2]   -1.3[ -2.0]   -0.5[ -1.0]   +0.1[ -0.3]#  +0.1[ -0.1]#   80%   (point estimate: 70%)
   top5 vs rest          -6.4[ -7.7]   -5.3[ -6.5]   -4.4[ -5.5]   -3.7[ -4.6]   -3.2[ -4.1]   -2.9[ -3.7]   -2.5[ -3.3]   -1.8[ -2.4]   -0.8[ -1.1]    100%   (point estimate: 100%)
   NQC-like spread       -6.3[ -7.6]   -5.0[ -6.2]   -3.6[ -4.7]   -3.1[ -4.0]   -2.9[ -3.7]   -2.5[ -3.3]   -2.1[ -2.8]   -1.4[ -2.0]   -0.5[ -0.9]    100%   (point estimate: 100%)
   WIG-like              -5.1[ -6.4]   -3.6[ -4.7]   -3.0[ -4.1]   -2.6[ -3.6]   -2.2[ -3.1]   -1.5[ -2.4]   -1.1[ -1.8]   -0.4[ -1.0]   -0.1[ -0.6]    100%   (point estimate: 80%)
   term coverage top1    -5.6[ -6.8]   -4.3[ -5.4]   -3.0[ -4.0]   -2.0[ -3.0]   -1.0[ -1.9]   -0.8[ -1.6]   -0.5[ -1.3]   -0.0[ -0.6]   +0.2[ -0.2]#   90%   (point estimate: 80%)
   ORACLE                +0.8[ -0.1]#  +5.4[ +4.8]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +5.6[ +5.0]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      56% (sd  27)   -1.29 MRR              37%     44%
   tag alarm               100      57% (sd  25)   -1.09 MRR              38%     43%
   tag alarm               200      53% (sd  21)   -1.18 MRR              44%     47%
   BM25 margin              50      68% (sd  24)   -1.25 MRR              34%     32%
   BM25 margin             100      64% (sd  18)   -1.26 MRR              45%     36%
   BM25 margin             200      66% (sd  14)   -1.01 MRR              39%     34%
   top5 vs rest             50      82% (sd  27)   -1.33 MRR              32%     18%
   top5 vs rest            100      87% (sd  19)   -1.02 MRR              28%     13%
   top5 vs rest            200      89% (sd  15)   -0.93 MRR              24%     11%
   NQC-like spread          50      80% (sd  26)   -1.26 MRR              40%     20%
   NQC-like spread         100      82% (sd  24)   -1.15 MRR              34%     18%
   NQC-like spread         200      86% (sd  14)   -0.89 MRR              32%     14%
   WIG-like                 50      71% (sd  32)   -1.29 MRR              38%     29%
   WIG-like                100      71% (sd  27)   -1.19 MRR              42%     29%
   WIG-like                200      71% (sd  25)   -1.12 MRR              42%     29%
   term coverage top1       50      61% (sd  32)   -1.57 MRR              41%     39%
   term coverage top1      100      61% (sd  28)   -1.37 MRR              40%     39%
   term coverage top1      200      64% (sd  23)   -0.90 MRR              38%     36%

## prime_testfull  (2801 questions; tag alarm fires on 1563 = 56%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  26.5  random  23.9  diff  +2.6  p=0.0001
   MRR  : tag  35.5  random  33.1  diff  +2.4  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.7 (p=0.000)        +1.4 (p=0.000)
   40%            +1.4 (p=0.008)        +1.4 (p=0.000)
   50%            +2.0 (p=0.001)        +2.1 (p=0.000)
   56% nat        +1.6 (p=0.006)        +1.8 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.4  95% CI [-0.7, +1.5]  p=0.521
   MRR  :  -0.7  95% CI [-1.5, +0.1]  p=0.085

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (53%)
   Hit@1:  +1.3  p=0.021
   MRR  :  +0.8  p=0.067

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.0/+0.0 (p=0.969)  40%: +0.7/+0.6 (p=0.136)  50%: +1.1/+1.1 (p=0.009)  nat: +0.6/+0.7 (p=0.060)
   vs NQC-like spread      30%: +0.0/+0.0 (p=0.985)  40%: -0.1/+0.0 (p=0.932)  50%: +0.1/+0.3 (p=0.458)  nat: -0.3/-0.0 (p=0.908)
   vs WIG-like             30%: +0.4/+0.1 (p=0.853)  40%: +0.6/+0.2 (p=0.569)  50%: +0.9/+0.7 (p=0.074)  nat: +0.6/+0.5 (p=0.182)
   vs term coverage top1   30%: +1.3/+1.1 (p=0.016)  40%: +1.6/+1.5 (p=0.002)  50%: +2.1/+2.0 (p=0.000)  nat: +1.5/+1.6 (p=0.000)

G. each selector reranking 1563 questions (56%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.7  [-1.5, +0.1]  p=0.085
   BM25 margin           -2.5  [-3.4, -1.7]  p=0.000
   top5 vs rest          -1.5  [-2.3, -0.6]  p=0.002
   NQC-like spread       -0.7  [-1.6, +0.2]  p=0.132
   WIG-like              -1.3  [-2.2, -0.4]  p=0.008
   term coverage top1    -2.3  [-3.2, -1.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              30.5    31.5    32.7    33.8    35.2    35.5*   36.0*   36.2*   36.4*   36.2*   60%
   BM25 margin            29.9    30.6    31.3    32.4    33.2    34.2    35.0    35.9*   36.2*   36.2*   80%
   top5 vs rest           30.1    31.3    32.7    33.2    34.2    35.1    35.5*   35.8*   35.9*   36.2*   70%
   NQC-like spread        30.0    31.4    32.7    33.8    35.0    35.6*   35.7*   35.7*   36.1*   36.2*   60%
   WIG-like               30.4    31.4    32.6    33.6    34.5    35.2    36.0*   36.2*   36.4*   36.2*   70%
   term coverage top1     29.8    30.7    31.6    32.4    33.2    33.9    34.5    35.3    35.8*   36.2*   90%
   ORACLE                 37.6*   41.6*   42.4*   42.4*   42.4*   42.4*   42.4*   42.4*   41.9*   36.2*   10%
   random (expected)      29.8    30.5    31.3    32.0    32.7    33.4    34.1    34.8    35.5    36.2*   100%
   (BM25 only 29.1; rerank ALL 36.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.7[ -6.9]   -4.7[ -5.8]   -3.5[ -4.6]   -2.4[ -3.4]   -1.0[ -1.8]   -0.7[ -1.5]   -0.2[ -0.9]#  -0.0[ -0.5]#  +0.2[ -0.2]#   70%   (point estimate: 50%)
   BM25 margin           -6.3[ -7.5]   -5.6[ -6.8]   -4.9[ -6.0]   -3.8[ -4.8]   -3.0[ -3.9]   -2.0[ -2.7]   -1.2[ -1.9]   -0.3[ -0.8]#  -0.0[ -0.3]#   80%   (point estimate: 80%)
   top5 vs rest          -6.1[ -7.3]   -4.9[ -6.0]   -3.5[ -4.6]   -3.0[ -4.1]   -2.0[ -3.0]   -1.1[ -2.0]   -0.7[ -1.4]   -0.4[ -1.1]   -0.3[ -0.8]#   90%   (point estimate: 70%)
   NQC-like spread       -6.2[ -7.4]   -4.8[ -6.0]   -3.5[ -4.6]   -2.4[ -3.4]   -1.3[ -2.2]   -0.6[ -1.5]   -0.5[ -1.2]   -0.5[ -1.1]   -0.1[ -0.5]#   90%   (point estimate: 60%)
   WIG-like              -5.8[ -7.1]   -4.8[ -5.9]   -3.6[ -4.7]   -2.6[ -3.7]   -1.7[ -2.7]   -1.0[ -1.9]   -0.2[ -0.9]#  -0.1[ -0.7]#  +0.2[ -0.2]#   70%   (point estimate: 60%)
   term coverage top1    -6.4[ -7.7]   -5.5[ -6.6]   -4.6[ -5.7]   -3.8[ -4.9]   -3.0[ -3.9]   -2.3[ -3.1]   -1.7[ -2.4]   -0.9[ -1.5]   -0.4[ -0.8]#   90%   (point estimate: 80%)
   ORACLE                +1.4[ +0.6]#  +5.4[ +4.7]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +5.7[ +5.0]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.7[ -6.9]   -4.7[ -5.8]   -3.5[ -4.6]   -2.4[ -3.4]   -1.0[ -1.8]   -0.7[ -1.5]   -0.2[ -0.9]   -0.0[ -0.5]   +0.2[ -0.2]#   90%   (point estimate: 70%)
   BM25 margin           -6.3[ -7.5]   -5.6[ -6.8]   -4.9[ -6.0]   -3.8[ -4.8]   -3.0[ -3.9]   -2.0[ -2.7]   -1.2[ -1.9]   -0.3[ -0.8]   -0.0[ -0.3]#   90%   (point estimate: 80%)
   top5 vs rest          -6.1[ -7.3]   -4.9[ -6.0]   -3.5[ -4.6]   -3.0[ -4.1]   -2.0[ -3.0]   -1.1[ -2.0]   -0.7[ -1.4]   -0.4[ -1.1]   -0.3[ -0.8]    100%   (point estimate: 80%)
   NQC-like spread       -6.2[ -7.4]   -4.8[ -6.0]   -3.5[ -4.6]   -2.4[ -3.4]   -1.3[ -2.2]   -0.6[ -1.5]   -0.5[ -1.2]   -0.5[ -1.1]   -0.1[ -0.5]    100%   (point estimate: 80%)
   WIG-like              -5.8[ -7.1]   -4.8[ -5.9]   -3.6[ -4.7]   -2.6[ -3.7]   -1.7[ -2.7]   -1.0[ -1.9]   -0.2[ -0.9]   -0.1[ -0.7]   +0.2[ -0.2]#   90%   (point estimate: 70%)
   term coverage top1    -6.4[ -7.7]   -5.5[ -6.6]   -4.6[ -5.7]   -3.8[ -4.9]   -3.0[ -3.9]   -2.3[ -3.1]   -1.7[ -2.4]   -0.9[ -1.5]   -0.4[ -0.8]    100%   (point estimate: 90%)
   ORACLE                +1.4[ +0.6]#  +5.4[ +4.7]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +6.2[ +5.6]#  +5.7[ +5.0]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      65% (sd  31)   -1.34 MRR              32%     35%
   tag alarm               100      65% (sd  26)   -1.13 MRR              33%     35%
   tag alarm               200      64% (sd  21)   -0.90 MRR              32%     36%
   BM25 margin              50      72% (sd  26)   -1.42 MRR              42%     28%
   BM25 margin             100      73% (sd  22)   -1.28 MRR              43%     27%
   BM25 margin             200      75% (sd  16)   -1.04 MRR              41%     25%
   top5 vs rest             50      72% (sd  31)   -1.40 MRR              34%     28%
   top5 vs rest            100      71% (sd  28)   -1.32 MRR              36%     29%
   top5 vs rest            200      70% (sd  24)   -1.22 MRR              41%     30%
   NQC-like spread          50      68% (sd  31)   -1.40 MRR              32%     32%
   NQC-like spread         100      67% (sd  27)   -1.27 MRR              34%     33%
   NQC-like spread         200      66% (sd  24)   -1.16 MRR              38%     34%
   WIG-like                 50      69% (sd  30)   -1.19 MRR              32%     31%
   WIG-like                100      66% (sd  27)   -1.25 MRR              38%     34%
   WIG-like                200      62% (sd  22)   -1.28 MRR              46%     38%
   term coverage top1       50      76% (sd  28)   -1.47 MRR              37%     24%
   term coverage top1      100      82% (sd  21)   -1.05 MRR              30%     18%
   term coverage top1      200      82% (sd  16)   -0.99 MRR              33%     18%

## POOLED over 3 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  45.6  random  42.4  diff  +3.2  p=0.0001
   MRR  : tag  54.6  random  51.9  diff  +2.7  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +1.9 (p=0.000)   MRR  +1.6 (p=0.000)
   40%      Hit@1  +1.3 (p=0.000)   MRR  +1.4 (p=0.000)
   50%      Hit@1  +1.2 (p=0.000)   MRR  +1.3 (p=0.000)
   natural  Hit@1  +1.6 (p=0.000)   MRR  +1.7 (p=0.000)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -2.3  95% CI [-3.1, -1.5]  p=0.000
   MRR  :  -2.4  95% CI [-2.9, -1.8]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +2.3  p=0.000
   MRR  :  +1.5  p=0.000

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.2/+0.6 (p=0.035)  40%: +1.3/+0.7 (p=0.012)  50%: +1.3/+0.9 (p=0.002)  nat: +1.1/+0.8 (p=0.005)
   vs NQC-like spread      30%: +0.6/+0.2 (p=0.395)  40%: +0.4/+0.2 (p=0.472)  50%: +0.6/+0.4 (p=0.140)  nat: +0.4/+0.2 (p=0.445)
   vs WIG-like             30%: +0.7/+0.3 (p=0.223)  40%: +0.9/+0.5 (p=0.075)  50%: +1.0/+0.7 (p=0.018)  nat: +0.6/+0.4 (p=0.123)
   vs term coverage top1   30%: +2.0/+1.5 (p=0.000)  40%: +2.0/+1.6 (p=0.000)  50%: +1.8/+1.6 (p=0.000)  nat: +2.0/+1.8 (p=0.000)
