# router41: label-free signals vs pre-retrieval vs trained routers  (deltas [1.0, 0.5] MRR points)

## mag_testfull (tag qwen8b; n=1000; mean gain +10.4 MRR; helped 28% hurt 13%)

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               70/70          80/70           +30             -2.8     +0.6 (0.476)
   tag alarm                                 70/60          80/70           +40             -1.7     +1.7 (0.019)
   top5 vs rest                             100/90         100/100          +10             -4.5     -1.1 (0.088)
   NQC-like spread                           90/90         100/90           +10             -3.0     +0.4 (0.494)
   WIG-like                                 100/90         100/100          +10             -3.4          -
   term coverage top1                       100/80         100/100          +20             -2.3     +1.1 (0.104)
   router ridge S (5-fold CV)                70/60          90/70           +40             -1.2     +2.3 (0.001)
   router gbm S (5-fold CV)                  90/70         100/90           +30             -2.4     +1.0 (0.136)
   router ridge S (other collections)        80/60          90/70           +40             -1.4     +2.0 (0.000)
   router gbm S (other collections)          90/80         100/90           +20             -3.6     -0.1 (0.837)
   ORACLE                                    20/20          20/20           +80             +4.9     +8.3 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.147, tag alarm +0.304, top5 vs rest +0.115, NQC-like spread -0.115, WIG-like -0.100, term coverage top1 -0.102

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -4.9   -3.4   -2.0
   n=  50  router ridge S          -4.1   -2.2   -1.0   P(router > WIG-like @50%) = 89%
   n=  50  router gbm   S          -5.4   -3.1   -1.5   P(router > WIG-like @50%) = 68%
   n= 100  WIG-like                 -4.9   -3.4   -2.0
   n= 100  router ridge S          -3.7   -1.7   -0.6   P(router > WIG-like @50%) = 98%
   n= 100  router gbm   S          -4.7   -2.6   -1.2   P(router > WIG-like @50%) = 83%
   n= 200  WIG-like                 -4.8   -3.3   -2.0
   n= 200  router ridge S          -3.4   -1.4   -0.4   P(router > WIG-like @50%) = 100%
   n= 200  router gbm   S          -4.6   -2.6   -1.3   P(router > WIG-like @50%) = 85%

## prime_testfull (tag qwen8b; n=1000; mean gain +10.8 MRR; helped 34% hurt 14%)

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/90         100/90           +10             -5.3     -1.0 (0.261)
   tag alarm                                 90/80         100/90           +20             -2.3     +2.0 (0.013)
   top5 vs rest                             100/80         100/100          +20             -4.1     +0.2 (0.772)
   NQC-like spread                          100/80         100/90           +20             -3.1     +1.2 (0.052)
   WIG-like                                  90/80         100/90           +20             -4.3          -
   term coverage top1                       100/90         100/100          +10             -4.6     -0.3 (0.688)
   router ridge S (5-fold CV)                90/80         100/80           +20             -2.5     +1.8 (0.014)
   router gbm S (5-fold CV)                  90/90          90/90           +10             -3.5     +0.8 (0.324)
   router ridge S (other collections)       100/70         100/90           +30             -3.0     +1.3 (0.050)
   router gbm S (other collections)         100/70         100/100          +30             -3.3     +1.0 (0.148)
   ORACLE                                    20/20          20/20           +80             +6.0    +10.3 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.067, tag alarm +0.216, top5 vs rest +0.200, NQC-like spread -0.252, WIG-like -0.007, term coverage top1 -0.062

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -6.9   -4.3   -1.4
   n=  50  router ridge S          -6.5   -4.1   -2.0   P(router > WIG-like @50%) = 60%
   n=  50  router gbm   S          -6.6   -4.4   -2.3   P(router > WIG-like @50%) = 54%
   n= 100  WIG-like                 -6.9   -4.3   -1.4
   n= 100  router ridge S          -6.1   -3.5   -1.6   P(router > WIG-like @50%) = 79%
   n= 100  router gbm   S          -6.5   -4.2   -2.2   P(router > WIG-like @50%) = 57%
   n= 200  WIG-like                 -6.9   -4.3   -1.4
   n= 200  router ridge S          -5.7   -2.9   -1.3   P(router > WIG-like @50%) = 93%
   n= 200  router gbm   S          -6.5   -4.2   -2.3   P(router > WIG-like @50%) = 61%

## dbpedia_test (tag qwen8b; n=400; mean gain +22.9 MRR; helped 43% hurt 6%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.22   rho(gain) -0.16
   avgIDF   rho(quality) +0.18   rho(gain) -0.20
   maxIDF   rho(quality) +0.02   rho(gain) -0.11
   avgICTF  rho(quality) +0.16   rho(gain) -0.18
   avgSCQ   rho(quality) +0.25   rho(gain) -0.18
   maxSCQ   rho(quality) +0.11   rho(gain) -0.11
   SCS      rho(quality) +0.20   rho(gain) -0.21

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/90         100/100          +10             -9.5     -1.0 (0.529)
   tag alarm                                100/90         100/90           +10             -9.0     -0.4 (0.754)
   top5 vs rest                             100/100        100/100           +0             -9.6     -1.1 (0.429)
   NQC-like spread                          100/100        100/100           +0             -9.6     -1.0 (0.467)
   WIG-like                                 100/90         100/100          +10             -8.6          -
   term coverage top1                       100/100        100/100           +0             -8.7     -0.1 (0.943)
   pre:qlen                                 100/100        100/100           +0             -9.6     -1.1 (0.420)
   pre:avgIDF                               100/100        100/100           +0             -7.9     +0.7 (0.618)
   pre:maxIDF                               100/100        100/100           +0             -9.4     -0.8 (0.572)
   pre:avgICTF                              100/100        100/100           +0             -8.5     +0.1 (0.967)
   pre:avgSCQ                               100/90         100/100          +10             -9.0     -0.4 (0.763)
   pre:maxSCQ                               100/100        100/100           +0             -9.1     -0.5 (0.707)
   pre:SCS                                  100/100        100/100           +0             -7.8     +0.8 (0.565)
   router ridge S (5-fold CV)               100/90         100/100          +10             -9.9     -1.3 (0.207)
   router gbm S (5-fold CV)                 100/100        100/100           +0             -9.7     -1.2 (0.427)
   router ridge S+P (5-fold CV)             100/100        100/100           +0             -8.1     +0.5 (0.697)
   router gbm S+P (5-fold CV)               100/90         100/100          +10            -10.8     -2.2 (0.140)
   router ridge S (other collections)        90/90          90/90           +10             -8.7     -0.1 (0.885)
   router gbm S (other collections)         100/100        100/100           +0             -8.5     +0.0 (0.986)
   ORACLE                                    40/30          40/30           +70             +2.5    +11.1 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.153, tag alarm +0.179, top5 vs rest +0.001, NQC-like spread -0.013, WIG-like -0.178, term coverage top1 -0.027
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.115, tag alarm +0.180, top5 vs rest +0.014, NQC-like spread +0.020, WIG-like -0.076, term coverage top1 -0.098, qlen +0.035, avgIDF -0.234, maxIDF -0.117, avgICTF +0.216, avgSCQ -0.037, maxSCQ -0.031, SCS -0.040

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                -13.4   -8.7   -4.6
   n=  50  router ridge S+P       -14.3   -9.2   -4.9   P(router > WIG-like @50%) = 36%
   n=  50  router gbm   S+P       -14.8   -9.7   -5.2   P(router > WIG-like @50%) = 24%
   n= 100  WIG-like                -13.4   -8.6   -4.5
   n= 100  router ridge S+P       -14.1   -9.0   -4.5   P(router > WIG-like @50%) = 47%
   n= 100  router gbm   S+P       -15.2  -10.3   -5.9   P(router > WIG-like @50%) = 11%
   n= 200  WIG-like                -13.4   -8.7   -4.5
   n= 200  router ridge S+P       -13.9   -8.3   -4.1   P(router > WIG-like @50%) = 61%
   n= 200  router gbm   S+P       -15.5  -10.7   -6.2   P(router > WIG-like @50%) = 10%

## beir_scifact (tag qwen8b; n=300; mean gain +10.7 MRR; helped 27% hurt 7%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.00   rho(gain) -0.08
   avgIDF   rho(quality) +0.11   rho(gain) -0.03
   maxIDF   rho(quality) +0.10   rho(gain) -0.00
   avgICTF  rho(quality) +0.06   rho(gain) -0.00
   avgSCQ   rho(quality) +0.04   rho(gain) -0.06
   maxSCQ   rho(quality) +0.10   rho(gain) -0.07
   SCS      rho(quality) +0.03   rho(gain) -0.03

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               70/70          90/70           +30             -2.4     +1.2 (0.329)
   tag alarm                                 80/70          80/80           +30             -2.8     +0.8 (0.557)
   top5 vs rest                             100/100        100/100           +0             -5.7     -2.1 (0.022)
   NQC-like spread                          100/80         100/100          +20             -3.5     +0.1 (0.873)
   WIG-like                                 100/90         100/100          +10             -3.5          -
   term coverage top1                       100/90         100/100          +10             -3.3     +0.2 (0.786)
   pre:qlen                                 100/90         100/90           +10             -5.7     -2.1 (0.113)
   pre:avgIDF                               100/90         100/100          +10             -5.1     -1.6 (0.234)
   pre:maxIDF                               100/100        100/100           +0             -4.8     -1.2 (0.414)
   pre:avgICTF                              100/90         100/100          +10             -5.2     -1.7 (0.207)
   pre:avgSCQ                               100/90         100/100          +10             -6.5     -3.0 (0.001)
   pre:maxSCQ                               100/100        100/100           +0             -5.1     -1.6 (0.112)
   pre:SCS                                  100/90         100/100          +10             -5.0     -1.5 (0.282)
   router ridge S (5-fold CV)                80/70          80/80           +30             -2.4     +1.2 (0.232)
   router gbm S (5-fold CV)                 100/100        100/100           +0             -5.2     -1.7 (0.123)
   router ridge S+P (5-fold CV)              90/80          90/90           +20             -3.0     +0.5 (0.627)
   router gbm S+P (5-fold CV)               100/100        100/100           +0             -4.5     -1.0 (0.343)
   router ridge S (other collections)        80/80          80/80           +20             -2.5     +1.0 (0.130)
   router gbm S (other collections)         100/70         100/100          +30             -3.6     -0.0 (0.977)
   ORACLE                                    20/20          20/20           +80             +2.0     +5.6 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.218, tag alarm -0.008, top5 vs rest -0.042, NQC-like spread -0.049, WIG-like -0.017, term coverage top1 -0.058
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.204, tag alarm -0.016, top5 vs rest -0.042, NQC-like spread -0.131, WIG-like -0.053, term coverage top1 -0.031, qlen +0.066, avgIDF +0.034, maxIDF -0.105, avgICTF +0.117, avgSCQ +0.067, maxSCQ +0.019, SCS -0.015

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -5.3   -3.6   -2.6
   n=  50  router ridge S+P        -6.2   -3.8   -1.9   P(router > WIG-like @50%) = 42%
   n=  50  router gbm   S+P        -6.5   -4.1   -2.1   P(router > WIG-like @50%) = 34%
   n= 100  WIG-like                 -5.4   -3.6   -2.6
   n= 100  router ridge S+P        -6.0   -3.5   -1.5   P(router > WIG-like @50%) = 59%
   n= 100  router gbm   S+P        -6.2   -3.9   -2.2   P(router > WIG-like @50%) = 47%
   n= 200  WIG-like                 -5.1   -3.4   -2.5
   n= 200  router ridge S+P        -5.7   -3.0   -1.1   P(router > WIG-like @50%) = 63%
   n= 200  router gbm   S+P        -5.7   -3.8   -2.4   P(router > WIG-like @50%) = 42%

## beir_nfcorpus (tag qwen8b; n=323; mean gain +7.3 MRR; helped 26% hurt 10%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.02   rho(gain) -0.21
   avgIDF   rho(quality) -0.19   rho(gain) -0.14
   maxIDF   rho(quality) -0.33   rho(gain) -0.03
   avgICTF  rho(quality) -0.25   rho(gain) -0.11
   avgSCQ   rho(quality) +0.51   rho(gain) -0.04
   maxSCQ   rho(quality) +0.36   rho(gain) +0.06
   SCS      rho(quality) -0.21   rho(gain) -0.15

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/90         100/100           +0             -2.6     +0.2 (0.846)
   tag alarm                                100/90         100/100           +0             -2.4     +0.4 (0.761)
   top5 vs rest                              90/80         100/90           +10             -3.8     -1.0 (0.184)
   NQC-like spread                          100/70         100/90           +20             -3.3     -0.5 (0.598)
   WIG-like                                  90/80         100/90           +10             -2.8          -
   term coverage top1                       100/100        100/100          -10             -1.2     +1.7 (0.072)
   pre:qlen                                 100/70         100/80           +20             -1.5     +1.3 (0.214)
   pre:avgIDF                                90/70          90/90           +20             -2.7     +0.1 (0.914)
   pre:maxIDF                               100/100        100/100          -10             -3.7     -0.9 (0.550)
   pre:avgICTF                               90/80         100/90           +10             -2.9     -0.1 (0.953)
   pre:avgSCQ                                80/80          90/80           +10             -4.4     -1.5 (0.068)
   pre:maxSCQ                               100/100        100/100          -10             -5.2     -2.3 (0.019)
   pre:SCS                                   90/70         100/90           +20             -2.4     +0.4 (0.721)
   router ridge S (5-fold CV)               100/80         100/100          +10             -2.1     +0.8 (0.436)
   router gbm S (5-fold CV)                  90/40         100/40           +50             -0.3     +2.5 (0.022)
   router ridge S+P (5-fold CV)              90/70         100/70           +20             -1.1     +1.7 (0.075)
   router gbm S+P (5-fold CV)                80/40          90/50           +50             -0.1     +2.7 (0.014)
   router ridge S (other collections)        90/60          90/70           +30             -1.5     +1.3 (0.148)
   router gbm S (other collections)          90/80          90/90           +10             -2.9     -0.0 (0.978)
   ORACLE                                    20/10          20/10           +80             +3.9     +6.7 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.003, tag alarm -0.199, top5 vs rest +0.103, NQC-like spread -0.033, WIG-like -0.090, term coverage top1 -0.090
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.112, tag alarm -0.273, top5 vs rest +0.037, NQC-like spread +0.095, WIG-like -0.263, term coverage top1 +0.011, qlen +0.216, avgIDF -0.151, maxIDF +0.016, avgICTF +0.097, avgSCQ +0.105, maxSCQ +0.089, SCS +0.052

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -4.3   -2.9   -1.0
   n=  50  router ridge S+P        -4.1   -2.6   -1.2   P(router > WIG-like @50%) = 67%
   n=  50  router gbm   S+P        -4.2   -2.7   -1.4   P(router > WIG-like @50%) = 56%
   n= 100  WIG-like                 -4.2   -2.8   -0.9
   n= 100  router ridge S+P        -3.8   -2.1   -0.9   P(router > WIG-like @50%) = 79%
   n= 100  router gbm   S+P        -3.8   -2.2   -1.3   P(router > WIG-like @50%) = 69%
   n= 200  WIG-like                 -4.2   -2.8   -0.9
   n= 200  router ridge S+P        -3.5   -1.6   -0.8   P(router > WIG-like @50%) = 86%
   n= 200  router gbm   S+P        -2.9   -1.4   -0.7   P(router > WIG-like @50%) = 87%

## beir_scidocs (tag qwen8b; n=1000; mean gain +10.3 MRR; helped 43% hurt 14%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.15   rho(gain) -0.12
   avgIDF   rho(quality) +0.10   rho(gain) +0.01
   maxIDF   rho(quality) +0.05   rho(gain) +0.01
   avgICTF  rho(quality) +0.08   rho(gain) +0.01
   avgSCQ   rho(quality) +0.15   rho(gain) +0.00
   maxSCQ   rho(quality) +0.20   rho(gain) +0.05
   SCS      rho(quality) +0.02   rho(gain) -0.04

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/90         100/90           +10             -4.6     -0.0 (0.996)
   tag alarm                                100/90         100/100          +10             -4.8     -0.2 (0.790)
   top5 vs rest                             100/100        100/100           +0             -5.6     -1.0 (0.079)
   NQC-like spread                          100/90         100/100          +10             -5.4     -0.8 (0.129)
   WIG-like                                 100/100        100/100           +0             -4.6          -
   term coverage top1                        90/80         100/90           +20             -3.7     +0.9 (0.143)
   pre:qlen                                 100/90         100/90           +10             -3.8     +0.8 (0.254)
   pre:avgIDF                               100/90         100/100          +10             -6.0     -1.4 (0.039)
   pre:maxIDF                               100/100        100/100           +0             -5.6     -1.0 (0.161)
   pre:avgICTF                              100/100        100/100           +0             -6.3     -1.7 (0.014)
   pre:avgSCQ                               100/100        100/100           +0             -5.7     -1.0 (0.118)
   pre:maxSCQ                               100/90         100/100          +10             -6.3     -1.6 (0.014)
   pre:SCS                                  100/90         100/100          +10             -5.4     -0.8 (0.258)
   router ridge S (5-fold CV)               100/90         100/100          +10             -4.0     +0.6 (0.356)
   router gbm S (5-fold CV)                 100/80         100/100          +20             -3.4     +1.2 (0.084)
   router ridge S+P (5-fold CV)             100/90         100/90           +10             -4.0     +0.6 (0.333)
   router gbm S+P (5-fold CV)                90/80         100/90           +20             -3.6     +1.0 (0.156)
   router ridge S (other collections)       100/90         100/90           +10             -4.6     -0.0 (0.997)
   router gbm S (other collections)         100/90         100/100          +10             -3.7     +0.9 (0.167)
   ORACLE                                    20/20          20/20           +80             +3.8     +8.4 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.055, tag alarm -0.018, top5 vs rest -0.037, NQC-like spread +0.055, WIG-like -0.002, term coverage top1 -0.118
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.071, tag alarm -0.029, top5 vs rest -0.027, NQC-like spread +0.030, WIG-like -0.046, term coverage top1 -0.049, qlen +0.063, avgIDF +0.096, maxIDF -0.068, avgICTF +0.125, avgSCQ -0.006, maxSCQ +0.027, SCS -0.133

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -7.0   -4.6   -2.4
   n=  50  router ridge S+P        -6.8   -4.6   -2.6   P(router > WIG-like @50%) = 45%
   n=  50  router gbm   S+P        -6.8   -4.6   -2.7   P(router > WIG-like @50%) = 52%
   n= 100  WIG-like                 -7.0   -4.6   -2.4
   n= 100  router ridge S+P        -6.7   -4.5   -2.4   P(router > WIG-like @50%) = 61%
   n= 100  router gbm   S+P        -6.8   -4.7   -2.7   P(router > WIG-like @50%) = 44%
   n= 200  WIG-like                 -7.0   -4.6   -2.4
   n= 200  router ridge S+P        -6.6   -4.3   -2.3   P(router > WIG-like @50%) = 70%
   n= 200  router gbm   S+P        -6.6   -4.6   -2.6   P(router > WIG-like @50%) = 50%

## amazon_testfull (tag qwen8b; n=500; mean gain +9.8 MRR; helped 32% hurt 14%)

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/80          90/80           +10             -2.6     -0.2 (0.878)
   tag alarm                                 90/90          90/90            +0             -3.2     -0.8 (0.537)
   top5 vs rest                              90/70         100/70           +20             -2.2     +0.2 (0.848)
   NQC-like spread                           80/70          90/70           +20             -1.5     +0.9 (0.380)
   WIG-like                                 100/60         100/100          +30             -2.4          -
   term coverage top1                       100/90         100/100           +0             -5.5     -3.1 (0.008)
   router ridge S (5-fold CV)               100/60         100/60           +30             -1.2     +1.2 (0.175)
   router gbm S (5-fold CV)                  80/60         100/70           +30             -1.5     +0.9 (0.441)
   router ridge S (other collections)        90/90         100/90            +0             -3.4     -1.0 (0.422)
   router gbm S (other collections)          90/90         100/90            +0             -3.0     -0.6 (0.556)
   ORACLE                                    20/10          20/20           +80             +6.8     +9.2 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.140, tag alarm +0.060, top5 vs rest -0.161, NQC-like spread -0.010, WIG-like -0.169, term coverage top1 +0.018

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -3.8   -2.5   -0.4
   n=  50  router ridge S          -4.3   -2.1   -0.7   P(router > WIG-like @50%) = 72%
   n=  50  router gbm   S          -5.0   -2.8   -1.2   P(router > WIG-like @50%) = 51%
   n= 100  WIG-like                 -3.8   -2.5   -0.4
   n= 100  router ridge S          -4.1   -1.8   -0.3   P(router > WIG-like @50%) = 81%
   n= 100  router gbm   S          -4.9   -2.7   -1.1   P(router > WIG-like @50%) = 44%
   n= 200  WIG-like                 -4.0   -2.5   -0.5
   n= 200  router ridge S          -3.8   -1.6   +0.1   P(router > WIG-like @50%) = 84%
   n= 200  router gbm   S          -4.8   -2.4   -0.7   P(router > WIG-like @50%) = 58%

