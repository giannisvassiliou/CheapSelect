## mag_testfull  (1000 questions; tag alarm fires on 262 = 26%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.4  random  52.3  diff  +5.1  p=0.0001
   MRR  : tag  62.8  random  59.8  diff  +3.0  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.7 (p=0.007)        +1.8 (p=0.001)
   40%            +2.2 (p=0.018)        +1.4 (p=0.007)
   50%            +1.4 (p=0.110)        +0.9 (p=0.060)
   26% nat        +2.9 (p=0.004)        +2.0 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -3.8  95% CI [-6.1, -1.5]  p=0.002
   MRR  :  -2.9  95% CI [-4.2, -1.6]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (37%)
   Hit@1:  +3.3  p=0.003
   MRR  :  +1.4  p=0.016

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +4.2/+1.8 (p=0.003)  40%: +3.7/+1.5 (p=0.011)  50%: +3.9/+1.7 (p=0.002)  nat: +3.9/+2.0 (p=0.001)
   vs NQC-like spread      30%: +2.7/+1.2 (p=0.043)  40%: +1.7/+0.6 (p=0.268)  50%: +1.6/+0.6 (p=0.274)  nat: +3.0/+1.4 (p=0.017)
   vs WIG-like             30%: +1.9/+0.7 (p=0.252)  40%: +2.0/+0.6 (p=0.290)  50%: +2.1/+0.7 (p=0.233)  nat: +1.8/+0.8 (p=0.170)
   vs term coverage top1   30%: +2.8/+0.9 (p=0.146)  40%: +1.5/+0.0 (p=0.938)  50%: +1.3/-0.1 (p=0.919)  nat: +2.9/+1.3 (p=0.032)

G. each selector reranking 262 questions (26%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.9  [-4.2, -1.6]  p=0.000
   BM25 margin           -5.0  [-6.5, -3.5]  p=0.000
   top5 vs rest          -4.9  [-6.4, -3.5]  p=0.000
   NQC-like spread       -4.3  [-5.7, -2.9]  p=0.000
   WIG-like              -3.7  [-5.1, -2.3]  p=0.000
   term coverage top1    -4.2  [-5.7, -2.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              60.4    62.1    63.0    63.5    64.2    65.0*   65.7*   66.1*   66.1*   65.7*   60%
   BM25 margin            59.1    60.0    61.1    62.1    63.3    64.3    65.7*   66.1*   66.1*   65.7*   70%
   top5 vs rest           58.6    60.0    61.1    62.0    62.5    63.3    64.2    64.9    65.3    65.7*   100%
   NQC-like spread        58.7    60.5    61.8    62.8    63.6    63.9    64.4    65.1    65.6*   65.7*   90%
   WIG-like               59.8    61.5    62.3    62.8    63.5    63.5    64.5    65.1*   65.3*   65.7*   80%
   term coverage top1     59.2    60.9    62.1    63.4    64.3    64.7*   65.0*   65.3*   65.5*   65.7*   60%
   ORACLE                 64.5    68.2*   69.8*   70.0*   70.0*   70.0*   70.0*   70.0*   69.5*   65.7*   20%
   random (expected)      58.5    59.3    60.1    60.9    61.7    62.5    63.3    64.1    64.9    65.7*   100%
   (BM25 only 57.7; rerank ALL 65.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.3[ -7.0]   -3.6[ -5.0]   -2.7[ -4.0]   -2.2[ -3.4]   -1.5[ -2.5]   -0.6[ -1.6]   +0.0[ -0.6]#  +0.4[ +0.0]#  +0.4[ +0.1]#   70%   (point estimate: 60%)
   BM25 margin           -6.6[ -8.2]   -5.7[ -7.2]   -4.6[ -6.0]   -3.6[ -5.0]   -2.4[ -3.6]   -1.4[ -2.4]   -0.0[ -0.6]#  +0.4[ -0.0]#  +0.4[ +0.1]#   70%   (point estimate: 70%)
   top5 vs rest          -7.1[ -8.8]   -5.7[ -7.2]   -4.6[ -6.0]   -3.7[ -5.0]   -3.2[ -4.4]   -2.4[ -3.5]   -1.5[ -2.4]   -0.8[ -1.6]   -0.4[ -0.9]#   90%   (point estimate: 80%)
   NQC-like spread       -7.0[ -8.7]   -5.2[ -6.7]   -3.9[ -5.3]   -2.9[ -4.1]   -2.1[ -3.2]   -1.8[ -2.8]   -1.3[ -2.1]   -0.6[ -1.3]   -0.1[ -0.6]#   90%   (point estimate: 80%)
   WIG-like              -5.9[ -7.5]   -4.2[ -5.7]   -3.4[ -4.8]   -2.9[ -4.2]   -2.2[ -3.4]   -2.2[ -3.3]   -1.1[ -2.1]   -0.6[ -1.3]   -0.4[ -1.0]    100%   (point estimate: 80%)
   term coverage top1    -6.5[ -8.1]   -4.8[ -6.3]   -3.6[ -5.0]   -2.3[ -3.5]   -1.4[ -2.6]   -1.0[ -2.0]   -0.7[ -1.7]   -0.4[ -1.2]   -0.2[ -0.7]#   90%   (point estimate: 60%)
   ORACLE                -1.2[ -2.4]   +2.5[ +1.7]#  +4.1[ +3.3]#  +4.3[ +3.6]#  +4.3[ +3.6]#  +4.3[ +3.6]#  +4.3[ +3.6]#  +4.3[ +3.6]#  +3.8[ +3.0]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.3[ -7.0]   -3.6[ -5.0]   -2.7[ -4.0]   -2.2[ -3.4]   -1.5[ -2.5]   -0.6[ -1.6]   +0.0[ -0.6]   +0.4[ +0.0]#  +0.4[ +0.1]#   80%   (point estimate: 70%)
   BM25 margin           -6.6[ -8.2]   -5.7[ -7.2]   -4.6[ -6.0]   -3.6[ -5.0]   -2.4[ -3.6]   -1.4[ -2.4]   -0.0[ -0.6]   +0.4[ -0.0]#  +0.4[ +0.1]#   80%   (point estimate: 70%)
   top5 vs rest          -7.1[ -8.8]   -5.7[ -7.2]   -4.6[ -6.0]   -3.7[ -5.0]   -3.2[ -4.4]   -2.4[ -3.5]   -1.5[ -2.4]   -0.8[ -1.6]   -0.4[ -0.9]    100%   (point estimate: 90%)
   NQC-like spread       -7.0[ -8.7]   -5.2[ -6.7]   -3.9[ -5.3]   -2.9[ -4.1]   -2.1[ -3.2]   -1.8[ -2.8]   -1.3[ -2.1]   -0.6[ -1.3]   -0.1[ -0.6]    100%   (point estimate: 90%)
   WIG-like              -5.9[ -7.5]   -4.2[ -5.7]   -3.4[ -4.8]   -2.9[ -4.2]   -2.2[ -3.4]   -2.2[ -3.3]   -1.1[ -2.1]   -0.6[ -1.3]   -0.4[ -1.0]    100%   (point estimate: 90%)
   term coverage top1    -6.5[ -8.1]   -4.8[ -6.3]   -3.6[ -5.0]   -2.3[ -3.5]   -1.4[ -2.6]   -1.0[ -2.0]   -0.7[ -1.7]   -0.4[ -1.2]   -0.2[ -0.7]    100%   (point estimate: 80%)
   ORACLE                -1.2[ -2.4]   +2.5[ +1.7]#  +4.1[ +3.3]#  +4.3[ +3.6]#  +4.3[ +3.6]#  +4.3[ +3.6]#  +4.3[ +3.6]#  +4.3[ +3.6]#  +3.8[ +3.0]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      60% (sd  22)   -0.95 MRR              31%     40%
   tag alarm               100      57% (sd  20)   -1.14 MRR              40%     43%
   tag alarm               200      60% (sd  13)   -0.84 MRR              30%     40%
   BM25 margin              50      65% (sd  19)   -1.09 MRR              42%     35%
   BM25 margin             100      64% (sd  15)   -1.08 MRR              45%     36%
   BM25 margin             200      66% (sd   9)   -0.74 MRR              37%     34%
   top5 vs rest             50      77% (sd  21)   -1.34 MRR              35%     23%
   top5 vs rest            100      78% (sd  19)   -1.24 MRR              36%     22%
   top5 vs rest            200      83% (sd  11)   -0.87 MRR              26%     17%
   NQC-like spread          50      71% (sd  25)   -1.40 MRR              46%     29%
   NQC-like spread         100      76% (sd  19)   -1.01 MRR              33%     24%
   NQC-like spread         200      76% (sd  15)   -0.97 MRR              34%     24%
   WIG-like                 50      75% (sd  29)   -1.29 MRR              36%     25%
   WIG-like                100      77% (sd  24)   -1.13 MRR              33%     23%
   WIG-like                200      77% (sd  17)   -1.06 MRR              42%     23%
   term coverage top1       50      69% (sd  29)   -1.42 MRR              36%     31%
   term coverage top1      100      66% (sd  23)   -1.27 MRR              42%     34%
   term coverage top1      200      67% (sd  19)   -1.08 MRR              42%     33%

## prime_testfull  (1000 questions; tag alarm fires on 546 = 55%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  29.3  random  25.8  diff  +3.5  p=0.0001
   MRR  : tag  37.3  random  34.5  diff  +2.8  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +3.3 (p=0.000)        +2.4 (p=0.000)
   40%            +3.3 (p=0.000)        +2.9 (p=0.000)
   50%            +2.8 (p=0.005)        +2.6 (p=0.000)
   55% nat        +3.3 (p=0.002)        +2.9 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.4  95% CI [-2.4, +1.6]  p=0.765
   MRR  :  -2.4  95% CI [-3.7, -1.1]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +1.5  p=0.175
   MRR  :  +0.3  p=0.708

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +2.0/+1.5 (p=0.032)  40%: +2.7/+2.2 (p=0.003)  50%: +2.1/+1.5 (p=0.023)  nat: +2.3/+1.7 (p=0.006)
   vs NQC-like spread      30%: +1.2/+1.0 (p=0.165)  40%: +1.3/+1.2 (p=0.103)  50%: +1.0/+0.8 (p=0.224)  nat: +1.5/+1.1 (p=0.073)
   vs WIG-like             30%: +1.5/+1.3 (p=0.052)  40%: +2.5/+2.0 (p=0.006)  50%: +2.4/+1.8 (p=0.016)  nat: +1.9/+1.3 (p=0.067)
   vs term coverage top1   30%: +0.9/+0.8 (p=0.263)  40%: +2.4/+2.0 (p=0.006)  50%: +2.3/+2.3 (p=0.002)  nat: +2.3/+2.1 (p=0.004)

G. each selector reranking 546 questions (55%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.4  [-3.7, -1.1]  p=0.000
   BM25 margin           -5.3  [-6.7, -3.9]  p=0.000
   top5 vs rest          -4.1  [-5.6, -2.7]  p=0.000
   NQC-like spread       -3.5  [-4.9, -2.1]  p=0.000
   WIG-like              -3.7  [-5.1, -2.3]  p=0.000
   term coverage top1    -4.5  [-5.9, -3.2]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              30.1    31.5    33.4    35.3    36.6    37.0    37.7    38.5    39.3*   39.7*   90%
   BM25 margin            29.0    29.6    30.9    32.4    34.0    35.5    36.8    38.2    39.1*   39.7*   90%
   top5 vs rest           29.1    30.5    31.8    33.1    35.1    36.4    37.9    38.4    39.0    39.7*   100%
   NQC-like spread        29.1    30.4    32.4    34.1    35.8    37.1    37.8    38.5    39.2*   39.7*   90%
   WIG-like               29.6    30.7    32.1    33.4    34.8    36.3    37.9    38.6    39.6*   39.7*   90%
   term coverage top1     29.6    31.3    32.6    33.3    34.3    36.0    36.8    37.7    38.7    39.7*   100%
   ORACLE                 36.5    41.1*   43.5*   43.8*   43.8*   43.8*   43.8*   43.8*   43.5*   39.7*   20%
   random (expected)      29.4    30.5    31.7    32.8    33.9    35.1    36.2    37.4    38.5    39.7*   100%
   (BM25 only 28.2; rerank ALL 39.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -9.6[-11.5]   -8.2[-10.0]   -6.3[ -8.1]   -4.3[ -5.9]   -3.1[ -4.4]   -2.6[ -3.8]   -2.0[ -3.1]   -1.1[ -1.9]   -0.4[ -0.9]#   90%   (point estimate: 90%)
   BM25 margin          -10.7[-12.7]  -10.0[-12.0]   -8.8[-10.6]   -7.2[ -8.9]   -5.7[ -7.2]   -4.1[ -5.4]   -2.9[ -3.9]   -1.5[ -2.3]   -0.5[ -1.1]    100%   (point estimate: 90%)
   top5 vs rest         -10.5[-12.6]   -9.2[-11.1]   -7.8[ -9.6]   -6.5[ -8.3]   -4.6[ -6.1]   -3.3[ -4.6]   -1.8[ -2.9]   -1.2[ -2.2]   -0.7[ -1.4]    100%   (point estimate: 90%)
   NQC-like spread      -10.6[-12.6]   -9.3[-11.2]   -7.3[ -9.1]   -5.5[ -7.1]   -3.9[ -5.3]   -2.6[ -3.8]   -1.9[ -3.0]   -1.1[ -2.0]   -0.5[ -1.1]    100%   (point estimate: 90%)
   WIG-like             -10.0[-12.1]   -8.9[-10.8]   -7.6[ -9.3]   -6.3[ -7.9]   -4.8[ -6.4]   -3.4[ -4.7]   -1.8[ -3.0]   -1.0[ -2.0]   -0.0[ -0.6]#   90%   (point estimate: 90%)
   term coverage top1   -10.0[-12.0]   -8.4[-10.2]   -7.1[ -8.7]   -6.3[ -7.9]   -5.3[ -6.8]   -3.7[ -4.9]   -2.8[ -4.0]   -2.0[ -2.9]   -1.0[ -1.7]    100%   (point estimate: 100%)
   ORACLE                -3.2[ -4.5]   +1.5[ +0.5]#  +3.9[ +3.1]#  +4.2[ +3.4]#  +4.2[ +3.4]#  +4.2[ +3.4]#  +4.2[ +3.4]#  +4.2[ +3.4]#  +3.9[ +3.1]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -9.6[-11.5]   -8.2[-10.0]   -6.3[ -8.1]   -4.3[ -5.9]   -3.1[ -4.4]   -2.6[ -3.8]   -2.0[ -3.1]   -1.1[ -1.9]   -0.4[ -0.9]    100%   (point estimate: 90%)
   BM25 margin          -10.7[-12.7]  -10.0[-12.0]   -8.8[-10.6]   -7.2[ -8.9]   -5.7[ -7.2]   -4.1[ -5.4]   -2.9[ -3.9]   -1.5[ -2.3]   -0.5[ -1.1]    100%   (point estimate: 100%)
   top5 vs rest         -10.5[-12.6]   -9.2[-11.1]   -7.8[ -9.6]   -6.5[ -8.3]   -4.6[ -6.1]   -3.3[ -4.6]   -1.8[ -2.9]   -1.2[ -2.2]   -0.7[ -1.4]    100%   (point estimate: 100%)
   NQC-like spread      -10.6[-12.6]   -9.3[-11.2]   -7.3[ -9.1]   -5.5[ -7.1]   -3.9[ -5.3]   -2.6[ -3.8]   -1.9[ -3.0]   -1.1[ -2.0]   -0.5[ -1.1]    100%   (point estimate: 90%)
   WIG-like             -10.0[-12.1]   -8.9[-10.8]   -7.6[ -9.3]   -6.3[ -7.9]   -4.8[ -6.4]   -3.4[ -4.7]   -1.8[ -3.0]   -1.0[ -2.0]   -0.0[ -0.6]    100%   (point estimate: 90%)
   term coverage top1   -10.0[-12.0]   -8.4[-10.2]   -7.1[ -8.7]   -6.3[ -7.9]   -5.3[ -6.8]   -3.7[ -4.9]   -2.8[ -4.0]   -2.0[ -2.9]   -1.0[ -1.7]    100%   (point estimate: 100%)
   ORACLE                -3.2[ -4.5]   +1.5[ +0.5]#  +3.9[ +3.1]#  +4.2[ +3.4]#  +4.2[ +3.4]#  +4.2[ +3.4]#  +4.2[ +3.4]#  +4.2[ +3.4]#  +3.9[ +3.1]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      81% (sd  21)   -1.31 MRR              42%     19%
   tag alarm               100      82% (sd  17)   -1.15 MRR              42%     18%
   tag alarm               200      84% (sd  13)   -0.99 MRR              42%     16%
   BM25 margin              50      85% (sd  15)   -1.29 MRR              38%     15%
   BM25 margin             100      88% (sd   9)   -0.87 MRR              32%     12%
   BM25 margin             200      88% (sd   7)   -0.76 MRR              27%     12%
   top5 vs rest             50      84% (sd  18)   -1.27 MRR              38%     16%
   top5 vs rest            100      87% (sd  15)   -1.05 MRR              36%     13%
   top5 vs rest            200      86% (sd  12)   -1.00 MRR              40%     14%
   NQC-like spread          50      83% (sd  20)   -1.30 MRR              38%     17%
   NQC-like spread         100      84% (sd  16)   -1.10 MRR              39%     16%
   NQC-like spread         200      85% (sd  13)   -1.03 MRR              44%     15%
   WIG-like                 50      80% (sd  20)   -1.43 MRR              44%     20%
   WIG-like                100      82% (sd  14)   -1.05 MRR              46%     18%
   WIG-like                200      83% (sd  11)   -0.91 MRR              48%     17%
   term coverage top1       50      87% (sd  18)   -1.33 MRR              52%     13%
   term coverage top1      100      91% (sd  11)   -0.91 MRR              48%      9%
   term coverage top1      200      93% (sd   8)   -0.76 MRR              45%      7%

## dbpedia_test  (400 questions; tag alarm fires on 68 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  49.5  random  47.4  diff  +2.1  p=0.0245
   MRR  : tag  35.8  random  35.4  diff  +0.4  p=0.1334

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.2 (p=0.531)        +0.2 (p=0.747)
   40%            +0.5 (p=0.857)        -0.0 (p=0.976)
   50%            +0.2 (p=1.000)        +0.2 (p=0.662)
   17% nat        +1.5 (p=0.470)        +0.8 (p=0.244)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -20.8  95% CI [-25.5, -16.0]  p=0.000
   MRR  : -12.9  95% CI [-14.7, -11.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (52%)
   Hit@1:  -1.0  p=0.726
   MRR  :  -0.3  p=0.675

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.0/+0.5 (p=0.545)  40%: +3.0/+0.3 (p=0.717)  50%: +1.8/+0.1 (p=0.931)  nat: +2.5/+0.8 (p=0.176)
   vs NQC-like spread      30%: +3.8/+0.5 (p=0.523)  40%: +4.8/+0.8 (p=0.381)  50%: +2.2/-0.1 (p=0.894)  nat: +1.5/+0.8 (p=0.194)
   vs WIG-like             30%: +1.0/-0.3 (p=0.698)  40%: +1.2/-0.2 (p=0.816)  50%: +1.0/-0.3 (p=0.738)  nat: +1.8/+0.2 (p=0.698)
   vs term coverage top1   30%: +1.2/-0.1 (p=0.934)  40%: +1.8/-0.1 (p=0.853)  50%: +0.8/-0.1 (p=0.861)  nat: +2.2/+0.5 (p=0.343)

G. each selector reranking 68 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -12.9  [-14.7, -11.2]  p=0.000
   BM25 margin          -13.7  [-15.6, -12.0]  p=0.000
   top5 vs rest         -13.8  [-15.6, -11.9]  p=0.000
   NQC-like spread      -13.7  [-15.5, -11.9]  p=0.000
   WIG-like             -13.2  [-14.9, -11.4]  p=0.000
   term coverage top1   -13.5  [-15.2, -11.7]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              34.7    36.4    37.7    39.1    40.8    42.3    44.3    46.0    47.6    48.7*   100%
   BM25 margin            34.4    35.6    37.5    39.1    40.6    42.6    44.3    45.8    47.4    48.7*   100%
   top5 vs rest           34.1    35.4    37.2    38.8    40.7    42.4    44.2    46.1    47.9    48.7*   100%
   NQC-like spread        33.8    35.4    37.2    38.3    40.9    42.7    44.5    46.3    47.7    48.7*   100%
   WIG-like               34.4    35.8    38.0    39.3    41.1    42.4    44.2    46.1    47.3    48.7*   100%
   term coverage top1     34.2    35.9    37.7    39.2    40.9    42.6    44.5    46.1    47.1    48.7*   100%
   ORACLE                 38.0    41.6    44.5    46.6    48.2*   49.3*   49.9*   49.9*   49.9*   48.7*   50%
   random (expected)      34.3    35.9    37.5    39.1    40.7    42.3    43.9    45.5    47.1    48.7*   100%
   (BM25 only 32.7; rerank ALL 48.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -14.0[-15.8]  -12.3[-14.1]  -11.0[-12.8]   -9.6[-11.2]   -7.9[ -9.4]   -6.4[ -7.8]   -4.4[ -5.8]   -2.7[ -3.7]   -1.1[ -1.7]    100%   (point estimate: 100%)
   BM25 margin          -14.3[-16.1]  -13.1[-14.7]  -11.2[-12.9]   -9.6[-11.2]   -8.1[ -9.6]   -6.1[ -7.5]   -4.4[ -5.7]   -2.9[ -3.9]   -1.3[ -2.0]    100%   (point estimate: 100%)
   top5 vs rest         -14.6[-16.4]  -13.3[-15.0]  -11.5[-13.2]   -9.9[-11.6]   -8.0[ -9.5]   -6.3[ -7.7]   -4.5[ -5.7]   -2.6[ -3.7]   -0.8[ -1.4]    100%   (point estimate: 90%)
   NQC-like spread      -14.9[-16.7]  -13.3[-15.0]  -11.5[-13.2]  -10.4[-12.1]   -7.8[ -9.3]   -6.0[ -7.4]   -4.2[ -5.5]   -2.4[ -3.5]   -1.0[ -1.7]    100%   (point estimate: 90%)
   WIG-like             -14.3[-16.2]  -12.9[-14.6]  -10.7[-12.4]   -9.4[-11.0]   -7.6[ -9.1]   -6.3[ -7.7]   -4.6[ -5.8]   -2.6[ -3.5]   -1.4[ -2.1]    100%   (point estimate: 100%)
   term coverage top1   -14.5[-16.3]  -12.8[-14.5]  -11.0[-12.5]   -9.5[-11.1]   -7.8[ -9.3]   -6.1[ -7.5]   -4.3[ -5.4]   -2.6[ -3.6]   -1.6[ -2.3]    100%   (point estimate: 100%)
   ORACLE               -10.7[-12.1]   -7.1[ -8.3]   -4.2[ -5.2]   -2.1[ -2.8]   -0.5[ -1.0]   +0.6[ +0.1]#  +1.1[ +0.7]#  +1.2[ +0.7]#  +1.2[ +0.7]#   60%   (point estimate: 50%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -14.0[-15.8]  -12.3[-14.1]  -11.0[-12.8]   -9.6[-11.2]   -7.9[ -9.4]   -6.4[ -7.8]   -4.4[ -5.8]   -2.7[ -3.7]   -1.1[ -1.7]    100%   (point estimate: 100%)
   BM25 margin          -14.3[-16.1]  -13.1[-14.7]  -11.2[-12.9]   -9.6[-11.2]   -8.1[ -9.6]   -6.1[ -7.5]   -4.4[ -5.7]   -2.9[ -3.9]   -1.3[ -2.0]    100%   (point estimate: 100%)
   top5 vs rest         -14.6[-16.4]  -13.3[-15.0]  -11.5[-13.2]   -9.9[-11.6]   -8.0[ -9.5]   -6.3[ -7.7]   -4.5[ -5.7]   -2.6[ -3.7]   -0.8[ -1.4]    100%   (point estimate: 100%)
   NQC-like spread      -14.9[-16.7]  -13.3[-15.0]  -11.5[-13.2]  -10.4[-12.1]   -7.8[ -9.3]   -6.0[ -7.4]   -4.2[ -5.5]   -2.4[ -3.5]   -1.0[ -1.7]    100%   (point estimate: 100%)
   WIG-like             -14.3[-16.2]  -12.9[-14.6]  -10.7[-12.4]   -9.4[-11.0]   -7.6[ -9.1]   -6.3[ -7.7]   -4.6[ -5.8]   -2.6[ -3.5]   -1.4[ -2.1]    100%   (point estimate: 100%)
   term coverage top1   -14.5[-16.3]  -12.8[-14.5]  -11.0[-12.5]   -9.5[-11.1]   -7.8[ -9.3]   -6.1[ -7.5]   -4.3[ -5.4]   -2.6[ -3.6]   -1.6[ -2.3]    100%   (point estimate: 100%)
   ORACLE               -10.7[-12.1]   -7.1[ -8.3]   -4.2[ -5.2]   -2.1[ -2.8]   -0.5[ -1.0]   +0.6[ +0.1]#  +1.1[ +0.7]#  +1.2[ +0.7]#  +1.2[ +0.7]#   60%   (point estimate: 50%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      96% (sd   6)   -0.55 MRR              36%      4%
   tag alarm               100      97% (sd   5)   -0.44 MRR              34%      3%
   tag alarm               200      98% (sd   4)   -0.34 MRR              24%      2%
   BM25 margin              50      96% (sd   5)   -0.50 MRR              34%      4%
   BM25 margin             100      97% (sd   5)   -0.41 MRR              28%      3%
   BM25 margin             200      98% (sd   4)   -0.27 MRR              17%      2%
   top5 vs rest             50      94% (sd   7)   -0.70 MRR              14%      6%
   top5 vs rest            100      94% (sd   5)   -0.58 MRR              18%      6%
   top5 vs rest            200      93% (sd   5)   -0.68 MRR              36%      7%
   NQC-like spread          50      94% (sd   7)   -0.71 MRR              41%      6%
   NQC-like spread         100      95% (sd   6)   -0.58 MRR              36%      5%
   NQC-like spread         200      95% (sd   5)   -0.66 MRR              46%      5%
   WIG-like                 50      97% (sd   5)   -0.47 MRR              30%      3%
   WIG-like                100      98% (sd   4)   -0.31 MRR              20%      2%
   WIG-like                200      99% (sd   3)   -0.13 MRR               7%      1%
   term coverage top1       50      97% (sd   5)   -0.46 MRR              26%      3%
   term coverage top1      100      98% (sd   4)   -0.28 MRR              16%      2%
   term coverage top1      200      99% (sd   2)   -0.10 MRR               6%      1%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  15%  MRR  33.1 | vs BM25 margin: +2.8 (p=0.025)  vs top5 vs rest: -1.3 (p=0.380)  vs NQC-like spread: -1.0 (p=0.512)  vs WIG-like: -0.8 (p=0.547)  vs term coverage top1: -0.3 (p=0.834)
   list           n= 105  fires  16%  MRR  32.9 | vs BM25 margin: -2.1 (p=0.173)  vs top5 vs rest: +1.4 (p=0.182)  vs NQC-like spread: +1.5 (p=0.188)  vs WIG-like: +0.6 (p=0.595)  vs term coverage top1: +1.8 (p=0.113)
   question       n= 125  fires  22%  MRR  24.4 | vs BM25 margin: +2.5 (p=0.057)  vs top5 vs rest: +2.1 (p=0.054)  vs NQC-like spread: +1.4 (p=0.145)  vs WIG-like: -0.8 (p=0.525)  vs term coverage top1: -0.8 (p=0.423)
   named entity   n=  86  fires  12%  MRR  58.4 | vs BM25 margin: -0.0 (p=0.988)  vs top5 vs rest: +0.4 (p=0.795)  vs NQC-like spread: +0.7 (p=0.644)  vs WIG-like: +2.2 (p=0.071)  vs term coverage top1: +1.8 (p=0.030)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR +0.4  [-1.3, +2.1]  p=0.610  (n=211)

## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.0  random  56.3  diff  +0.7  p=0.2515
   MRR  : tag  68.0  random  68.0  diff  -0.0  p=0.4952

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.3 (p=1.000)        -0.0 (p=0.957)
   40%            -1.0 (p=0.379)        -1.1 (p=0.025)
   50%            -0.3 (p=1.000)        -0.6 (p=0.268)
   15% nat        -1.3 (p=0.502)        -1.5 (p=0.087)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -10.0  95% CI [-14.3, -6.0]  p=0.000
   MRR  :  -8.7  95% CI [-11.4, -6.1]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (29%)
   Hit@1:  +3.3  p=0.076
   MRR  :  +2.2  p=0.069

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +4.3/+2.3 (p=0.052)  40%: +4.0/+2.5 (p=0.048)  50%: +3.7/+2.6 (p=0.045)  nat: +1.3/+0.4 (p=0.655)
   vs NQC-like spread      30%: +1.0/-0.6 (p=0.608)  40%: +0.7/-0.7 (p=0.525)  50%: +0.7/+0.4 (p=0.719)  nat: -1.0/-1.7 (p=0.054)
   vs WIG-like             30%: +1.0/-0.7 (p=0.557)  40%: +0.3/-0.8 (p=0.507)  50%: +1.3/+0.5 (p=0.677)  nat: +0.3/-0.9 (p=0.338)
   vs term coverage top1   30%: +0.3/-0.9 (p=0.441)  40%: -0.3/-0.8 (p=0.505)  50%: +0.7/+0.4 (p=0.682)  nat: -0.7/-1.6 (p=0.090)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -8.7  [-11.4, -6.1]  p=0.000
   BM25 margin           -7.1  [-9.7, -4.7]  p=0.000
   top5 vs rest          -9.0  [-11.8, -6.3]  p=0.000
   NQC-like spread       -7.0  [-9.5, -4.6]  p=0.000
   WIG-like              -7.8  [-10.5, -5.2]  p=0.000
   term coverage top1    -7.0  [-9.6, -4.6]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              68.0    69.0    71.1    72.1    74.0    75.1    75.9    76.4*   76.6*   76.7*   80%
   BM25 margin            68.3    70.1    71.1    73.2    74.7    75.6    76.3    76.4*   76.6*   76.7*   80%
   top5 vs rest           67.2    67.8    68.8    69.6    71.4    72.2    72.9    74.7    75.9*   76.7*   90%
   NQC-like spread        68.6    70.7    71.7    72.8    73.6    74.6    75.8*   76.1*   76.4*   76.7*   70%
   WIG-like               68.2    70.1    71.8    72.9    73.5    74.0    74.5    75.1    76.4*   76.7*   90%
   term coverage top1     68.6    70.5    72.0    72.8    73.6    74.8    75.3    75.5    75.9*   76.7*   90%
   ORACLE                 73.5    77.1*   78.5*   78.5*   78.5*   78.5*   78.5*   78.5*   78.5*   76.7*   20%
   random (expected)      67.5    68.5    69.5    70.5    71.6    72.6    73.6    74.6    75.7    76.7*   100%
   (BM25 only 66.4; rerank ALL 76.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.7[-11.4]   -7.7[-10.3]   -5.6[ -8.1]   -4.6[ -6.8]   -2.7[ -4.2]   -1.6[ -2.7]   -0.8[ -1.4]   -0.3[ -0.6]#  -0.1[ -0.2]#   80%   (point estimate: 70%)
   BM25 margin           -8.4[-11.1]   -6.6[ -9.1]   -5.6[ -7.9]   -3.5[ -5.4]   -2.0[ -3.2]   -1.1[ -1.8]   -0.4[ -0.9]#  -0.3[ -0.6]#  -0.1[ -0.2]#   70%   (point estimate: 70%)
   top5 vs rest          -9.5[-12.2]   -8.9[-11.7]   -7.9[-10.7]   -7.1[ -9.8]   -5.3[ -7.6]   -4.5[ -6.7]   -3.7[ -5.7]   -2.0[ -3.5]   -0.8[ -2.0]    100%   (point estimate: 90%)
   NQC-like spread       -8.1[-10.8]   -6.0[ -8.3]   -5.0[ -7.2]   -3.9[ -5.9]   -3.1[ -4.7]   -2.1[ -3.6]   -0.9[ -2.0]   -0.6[ -1.6]   -0.3[ -0.7]#   90%   (point estimate: 70%)
   WIG-like              -8.5[-11.2]   -6.6[ -9.1]   -4.9[ -7.2]   -3.8[ -5.7]   -3.1[ -4.9]   -2.7[ -4.4]   -2.2[ -3.8]   -1.6[ -3.0]   -0.3[ -1.3]    100%   (point estimate: 90%)
   term coverage top1    -8.1[-10.7]   -6.2[ -8.7]   -4.7[ -6.7]   -3.8[ -5.6]   -3.1[ -4.7]   -1.9[ -3.2]   -1.3[ -2.5]   -1.1[ -2.2]   -0.8[ -1.7]    100%   (point estimate: 90%)
   ORACLE                -3.2[ -4.9]   +0.4[ -0.6]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.7[-11.4]   -7.7[-10.3]   -5.6[ -8.1]   -4.6[ -6.8]   -2.7[ -4.2]   -1.6[ -2.7]   -0.8[ -1.4]   -0.3[ -0.6]   -0.1[ -0.2]#   90%   (point estimate: 80%)
   BM25 margin           -8.4[-11.1]   -6.6[ -9.1]   -5.6[ -7.9]   -3.5[ -5.4]   -2.0[ -3.2]   -1.1[ -1.8]   -0.4[ -0.9]   -0.3[ -0.6]   -0.1[ -0.2]#   90%   (point estimate: 70%)
   top5 vs rest          -9.5[-12.2]   -8.9[-11.7]   -7.9[-10.7]   -7.1[ -9.8]   -5.3[ -7.6]   -4.5[ -6.7]   -3.7[ -5.7]   -2.0[ -3.5]   -0.8[ -2.0]    100%   (point estimate: 100%)
   NQC-like spread       -8.1[-10.8]   -6.0[ -8.3]   -5.0[ -7.2]   -3.9[ -5.9]   -3.1[ -4.7]   -2.1[ -3.6]   -0.9[ -2.0]   -0.6[ -1.6]   -0.3[ -0.7]    100%   (point estimate: 90%)
   WIG-like              -8.5[-11.2]   -6.6[ -9.1]   -4.9[ -7.2]   -3.8[ -5.7]   -3.1[ -4.9]   -2.7[ -4.4]   -2.2[ -3.8]   -1.6[ -3.0]   -0.3[ -1.3]    100%   (point estimate: 90%)
   term coverage top1    -8.1[-10.7]   -6.2[ -8.7]   -4.7[ -6.7]   -3.8[ -5.6]   -3.1[ -4.7]   -1.9[ -3.2]   -1.3[ -2.5]   -1.1[ -2.2]   -0.8[ -1.7]    100%   (point estimate: 100%)
   ORACLE                -3.2[ -4.9]   +0.4[ -0.6]   +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#  +1.8[ +1.0]#   30%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      67% (sd  13)   -1.32 MRR              40%     33%
   tag alarm               100      71% (sd   7)   -0.82 MRR              24%     29%
   tag alarm               200      70% (sd   5)   -0.84 MRR              28%     30%
   BM25 margin              50      64% (sd  12)   -1.14 MRR              46%     36%
   BM25 margin             100      65% (sd   8)   -0.88 MRR              42%     35%
   BM25 margin             200      66% (sd   5)   -0.79 MRR              36%     34%
   top5 vs rest             50      89% (sd  13)   -1.21 MRR              32%     11%
   top5 vs rest            100      93% (sd   7)   -0.87 MRR              34%      7%
   top5 vs rest            200      93% (sd   5)   -0.83 MRR              38%      7%
   NQC-like spread          50      74% (sd  19)   -1.37 MRR              42%     26%
   NQC-like spread         100      76% (sd  12)   -1.02 MRR              38%     24%
   NQC-like spread         200      75% (sd   8)   -1.02 MRR              45%     25%
   WIG-like                 50      83% (sd  19)   -1.26 MRR              41%     17%
   WIG-like                100      87% (sd  13)   -0.95 MRR              26%     13%
   WIG-like                200      88% (sd   7)   -0.91 MRR              30%     12%
   term coverage top1       50      81% (sd  18)   -1.18 MRR              46%     19%
   term coverage top1      100      84% (sd  14)   -1.05 MRR              44%     16%
   term coverage top1      200      87% (sd   9)   -0.90 MRR              32%     13%

## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  43.7  random  44.1  diff  -0.5  p=0.9668
   MRR  : tag  31.0  random  31.0  diff  -0.0  p=0.6214

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.1 (p=0.373)
   40%            -0.6 (p=0.504)        -0.5 (p=0.091)
   50%            +0.3 (p=1.000)        +0.1 (p=0.495)
   2% nat         -0.3 (p=1.000)        +0.1 (p=0.500)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.7  95% CI [-12.4, -3.1]  p=0.002
   MRR  :  -5.4  95% CI [-7.0, -3.9]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +0.9  p=0.686
   MRR  :  +0.2  p=0.756

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.9/-0.0 (p=0.977)  40%: +1.2/-0.7 (p=0.324)  50%: +2.5/-0.5 (p=0.467)  nat: -0.3/+0.1 (p=0.500)
   vs NQC-like spread      30%: +2.5/-0.5 (p=0.337)  40%: +0.9/-1.2 (p=0.065)  50%: +2.5/-0.8 (p=0.172)  nat: -0.3/+0.1 (p=0.500)
   vs WIG-like             30%: +0.6/+0.1 (p=0.819)  40%: -0.3/-0.1 (p=0.865)  50%: +0.6/-0.3 (p=0.662)  nat: -0.3/+0.1 (p=0.500)
   vs term coverage top1   30%: +0.9/-0.5 (p=0.322)  40%: -0.3/-1.1 (p=0.057)  50%: -0.9/-1.1 (p=0.040)  nat: -0.3/+0.1 (p=0.500)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -5.4  [-7.0, -3.9]  p=0.000
   BM25 margin           -5.5  [-7.1, -4.0]  p=0.000
   top5 vs rest          -5.5  [-7.1, -4.0]  p=0.000
   NQC-like spread       -5.5  [-7.1, -4.0]  p=0.000
   WIG-like              -5.5  [-7.1, -4.0]  p=0.000
   term coverage top1    -5.5  [-7.1, -4.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              31.1    31.7    32.4    32.8    33.7    34.1    34.5    35.4    35.9    36.4*   100%
   BM25 margin            30.9    31.6    32.3    33.3    33.6    34.3    34.5    35.3    35.9    36.4*   100%
   top5 vs rest           31.0    31.7    32.4    33.5    34.2    34.7    35.4    36.0*   36.5*   36.4*   80%
   NQC-like spread        30.9    32.1    32.9    34.0    34.6    35.3    36.1*   36.3*   36.3*   36.4*   70%
   WIG-like               30.9    31.3    32.3    32.9    34.0    34.8    35.5    35.7    36.3*   36.4*   90%
   term coverage top1     31.2    31.9    32.9    33.9    34.9    35.2    35.7    35.6    36.0    36.4*   100%
   ORACLE                 34.7    36.7*   37.7*   38.0*   38.0*   38.0*   38.0*   38.0*   37.8*   36.4*   20%
   random (expected)      31.5    32.0    32.6    33.1    33.7    34.2    34.8    35.3    35.9    36.4*   100%
   (BM25 only 30.9; rerank ALL 36.4)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.4[ -6.9]   -4.7[ -6.2]   -4.0[ -5.4]   -3.7[ -5.0]   -2.7[ -3.9]   -2.3[ -3.5]   -1.9[ -2.9]   -1.1[ -1.9]   -0.5[ -1.1]    100%   (point estimate: 90%)
   BM25 margin           -5.5[ -7.1]   -4.8[ -6.3]   -4.1[ -5.5]   -3.2[ -4.5]   -2.8[ -4.0]   -2.1[ -3.2]   -2.0[ -3.0]   -1.1[ -2.0]   -0.5[ -1.1]    100%   (point estimate: 90%)
   top5 vs rest          -5.5[ -7.0]   -4.8[ -6.2]   -4.0[ -5.4]   -3.0[ -4.1]   -2.3[ -3.3]   -1.8[ -2.6]   -1.0[ -1.8]   -0.4[ -0.9]#  +0.0[ -0.3]#   80%   (point estimate: 80%)
   NQC-like spread       -5.6[ -7.1]   -4.3[ -5.7]   -3.5[ -4.8]   -2.5[ -3.5]   -1.9[ -2.8]   -1.1[ -1.8]   -0.4[ -0.9]#  -0.2[ -0.5]#  -0.1[ -0.2]#   70%   (point estimate: 70%)
   WIG-like              -5.5[ -7.1]   -5.1[ -6.6]   -4.1[ -5.6]   -3.6[ -4.9]   -2.4[ -3.5]   -1.6[ -2.6]   -0.9[ -1.7]   -0.8[ -1.3]   -0.2[ -0.5]#   90%   (point estimate: 70%)
   term coverage top1    -5.2[ -6.8]   -4.6[ -6.0]   -3.5[ -4.8]   -2.5[ -3.7]   -1.6[ -2.5]   -1.3[ -2.2]   -0.8[ -1.4]   -0.8[ -1.4]   -0.4[ -0.9]#   90%   (point estimate: 70%)
   ORACLE                -1.7[ -2.7]   +0.2[ -0.4]#  +1.2[ +0.7]#  +1.5[ +1.0]#  +1.5[ +1.0]#  +1.5[ +1.0]#  +1.5[ +1.0]#  +1.5[ +1.0]#  +1.4[ +0.9]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.4[ -6.9]   -4.7[ -6.2]   -4.0[ -5.4]   -3.7[ -5.0]   -2.7[ -3.9]   -2.3[ -3.5]   -1.9[ -2.9]   -1.1[ -1.9]   -0.5[ -1.1]    100%   (point estimate: 100%)
   BM25 margin           -5.5[ -7.1]   -4.8[ -6.3]   -4.1[ -5.5]   -3.2[ -4.5]   -2.8[ -4.0]   -2.1[ -3.2]   -2.0[ -3.0]   -1.1[ -2.0]   -0.5[ -1.1]    100%   (point estimate: 100%)
   top5 vs rest          -5.5[ -7.0]   -4.8[ -6.2]   -4.0[ -5.4]   -3.0[ -4.1]   -2.3[ -3.3]   -1.8[ -2.6]   -1.0[ -1.8]   -0.4[ -0.9]   +0.0[ -0.3]#   90%   (point estimate: 80%)
   NQC-like spread       -5.6[ -7.1]   -4.3[ -5.7]   -3.5[ -4.8]   -2.5[ -3.5]   -1.9[ -2.8]   -1.1[ -1.8]   -0.4[ -0.9]   -0.2[ -0.5]#  -0.1[ -0.2]#   80%   (point estimate: 70%)
   WIG-like              -5.5[ -7.1]   -5.1[ -6.6]   -4.1[ -5.6]   -3.6[ -4.9]   -2.4[ -3.5]   -1.6[ -2.6]   -0.9[ -1.7]   -0.8[ -1.3]   -0.2[ -0.5]#   90%   (point estimate: 90%)
   term coverage top1    -5.2[ -6.8]   -4.6[ -6.0]   -3.5[ -4.8]   -2.5[ -3.7]   -1.6[ -2.5]   -1.3[ -2.2]   -0.8[ -1.4]   -0.8[ -1.4]   -0.4[ -0.9]    100%   (point estimate: 90%)
   ORACLE                -1.7[ -2.7]   +0.2[ -0.4]#  +1.2[ +0.7]#  +1.5[ +1.0]#  +1.5[ +1.0]#  +1.5[ +1.0]#  +1.5[ +1.0]#  +1.5[ +1.0]#  +1.4[ +0.9]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      85% (sd  15)   -0.93 MRR              37%     15%
   tag alarm               100      86% (sd  12)   -0.95 MRR              38%     14%
   tag alarm               200      88% (sd   5)   -0.72 MRR              26%     12%
   BM25 margin              50      84% (sd  15)   -1.01 MRR              43%     16%
   BM25 margin             100      87% (sd  10)   -0.85 MRR              34%     13%
   BM25 margin             200      88% (sd   5)   -0.81 MRR              30%     12%
   top5 vs rest             50      70% (sd  14)   -1.19 MRR              57%     30%
   top5 vs rest            100      74% (sd   9)   -0.88 MRR              46%     26%
   top5 vs rest            200      75% (sd   6)   -0.79 MRR              42%     25%
   NQC-like spread          50      63% (sd  14)   -1.07 MRR              46%     37%
   NQC-like spread         100      65% (sd   9)   -0.89 MRR              44%     35%
   NQC-like spread         200      67% (sd   5)   -0.67 MRR              32%     33%
   WIG-like                 50      75% (sd  16)   -1.04 MRR              35%     25%
   WIG-like                100      76% (sd  11)   -0.89 MRR              33%     24%
   WIG-like                200      75% (sd   7)   -0.89 MRR              43%     25%
   term coverage top1       50      68% (sd  21)   -1.18 MRR              46%     32%
   term coverage top1      100      70% (sd  15)   -0.98 MRR              42%     30%
   term coverage top1      200      70% (sd  12)   -1.04 MRR              48%     30%

## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.8  random  19.7  diff  +0.1  p=0.4774
   MRR  : tag  16.1  random  16.2  diff  -0.0  p=0.6294

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.7 (p=0.285)        -0.3 (p=0.122)
   40%            +0.1 (p=1.000)        -0.0 (p=0.941)
   50%            -0.3 (p=0.651)        -0.0 (p=0.862)
   12% nat        -0.1 (p=1.000)        +0.2 (p=0.407)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.5  95% CI [-9.9, -5.1]  p=0.000
   MRR  :  -6.6  95% CI [-7.5, -5.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +0.7  p=0.475
   MRR  :  -0.1  p=0.837

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.4/+0.3 (p=0.340)  40%: +1.9/+0.6 (p=0.099)  50%: +1.9/+0.1 (p=0.808)  nat: +0.5/+0.1 (p=0.503)
   vs NQC-like spread      30%: +0.8/+0.2 (p=0.615)  40%: +1.1/+0.5 (p=0.136)  50%: +1.4/+0.4 (p=0.255)  nat: +0.6/+0.2 (p=0.310)
   vs WIG-like             30%: +1.0/+0.1 (p=0.879)  40%: +0.7/-0.1 (p=0.756)  50%: +0.7/-0.1 (p=0.789)  nat: +0.2/+0.0 (p=1.000)
   vs term coverage top1   30%: -0.6/-0.7 (p=0.050)  40%: -0.5/-0.5 (p=0.140)  50%: -0.9/-0.7 (p=0.042)  nat: -0.4/-0.3 (p=0.182)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -6.6  [-7.5, -5.8]  p=0.000
   BM25 margin           -6.8  [-7.7, -6.0]  p=0.000
   top5 vs rest          -6.8  [-7.7, -5.9]  p=0.000
   NQC-like spread       -6.8  [-7.8, -6.0]  p=0.000
   WIG-like              -6.6  [-7.5, -5.8]  p=0.000
   term coverage top1    -6.3  [-7.1, -5.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              16.1    16.5    17.4    18.3    19.0    19.8    20.4    21.0    21.9    22.7*   100%
   BM25 margin            15.8    16.8    17.8    18.3    19.0    19.8    20.5    21.2    22.1    22.7*   100%
   top5 vs rest           15.7    16.7    17.1    17.7    18.9    19.6    20.3    21.1    21.9    22.7*   100%
   NQC-like spread        15.8    16.4    17.3    17.8    18.6    19.4    20.0    21.1    22.1    22.7*   100%
   WIG-like               16.0    16.6    17.4    18.4    19.1    19.9    20.6    21.2    22.0    22.7*   100%
   term coverage top1     16.3    17.3    18.1    18.9    19.7    20.2    20.9    21.8    22.2    22.7*   100%
   ORACLE                 19.2    21.3    22.8*   23.8*   24.0*   24.0*   24.0*   24.0*   23.9*   22.7*   30%
   random (expected)      16.0    16.8    17.5    18.3    19.0    19.7    20.5    21.2    22.0    22.7*   100%
   (BM25 only 15.3; rerank ALL 22.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -6.6[ -7.5]   -6.2[ -7.1]   -5.3[ -6.1]   -4.4[ -5.1]   -3.8[ -4.4]   -3.0[ -3.6]   -2.3[ -2.8]   -1.7[ -2.2]   -0.8[ -1.1]    100%   (point estimate: 90%)
   BM25 margin           -7.0[ -7.9]   -5.9[ -6.8]   -5.0[ -5.8]   -4.4[ -5.1]   -3.7[ -4.4]   -3.0[ -3.6]   -2.2[ -2.8]   -1.6[ -2.0]   -0.6[ -0.9]#   90%   (point estimate: 90%)
   top5 vs rest          -7.0[ -7.9]   -6.0[ -6.8]   -5.6[ -6.4]   -5.0[ -5.8]   -3.8[ -4.5]   -3.1[ -3.7]   -2.5[ -3.0]   -1.6[ -2.0]   -0.9[ -1.2]    100%   (point estimate: 90%)
   NQC-like spread       -6.9[ -7.8]   -6.3[ -7.2]   -5.5[ -6.2]   -4.9[ -5.7]   -4.2[ -4.9]   -3.4[ -4.0]   -2.7[ -3.3]   -1.7[ -2.1]   -0.7[ -1.0]#   90%   (point estimate: 90%)
   WIG-like              -6.8[ -7.7]   -6.1[ -7.0]   -5.3[ -6.2]   -4.3[ -5.0]   -3.7[ -4.3]   -2.8[ -3.4]   -2.2[ -2.7]   -1.5[ -2.0]   -0.8[ -1.1]    100%   (point estimate: 90%)
   term coverage top1    -6.4[ -7.3]   -5.5[ -6.3]   -4.6[ -5.4]   -3.9[ -4.6]   -3.0[ -3.7]   -2.5[ -3.1]   -1.9[ -2.3]   -1.0[ -1.3]   -0.5[ -0.8]#   90%   (point estimate: 80%)
   ORACLE                -3.5[ -4.1]   -1.4[ -1.8]   +0.1[ -0.3]#  +1.0[ +0.8]#  +1.2[ +1.0]#  +1.2[ +1.0]#  +1.2[ +1.0]#  +1.2[ +1.0]#  +1.2[ +1.0]#   30%   (point estimate: 30%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -6.6[ -7.5]   -6.2[ -7.1]   -5.3[ -6.1]   -4.4[ -5.1]   -3.8[ -4.4]   -3.0[ -3.6]   -2.3[ -2.8]   -1.7[ -2.2]   -0.8[ -1.1]    100%   (point estimate: 100%)
   BM25 margin           -7.0[ -7.9]   -5.9[ -6.8]   -5.0[ -5.8]   -4.4[ -5.1]   -3.7[ -4.4]   -3.0[ -3.6]   -2.2[ -2.8]   -1.6[ -2.0]   -0.6[ -0.9]    100%   (point estimate: 100%)
   top5 vs rest          -7.0[ -7.9]   -6.0[ -6.8]   -5.6[ -6.4]   -5.0[ -5.8]   -3.8[ -4.5]   -3.1[ -3.7]   -2.5[ -3.0]   -1.6[ -2.0]   -0.9[ -1.2]    100%   (point estimate: 100%)
   NQC-like spread       -6.9[ -7.8]   -6.3[ -7.2]   -5.5[ -6.2]   -4.9[ -5.7]   -4.2[ -4.9]   -3.4[ -4.0]   -2.7[ -3.3]   -1.7[ -2.1]   -0.7[ -1.0]    100%   (point estimate: 100%)
   WIG-like              -6.8[ -7.7]   -6.1[ -7.0]   -5.3[ -6.2]   -4.3[ -5.0]   -3.7[ -4.3]   -2.8[ -3.4]   -2.2[ -2.7]   -1.5[ -2.0]   -0.8[ -1.1]    100%   (point estimate: 100%)
   term coverage top1    -6.4[ -7.3]   -5.5[ -6.3]   -4.6[ -5.4]   -3.9[ -4.6]   -3.0[ -3.7]   -2.5[ -3.1]   -1.9[ -2.3]   -1.0[ -1.3]   -0.5[ -0.8]    100%   (point estimate: 100%)
   ORACLE                -3.5[ -4.1]   -1.4[ -1.8]   +0.1[ -0.3]#  +1.0[ +0.8]#  +1.2[ +1.0]#  +1.2[ +1.0]#  +1.2[ +1.0]#  +1.2[ +1.0]#  +1.2[ +1.0]#   30%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      91% (sd   9)   -0.74 MRR              16%      9%
   tag alarm               100      91% (sd   7)   -0.72 MRR              15%      9%
   tag alarm               200      92% (sd   5)   -0.69 MRR               5%      8%
   BM25 margin              50      88% (sd  11)   -0.88 MRR              30%     12%
   BM25 margin             100      89% (sd   8)   -0.80 MRR              20%     11%
   BM25 margin             200      90% (sd   4)   -0.66 MRR               7%     10%
   top5 vs rest             50      90% (sd  12)   -0.87 MRR              23%     10%
   top5 vs rest            100      92% (sd   8)   -0.72 MRR              16%      8%
   top5 vs rest            200      93% (sd   6)   -0.63 MRR               8%      7%
   NQC-like spread          50      90% (sd   9)   -0.76 MRR              22%     10%
   NQC-like spread         100      92% (sd   6)   -0.58 MRR              10%      8%
   NQC-like spread         200      92% (sd   5)   -0.61 MRR               6%      8%
   WIG-like                 50      88% (sd  13)   -0.88 MRR              27%     12%
   WIG-like                100      90% (sd   8)   -0.76 MRR              19%     10%
   WIG-like                200      91% (sd   5)   -0.74 MRR              10%      9%
   term coverage top1       50      85% (sd  10)   -0.78 MRR              18%     15%
   term coverage top1      100      85% (sd   9)   -0.78 MRR              23%     15%
   term coverage top1      200      86% (sd   6)   -0.71 MRR              29%     14%

## amazon_testfull  (500 questions; tag alarm fires on 219 = 44%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.6  random  56.1  diff  +1.5  p=0.1229
   MRR  : tag  53.3  random  52.4  diff  +0.9  p=0.0808

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.0 (p=0.502)        +0.5 (p=0.432)
   40%            +0.2 (p=1.000)        -0.4 (p=0.672)
   50%            -1.0 (p=0.620)        -1.5 (p=0.086)
   44% nat        -0.4 (p=0.906)        -1.0 (p=0.273)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -3.6  95% CI [-6.8, -0.4]  p=0.036
   MRR  :  -3.8  95% CI [-5.4, -2.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (46%)
   Hit@1:  +2.2  p=0.218
   MRR  :  -0.2  p=0.839

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.6/-0.9 (p=0.294)  40%: -1.2/-1.8 (p=0.045)  50%: -0.4/-1.5 (p=0.115)  nat: -1.4/-1.7 (p=0.061)
   vs NQC-like spread      30%: -1.0/-1.0 (p=0.225)  40%: -0.8/-1.5 (p=0.091)  50%: -1.2/-1.9 (p=0.047)  nat: -1.2/-1.8 (p=0.050)
   vs WIG-like             30%: -1.0/+0.5 (p=0.613)  40%: -1.2/-0.2 (p=0.837)  50%: -1.4/-0.1 (p=0.920)  nat: -2.0/-0.4 (p=0.665)
   vs term coverage top1   30%: +3.0/+2.2 (p=0.012)  40%: +3.2/+2.2 (p=0.016)  50%: +1.8/+1.5 (p=0.115)  nat: +2.0/+1.5 (p=0.099)

G. each selector reranking 219 questions (44%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -3.8  [-5.4, -2.2]  p=0.000
   BM25 margin           -2.8  [-4.6, -1.1]  p=0.001
   top5 vs rest          -2.1  [-3.8, -0.4]  p=0.015
   NQC-like spread       -2.0  [-3.7, -0.3]  p=0.020
   WIG-like              -3.4  [-5.4, -1.4]  p=0.001
   term coverage top1    -5.3  [-7.3, -3.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              49.9    51.6    53.2    53.3    53.9    54.2    55.5    55.9    57.4*   57.1*   90%
   BM25 margin            50.3    51.3    52.7    53.7    55.3    56.3*   55.8    57.0*   57.5*   57.1*   80%
   top5 vs rest           50.6    52.2    54.1    55.1    55.3    56.0*   56.7*   57.4*   57.3*   57.1*   60%
   NQC-like spread        50.2    52.5    54.3    54.8    55.7*   56.1*   56.7*   57.5*   57.6*   57.1*   50%
   WIG-like               50.5    51.6    52.8    53.5    54.0    55.6*   56.3*   56.3*   56.4*   57.1*   60%
   term coverage top1     49.7    50.0    51.1    51.1    52.4    54.0    54.6    55.5    56.8*   57.1*   90%
   ORACLE                 55.5*   58.9*   60.9*   61.8*   62.0*   62.0*   62.0*   62.0*   61.1*   57.1*   10%
   random (expected)      49.6    50.4    51.3    52.1    52.9    53.8    54.6    55.4    56.3    57.1*   100%
   (BM25 only 48.8; rerank ALL 57.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.3[ -9.4]   -5.5[ -7.5]   -3.9[ -5.7]   -3.8[ -5.4]   -3.2[ -4.8]   -2.9[ -4.2]   -1.6[ -2.6]   -1.2[ -2.1]   +0.3[ -0.1]#   90%   (point estimate: 90%)
   BM25 margin           -6.8[ -9.0]   -5.8[ -8.0]   -4.4[ -6.3]   -3.4[ -5.2]   -1.8[ -3.4]   -0.8[ -2.3]   -1.3[ -2.5]   -0.1[ -0.8]#  +0.4[ +0.0]#   80%   (point estimate: 80%)
   top5 vs rest          -6.5[ -8.7]   -4.9[ -7.0]   -3.0[ -4.8]   -2.0[ -3.7]   -1.8[ -3.3]   -1.1[ -2.5]   -0.4[ -1.7]   +0.3[ -0.7]#  +0.2[ -0.4]#   80%   (point estimate: 70%)
   NQC-like spread       -7.0[ -9.3]   -4.6[ -6.7]   -2.8[ -4.6]   -2.3[ -4.0]   -1.4[ -3.0]   -1.0[ -2.4]   -0.4[ -1.8]   +0.4[ -0.7]#  +0.5[ -0.2]#   80%   (point estimate: 60%)
   WIG-like              -6.6[ -8.9]   -5.5[ -7.6]   -4.3[ -6.3]   -3.6[ -5.5]   -3.2[ -5.0]   -1.5[ -3.2]   -0.8[ -2.4]   -0.8[ -2.0]   -0.7[ -1.6]    100%   (point estimate: 70%)
   term coverage top1    -7.4[ -9.7]   -7.1[ -9.2]   -6.0[ -8.1]   -6.0[ -8.0]   -4.7[ -6.6]   -3.1[ -4.8]   -2.6[ -4.0]   -1.6[ -2.9]   -0.3[ -1.3]    100%   (point estimate: 90%)
   ORACLE                -1.6[ -3.2]   +1.8[ +0.5]#  +3.8[ +2.7]#  +4.7[ +3.6]#  +4.9[ +3.8]#  +4.9[ +3.8]#  +4.9[ +3.8]#  +4.9[ +3.8]#  +4.0[ +2.9]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.3[ -9.4]   -5.5[ -7.5]   -3.9[ -5.7]   -3.8[ -5.4]   -3.2[ -4.8]   -2.9[ -4.2]   -1.6[ -2.6]   -1.2[ -2.1]   +0.3[ -0.1]#   90%   (point estimate: 90%)
   BM25 margin           -6.8[ -9.0]   -5.8[ -8.0]   -4.4[ -6.3]   -3.4[ -5.2]   -1.8[ -3.4]   -0.8[ -2.3]   -1.3[ -2.5]   -0.1[ -0.8]   +0.4[ +0.0]#   90%   (point estimate: 80%)
   top5 vs rest          -6.5[ -8.7]   -4.9[ -7.0]   -3.0[ -4.8]   -2.0[ -3.7]   -1.8[ -3.3]   -1.1[ -2.5]   -0.4[ -1.7]   +0.3[ -0.7]   +0.2[ -0.4]#   90%   (point estimate: 70%)
   NQC-like spread       -7.0[ -9.3]   -4.6[ -6.7]   -2.8[ -4.6]   -2.3[ -4.0]   -1.4[ -3.0]   -1.0[ -2.4]   -0.4[ -1.8]   +0.4[ -0.7]   +0.5[ -0.2]#   90%   (point estimate: 70%)
   WIG-like              -6.6[ -8.9]   -5.5[ -7.6]   -4.3[ -6.3]   -3.6[ -5.5]   -3.2[ -5.0]   -1.5[ -3.2]   -0.8[ -2.4]   -0.8[ -2.0]   -0.7[ -1.6]    100%   (point estimate: 100%)
   term coverage top1    -7.4[ -9.7]   -7.1[ -9.2]   -6.0[ -8.1]   -6.0[ -8.0]   -4.7[ -6.6]   -3.1[ -4.8]   -2.6[ -4.0]   -1.6[ -2.9]   -0.3[ -1.3]    100%   (point estimate: 90%)
   ORACLE                -1.6[ -3.2]   +1.8[ +0.5]#  +3.8[ +2.7]#  +4.7[ +3.6]#  +4.9[ +3.8]#  +4.9[ +3.8]#  +4.9[ +3.8]#  +4.9[ +3.8]#  +4.0[ +2.9]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      77% (sd  20)   -1.11 MRR              53%     23%
   tag alarm               100      81% (sd  13)   -0.76 MRR              44%     19%
   tag alarm               200      82% (sd   9)   -0.74 MRR              48%     18%
   BM25 margin              50      70% (sd  19)   -0.94 MRR              35%     30%
   BM25 margin             100      70% (sd  17)   -1.01 MRR              41%     30%
   BM25 margin             200      71% (sd  12)   -0.73 MRR              36%     29%
   top5 vs rest             50      65% (sd  25)   -1.16 MRR              42%     35%
   top5 vs rest            100      63% (sd  21)   -1.14 MRR              46%     37%
   top5 vs rest            200      64% (sd  14)   -0.85 MRR              46%     36%
   NQC-like spread          50      66% (sd  25)   -1.03 MRR              38%     34%
   NQC-like spread         100      60% (sd  22)   -1.28 MRR              50%     40%
   NQC-like spread         200      64% (sd  16)   -0.82 MRR              45%     36%
   WIG-like                 50      78% (sd  27)   -1.38 MRR              30%     22%
   WIG-like                100      81% (sd  20)   -1.08 MRR              32%     19%
   WIG-like                200      81% (sd  17)   -1.07 MRR              42%     19%
   term coverage top1       50      83% (sd  20)   -1.38 MRR              36%     17%
   term coverage top1      100      88% (sd  13)   -0.92 MRR              30%     12%
   term coverage top1      200      89% (sd   7)   -0.70 MRR              21%     11%

## POOLED over 7 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  41.2  random  38.9  diff  +2.3  p=0.0001
   MRR  : tag  41.5  random  40.1  diff  +1.4  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +1.4 (p=0.000)   MRR  +1.0 (p=0.000)
   40%      Hit@1  +1.2 (p=0.002)   MRR  +0.8 (p=0.001)
   50%      Hit@1  +0.8 (p=0.038)   MRR  +0.6 (p=0.007)
   natural  Hit@1  +1.3 (p=0.002)   MRR  +1.0 (p=0.000)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -6.0  95% CI [-7.2, -4.9]  p=0.000
   MRR  :  -5.2  95% CI [-5.7, -4.6]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +1.7  p=0.001
   MRR  :  +0.5  p=0.082

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +2.3/+0.9 (p=0.001)  40%: +2.3/+0.9 (p=0.001)  50%: +2.3/+0.7 (p=0.006)  nat: +1.6/+0.8 (p=0.001)
   vs NQC-like spread      30%: +1.5/+0.4 (p=0.153)  40%: +1.3/+0.3 (p=0.286)  50%: +1.2/+0.1 (p=0.575)  nat: +1.0/+0.4 (p=0.122)
   vs WIG-like             30%: +1.1/+0.4 (p=0.094)  40%: +1.1/+0.5 (p=0.095)  50%: +1.2/+0.5 (p=0.070)  nat: +0.8/+0.4 (p=0.122)
   vs term coverage top1   30%: +1.2/+0.4 (p=0.173)  40%: +1.2/+0.4 (p=0.112)  50%: +0.8/+0.4 (p=0.116)  nat: +1.4/+0.8 (p=0.002)
