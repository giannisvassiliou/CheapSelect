# holdout47: practitioner checklist on held-out collections (200 splits, n = 200 labels, rule UCB95, boundaries 1*delta and 15*delta, correct = no violation and regret <= 5 points)

## held-out: 7 pairs, 42 pair x metric x delta cells

strategy        | mean saving | P(violation) | mean regret | P(correct) | P(same family as hindsight)
----------------|------------:|-------------:|------------:|-----------:|---------------------------:
checklist       |        10.2 |        0.061 |         9.9 |       0.31 |       0.42
no_regime       |        10.3 |        0.066 |         9.9 |       0.31 |       0.34
always_wig      |         7.9 |        0.055 |        12.4 |       0.24 |       0.81
always_random   |         8.0 |        0.019 |        11.5 |       0.26 |       0.04
always_all      |         0.0 |        0.000 |        19.2 |       0.15 |       0.15
hindsight best  |        19.2 |   (uses test labels: upper bound)

regime called from 200 labels = regime from all labels: 0.94 of splits

pair                             metric delta  gain  rho  regime | C: low/mid/high | checklist save viol regret correct | hindsight save family (top selector)
beir_cqa_english:h47mini         MRR    0.5    6.0  11.9 middle | 0.01/0.76/0.23 |   1.5 0.070   6.9 0.42 |   7.8 selector (BM25 margin)
beir_cqa_english:h47mini         MRR    1.0    6.0   6.0 middle | 0.01/0.99/0.00 |   9.1 0.060   7.9 0.43 |  16.1 selector (BM25 margin)
beir_cqa_english:h47mini         MRR    2.0    6.0   3.0 middle | 0.01/0.98/0.00 |  20.7 0.110   9.7 0.33 |  28.3 selector (BM25 margin)
beir_cqa_english:h47mini         ndcg   0.5    3.5   7.0 middle | 0.01/0.99/0.00 |   7.4 0.085   7.0 0.45 |  13.2 selector (BM25 margin)
beir_cqa_english:h47mini         ndcg   1.0    3.5   3.5 middle | 0.01/0.99/0.00 |  18.4 0.100   7.3 0.39 |  24.3 selector (NQC-like spread)
beir_cqa_english:h47mini         ndcg   2.0    3.5   1.7 middle | 0.07/0.94/0.00 |  38.3 0.080   8.7 0.35 |  44.3 selector (NQC-like spread)
beir_cqa_english:h47bge          MRR    0.5    6.0  12.1 middle | 0.01/0.76/0.24 |   2.5 0.075   9.9 0.33 |  11.0 selector (BM25 margin)
beir_cqa_english:h47bge          MRR    1.0    6.0   6.0 middle | 0.01/0.99/0.00 |  10.2 0.075  13.1 0.23 |  21.7 selector (BM25 margin)
beir_cqa_english:h47bge          MRR    2.0    6.0   3.0 middle | 0.04/0.96/0.00 |  23.8 0.135  15.1 0.16 |  36.1 selector (BM25 margin)
beir_cqa_english:h47bge          ndcg   0.5    3.8   7.6 middle | 0.01/0.99/0.01 |   7.1 0.070  10.4 0.27 |  16.1 selector (NQC-like spread)
beir_cqa_english:h47bge          ndcg   1.0    3.8   3.8 middle | 0.01/0.99/0.00 |  19.9 0.090  10.9 0.28 |  28.6 selector (NQC-like spread)
beir_cqa_english:h47bge          ndcg   2.0    3.8   1.9 middle | 0.09/0.92/0.00 |  38.0 0.090  11.3 0.21 |  47.4 selector (NQC-like spread)
beir_cqa_english:h47monot5       MRR    0.5   11.0  22.1 high   | 0.00/0.05/0.95 |   0.1 0.010   4.0 0.61 |   4.0 all (BM25 margin)
beir_cqa_english:h47monot5       MRR    1.0   11.0  11.0 middle | 0.00/0.98/0.02 |   2.4 0.085   9.2 0.25 |  10.7 selector (BM25 margin)
beir_cqa_english:h47monot5       MRR    2.0   11.0   5.5 middle | 0.00/1.00/0.00 |  12.5 0.090   8.3 0.28 |  19.8 selector (BM25 margin)
beir_cqa_english:h47monot5       ndcg   0.5    6.6  13.1 middle | 0.00/0.80/0.20 |   1.7 0.060   5.7 0.43 |   6.9 selector (BM25 margin)
beir_cqa_english:h47monot5       ndcg   1.0    6.6   6.6 middle | 0.00/1.00/0.00 |  11.5 0.085   6.1 0.39 |  16.8 selector (BM25 margin)
beir_cqa_english:h47monot5       ndcg   2.0    6.6   3.3 middle | 0.00/1.00/0.00 |  24.0 0.095   7.9 0.32 |  30.5 selector (NQC-like spread)
beir_cqa_gaming:h47mini          MRR    0.5    7.9  15.8 high   | 0.00/0.42/0.58 |   0.1 0.005  10.3 0.27 |  10.4 selector (BM25 margin)
beir_cqa_gaming:h47mini          MRR    1.0    7.9   7.9 middle | 0.00/1.00/0.00 |   3.9 0.065  14.5 0.10 |  17.6 selector (BM25 margin)
beir_cqa_gaming:h47mini          MRR    2.0    7.9   3.9 middle | 0.00/1.00/0.00 |  15.3 0.045  16.3 0.12 |  30.8 selector (BM25 margin)
beir_cqa_gaming:h47mini          ndcg   0.5    5.0   9.9 middle | 0.00/0.99/0.01 |   2.0 0.090  12.8 0.13 |  13.7 selector (BM25 margin)
beir_cqa_gaming:h47mini          ndcg   1.0    5.0   5.0 middle | 0.00/1.00/0.00 |  13.2 0.060  13.2 0.19 |  25.4 selector (BM25 margin)
beir_cqa_gaming:h47mini          ndcg   2.0    5.0   2.5 middle | 0.00/1.00/0.00 |  30.3 0.080  13.6 0.12 |  43.0 selector (BM25 margin)
beir_cqa_gaming:h47bge           MRR    0.5    8.1  16.1 high   | 0.00/0.39/0.61 |   0.5 0.025  12.8 0.10 |  12.7 selector (BM25 margin)
beir_cqa_gaming:h47bge           MRR    1.0    8.1   8.1 middle | 0.00/1.00/0.00 |   3.6 0.065  16.1 0.08 |  18.9 selector (BM25 margin)
beir_cqa_gaming:h47bge           MRR    2.0    8.1   4.0 middle | 0.01/0.99/0.00 |  15.2 0.050  18.5 0.10 |  32.8 selector (BM25 margin)
beir_cqa_gaming:h47bge           ndcg   0.5    5.1  10.2 middle | 0.00/0.99/0.01 |   1.4 0.110  13.2 0.09 |  13.4 selector (BM25 margin)
beir_cqa_gaming:h47bge           ndcg   1.0    5.1   5.1 middle | 0.00/1.00/0.00 |  12.3 0.080  13.9 0.17 |  25.1 selector (BM25 margin)
beir_cqa_gaming:h47bge           ndcg   2.0    5.1   2.6 middle | 0.01/0.99/0.00 |  29.1 0.060  14.3 0.14 |  42.6 selector (BM25 margin)
beir_cqa_gaming:h47monot5        MRR    0.5   13.5  27.0 high   | 0.00/0.01/0.99 |   0.0 0.000   9.8 0.17 |   9.8 selector (BM25 margin)
beir_cqa_gaming:h47monot5        MRR    1.0   13.5  13.5 middle | 0.00/0.78/0.23 |   0.6 0.050  13.9 0.06 |  13.9 selector (BM25 margin)
beir_cqa_gaming:h47monot5        MRR    2.0   13.5   6.8 middle | 0.00/1.00/0.00 |   9.8 0.045  12.2 0.17 |  21.5 selector (BM25 margin)
beir_cqa_gaming:h47monot5        ndcg   0.5    8.6  17.2 high   | 0.00/0.18/0.82 |   0.2 0.015  10.4 0.20 |  10.4 selector (BM25 margin)
beir_cqa_gaming:h47monot5        ndcg   1.0    8.6   8.6 middle | 0.00/1.00/0.00 |   4.8 0.055  13.3 0.11 |  17.4 selector (BM25 margin)
beir_cqa_gaming:h47monot5        ndcg   2.0    8.6   4.3 middle | 0.00/1.00/0.00 |  15.9 0.025  16.1 0.07 |  31.5 selector (BM25 margin)
beir_climate-fever:h47mini       MRR    0.5   12.7  25.5 high   | 0.00/0.01/0.99 |   0.0 0.000   0.1 0.98 |   0.1 all (BM25 margin)
beir_climate-fever:h47mini       MRR    1.0   12.7  12.7 middle | 0.00/0.85/0.15 |   0.1 0.010   1.7 0.81 |   1.7 all (BM25 margin)
beir_climate-fever:h47mini       MRR    2.0   12.7   6.4 middle | 0.00/1.00/0.00 |   9.3 0.050   2.1 0.78 |  11.5 selector (BM25 margin)
beir_climate-fever:h47mini       ndcg   0.5    9.5  19.1 high   | 0.00/0.04/0.96 |   0.0 0.000   0.1 0.98 |   0.1 all (BM25 margin)
beir_climate-fever:h47mini       ndcg   1.0    9.5   9.5 middle | 0.00/1.00/0.00 |   0.8 0.045   3.8 0.56 |   4.2 all (BM25 margin)
beir_climate-fever:h47mini       ndcg   2.0    9.5   4.8 middle | 0.00/1.00/0.00 |  10.5 0.080   4.7 0.55 |  14.9 selector (BM25 margin)

## in-sample: 21 pairs, 63 pair x metric x delta cells

strategy        | mean saving | P(violation) | mean regret | P(correct) | P(same family as hindsight)
----------------|------------:|-------------:|------------:|-----------:|---------------------------:
checklist       |        16.4 |        0.036 |         9.6 |       0.48 |       0.50
no_regime       |        17.9 |        0.041 |         8.3 |       0.51 |       0.38
always_wig      |        13.7 |        0.033 |        12.3 |       0.43 |       0.66
always_random   |        13.4 |        0.019 |        12.3 |       0.39 |       0.10
always_all      |         0.0 |        0.000 |        24.9 |       0.26 |       0.25
hindsight best  |        24.9 |   (uses test labels: upper bound)

regime called from 200 labels = regime from all labels: 0.87 of splits

pair                             metric delta  gain  rho  regime | C: low/mid/high | checklist save viol regret correct | hindsight save family (top selector)
amazon_testfull:full             MRR    0.5   11.8  23.5 high   | 0.00/0.04/0.96 |   0.0 0.000   9.2 0.19 |   9.2 selector (BM25 margin)
amazon_testfull:full             MRR    1.0   11.8  11.8 middle | 0.00/0.92/0.08 |   2.3 0.030  12.5 0.12 |  14.0 selector (BM25 margin)
amazon_testfull:full             MRR    2.0   11.8   5.9 middle | 0.00/1.00/0.00 |  14.1 0.045  10.9 0.26 |  23.8 selector (NQC-like spread)
mag_testfull:full                MRR    0.5    4.5   8.9 middle | 0.04/0.89/0.07 |   8.2 0.045  20.0 0.17 |  27.1 selector (tag alarm)
mag_testfull:full                MRR    1.0    4.5   4.5 middle | 0.07/0.93/0.00 |  20.7 0.050  20.6 0.22 |  40.9 selector (tag alarm)
mag_testfull:full                MRR    2.0    4.5   2.2 middle | 0.15/0.85/0.00 |  37.4 0.040  22.2 0.22 |  59.5 selector (tag alarm)
prime_testfull:full              MRR    0.5    3.9   7.8 middle | 0.09/0.81/0.10 |   8.4 0.040  11.3 0.41 |  18.4 selector (WIG-like)
prime_testfull:full              MRR    1.0    3.9   3.9 middle | 0.12/0.88/0.00 |  19.1 0.050  12.8 0.34 |  30.6 selector (tag alarm)
prime_testfull:full              MRR    2.0    3.9   2.0 middle | 0.26/0.74/0.00 |  31.8 0.045  16.8 0.21 |  47.0 selector (tag alarm)
dbpedia_test:dbp                 MRR    0.5   19.5  39.0 high   | 0.00/0.00/1.00 |   0.0 0.000   0.9 0.90 |   0.9 all (tag alarm)
dbpedia_test:dbp                 MRR    1.0   19.5  19.5 high   | 0.00/0.01/0.98 |   0.0 0.000   3.1 0.68 |   3.1 all (tag alarm)
dbpedia_test:dbp                 MRR    2.0   19.5   9.8 middle | 0.00/1.00/0.00 |   4.8 0.110   5.8 0.44 |   9.1 selector (tag alarm)
beir_fiqa:bge                    MRR    0.5   17.7  35.5 high   | 0.00/0.00/1.00 |   0.0 0.000   0.1 0.99 |   0.1 all (tag alarm)
beir_fiqa:bge                    MRR    1.0   17.7  17.7 high   | 0.00/0.08/0.92 |   0.0 0.005   1.5 0.81 |   1.5 all (tag alarm)
beir_fiqa:bge                    MRR    2.0   17.7   8.9 middle | 0.00/1.00/0.00 |   3.9 0.075   6.1 0.41 |   9.4 selector (BM25 margin)
beir_arguana:bge                 MRR    0.5   22.0  44.0 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_arguana:bge                 MRR    1.0   22.0  22.0 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_arguana:bge                 MRR    2.0   22.0  11.0 middle | 0.00/1.00/0.00 |   0.3 0.035   0.9 0.86 |   0.9 all (BM25 margin)
beir_scidocs:bge                 MRR    0.5    2.5   5.0 middle | 0.12/0.89/0.00 |   5.9 0.035   8.1 0.46 |  13.4 selector (term coverage top1)
beir_scidocs:bge                 MRR    1.0    2.5   2.5 middle | 0.14/0.85/0.00 |  18.1 0.040   9.7 0.39 |  27.0 selector (term coverage top1)
beir_scidocs:bge                 MRR    2.0    2.5   1.2 middle | 0.33/0.67/0.00 |  36.9 0.045  11.1 0.34 |  46.2 selector (term coverage top1)
amazon_testfull:mini             MRR    0.5    5.8  11.6 middle | 0.01/0.71/0.28 |   5.8 0.035  15.0 0.14 |  19.4 selector (BM25 margin)
amazon_testfull:mini             MRR    1.0    5.8   5.8 middle | 0.03/0.96/0.01 |  12.4 0.035  16.3 0.20 |  27.1 selector (BM25 margin)
amazon_testfull:mini             MRR    2.0    5.8   2.9 middle | 0.07/0.93/0.00 |  27.1 0.045  15.5 0.28 |  41.7 selector (BM25 margin)
mag_testfull:mini                MRR    0.5    0.1   0.2 low    | 0.65/0.35/0.00 |  21.5 0.050  37.1 0.12 |  54.0 selector (tag alarm)
mag_testfull:mini                MRR    1.0    0.1   0.1 low    | 0.70/0.29/0.00 |  37.7 0.035  32.8 0.17 |  67.3 selector (tag alarm)
mag_testfull:mini                MRR    2.0    0.1   0.0 low    | 0.84/0.16/0.00 |  60.5 0.000  23.7 0.27 |  84.2 selector (tag alarm)
prime_testfull:mini              MRR    0.5    0.4   0.7 low    | 0.48/0.52/0.00 |  21.4 0.090  23.6 0.27 |  38.3 selector (BM25 margin)
prime_testfull:mini              MRR    1.0    0.4   0.4 low    | 0.57/0.42/0.00 |  34.0 0.035  23.0 0.27 |  54.1 selector (tag alarm)
prime_testfull:mini              MRR    2.0    0.4   0.2 low    | 0.76/0.24/0.00 |  52.7 0.000  18.4 0.30 |  71.1 selector (tag alarm)
dbpedia_test:mini                MRR    0.5   19.2  38.5 high   | 0.00/0.00/1.00 |   0.0 0.000   1.0 0.89 |   1.0 all (tag alarm)
dbpedia_test:mini                MRR    1.0   19.2  19.2 high   | 0.00/0.00/1.00 |   0.0 0.000   3.1 0.69 |   3.1 all (tag alarm)
dbpedia_test:mini                MRR    2.0   19.2   9.6 middle | 0.00/1.00/0.00 |   5.2 0.105   6.0 0.42 |   9.8 selector (tag alarm)
beir_fiqa:mini                   MRR    0.5   11.8  23.6 high   | 0.00/0.01/0.98 |   0.0 0.000   0.7 0.93 |   0.7 all (tag alarm)
beir_fiqa:mini                   MRR    1.0   11.8  11.8 middle | 0.00/0.94/0.06 |   0.7 0.050   5.1 0.48 |   5.2 selector (tag alarm)
beir_fiqa:mini                   MRR    2.0   11.8   5.9 middle | 0.00/1.00/0.00 |   9.6 0.030   4.6 0.59 |  13.9 selector (BM25 margin)
beir_arguana:mini                MRR    0.5   -0.8  -1.6 low    | 0.89/0.12/0.00 |  52.1 0.000   2.9 0.87 |  55.0 random (NQC-like spread)
beir_arguana:mini                MRR    1.0   -0.8  -0.8 low    | 0.94/0.06/0.00 |  72.8 0.000   3.5 0.83 |  76.3 random (NQC-like spread)
beir_arguana:mini                MRR    2.0   -0.8  -0.4 low    | 0.99/0.01/0.00 |  93.8 0.000   1.4 0.92 |  95.1 random (top5 vs rest)
beir_scidocs:mini                MRR    0.5    1.6   3.1 middle | 0.20/0.81/0.00 |   9.0 0.095   8.1 0.41 |  14.4 selector (term coverage top1)
beir_scidocs:mini                MRR    1.0    1.6   1.6 middle | 0.31/0.69/0.00 |  21.9 0.080   8.8 0.39 |  27.0 selector (term coverage top1)
beir_scidocs:mini                MRR    2.0    1.6   0.8 low    | 0.55/0.46/0.00 |  44.0 0.075   9.7 0.39 |  49.4 selector (term coverage top1)
amazon_testfull:monot5           MRR    0.5   14.3  28.6 high   | 0.00/0.01/0.99 |   0.0 0.000   7.9 0.23 |   7.9 selector (BM25 margin)
amazon_testfull:monot5           MRR    1.0   14.3  14.3 middle | 0.00/0.62/0.38 |   0.7 0.035  10.8 0.10 |  11.1 selector (BM25 margin)
amazon_testfull:monot5           MRR    2.0   14.3   7.2 middle | 0.00/1.00/0.00 |   9.2 0.035  12.4 0.17 |  20.9 selector (BM25 margin)
mag_testfull:monot5              MRR    0.5    7.5  15.1 high   | 0.00/0.52/0.48 |   1.7 0.035  16.2 0.06 |  16.7 selector (tag alarm)
mag_testfull:monot5              MRR    1.0    7.5   7.5 middle | 0.01/0.99/0.00 |   6.3 0.045  18.0 0.09 |  23.0 selector (tag alarm)
mag_testfull:monot5              MRR    2.0    7.5   3.8 middle | 0.01/0.99/0.00 |  18.9 0.045  18.7 0.10 |  36.5 selector (tag alarm)
prime_testfull:monot5            MRR    0.5    7.1  14.1 middle | 0.00/0.58/0.42 |   3.3 0.045   7.0 0.43 |   9.0 selector (BM25 margin)
prime_testfull:monot5            MRR    1.0    7.1   7.1 middle | 0.01/0.98/0.00 |  10.0 0.040   7.7 0.41 |  16.9 selector (tag alarm)
prime_testfull:monot5            MRR    2.0    7.1   3.5 middle | 0.03/0.97/0.00 |  22.9 0.075   9.3 0.36 |  30.9 selector (tag alarm)
dbpedia_test:monot5              MRR    0.5   19.7  39.5 high   | 0.00/0.00/1.00 |   0.0 0.000   1.1 0.88 |   1.1 all (tag alarm)
dbpedia_test:monot5              MRR    1.0   19.7  19.7 high   | 0.00/0.01/0.99 |   0.0 0.000   3.6 0.64 |   3.6 all (tag alarm)
dbpedia_test:monot5              MRR    2.0   19.7   9.9 middle | 0.00/1.00/0.00 |   4.7 0.100   6.6 0.39 |   9.9 selector (tag alarm)
beir_fiqa:monot5                 MRR    0.5   25.0  50.1 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_fiqa:monot5                 MRR    1.0   25.0  25.0 high   | 0.00/0.00/1.00 |   0.0 0.000   0.3 0.96 |   0.3 all (BM25 margin)
beir_fiqa:monot5                 MRR    2.0   25.0  12.5 middle | 0.00/0.98/0.02 |   0.5 0.060   5.2 0.42 |   5.3 selector (tag alarm)
beir_arguana:monot5              MRR    0.5    0.6   1.2 middle | 0.53/0.47/0.00 |  19.4 0.075   5.8 0.65 |  20.1 selector (NQC-like spread)
beir_arguana:monot5              MRR    1.0    0.6   0.6 low    | 0.64/0.36/0.00 |  36.6 0.060   7.0 0.61 |  39.6 selector (NQC-like spread)
beir_arguana:monot5              MRR    2.0    0.6   0.3 low    | 0.82/0.18/0.00 |  62.1 0.000   6.7 0.63 |  68.8 selector (WIG-like)
beir_scidocs:monot5              MRR    0.5    5.1  10.2 middle | 0.00/0.89/0.11 |   3.3 0.085   3.3 0.65 |   5.3 all (NQC-like spread)
beir_scidocs:monot5              MRR    1.0    5.1   5.1 middle | 0.01/0.99/0.00 |  12.4 0.045   5.2 0.61 |  16.9 selector (term coverage top1)
beir_scidocs:monot5              MRR    2.0    5.1   2.5 middle | 0.01/0.98/0.00 |  26.2 0.030   8.3 0.47 |  33.8 selector (term coverage top1)

## by rho = mean gain / delta (whole collection)

group     rho bucket    cells | hindsight save  P(all/random/selector best) | random save | WIG save viol | checklist save correct
held-out  (1, 3]            5 |           41.1  0.01/0.04/0.96               |        26.5 |     28.1 0.063 |           31.3 0.23
held-out  (3, 7]           17 |           23.6  0.01/0.09/0.91               |        11.1 |      9.6 0.061 |           14.0 0.30
held-out  (7, 15]          13 |           11.8  0.22/0.01/0.77               |         1.0 |      1.9 0.057 |            2.5 0.28
held-out  (15, 30]          7 |            6.8  0.47/0.00/0.53               |         0.0 |      0.4 0.031 |            0.1 0.47
in-sample (-inf, 1]        12 |           62.8  0.01/0.37/0.62               |        47.2 |     39.9 0.018 |           49.1 0.47
in-sample (1, 3]            8 |           37.8  0.02/0.10/0.88               |        20.9 |     23.6 0.036 |           27.4 0.37
in-sample (3, 7]           10 |           24.8  0.04/0.08/0.88               |         9.0 |     11.7 0.042 |           14.5 0.36
in-sample (7, 15]          17 |           12.6  0.21/0.01/0.79               |         1.1 |      4.3 0.052 |            4.6 0.36
in-sample (15, 30]         10 |            4.6  0.59/0.00/0.41               |         0.0 |      0.5 0.022 |            0.2 0.62
in-sample (30, inf]         6 |            0.5  0.92/0.00/0.08               |         0.0 |      0.1 0.004 |            0.0 0.94

skipped: amazon_testfull:full: no ndcg; mag_testfull:full: no ndcg; prime_testfull:full: no ndcg; dbpedia_test:dbp: no ndcg; beir_scifact:bge: N = 300 too small for n = 200; beir_scifact:bge: no ndcg; beir_nfcorpus:bge: N = 323 too small for n = 200; beir_nfcorpus:bge: no ndcg; beir_fiqa:bge: no ndcg; beir_arguana:bge: no ndcg; beir_scidocs:bge: no ndcg; amazon_testfull:mini: no ndcg; mag_testfull:mini: no ndcg; prime_testfull:mini: no ndcg; dbpedia_test:mini: no ndcg; beir_scifact:mini: N = 300 too small for n = 200; beir_scifact:mini: no ndcg; beir_nfcorpus:mini: N = 323 too small for n = 200; beir_nfcorpus:mini: no ndcg; beir_fiqa:mini: no ndcg; beir_arguana:mini: no ndcg; beir_scidocs:mini: no ndcg; amazon_testfull:monot5: no ndcg; mag_testfull:monot5: no ndcg; prime_testfull:monot5: no ndcg; dbpedia_test:monot5: no ndcg; beir_scifact:monot5: N = 300 too small for n = 200; beir_scifact:monot5: no ndcg; beir_nfcorpus:monot5: N = 323 too small for n = 200; beir_nfcorpus:monot5: no ndcg; beir_fiqa:monot5: no ndcg; beir_arguana:monot5: no ndcg; beir_scidocs:monot5: no ndcg
