## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.4  random  55.3  diff  +2.2  p=0.0004
   MRR  : tag  53.0  random  52.1  diff  +0.9  p=0.0018

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.2 (p=0.127)        +0.5 (p=0.229)
   40%            +0.1 (p=1.000)        +0.1 (p=0.781)
   50%            -0.8 (p=0.413)        -0.2 (p=0.694)
   47% nat        -0.2 (p=0.839)        +0.0 (p=0.953)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.7  95% CI [-6.4, -3.0]  p=0.000
   MRR  :  -3.7  95% CI [-4.6, -2.9]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +1.6  p=0.084
   MRR  :  +0.2  p=0.602

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.1/-0.7 (p=0.142)  40%: -0.7/-1.0 (p=0.042)  50%: -1.0/-1.5 (p=0.002)  nat: -0.8/-1.3 (p=0.008)
   vs NQC-like spread      30%: -0.4/-0.8 (p=0.084)  40%: -1.3/-1.3 (p=0.008)  50%: -1.4/-1.5 (p=0.002)  nat: -1.8/-1.6 (p=0.001)
   vs WIG-like             30%: +0.6/-0.4 (p=0.395)  40%: +0.2/-0.4 (p=0.375)  50%: -0.4/-1.0 (p=0.041)  nat: +0.1/-0.9 (p=0.072)
   vs term coverage top1   30%: +3.2/+1.0 (p=0.037)  40%: +3.5/+1.2 (p=0.016)  50%: +3.0/+1.1 (p=0.026)  nat: +2.9/+1.0 (p=0.042)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -3.7  [-4.6, -2.9]  p=0.000
   BM25 margin           -3.8  [-4.7, -2.9]  p=0.000
   top5 vs rest          -2.4  [-3.3, -1.6]  p=0.000
   NQC-like spread       -2.1  [-3.0, -1.3]  p=0.000
   WIG-like              -2.9  [-3.9, -1.9]  p=0.000
   term coverage top1    -4.8  [-5.8, -3.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              49.1    50.3    51.8    52.6    53.3    54.2    54.8    55.7    56.6*   56.8*   90%
   BM25 margin            49.2    50.3    51.3    52.5    53.5    54.4    55.3    56.2    56.7*   56.8*   90%
   top5 vs rest           49.3    50.9    52.5    53.6    54.8    55.5    55.9    56.8*   56.8*   56.8*   80%
   NQC-like spread        49.2    50.9    52.6    53.9    54.9    55.6    56.0    56.7*   56.9*   56.8*   80%
   WIG-like               49.7    50.9    52.2    53.1    54.3    55.4    56.5*   56.6*   56.6*   56.8*   70%
   term coverage top1     49.0    49.9    50.8    51.4    52.2    53.5    54.2    54.8    55.7    56.8*   100%
   ORACLE                 54.4    57.7*   59.9*   61.0*   61.3*   61.3*   61.3*   61.3*   60.4*   56.8*   20%
   random (expected)      48.9    49.8    50.7    51.5    52.4    53.3    54.1    55.0    55.9    56.8*   100%
   (BM25 only 48.0; rerank ALL 56.8)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.7[ -8.9]   -6.5[ -7.6]   -5.0[ -6.0]   -4.1[ -5.0]   -3.4[ -4.3]   -2.6[ -3.3]   -2.0[ -2.6]   -1.1[ -1.5]   -0.2[ -0.4]#   90%   (point estimate: 90%)
   BM25 margin           -7.5[ -8.8]   -6.5[ -7.6]   -5.5[ -6.5]   -4.2[ -5.2]   -3.3[ -4.1]   -2.3[ -3.1]   -1.5[ -2.1]   -0.6[ -1.0]   -0.0[ -0.3]#   90%   (point estimate: 80%)
   top5 vs rest          -7.4[ -8.7]   -5.8[ -6.9]   -4.3[ -5.4]   -3.1[ -4.2]   -1.9[ -2.8]   -1.3[ -2.1]   -0.9[ -1.5]   +0.0[ -0.5]#  +0.0[ -0.3]#   80%   (point estimate: 70%)
   NQC-like spread       -7.6[ -8.8]   -5.8[ -7.0]   -4.2[ -5.2]   -2.8[ -3.8]   -1.9[ -2.8]   -1.1[ -1.9]   -0.8[ -1.5]   -0.1[ -0.6]#  +0.1[ -0.3]#   80%   (point estimate: 70%)
   WIG-like              -7.0[ -8.3]   -5.9[ -7.0]   -4.6[ -5.6]   -3.7[ -4.7]   -2.4[ -3.4]   -1.4[ -2.2]   -0.3[ -1.1]   -0.2[ -0.8]#  -0.2[ -0.6]#   80%   (point estimate: 70%)
   term coverage top1    -7.8[ -9.0]   -6.8[ -8.0]   -6.0[ -7.1]   -5.3[ -6.4]   -4.5[ -5.5]   -3.3[ -4.1]   -2.6[ -3.3]   -1.9[ -2.6]   -1.0[ -1.5]    100%   (point estimate: 100%)
   ORACLE                -2.4[ -3.3]   +1.0[ +0.2]#  +3.1[ +2.4]#  +4.3[ +3.7]#  +4.5[ +3.9]#  +4.5[ +3.9]#  +4.5[ +3.9]#  +4.5[ +3.9]#  +3.6[ +3.0]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.7[ -8.9]   -6.5[ -7.6]   -5.0[ -6.0]   -4.1[ -5.0]   -3.4[ -4.3]   -2.6[ -3.3]   -2.0[ -2.6]   -1.1[ -1.5]   -0.2[ -0.4]#   90%   (point estimate: 90%)
   BM25 margin           -7.5[ -8.8]   -6.5[ -7.6]   -5.5[ -6.5]   -4.2[ -5.2]   -3.3[ -4.1]   -2.3[ -3.1]   -1.5[ -2.1]   -0.6[ -1.0]   -0.0[ -0.3]#   90%   (point estimate: 90%)
   top5 vs rest          -7.4[ -8.7]   -5.8[ -6.9]   -4.3[ -5.4]   -3.1[ -4.2]   -1.9[ -2.8]   -1.3[ -2.1]   -0.9[ -1.5]   +0.0[ -0.5]#  +0.0[ -0.3]#   80%   (point estimate: 80%)
   NQC-like spread       -7.6[ -8.8]   -5.8[ -7.0]   -4.2[ -5.2]   -2.8[ -3.8]   -1.9[ -2.8]   -1.1[ -1.9]   -0.8[ -1.5]   -0.1[ -0.6]   +0.1[ -0.3]#   90%   (point estimate: 80%)
   WIG-like              -7.0[ -8.3]   -5.9[ -7.0]   -4.6[ -5.6]   -3.7[ -4.7]   -2.4[ -3.4]   -1.4[ -2.2]   -0.3[ -1.1]   -0.2[ -0.8]   -0.2[ -0.6]    100%   (point estimate: 70%)
   term coverage top1    -7.8[ -9.0]   -6.8[ -8.0]   -6.0[ -7.1]   -5.3[ -6.4]   -4.5[ -5.5]   -3.3[ -4.1]   -2.6[ -3.3]   -1.9[ -2.6]   -1.0[ -1.5]    100%   (point estimate: 100%)
   ORACLE                -2.4[ -3.3]   +1.0[ +0.2]#  +3.1[ +2.4]#  +4.3[ +3.7]#  +4.5[ +3.9]#  +4.5[ +3.9]#  +4.5[ +3.9]#  +4.5[ +3.9]#  +3.6[ +3.0]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      80% (sd  15)   -1.11 MRR              57%     20%
   tag alarm               100      84% (sd  12)   -0.81 MRR              44%     16%
   tag alarm               200      84% (sd   8)   -0.71 MRR              42%     16%
   BM25 margin              50      77% (sd  18)   -1.14 MRR              40%     23%
   BM25 margin             100      79% (sd  12)   -0.86 MRR              31%     21%
   BM25 margin             200      80% (sd   8)   -0.76 MRR              23%     20%
   top5 vs rest             50      67% (sd  24)   -1.36 MRR              39%     33%
   top5 vs rest            100      69% (sd  18)   -1.04 MRR              38%     31%
   top5 vs rest            200      68% (sd  13)   -0.96 MRR              40%     32%
   NQC-like spread          50      66% (sd  26)   -1.51 MRR              42%     34%
   NQC-like spread         100      70% (sd  19)   -0.97 MRR              37%     30%
   NQC-like spread         200      68% (sd  17)   -0.99 MRR              42%     32%
   WIG-like                 50      71% (sd  24)   -1.22 MRR              38%     29%
   WIG-like                100      72% (sd  20)   -1.05 MRR              40%     28%
   WIG-like                200      72% (sd  16)   -0.82 MRR              35%     28%
   term coverage top1       50      90% (sd  17)   -0.98 MRR              44%     10%
   term coverage top1      100      93% (sd  10)   -0.70 MRR              45%      7%
   term coverage top1      200      94% (sd   9)   -0.64 MRR              41%      6%

## mag_testfull  (2665 questions; tag alarm fires on 710 = 27%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.2  random  51.9  diff  +4.4  p=0.0001
   MRR  : tag  62.6  random  59.9  diff  +2.7  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +3.5 (p=0.000)        +2.4 (p=0.000)
   40%            +2.5 (p=0.000)        +1.8 (p=0.000)
   50%            +2.0 (p=0.000)        +1.3 (p=0.000)
   27% nat        +3.5 (p=0.000)        +2.4 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.5  95% CI [-0.9, +1.8]  p=0.558
   MRR  :  +0.4  95% CI [-0.4, +1.1]  p=0.376

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (38%)
   Hit@1:  +1.9  p=0.002
   MRR  :  +1.0  p=0.005

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.5/+1.9 (p=0.000)  40%: +2.7/+1.1 (p=0.002)  50%: +2.4/+1.0 (p=0.007)  nat: +3.2/+1.8 (p=0.000)
   vs NQC-like spread      30%: +2.8/+1.5 (p=0.000)  40%: +2.0/+0.8 (p=0.015)  50%: +2.2/+0.9 (p=0.011)  nat: +3.0/+1.6 (p=0.000)
   vs WIG-like             30%: +1.0/+0.3 (p=0.345)  40%: +0.6/-0.0 (p=0.925)  50%: +0.6/-0.1 (p=0.822)  nat: +1.1/+0.4 (p=0.144)
   vs term coverage top1   30%: +2.0/+0.6 (p=0.059)  40%: +0.8/-0.3 (p=0.393)  50%: +0.5/-0.6 (p=0.064)  nat: +2.2/+0.8 (p=0.012)

G. each selector reranking 710 questions (27%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +0.4  [-0.4, +1.1]  p=0.376
   BM25 margin           -2.1  [-2.9, -1.2]  p=0.000
   top5 vs rest          -1.5  [-2.3, -0.7]  p=0.000
   NQC-like spread       -1.3  [-2.1, -0.5]  p=0.001
   WIG-like              -0.1  [-0.9, +0.7]  p=0.810
   term coverage top1    -0.4  [-1.3, +0.4]  p=0.328

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              60.5    61.9*   62.6*   62.4*   62.5*   62.6*   62.6*   62.6*   62.3*   62.2*   20%
   BM25 margin            59.7    59.7    60.2    60.7    61.2    61.8*   62.2*   62.3*   62.3*   62.2*   60%
   top5 vs rest           59.4    60.3    60.7    61.3    61.6*   61.8*   61.8*   61.9*   62.2*   62.2*   50%
   NQC-like spread        59.6    60.5    61.1    61.6*   61.7*   61.9*   61.9*   62.0*   62.2*   62.2*   40%
   WIG-like               60.9    61.9*   62.3*   62.5*   62.6*   62.7*   62.9*   62.9*   62.9*   62.2*   20%
   term coverage top1     60.4    61.1    62.0*   62.7*   63.2*   63.1*   63.1*   63.1*   62.9*   62.2*   30%
   ORACLE                 64.9*   67.5*   68.2*   68.2*   68.2*   68.2*   68.2*   68.2*   66.8*   62.2*   10%
   random (expected)      59.3    59.7    60.0    60.3    60.6    60.9    61.3    61.6    61.9    62.2*   100%
   (BM25 only 59.0; rerank ALL 62.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.7[ -2.6]   -0.3[ -1.1]   +0.4[ -0.4]#  +0.2[ -0.5]#  +0.3[ -0.3]#  +0.4[ -0.2]#  +0.4[ -0.0]#  +0.3[ +0.1]#  +0.1[ -0.0]#   30%   (point estimate: 20%)
   BM25 margin           -2.5[ -3.5]   -2.5[ -3.4]   -2.0[ -2.9]   -1.5[ -2.3]   -1.0[ -1.7]   -0.4[ -1.0]#  +0.0[ -0.4]#  +0.1[ -0.2]#  +0.1[ -0.0]#   60%   (point estimate: 60%)
   top5 vs rest          -2.8[ -3.7]   -1.9[ -2.8]   -1.5[ -2.3]   -0.9[ -1.6]   -0.6[ -1.3]   -0.4[ -1.0]   -0.5[ -1.0]#  -0.3[ -0.7]#  -0.0[ -0.3]#   70%   (point estimate: 40%)
   NQC-like spread       -2.7[ -3.6]   -1.7[ -2.5]   -1.1[ -1.8]   -0.6[ -1.3]   -0.5[ -1.1]   -0.4[ -0.9]#  -0.4[ -0.8]#  -0.2[ -0.6]#  +0.0[ -0.2]#   60%   (point estimate: 40%)
   WIG-like              -1.3[ -2.3]   -0.3[ -1.1]   +0.1[ -0.8]#  +0.3[ -0.5]#  +0.4[ -0.3]#  +0.5[ -0.2]#  +0.7[ +0.2]#  +0.7[ +0.2]#  +0.6[ +0.3]#   30%   (point estimate: 20%)
   term coverage top1    -1.9[ -2.8]   -1.1[ -2.0]   -0.2[ -1.1]   +0.5[ -0.2]#  +1.0[ +0.3]#  +0.9[ +0.3]#  +0.9[ +0.3]#  +0.9[ +0.4]#  +0.7[ +0.3]#   40%   (point estimate: 30%)
   ORACLE                +2.7[ +2.0]#  +5.3[ +4.8]#  +6.0[ +5.4]#  +6.0[ +5.4]#  +6.0[ +5.4]#  +6.0[ +5.4]#  +6.0[ +5.4]#  +5.9[ +5.4]#  +4.6[ +4.1]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.7[ -2.6]   -0.3[ -1.1]   +0.4[ -0.4]#  +0.2[ -0.5]#  +0.3[ -0.3]#  +0.4[ -0.2]#  +0.4[ -0.0]#  +0.3[ +0.1]#  +0.1[ -0.0]#   30%   (point estimate: 20%)
   BM25 margin           -2.5[ -3.5]   -2.5[ -3.4]   -2.0[ -2.9]   -1.5[ -2.3]   -1.0[ -1.7]   -0.4[ -1.0]   +0.0[ -0.4]#  +0.1[ -0.2]#  +0.1[ -0.0]#   70%   (point estimate: 60%)
   top5 vs rest          -2.8[ -3.7]   -1.9[ -2.8]   -1.5[ -2.3]   -0.9[ -1.6]   -0.6[ -1.3]   -0.4[ -1.0]   -0.5[ -1.0]   -0.3[ -0.7]   -0.0[ -0.3]#   90%   (point estimate: 60%)
   NQC-like spread       -2.7[ -3.6]   -1.7[ -2.5]   -1.1[ -1.8]   -0.6[ -1.3]   -0.5[ -1.1]   -0.4[ -0.9]   -0.4[ -0.8]   -0.2[ -0.6]   +0.0[ -0.2]#   90%   (point estimate: 60%)
   WIG-like              -1.3[ -2.3]   -0.3[ -1.1]   +0.1[ -0.8]   +0.3[ -0.5]   +0.4[ -0.3]#  +0.5[ -0.2]#  +0.7[ +0.2]#  +0.7[ +0.2]#  +0.6[ +0.3]#   50%   (point estimate: 20%)
   term coverage top1    -1.9[ -2.8]   -1.1[ -2.0]   -0.2[ -1.1]   +0.5[ -0.2]#  +1.0[ +0.3]#  +0.9[ +0.3]#  +0.9[ +0.3]#  +0.9[ +0.4]#  +0.7[ +0.3]#   40%   (point estimate: 30%)
   ORACLE                +2.7[ +2.0]#  +5.3[ +4.8]#  +6.0[ +5.4]#  +6.0[ +5.4]#  +6.0[ +5.4]#  +6.0[ +5.4]#  +6.0[ +5.4]#  +5.9[ +5.4]#  +4.6[ +4.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      42% (sd  30)   -0.44 MRR              32%     58%
   tag alarm               100      36% (sd  27)   -0.53 MRR              36%     64%
   tag alarm               200      28% (sd  21)   -0.59 MRR              34%     72%
   BM25 margin              50      55% (sd  30)   -0.91 MRR              41%     45%
   BM25 margin             100      53% (sd  25)   -0.91 MRR              40%     47%
   BM25 margin             200      49% (sd  21)   -1.06 MRR              53%     51%
   top5 vs rest             50      60% (sd  33)   -0.89 MRR              29%     40%
   top5 vs rest            100      58% (sd  31)   -0.90 MRR              28%     42%
   top5 vs rest            200      52% (sd  28)   -1.01 MRR              34%     48%
   NQC-like spread          50      59% (sd  34)   -0.82 MRR              32%     41%
   NQC-like spread         100      54% (sd  31)   -0.87 MRR              34%     46%
   NQC-like spread         200      47% (sd  27)   -1.00 MRR              40%     53%
   WIG-like                 50      47% (sd  35)   -0.23 MRR              34%     53%
   WIG-like                100      36% (sd  30)   -0.40 MRR              40%     64%
   WIG-like                200      27% (sd  22)   -0.50 MRR              41%     73%
   term coverage top1       50      38% (sd  31)   -0.58 MRR              48%     62%
   term coverage top1      100      34% (sd  26)   -0.55 MRR              46%     66%
   term coverage top1      200      30% (sd  19)   -0.51 MRR              48%     70%

## prime_testfull  (2801 questions; tag alarm fires on 1563 = 56%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  24.7  random  21.9  diff  +2.8  p=0.0001
   MRR  : tag  33.3  random  31.2  diff  +2.1  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.3 (p=0.000)        +1.7 (p=0.000)
   40%            +1.9 (p=0.000)        +1.6 (p=0.000)
   50%            +2.1 (p=0.000)        +1.9 (p=0.000)
   56% nat        +1.4 (p=0.013)        +1.6 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +2.1  95% CI [+1.0, +3.2]  p=0.000
   MRR  :  -0.1  95% CI [-0.8, +0.6]  p=0.766

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +0.4  p=0.494
   MRR  :  +0.2  p=0.566

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.8/+0.5 (p=0.187)  40%: +1.4/+0.8 (p=0.042)  50%: +1.6/+1.0 (p=0.008)  nat: +0.7/+0.7 (p=0.056)
   vs NQC-like spread      30%: +0.7/+0.5 (p=0.140)  40%: +0.6/+0.4 (p=0.260)  50%: +0.5/+0.4 (p=0.297)  nat: -0.3/+0.0 (p=0.894)
   vs WIG-like             30%: +0.6/+0.2 (p=0.545)  40%: +0.9/+0.3 (p=0.390)  50%: +1.1/+0.7 (p=0.072)  nat: +0.5/+0.5 (p=0.186)
   vs term coverage top1   30%: +1.5/+0.9 (p=0.017)  40%: +2.0/+1.2 (p=0.001)  50%: +2.5/+1.6 (p=0.000)  nat: +1.7/+1.3 (p=0.001)

G. each selector reranking 1563 questions (56%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.1  [-0.8, +0.6]  p=0.766
   BM25 margin           -1.7  [-2.5, -1.0]  p=0.000
   top5 vs rest          -0.8  [-1.5, +0.0]  p=0.051
   NQC-like spread       -0.2  [-0.9, +0.6]  p=0.700
   WIG-like              -0.6  [-1.4, +0.2]  p=0.149
   term coverage top1    -1.4  [-2.1, -0.6]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              29.5    30.3    31.4    32.2    33.2*   33.3*   33.3*   33.6*   33.6*   33.5*   50%
   BM25 margin            28.7    29.2    29.6    30.7    31.3    32.2    32.7    33.3*   33.5*   33.5*   80%
   top5 vs rest           29.1    30.0    30.9    31.4    32.2    32.9*   33.3*   33.5*   33.4*   33.5*   60%
   NQC-like spread        29.0    29.9    30.8    31.8    32.8*   33.3*   33.4*   33.5*   33.6*   33.5*   50%
   WIG-like               29.3    30.3    31.2    31.9    32.5    33.1*   33.7*   33.8*   34.0*   33.5*   60%
   term coverage top1     28.9    29.9    30.5    31.0    31.6    32.1    32.7    33.1*   33.1*   33.5*   80%
   ORACLE                 35.3*   38.7*   39.6*   39.6*   39.6*   39.6*   39.6*   39.6*   38.5*   33.5*   10%
   random (expected)      28.9    29.4    29.9    30.4    30.9    31.4    31.9    32.4    32.9    33.5*   100%
   (BM25 only 28.4; rerank ALL 33.5)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -3.9[ -5.0]   -3.1[ -4.1]   -2.1[ -3.0]   -1.2[ -2.1]   -0.3[ -1.0]   -0.2[ -0.9]#  -0.2[ -0.7]#  +0.1[ -0.3]#  +0.1[ -0.2]#   60%   (point estimate: 50%)
   BM25 margin           -4.7[ -5.8]   -4.3[ -5.3]   -3.8[ -4.8]   -2.8[ -3.7]   -2.1[ -2.9]   -1.3[ -2.0]   -0.7[ -1.3]   -0.1[ -0.6]#  +0.1[ -0.2]#   80%   (point estimate: 70%)
   top5 vs rest          -4.4[ -5.5]   -3.5[ -4.5]   -2.6[ -3.6]   -2.0[ -2.9]   -1.2[ -2.0]   -0.5[ -1.3]   -0.1[ -0.8]#  +0.1[ -0.5]#  -0.0[ -0.4]#   70%   (point estimate: 60%)
   NQC-like spread       -4.5[ -5.6]   -3.6[ -4.6]   -2.6[ -3.6]   -1.7[ -2.6]   -0.6[ -1.4]   -0.2[ -0.9]#  -0.1[ -0.7]#  +0.1[ -0.4]#  +0.2[ -0.2]#   60%   (point estimate: 50%)
   WIG-like              -4.1[ -5.2]   -3.2[ -4.2]   -2.3[ -3.3]   -1.6[ -2.4]   -0.9[ -1.7]   -0.4[ -1.1]   +0.3[ -0.4]#  +0.3[ -0.2]#  +0.5[ +0.1]#   70%   (point estimate: 50%)
   term coverage top1    -4.6[ -5.7]   -3.5[ -4.6]   -3.0[ -3.9]   -2.5[ -3.3]   -1.8[ -2.7]   -1.3[ -2.0]   -0.7[ -1.3]   -0.4[ -0.9]#  -0.3[ -0.7]#   80%   (point estimate: 70%)
   ORACLE                +1.9[ +1.1]#  +5.2[ +4.6]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +5.0[ +4.4]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -3.9[ -5.0]   -3.1[ -4.1]   -2.1[ -3.0]   -1.2[ -2.1]   -0.3[ -1.0]   -0.2[ -0.9]   -0.2[ -0.7]   +0.1[ -0.3]#  +0.1[ -0.2]#   80%   (point estimate: 50%)
   BM25 margin           -4.7[ -5.8]   -4.3[ -5.3]   -3.8[ -4.8]   -2.8[ -3.7]   -2.1[ -2.9]   -1.3[ -2.0]   -0.7[ -1.3]   -0.1[ -0.6]   +0.1[ -0.2]#   90%   (point estimate: 80%)
   top5 vs rest          -4.4[ -5.5]   -3.5[ -4.5]   -2.6[ -3.6]   -2.0[ -2.9]   -1.2[ -2.0]   -0.5[ -1.3]   -0.1[ -0.8]   +0.1[ -0.5]#  -0.0[ -0.4]#   80%   (point estimate: 70%)
   NQC-like spread       -4.5[ -5.6]   -3.6[ -4.6]   -2.6[ -3.6]   -1.7[ -2.6]   -0.6[ -1.4]   -0.2[ -0.9]   -0.1[ -0.7]   +0.1[ -0.4]#  +0.2[ -0.2]#   80%   (point estimate: 60%)
   WIG-like              -4.1[ -5.2]   -3.2[ -4.2]   -2.3[ -3.3]   -1.6[ -2.4]   -0.9[ -1.7]   -0.4[ -1.1]   +0.3[ -0.4]#  +0.3[ -0.2]#  +0.5[ +0.1]#   70%   (point estimate: 60%)
   term coverage top1    -4.6[ -5.7]   -3.5[ -4.6]   -3.0[ -3.9]   -2.5[ -3.3]   -1.8[ -2.7]   -1.3[ -2.0]   -0.7[ -1.3]   -0.4[ -0.9]   -0.3[ -0.7]    100%   (point estimate: 80%)
   ORACLE                +1.9[ +1.1]#  +5.2[ +4.6]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +6.1[ +5.5]#  +5.0[ +4.4]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      63% (sd  32)   -0.98 MRR              34%     37%
   tag alarm               100      60% (sd  30)   -0.97 MRR              36%     40%
   tag alarm               200      52% (sd  25)   -1.07 MRR              44%     48%
   BM25 margin              50      67% (sd  29)   -1.32 MRR              38%     33%
   BM25 margin             100      70% (sd  24)   -1.10 MRR              38%     30%
   BM25 margin             200      68% (sd  19)   -1.08 MRR              36%     32%
   top5 vs rest             50      65% (sd  31)   -1.08 MRR              35%     35%
   top5 vs rest            100      60% (sd  29)   -1.22 MRR              42%     40%
   top5 vs rest            200      58% (sd  23)   -1.11 MRR              43%     42%
   NQC-like spread          50      60% (sd  33)   -1.26 MRR              36%     40%
   NQC-like spread         100      56% (sd  30)   -1.32 MRR              40%     44%
   NQC-like spread         200      54% (sd  24)   -1.19 MRR              38%     46%
   WIG-like                 50      61% (sd  33)   -1.06 MRR              30%     39%
   WIG-like                100      56% (sd  28)   -1.08 MRR              38%     44%
   WIG-like                200      52% (sd  23)   -1.13 MRR              40%     48%
   term coverage top1       50      69% (sd  30)   -1.22 MRR              35%     31%
   term coverage top1      100      71% (sd  28)   -1.15 MRR              34%     29%
   term coverage top1      200      71% (sd  23)   -1.06 MRR              34%     29%

## dbpedia_test  (400 questions; tag alarm fires on 68 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  48.2  random  46.7  diff  +1.6  p=0.0670
   MRR  : tag  35.1  random  34.8  diff  +0.2  p=0.2621

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.2 (p=0.508)        +0.3 (p=0.628)
   40%            +0.8 (p=0.689)        +0.1 (p=0.791)
   50%            +0.5 (p=0.822)        +0.3 (p=0.374)
   17% nat        +0.5 (p=0.879)        +0.3 (p=0.651)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -17.8  95% CI [-22.2, -13.2]  p=0.000
   MRR  : -10.4  95% CI [-12.2, -8.6]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +0.8  p=0.798
   MRR  :  -0.0  p=0.955

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +2.8/+0.1 (p=0.840)  40%: +2.8/-0.2 (p=0.756)  50%: +1.5/-0.6 (p=0.488)  nat: +0.8/+0.0 (p=0.930)
   vs NQC-like spread      30%: +2.5/+0.0 (p=0.960)  40%: +4.0/+0.2 (p=0.786)  50%: +1.8/-0.7 (p=0.393)  nat: +0.5/+0.2 (p=0.732)
   vs WIG-like             30%: +1.0/-0.0 (p=0.998)  40%: +2.0/-0.1 (p=0.917)  50%: +1.2/-0.2 (p=0.776)  nat: +1.5/+0.2 (p=0.687)
   vs term coverage top1   30%: +2.2/+0.4 (p=0.471)  40%: +2.8/+0.4 (p=0.556)  50%: +1.0/+0.0 (p=0.960)  nat: +1.5/+0.4 (p=0.386)

G. each selector reranking 68 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -10.4  [-12.2, -8.6]  p=0.000
   BM25 margin          -10.7  [-12.5, -8.9]  p=0.000
   top5 vs rest         -10.5  [-12.3, -8.7]  p=0.000
   NQC-like spread      -10.6  [-12.4, -8.9]  p=0.000
   WIG-like             -10.6  [-12.4, -8.9]  p=0.000
   term coverage top1   -10.8  [-12.6, -9.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              34.2    35.7    36.8    37.9    39.0    40.3    41.8    43.4    44.4    45.5*   100%
   BM25 margin            34.0    35.1    36.5    37.7    38.7    40.4    41.9    43.3    44.2    45.5*   100%
   top5 vs rest           34.1    35.4    36.7    38.1    39.6    40.8    42.1    43.6    44.8    45.5*   100%
   NQC-like spread        33.9    35.2    36.8    37.6    39.7    41.1    42.4    43.9    44.7    45.5*   100%
   WIG-like               34.1    35.0    36.8    37.9    39.2    40.3    41.8    43.2    44.3    45.5*   100%
   term coverage top1     33.9    35.1    36.4    37.5    39.0    40.3    41.8    43.5    44.1    45.5*   100%
   ORACLE                 37.7    40.9    43.6    45.5*   46.7*   47.4*   47.5*   47.5*   47.2*   45.5*   40%
   random (expected)      33.9    35.2    36.5    37.8    39.1    40.3    41.6    42.9    44.2    45.5*   100%
   (BM25 only 32.7; rerank ALL 45.5)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -11.3[-13.1]   -9.8[-11.5]   -8.7[-10.3]   -7.6[ -9.2]   -6.5[ -7.9]   -5.2[ -6.5]   -3.7[ -4.9]   -2.1[ -3.0]   -1.1[ -1.7]    100%   (point estimate: 100%)
   BM25 margin          -11.5[-13.2]  -10.4[-12.1]   -8.9[-10.6]   -7.7[ -9.3]   -6.8[ -8.2]   -5.1[ -6.4]   -3.5[ -4.7]   -2.2[ -3.0]   -1.3[ -1.9]    100%   (point estimate: 100%)
   top5 vs rest         -11.4[-13.2]  -10.0[-11.8]   -8.8[-10.5]   -7.4[ -8.9]   -5.9[ -7.4]   -4.7[ -6.1]   -3.4[ -4.6]   -1.9[ -2.9]   -0.7[ -1.2]    100%   (point estimate: 90%)
   NQC-like spread      -11.5[-13.4]  -10.3[-12.1]   -8.7[-10.4]   -7.8[ -9.5]   -5.7[ -7.2]   -4.4[ -5.7]   -3.0[ -4.2]   -1.6[ -2.6]   -0.8[ -1.4]    100%   (point estimate: 90%)
   WIG-like             -11.4[-13.2]  -10.5[-12.3]   -8.7[-10.3]   -7.5[ -9.1]   -6.3[ -7.7]   -5.2[ -6.5]   -3.7[ -4.9]   -2.2[ -3.2]   -1.1[ -1.8]    100%   (point estimate: 100%)
   term coverage top1   -11.6[-13.4]  -10.4[-12.2]   -9.1[-10.8]   -8.0[ -9.6]   -6.5[ -8.0]   -5.1[ -6.5]   -3.7[ -4.9]   -2.0[ -2.9]   -1.4[ -2.1]    100%   (point estimate: 100%)
   ORACLE                -7.8[ -9.3]   -4.5[ -5.6]   -1.9[ -2.8]   +0.0[ -0.7]#  +1.3[ +0.6]#  +1.9[ +1.3]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +1.7[ +1.2]#   40%   (point estimate: 40%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -11.3[-13.1]   -9.8[-11.5]   -8.7[-10.3]   -7.6[ -9.2]   -6.5[ -7.9]   -5.2[ -6.5]   -3.7[ -4.9]   -2.1[ -3.0]   -1.1[ -1.7]    100%   (point estimate: 100%)
   BM25 margin          -11.5[-13.2]  -10.4[-12.1]   -8.9[-10.6]   -7.7[ -9.3]   -6.8[ -8.2]   -5.1[ -6.4]   -3.5[ -4.7]   -2.2[ -3.0]   -1.3[ -1.9]    100%   (point estimate: 100%)
   top5 vs rest         -11.4[-13.2]  -10.0[-11.8]   -8.8[-10.5]   -7.4[ -8.9]   -5.9[ -7.4]   -4.7[ -6.1]   -3.4[ -4.6]   -1.9[ -2.9]   -0.7[ -1.2]    100%   (point estimate: 100%)
   NQC-like spread      -11.5[-13.4]  -10.3[-12.1]   -8.7[-10.4]   -7.8[ -9.5]   -5.7[ -7.2]   -4.4[ -5.7]   -3.0[ -4.2]   -1.6[ -2.6]   -0.8[ -1.4]    100%   (point estimate: 100%)
   WIG-like             -11.4[-13.2]  -10.5[-12.3]   -8.7[-10.3]   -7.5[ -9.1]   -6.3[ -7.7]   -5.2[ -6.5]   -3.7[ -4.9]   -2.2[ -3.2]   -1.1[ -1.8]    100%   (point estimate: 100%)
   term coverage top1   -11.6[-13.4]  -10.4[-12.2]   -9.1[-10.8]   -8.0[ -9.6]   -6.5[ -8.0]   -5.1[ -6.5]   -3.7[ -4.9]   -2.0[ -2.9]   -1.4[ -2.1]    100%   (point estimate: 100%)
   ORACLE                -7.8[ -9.3]   -4.5[ -5.6]   -1.9[ -2.8]   +0.0[ -0.7]   +1.3[ +0.6]#  +1.9[ +1.3]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +1.7[ +1.2]#   50%   (point estimate: 40%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      94% (sd   7)   -0.70 MRR              46%      6%
   tag alarm               100      96% (sd   6)   -0.50 MRR              37%      4%
   tag alarm               200      97% (sd   5)   -0.39 MRR              26%      3%
   BM25 margin              50      94% (sd   7)   -0.69 MRR              43%      6%
   BM25 margin             100      96% (sd   5)   -0.54 MRR              38%      4%
   BM25 margin             200      98% (sd   4)   -0.36 MRR              24%      2%
   top5 vs rest             50      91% (sd   8)   -0.82 MRR              24%      9%
   top5 vs rest            100      91% (sd   7)   -0.80 MRR              18%      9%
   top5 vs rest            200      91% (sd   5)   -0.76 MRR              20%      9%
   NQC-like spread          50      91% (sd   9)   -0.81 MRR              24%      9%
   NQC-like spread         100      92% (sd   7)   -0.71 MRR              17%      8%
   NQC-like spread         200      91% (sd   5)   -0.87 MRR              31%      9%
   WIG-like                 50      95% (sd   7)   -0.67 MRR              44%      5%
   WIG-like                100      96% (sd   6)   -0.56 MRR              37%      4%
   WIG-like                200      97% (sd   5)   -0.41 MRR              26%      3%
   term coverage top1       50      95% (sd   7)   -0.70 MRR              38%      5%
   term coverage top1      100      97% (sd   5)   -0.45 MRR              27%      3%
   term coverage top1      200      98% (sd   4)   -0.33 MRR              20%      2%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  15%  MRR  33.2 | vs BM25 margin: +2.1 (p=0.072)  vs top5 vs rest: -0.9 (p=0.579)  vs NQC-like spread: -0.6 (p=0.696)  vs WIG-like: +0.2 (p=0.868)  vs term coverage top1: +0.4 (p=0.734)
   list           n= 105  fires  16%  MRR  32.6 | vs BM25 margin: -1.9 (p=0.163)  vs top5 vs rest: +0.6 (p=0.603)  vs NQC-like spread: +1.4 (p=0.258)  vs WIG-like: +1.0 (p=0.393)  vs term coverage top1: +1.4 (p=0.198)
   question       n= 125  fires  22%  MRR  23.5 | vs BM25 margin: +1.5 (p=0.213)  vs top5 vs rest: +0.6 (p=0.550)  vs NQC-like spread: +0.1 (p=0.931)  vs WIG-like: -0.8 (p=0.473)  vs term coverage top1: -0.4 (p=0.586)
   named entity   n=  86  fires  12%  MRR  56.7 | vs BM25 margin: -0.6 (p=0.498)  vs top5 vs rest: -0.5 (p=0.569)  vs NQC-like spread: -0.3 (p=0.753)  vs WIG-like: +0.7 (p=0.315)  vs term coverage top1: +0.4 (p=0.589)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR -0.2  [-1.5, +1.0]  p=0.795  (n=211)

## POOLED over 4 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  44.3  random  41.2  diff  +3.1  p=0.0001
   MRR  : tag  48.1  random  46.1  diff  +2.0  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +2.4 (p=0.000)   MRR  +1.6 (p=0.000)
   40%      Hit@1  +1.7 (p=0.000)   MRR  +1.2 (p=0.000)
   50%      Hit@1  +1.4 (p=0.000)   MRR  +1.2 (p=0.000)
   natural  Hit@1  +1.8 (p=0.000)   MRR  +1.5 (p=0.000)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -1.0  95% CI [-1.8, -0.2]  p=0.010
   MRR  :  -1.3  95% CI [-1.7, -0.8]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +1.2  p=0.001
   MRR  :  +0.5  p=0.027

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.7/+0.7 (p=0.001)  40%: +1.5/+0.5 (p=0.039)  50%: +1.3/+0.3 (p=0.122)  nat: +1.3/+0.6 (p=0.004)
   vs NQC-like spread      30%: +1.3/+0.5 (p=0.010)  40%: +0.8/+0.2 (p=0.387)  50%: +0.7/+0.1 (p=0.762)  nat: +0.6/+0.3 (p=0.218)
   vs WIG-like             30%: +0.8/+0.1 (p=0.652)  40%: +0.7/+0.0 (p=0.965)  50%: +0.6/-0.0 (p=0.961)  nat: +0.7/+0.2 (p=0.426)
   vs term coverage top1   30%: +2.1/+0.8 (p=0.000)  40%: +1.9/+0.6 (p=0.004)  50%: +1.8/+0.6 (p=0.005)  nat: +2.1/+1.0 (p=0.000)
