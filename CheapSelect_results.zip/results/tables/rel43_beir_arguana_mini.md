## beir_arguana  (1401 questions; tag alarm fires on 9 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.1  diff  +0.0  p=0.9951
   MRR  : tag  21.9  random  21.9  diff  -0.0  p=0.8287

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.1 (p=0.343)
   40%            +0.0 (p=1.000)        -0.0 (p=0.907)
   50%            +0.0 (p=1.000)        -0.0 (p=0.409)
   1% nat         +0.1 (p=1.000)        +0.0 (p=0.782)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.1  95% CI [+0.0, +0.2]  p=1.000
   MRR  :  +0.8  95% CI [-0.2, +1.7]  p=0.116

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (3%)
   Hit@1:  +0.0  p=1.000
   MRR  :  -0.0  p=0.961

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.1/-0.3 (p=0.478)  40%: -0.1/-0.0 (p=0.965)  50%: -0.1/+0.0 (p=0.991)  nat: +0.0/-0.1 (p=0.048)
   vs NQC-like spread      30%: -0.1/+0.3 (p=0.329)  40%: -0.1/+0.2 (p=0.469)  50%: -0.1/-0.0 (p=0.935)  nat: +0.0/-0.0 (p=0.606)
   vs WIG-like             30%: -0.1/-0.1 (p=0.828)  40%: -0.1/+0.2 (p=0.673)  50%: -0.1/+0.0 (p=0.961)  nat: +0.0/+0.0 (p=0.986)
   vs term coverage top1   30%: -0.1/-0.3 (p=0.370)  40%: -0.1/-0.3 (p=0.340)  50%: +0.0/-0.3 (p=0.348)  nat: +0.0/+0.0 (p=0.783)

G. each selector reranking 9 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +0.8  [-0.2, +1.7]  p=0.116
   BM25 margin           +0.7  [-0.2, +1.7]  p=0.125
   top5 vs rest          +0.9  [-0.1, +1.8]  p=0.072
   NQC-like spread       +0.8  [-0.1, +1.7]  p=0.103
   WIG-like              +0.8  [-0.2, +1.7]  p=0.116
   term coverage top1    +0.7  [-0.2, +1.7]  p=0.125

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              22.0*   22.1*   21.8*   21.7*   21.5*   21.3*   21.0*   20.9*   21.0*   21.1*   10%
   BM25 margin            22.1*   22.1*   21.8*   21.7*   21.5*   21.3*   21.0*   20.9*   21.0*   21.1*   10%
   top5 vs rest           22.1*   22.1*   22.0*   21.7*   21.5*   21.2*   21.1*   21.1*   21.1*   21.1*   10%
   NQC-like spread        21.8*   21.7*   21.5*   21.5*   21.5*   21.6*   21.5*   21.5*   21.3*   21.1*   10%
   WIG-like               22.1*   22.1*   21.8*   21.5*   21.4*   21.3*   20.9*   21.1*   21.2*   21.1*   10%
   term coverage top1     21.7*   22.0*   22.0*   22.0*   21.8*   21.8*   21.7*   21.6*   21.4*   21.1*   10%
   ORACLE                 25.2*   26.9*   27.7*   27.9*   27.9*   27.9*   27.5*   26.5*   24.6*   21.1*   10%
   random (expected)      21.8*   21.8*   21.7*   21.6*   21.5*   21.4*   21.4*   21.3*   21.2*   21.1*   10%
   (BM25 only 21.9; rerank ALL 21.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.42 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +0.9[ +0.0]#  +0.9[ +0.1]#  +0.7[ -0.1]#  +0.6[ -0.1]#  +0.3[ -0.3]#  +0.2[ -0.4]   -0.1[ -0.6]   -0.2[ -0.7]   -0.1[ -0.4]    100%   (point estimate: 10%)
   BM25 margin           +0.9[ +0.1]#  +0.9[ +0.1]#  +0.7[ -0.1]#  +0.6[ -0.1]#  +0.4[ -0.3]#  +0.2[ -0.4]#  -0.1[ -0.6]   -0.2[ -0.7]   -0.1[ -0.4]    100%   (point estimate: 10%)
   top5 vs rest          +1.0[ +0.1]#  +1.0[ +0.1]#  +0.9[ +0.1]#  +0.6[ -0.1]#  +0.3[ -0.3]#  +0.1[ -0.4]#  -0.1[ -0.5]   -0.0[ -0.4]#  -0.0[ -0.3]#   80%   (point estimate: 10%)
   NQC-like spread       +0.7[ -0.1]#  +0.6[ -0.2]#  +0.4[ -0.4]#  +0.4[ -0.3]#  +0.4[ -0.3]#  +0.4[ -0.2]#  +0.4[ -0.1]#  +0.4[ -0.0]#  +0.1[ -0.2]#   10%   (point estimate: 10%)
   WIG-like              +1.0[ +0.1]#  +1.0[ +0.2]#  +0.7[ -0.0]#  +0.4[ -0.3]#  +0.3[ -0.3]#  +0.1[ -0.4]   -0.2[ -0.7]   -0.0[ -0.4]#  +0.1[ -0.2]#   80%   (point estimate: 10%)
   term coverage top1    +0.6[ -0.2]#  +0.9[ +0.0]#  +0.9[ +0.2]#  +0.9[ +0.2]#  +0.7[ +0.0]#  +0.7[ +0.1]#  +0.6[ +0.1]#  +0.4[ +0.0]#  +0.3[ -0.0]#   10%   (point estimate: 10%)
   ORACLE                +4.1[ +3.4]#  +5.8[ +5.2]#  +6.6[ +6.0]#  +6.8[ +6.2]#  +6.8[ +6.2]#  +6.8[ +6.2]#  +6.4[ +5.8]#  +5.3[ +4.8]#  +3.5[ +2.9]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.42): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      66% (sd  38)   +0.21 MRR               0%     34%
   BM25 margin             100      51% (sd  42)   +0.40 MRR               0%     49%
   top5 vs rest            100      65% (sd  37)   +0.27 MRR               0%     35%
   NQC-like spread         100      59% (sd  39)   +0.35 MRR               0%     41%
   WIG-like                100      48% (sd  39)   +0.46 MRR               0%     52%
   term coverage top1      100      50% (sd  38)   +0.33 MRR               0%     50%

