## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.7  random  54.7  diff  +2.0  p=0.0272
   MRR  : tag  64.9  random  63.9  diff  +1.0  p=0.0609

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.2 (p=0.783)
   40%            +0.3 (p=1.000)        -0.3 (p=0.463)
   50%            +0.0 (p=1.000)        -0.6 (p=0.214)
   15% nat        +1.3 (p=0.501)        +0.4 (p=0.669)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.0  95% CI [-4.7, +4.7]  p=1.000
   MRR  :  -0.7  95% CI [-3.9, +2.5]  p=0.681

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (30%)
   Hit@1:  -1.3  p=0.570
   MRR  :  -0.5  p=0.680

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.3/+1.8 (p=0.132)  40%: +4.7/+2.9 (p=0.043)  50%: +4.3/+2.8 (p=0.052)  nat: +2.3/+1.1 (p=0.187)
   vs NQC-like spread      30%: +1.3/-0.3 (p=0.805)  40%: +2.0/+0.3 (p=0.806)  50%: +2.0/+1.0 (p=0.369)  nat: +0.3/-0.6 (p=0.481)
   vs WIG-like             30%: +2.3/+1.2 (p=0.355)  40%: +2.7/+1.5 (p=0.230)  50%: +3.3/+2.5 (p=0.046)  nat: +2.7/+1.1 (p=0.275)
   vs term coverage top1   30%: +1.0/+0.7 (p=0.558)  40%: +2.7/+2.1 (p=0.085)  50%: +3.0/+2.5 (p=0.026)  nat: +0.3/-0.2 (p=0.847)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.7  [-3.9, +2.5]  p=0.681
   BM25 margin           -1.1  [-4.2, +1.9]  p=0.472
   top5 vs rest          -1.8  [-5.2, +1.7]  p=0.324
   NQC-like spread       -0.1  [-3.3, +3.1]  p=0.952
   WIG-like              -1.8  [-4.9, +1.3]  p=0.251
   term coverage top1    -0.5  [-3.6, +2.5]  p=0.748

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              65.1*   65.2*   65.7*   66.6*   67.5*   67.8*   67.0*   66.3*   65.9*   65.6*   10%
   BM25 margin            63.7*   64.9*   66.0*   66.9*   68.1*   67.1*   66.9*   65.9*   65.9*   65.6*   10%
   top5 vs rest           63.5*   63.8*   63.9*   63.7*   64.6*   64.5*   65.0*   64.9*   65.1*   65.6*   10%
   NQC-like spread        64.5*   65.8*   66.0*   66.3*   66.5*   66.2*   66.3*   65.7*   65.6*   65.6*   10%
   WIG-like               64.0*   64.4*   64.6*   65.1*   64.9*   64.9*   64.7*   64.4*   65.7*   65.6*   10%
   term coverage top1     64.6*   64.2*   65.0*   64.5*   65.0*   65.5*   65.9*   65.7*   65.2*   65.6*   10%
   ORACLE                 70.4*   72.5*   72.5*   72.5*   72.5*   72.5*   72.5*   72.5*   71.5*   65.6*   10%
   random (expected)      63.8    64.0    64.2    64.4    64.6    64.8    65.0    65.2    65.4    65.6*   100%
   (BM25 only 63.6; rerank ALL 65.6)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.31 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.5[ -3.7]   -0.3[ -3.5]   +0.2[ -2.6]   +1.0[ -1.2]#  +1.9[ +0.1]#  +2.2[ +0.8]#  +1.4[ +0.5]#  +0.7[ +0.1]#  +0.3[ -0.0]#   40%   (point estimate: 10%)
   BM25 margin           -1.9[ -5.2]   -0.7[ -3.6]   +0.4[ -2.1]   +1.4[ -0.6]#  +2.5[ +1.0]#  +1.5[ +0.5]#  +1.3[ +0.5]#  +0.4[ -0.0]#  +0.3[ -0.0]#   40%   (point estimate: 20%)
   top5 vs rest          -2.0[ -5.5]   -1.7[ -5.1]   -1.7[ -5.0]   -1.9[ -5.0]   -1.0[ -3.7]   -1.1[ -3.7]   -0.6[ -3.0]   -0.6[ -2.5]   -0.4[ -1.9]    100%   (point estimate: 50%)
   NQC-like spread       -1.1[ -4.3]   +0.2[ -2.7]   +0.5[ -2.3]   +0.8[ -2.0]   +0.9[ -1.4]   +0.6[ -1.2]#  +0.7[ -0.8]#  +0.1[ -1.2]#  +0.0[ -0.8]#   60%   (point estimate: 10%)
   WIG-like              -1.5[ -4.8]   -1.2[ -4.1]   -1.0[ -3.7]   -0.4[ -2.8]   -0.6[ -2.8]   -0.7[ -2.8]   -0.8[ -2.6]   -1.2[ -2.7]   +0.1[ -0.8]#   90%   (point estimate: 20%)
   term coverage top1    -1.0[ -4.3]   -1.3[ -4.3]   -0.5[ -2.9]   -1.0[ -3.2]   -0.6[ -2.5]   -0.1[ -1.5]   +0.3[ -0.9]#  +0.1[ -1.0]#  -0.3[ -1.2]#   70%   (point estimate: 30%)
   ORACLE                +4.8[ +2.6]#  +6.9[ +4.9]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +5.9[ +4.0]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.31): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      20% (sd  14)   -0.28 MRR              15%     80%
   BM25 margin             100      19% (sd  11)   -1.16 MRR              55%     81%
   top5 vs rest            100      62% (sd  37)   -1.14 MRR              40%     38%
   NQC-like spread         100      24% (sd  24)   -1.05 MRR              50%     76%
   WIG-like                100      32% (sd  34)   -1.79 MRR              70%     68%
   term coverage top1      100      30% (sd  22)   -1.28 MRR              45%     70%

