## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.3  random  18.9  diff  +0.4  p=0.1541
   MRR  : tag  28.8  random  28.6  diff  +0.2  p=0.2881

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=0.677)        -0.4 (p=0.294)
   40%            +0.1 (p=1.000)        -0.1 (p=0.724)
   50%            +0.2 (p=0.803)        +0.0 (p=0.999)
   12% nat        +0.0 (p=1.000)        +0.2 (p=0.638)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.7  95% CI [-2.9, +1.5]  p=0.583
   MRR  :  -2.0  95% CI [-3.7, -0.4]  p=0.012

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +0.9  p=0.301
   MRR  :  +0.9  p=0.130

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.2/+0.5 (p=0.407)  40%: +1.2/+0.6 (p=0.374)  50%: +1.1/+0.4 (p=0.559)  nat: +0.5/+0.3 (p=0.470)
   vs NQC-like spread      30%: +0.9/+0.2 (p=0.682)  40%: +0.8/+0.1 (p=0.853)  50%: +0.6/+0.0 (p=0.973)  nat: +0.9/+0.6 (p=0.132)
   vs WIG-like             30%: +0.4/-0.3 (p=0.602)  40%: +0.1/-0.7 (p=0.215)  50%: +0.1/-0.5 (p=0.437)  nat: -0.1/-0.3 (p=0.488)
   vs term coverage top1   30%: +0.2/-0.5 (p=0.406)  40%: +0.3/-0.5 (p=0.382)  50%: -0.1/-0.6 (p=0.342)  nat: -0.3/-0.5 (p=0.280)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.0  [-3.7, -0.4]  p=0.012
   BM25 margin           -2.2  [-3.9, -0.7]  p=0.006
   top5 vs rest          -2.3  [-4.0, -0.7]  p=0.006
   NQC-like spread       -2.6  [-4.3, -1.0]  p=0.002
   WIG-like              -1.8  [-3.4, -0.2]  p=0.032
   term coverage top1    -1.5  [-3.1, +0.0]  p=0.053

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              28.9    28.9    29.2    29.5    30.0*   30.3*   30.5*   30.5*   30.6*   30.8*   50%
   BM25 margin            28.5    29.1    29.6*   29.6*   30.0*   30.2*   30.5*   30.5*   30.7*   30.8*   30%
   top5 vs rest           28.4    29.0    28.7    28.9    29.6*   30.4*   30.7*   30.8*   30.5*   30.8*   50%
   NQC-like spread        28.3    28.6    28.9    29.4    30.0*   30.4*   30.6*   30.8*   31.0*   30.8*   50%
   WIG-like               29.0    29.3    29.5*   30.2*   30.5*   31.1*   31.3*   31.0*   30.9*   30.8*   30%
   term coverage top1     29.3*   29.7*   29.6*   30.0*   30.5*   30.4*   30.7*   31.4*   30.9*   30.8*   10%
   ORACLE                 34.6*   36.4*   36.8*   36.8*   36.8*   36.8*   36.8*   36.7*   35.9*   30.8*   10%
   random (expected)      28.6    28.8    29.1    29.3    29.6    29.8    30.1    30.3    30.6    30.8*   100%
   (BM25 only 28.3; rerank ALL 30.8)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.62 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.9[ -3.6]   -2.0[ -3.5]   -1.7[ -3.1]   -1.3[ -2.6]   -0.8[ -2.0]   -0.5[ -1.5]   -0.3[ -1.3]   -0.3[ -1.1]   -0.2[ -0.6]    100%   (point estimate: 60%)
   BM25 margin           -2.3[ -3.9]   -1.8[ -3.3]   -1.3[ -2.6]   -1.2[ -2.4]   -0.8[ -2.0]   -0.6[ -1.7]   -0.3[ -1.2]   -0.3[ -1.0]   -0.1[ -0.5]#   90%   (point estimate: 70%)
   top5 vs rest          -2.4[ -4.1]   -1.9[ -3.4]   -2.1[ -3.6]   -1.9[ -3.2]   -1.2[ -2.5]   -0.5[ -1.6]   -0.1[ -1.1]   -0.0[ -0.9]   -0.3[ -1.0]    100%   (point estimate: 60%)
   NQC-like spread       -2.6[ -4.2]   -2.3[ -3.8]   -1.9[ -3.3]   -1.4[ -2.8]   -0.9[ -2.0]   -0.4[ -1.5]   -0.2[ -1.2]   -0.1[ -0.9]   +0.2[ -0.4]#   90%   (point estimate: 60%)
   WIG-like              -1.9[ -3.5]   -1.6[ -3.1]   -1.4[ -2.9]   -0.6[ -2.0]   -0.3[ -1.6]   +0.3[ -0.8]   +0.5[ -0.5]#  +0.1[ -0.7]   +0.1[ -0.6]#   90%   (point estimate: 40%)
   term coverage top1    -1.5[ -3.0]   -1.1[ -2.6]   -1.2[ -2.6]   -0.8[ -2.0]   -0.3[ -1.3]   -0.4[ -1.3]   -0.1[ -0.9]   +0.6[ +0.0]#  +0.1[ -0.3]#   80%   (point estimate: 50%)
   ORACLE                +3.7[ +2.6]#  +5.5[ +4.5]#  +5.9[ +4.9]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +6.0[ +5.0]#  +5.9[ +4.9]#  +5.1[ +4.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.62): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      64% (sd  34)   -0.80 MRR              30%     36%
   BM25 margin             100      60% (sd  34)   -0.93 MRR              45%     40%
   top5 vs rest            100      70% (sd  31)   -0.86 MRR              35%     30%
   NQC-like spread         100      74% (sd  28)   -0.48 MRR              25%     26%
   WIG-like                100      58% (sd  34)   -0.57 MRR              40%     42%
   term coverage top1      100      65% (sd  27)   -0.18 MRR              30%     35%

