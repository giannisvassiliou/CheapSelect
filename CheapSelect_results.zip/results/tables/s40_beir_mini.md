## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.7  random  54.7  diff  +2.0  p=0.0272
   MRR  : tag  64.9  random  63.9  diff  +1.0  p=0.0609

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.2 (p=0.783)
   40%            +0.3 (p=1.000)        -0.3 (p=0.463)
   50%            +0.0 (p=1.000)        -0.6 (p=0.214)
   15% nat        +1.3 (p=0.501)        +0.4 (p=0.669)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.0  95% CI [-4.7, +4.7]  p=1.000
   MRR  :  -0.7  95% CI [-3.9, +2.5]  p=0.681

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (30%)
   Hit@1:  -1.3  p=0.570
   MRR  :  -0.5  p=0.680

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.3/+1.8 (p=0.132)  40%: +4.7/+2.9 (p=0.043)  50%: +4.3/+2.8 (p=0.052)  nat: +2.3/+1.1 (p=0.187)
   vs NQC-like spread      30%: +1.3/-0.3 (p=0.805)  40%: +2.0/+0.3 (p=0.806)  50%: +2.0/+1.0 (p=0.369)  nat: +0.3/-0.6 (p=0.481)
   vs WIG-like             30%: +2.3/+1.2 (p=0.355)  40%: +2.7/+1.5 (p=0.230)  50%: +3.3/+2.5 (p=0.046)  nat: +2.7/+1.1 (p=0.275)
   vs term coverage top1   30%: +1.0/+0.7 (p=0.558)  40%: +2.7/+2.1 (p=0.085)  50%: +3.0/+2.5 (p=0.026)  nat: +0.3/-0.2 (p=0.847)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.7  [-3.9, +2.5]  p=0.681
   BM25 margin           -1.1  [-4.2, +1.9]  p=0.472
   top5 vs rest          -1.8  [-5.2, +1.7]  p=0.324
   NQC-like spread       -0.1  [-3.3, +3.1]  p=0.952
   WIG-like              -1.8  [-4.9, +1.3]  p=0.251
   term coverage top1    -0.5  [-3.6, +2.5]  p=0.748

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              65.1*   65.2*   65.7*   66.6*   67.5*   67.8*   67.0*   66.3*   65.9*   65.6*   10%
   BM25 margin            63.7*   64.9*   66.0*   66.9*   68.1*   67.1*   66.9*   65.9*   65.9*   65.6*   10%
   top5 vs rest           63.5*   63.8*   63.9*   63.7*   64.6*   64.5*   65.0*   64.9*   65.1*   65.6*   10%
   NQC-like spread        64.5*   65.8*   66.0*   66.3*   66.5*   66.2*   66.3*   65.7*   65.6*   65.6*   10%
   WIG-like               64.0*   64.4*   64.6*   65.1*   64.9*   64.9*   64.7*   64.4*   65.7*   65.6*   10%
   term coverage top1     64.6*   64.2*   65.0*   64.5*   65.0*   65.5*   65.9*   65.7*   65.2*   65.6*   10%
   ORACLE                 70.4*   72.5*   72.5*   72.5*   72.5*   72.5*   72.5*   72.5*   71.5*   65.6*   10%
   random (expected)      63.8    64.0    64.2    64.4    64.6    64.8    65.0    65.2    65.4    65.6*   100%
   (BM25 only 63.6; rerank ALL 65.6)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.5[ -3.7]   -0.3[ -3.5]   +0.2[ -2.6]   +1.0[ -1.2]   +1.9[ +0.1]#  +2.2[ +0.8]#  +1.4[ +0.5]#  +0.7[ +0.1]#  +0.3[ -0.0]#   50%   (point estimate: 10%)
   BM25 margin           -1.9[ -5.2]   -0.7[ -3.6]   +0.4[ -2.1]   +1.4[ -0.6]#  +2.5[ +1.0]#  +1.5[ +0.5]#  +1.3[ +0.5]#  +0.4[ -0.0]#  +0.3[ -0.0]#   40%   (point estimate: 20%)
   top5 vs rest          -2.0[ -5.5]   -1.7[ -5.1]   -1.7[ -5.0]   -1.9[ -5.0]   -1.0[ -3.7]   -1.1[ -3.7]   -0.6[ -3.0]   -0.6[ -2.5]   -0.4[ -1.9]    100%   (point estimate: 70%)
   NQC-like spread       -1.1[ -4.3]   +0.2[ -2.7]   +0.5[ -2.3]   +0.8[ -2.0]   +0.9[ -1.4]   +0.6[ -1.2]   +0.7[ -0.8]#  +0.1[ -1.2]   +0.0[ -0.8]#   90%   (point estimate: 20%)
   WIG-like              -1.5[ -4.8]   -1.2[ -4.1]   -1.0[ -3.7]   -0.4[ -2.8]   -0.6[ -2.8]   -0.7[ -2.8]   -0.8[ -2.6]   -1.2[ -2.7]   +0.1[ -0.8]#   90%   (point estimate: 90%)
   term coverage top1    -1.0[ -4.3]   -1.3[ -4.3]   -0.5[ -2.9]   -1.0[ -3.2]   -0.6[ -2.5]   -0.1[ -1.5]   +0.3[ -0.9]#  +0.1[ -1.0]#  -0.3[ -1.2]    100%   (point estimate: 50%)
   ORACLE                +4.8[ +2.6]#  +6.9[ +4.9]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +5.9[ +4.0]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.5[ -3.7]   -0.3[ -3.5]   +0.2[ -2.6]   +1.0[ -1.2]   +1.9[ +0.1]#  +2.2[ +0.8]#  +1.4[ +0.5]#  +0.7[ +0.1]#  +0.3[ -0.0]#   50%   (point estimate: 10%)
   BM25 margin           -1.9[ -5.2]   -0.7[ -3.6]   +0.4[ -2.1]   +1.4[ -0.6]   +2.5[ +1.0]#  +1.5[ +0.5]#  +1.3[ +0.5]#  +0.4[ -0.0]#  +0.3[ -0.0]#   50%   (point estimate: 30%)
   top5 vs rest          -2.0[ -5.5]   -1.7[ -5.1]   -1.7[ -5.0]   -1.9[ -5.0]   -1.0[ -3.7]   -1.1[ -3.7]   -0.6[ -3.0]   -0.6[ -2.5]   -0.4[ -1.9]    100%   (point estimate: 90%)
   NQC-like spread       -1.1[ -4.3]   +0.2[ -2.7]   +0.5[ -2.3]   +0.8[ -2.0]   +0.9[ -1.4]   +0.6[ -1.2]   +0.7[ -0.8]   +0.1[ -1.2]   +0.0[ -0.8]    100%   (point estimate: 20%)
   WIG-like              -1.5[ -4.8]   -1.2[ -4.1]   -1.0[ -3.7]   -0.4[ -2.8]   -0.6[ -2.8]   -0.7[ -2.8]   -0.8[ -2.6]   -1.2[ -2.7]   +0.1[ -0.8]    100%   (point estimate: 90%)
   term coverage top1    -1.0[ -4.3]   -1.3[ -4.3]   -0.5[ -2.9]   -1.0[ -3.2]   -0.6[ -2.5]   -0.1[ -1.5]   +0.3[ -0.9]   +0.1[ -1.0]   -0.3[ -1.2]    100%   (point estimate: 60%)
   ORACLE                +4.8[ +2.6]#  +6.9[ +4.9]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +7.0[ +5.0]#  +5.9[ +4.0]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      28% (sd  20)   +0.11 MRR              27%     72%
   tag alarm               100      24% (sd  16)   -0.11 MRR              37%     76%
   tag alarm               200      19% (sd  12)   -0.29 MRR              36%     81%
   BM25 margin              50      29% (sd  18)   -0.17 MRR              38%     71%
   BM25 margin             100      23% (sd  13)   -0.59 MRR              43%     77%
   BM25 margin             200      22% (sd   9)   -0.72 MRR              45%     78%
   top5 vs rest             50      67% (sd  36)   -0.99 MRR              38%     33%
   top5 vs rest            100      69% (sd  33)   -1.04 MRR              38%     31%
   top5 vs rest            200      63% (sd  28)   -1.53 MRR              46%     37%
   NQC-like spread          50      44% (sd  37)   -0.56 MRR              44%     56%
   NQC-like spread         100      32% (sd  29)   -0.59 MRR              44%     68%
   NQC-like spread         200      21% (sd  16)   -0.70 MRR              48%     79%
   WIG-like                 50      66% (sd  37)   -0.75 MRR              34%     34%
   WIG-like                100      60% (sd  36)   -0.88 MRR              36%     40%
   WIG-like                200      58% (sd  34)   -1.11 MRR              40%     42%
   term coverage top1       50      54% (sd  32)   -0.62 MRR              27%     46%
   term coverage top1      100      48% (sd  31)   -0.82 MRR              38%     52%
   term coverage top1      200      37% (sd  21)   -1.23 MRR              45%     63%

## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  44.3  random  44.1  diff  +0.2  p=0.4349
   MRR  : tag  52.3  random  52.3  diff  -0.0  p=0.4894

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.6 (p=0.630)        +0.1 (p=0.783)
   40%            +0.3 (p=1.000)        +0.1 (p=0.816)
   50%            +0.6 (p=0.503)        +0.3 (p=0.378)
   2% nat         +0.3 (p=1.000)        +0.1 (p=0.878)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.3  95% CI [-8.7, +0.0]  p=0.064
   MRR  :  -4.5  95% CI [-7.4, -1.7]  p=0.002

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (44%)
   Hit@1:  +0.3  p=1.000
   MRR  :  -0.3  p=0.813

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.4/+1.9 (p=0.088)  40%: +2.5/+2.1 (p=0.084)  50%: +3.1/+2.0 (p=0.089)  nat: +0.3/+0.1 (p=0.878)
   vs NQC-like spread      30%: +2.8/+1.2 (p=0.264)  40%: +1.5/+1.0 (p=0.399)  50%: +3.1/+1.7 (p=0.116)  nat: +0.3/+0.1 (p=0.878)
   vs WIG-like             30%: +2.8/+1.7 (p=0.128)  40%: +1.9/+1.6 (p=0.159)  50%: +1.9/+1.2 (p=0.292)  nat: +0.3/+0.1 (p=0.878)
   vs term coverage top1   30%: +2.8/+1.0 (p=0.350)  40%: +1.5/+0.6 (p=0.628)  50%: +0.3/-0.1 (p=0.910)  nat: +0.3/+0.1 (p=0.878)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -4.5  [-7.4, -1.7]  p=0.002
   BM25 margin           -4.7  [-7.7, -1.8]  p=0.002
   top5 vs rest          -4.7  [-7.7, -1.8]  p=0.002
   NQC-like spread       -4.7  [-7.7, -1.8]  p=0.002
   WIG-like              -4.7  [-7.7, -1.8]  p=0.002
   term coverage top1    -4.7  [-7.7, -1.8]  p=0.002

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              52.2    53.1    54.6    55.2*   55.9*   55.6*   56.1*   56.2*   56.7*   56.8*   40%
   BM25 margin            51.9    53.2    54.5    55.1*   55.6*   55.6*   56.1*   56.2*   56.7*   56.8*   40%
   top5 vs rest           51.7    51.7    52.7    53.0    53.9    54.5    55.7*   56.4*   57.2*   56.8*   70%
   NQC-like spread        51.6    53.5    53.4    54.2    54.3    55.8*   56.5*   56.7*   56.5*   56.8*   60%
   WIG-like               52.1    51.8    52.9    53.5    54.7    55.8*   56.0*   56.2*   56.6*   56.8*   60%
   term coverage top1     52.2    52.9    53.6    54.6    56.0*   55.8*   55.4    55.8*   56.3*   56.8*   80%
   ORACLE                 58.6*   61.1*   61.1*   61.1*   61.1*   61.1*   61.1*   61.1*   61.1*   56.8*   10%
   random (expected)      52.6    53.1    53.5    54.0    54.5    54.9    55.4    55.9    56.3    56.8*   100%
   (BM25 only 52.1; rerank ALL 56.8)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.6[ -7.4]   -3.7[ -6.2]   -2.2[ -4.4]   -1.6[ -3.6]   -0.9[ -2.5]   -1.2[ -2.7]   -0.7[ -1.8]   -0.6[ -1.4]   -0.1[ -0.5]#   90%   (point estimate: 70%)
   BM25 margin           -4.9[ -7.7]   -3.6[ -6.2]   -2.3[ -4.6]   -1.7[ -3.7]   -1.2[ -2.8]   -1.2[ -2.6]   -0.7[ -1.8]   -0.6[ -1.4]   -0.1[ -0.5]#   90%   (point estimate: 70%)
   top5 vs rest          -5.1[ -7.9]   -5.1[ -7.8]   -4.1[ -6.7]   -3.8[ -6.1]   -2.9[ -4.9]   -2.3[ -4.2]   -1.1[ -2.7]   -0.4[ -1.5]   +0.4[ -0.4]#   90%   (point estimate: 80%)
   NQC-like spread       -5.2[ -8.1]   -3.3[ -5.8]   -3.4[ -5.8]   -2.6[ -4.8]   -2.5[ -4.3]   -1.0[ -2.3]   -0.3[ -1.4]   -0.1[ -0.7]#  -0.3[ -0.8]#   80%   (point estimate: 60%)
   WIG-like              -4.7[ -7.5]   -5.0[ -7.5]   -3.9[ -6.4]   -3.3[ -5.5]   -2.1[ -4.1]   -1.0[ -2.8]   -0.8[ -2.1]   -0.6[ -1.7]   -0.2[ -0.7]#   90%   (point estimate: 60%)
   term coverage top1    -4.6[ -7.4]   -3.9[ -6.5]   -3.2[ -5.8]   -2.2[ -4.4]   -0.8[ -2.5]   -1.0[ -2.7]   -1.3[ -2.6]   -1.0[ -2.2]   -0.5[ -1.6]    100%   (point estimate: 90%)
   ORACLE                +1.8[ -0.1]#  +4.3[ +2.7]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.7]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.6[ -7.4]   -3.7[ -6.2]   -2.2[ -4.4]   -1.6[ -3.6]   -0.9[ -2.5]   -1.2[ -2.7]   -0.7[ -1.8]   -0.6[ -1.4]   -0.1[ -0.5]    100%   (point estimate: 90%)
   BM25 margin           -4.9[ -7.7]   -3.6[ -6.2]   -2.3[ -4.6]   -1.7[ -3.7]   -1.2[ -2.8]   -1.2[ -2.6]   -0.7[ -1.8]   -0.6[ -1.4]   -0.1[ -0.5]    100%   (point estimate: 90%)
   top5 vs rest          -5.1[ -7.9]   -5.1[ -7.8]   -4.1[ -6.7]   -3.8[ -6.1]   -2.9[ -4.9]   -2.3[ -4.2]   -1.1[ -2.7]   -0.4[ -1.5]   +0.4[ -0.4]#   90%   (point estimate: 80%)
   NQC-like spread       -5.2[ -8.1]   -3.3[ -5.8]   -3.4[ -5.8]   -2.6[ -4.8]   -2.5[ -4.3]   -1.0[ -2.3]   -0.3[ -1.4]   -0.1[ -0.7]   -0.3[ -0.8]    100%   (point estimate: 70%)
   WIG-like              -4.7[ -7.5]   -5.0[ -7.5]   -3.9[ -6.4]   -3.3[ -5.5]   -2.1[ -4.1]   -1.0[ -2.8]   -0.8[ -2.1]   -0.6[ -1.7]   -0.2[ -0.7]    100%   (point estimate: 90%)
   term coverage top1    -4.6[ -7.4]   -3.9[ -6.5]   -3.2[ -5.8]   -2.2[ -4.4]   -0.8[ -2.5]   -1.0[ -2.7]   -1.3[ -2.6]   -1.0[ -2.2]   -0.5[ -1.6]    100%   (point estimate: 100%)
   ORACLE                +1.8[ -0.1]#  +4.3[ +2.7]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.7]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      61% (sd  27)   -1.41 MRR              40%     39%
   tag alarm               100      62% (sd  24)   -1.40 MRR              38%     38%
   tag alarm               200      64% (sd  16)   -1.16 MRR              36%     36%
   BM25 margin              50      61% (sd  26)   -1.42 MRR              42%     39%
   BM25 margin             100      67% (sd  23)   -1.18 MRR              34%     33%
   BM25 margin             200      63% (sd  18)   -1.33 MRR              44%     37%
   top5 vs rest             50      71% (sd  25)   -1.37 MRR              42%     29%
   top5 vs rest            100      72% (sd  17)   -1.28 MRR              43%     28%
   top5 vs rest            200      75% (sd   7)   -1.16 MRR              50%     25%
   NQC-like spread          50      69% (sd  24)   -1.08 MRR              34%     31%
   NQC-like spread         100      66% (sd  17)   -0.93 MRR              36%     34%
   NQC-like spread         200      65% (sd   7)   -0.88 MRR              44%     35%
   WIG-like                 50      73% (sd  24)   -1.15 MRR              34%     27%
   WIG-like                100      69% (sd  18)   -1.27 MRR              46%     31%
   WIG-like                200      71% (sd  13)   -1.01 MRR              41%     29%
   term coverage top1       50      67% (sd  30)   -1.28 MRR              34%     33%
   term coverage top1      100      69% (sd  23)   -0.99 MRR              31%     31%
   term coverage top1      200      65% (sd  18)   -1.18 MRR              46%     35%

## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  25.3  random  24.9  diff  +0.4  p=0.3320
   MRR  : tag  33.4  random  33.2  diff  +0.2  p=0.3496

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -1.7 (p=0.154)        -1.8 (p=0.032)
   40%            -0.2 (p=1.000)        -0.1 (p=0.850)
   50%            +0.0 (p=1.000)        +0.0 (p=0.992)
   25% nat        -1.5 (p=0.227)        -1.8 (p=0.066)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.9  95% CI [-10.8, -4.9]  p=0.000
   MRR  :  -8.7  95% CI [-10.9, -6.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (51%)
   Hit@1:  +0.9  p=0.472
   MRR  :  +0.4  p=0.593

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.2/-0.5 (p=0.591)  40%: +1.5/+1.1 (p=0.232)  50%: +2.3/+1.9 (p=0.050)  nat: -0.3/-0.6 (p=0.464)
   vs NQC-like spread      30%: -0.5/-0.9 (p=0.322)  40%: +1.9/+1.4 (p=0.137)  50%: +2.0/+1.7 (p=0.064)  nat: -0.8/-1.2 (p=0.175)
   vs WIG-like             30%: +0.6/-0.1 (p=0.933)  40%: +2.5/+1.7 (p=0.075)  50%: +2.0/+1.5 (p=0.112)  nat: +0.6/-0.2 (p=0.849)
   vs term coverage top1   30%: +1.2/+0.6 (p=0.435)  40%: +2.2/+1.8 (p=0.053)  50%: +1.2/+1.1 (p=0.265)  nat: +0.8/+0.4 (p=0.598)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -8.7  [-10.9, -6.3]  p=0.000
   BM25 margin           -6.9  [-9.0, -4.8]  p=0.000
   top5 vs rest          -8.0  [-10.3, -5.8]  p=0.000
   NQC-like spread       -7.5  [-9.7, -5.4]  p=0.000
   WIG-like              -8.5  [-10.8, -6.2]  p=0.000
   term coverage top1    -9.0  [-11.4, -6.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              32.0    33.0    34.2    36.7    38.0    39.3    39.7    40.6    41.7*   42.0*   90%
   BM25 margin            32.0    34.4    36.1    36.8    38.0    38.4    39.4    40.7    41.3    42.0*   100%
   top5 vs rest           31.7    33.6    34.7    35.5    36.1    37.0    38.3    39.4    40.7    42.0*   100%
   NQC-like spread        32.5    34.2    35.1    35.3    36.3    37.5    38.4    39.3    40.9    42.0*   100%
   WIG-like               31.5    32.7    34.3    35.0    36.5    37.8    38.7    39.8    41.1    42.0*   100%
   term coverage top1     31.5    32.5    33.6    34.9    36.9    38.5    40.0    40.7    41.7*   42.0*   90%
   ORACLE                 38.9    43.7*   45.4*   45.7*   45.7*   45.7*   45.7*   45.7*   45.6*   42.0*   20%
   random (expected)      31.4    32.6    33.8    35.0    36.1    37.3    38.5    39.7    40.9    42.0*   100%
   (BM25 only 30.3; rerank ALL 42.0)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -10.0[-12.5]   -9.1[-11.4]   -7.8[-10.0]   -5.4[ -7.2]   -4.1[ -5.6]   -2.8[ -4.2]   -2.4[ -3.6]   -1.4[ -2.4]   -0.3[ -0.8]#   90%   (point estimate: 90%)
   BM25 margin          -10.0[-12.4]   -7.6[ -9.7]   -6.0[ -7.9]   -5.2[ -7.0]   -4.1[ -5.7]   -3.6[ -5.0]   -2.6[ -3.8]   -1.3[ -2.2]   -0.7[ -1.3]    100%   (point estimate: 90%)
   top5 vs rest         -10.4[-12.8]   -8.5[-10.7]   -7.3[ -9.3]   -6.5[ -8.5]   -5.9[ -7.8]   -5.1[ -6.8]   -3.8[ -5.3]   -2.6[ -4.0]   -1.4[ -2.2]    100%   (point estimate: 100%)
   NQC-like spread       -9.6[-11.9]   -7.9[-10.1]   -6.9[ -8.9]   -6.7[ -8.7]   -5.7[ -7.6]   -4.5[ -6.2]   -3.7[ -5.2]   -2.8[ -4.0]   -1.2[ -2.0]    100%   (point estimate: 100%)
   WIG-like             -10.6[-12.9]   -9.4[-11.6]   -7.8[-10.0]   -7.0[ -9.1]   -5.6[ -7.5]   -4.3[ -6.0]   -3.3[ -4.9]   -2.3[ -3.7]   -1.0[ -1.9]    100%   (point estimate: 90%)
   term coverage top1   -10.5[-12.8]   -9.6[-11.9]   -8.4[-10.6]   -7.2[ -9.2]   -5.1[ -7.0]   -3.5[ -5.1]   -2.1[ -3.4]   -1.4[ -2.5]   -0.4[ -1.2]    100%   (point estimate: 90%)
   ORACLE                -3.2[ -4.8]   +1.7[ +0.5]#  +3.4[ +2.3]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -10.0[-12.5]   -9.1[-11.4]   -7.8[-10.0]   -5.4[ -7.2]   -4.1[ -5.6]   -2.8[ -4.2]   -2.4[ -3.6]   -1.4[ -2.4]   -0.3[ -0.8]    100%   (point estimate: 90%)
   BM25 margin          -10.0[-12.4]   -7.6[ -9.7]   -6.0[ -7.9]   -5.2[ -7.0]   -4.1[ -5.7]   -3.6[ -5.0]   -2.6[ -3.8]   -1.3[ -2.2]   -0.7[ -1.3]    100%   (point estimate: 100%)
   top5 vs rest         -10.4[-12.8]   -8.5[-10.7]   -7.3[ -9.3]   -6.5[ -8.5]   -5.9[ -7.8]   -5.1[ -6.8]   -3.8[ -5.3]   -2.6[ -4.0]   -1.4[ -2.2]    100%   (point estimate: 100%)
   NQC-like spread       -9.6[-11.9]   -7.9[-10.1]   -6.9[ -8.9]   -6.7[ -8.7]   -5.7[ -7.6]   -4.5[ -6.2]   -3.7[ -5.2]   -2.8[ -4.0]   -1.2[ -2.0]    100%   (point estimate: 100%)
   WIG-like             -10.6[-12.9]   -9.4[-11.6]   -7.8[-10.0]   -7.0[ -9.1]   -5.6[ -7.5]   -4.3[ -6.0]   -3.3[ -4.9]   -2.3[ -3.7]   -1.0[ -1.9]    100%   (point estimate: 100%)
   term coverage top1   -10.5[-12.8]   -9.6[-11.9]   -8.4[-10.6]   -7.2[ -9.2]   -5.1[ -7.0]   -3.5[ -5.1]   -2.1[ -3.4]   -1.4[ -2.5]   -0.4[ -1.2]    100%   (point estimate: 90%)
   ORACLE                -3.2[ -4.8]   +1.7[ +0.5]#  +3.4[ +2.3]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      82% (sd  20)   -1.41 MRR              42%     18%
   tag alarm               100      84% (sd  13)   -1.07 MRR              33%     16%
   tag alarm               200      87% (sd   7)   -0.78 MRR              28%     13%
   BM25 margin              50      83% (sd  18)   -1.45 MRR              43%     17%
   BM25 margin             100      88% (sd  11)   -1.03 MRR              30%     12%
   BM25 margin             200      90% (sd   8)   -0.87 MRR              24%     10%
   top5 vs rest             50      91% (sd  16)   -1.21 MRR              46%      9%
   top5 vs rest            100      93% (sd  12)   -1.00 MRR              45%      7%
   top5 vs rest            200      95% (sd   7)   -0.76 MRR              41%      5%
   NQC-like spread          50      92% (sd  11)   -1.05 MRR              52%      8%
   NQC-like spread         100      93% (sd  10)   -0.83 MRR              46%      7%
   NQC-like spread         200      96% (sd   6)   -0.61 MRR              38%      4%
   WIG-like                 50      90% (sd  17)   -1.21 MRR              35%     10%
   WIG-like                100      92% (sd  12)   -0.99 MRR              34%      8%
   WIG-like                200      94% (sd   7)   -0.77 MRR              36%      6%
   term coverage top1       50      85% (sd  17)   -1.24 MRR              38%     15%
   term coverage top1      100      86% (sd  13)   -1.08 MRR              40%     14%
   term coverage top1      200      87% (sd  10)   -0.92 MRR              42%     13%

## beir_arguana  (1401 questions; tag alarm fires on 9 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.1  diff  +0.0  p=0.9927
   MRR  : tag  21.9  random  21.9  diff  -0.0  p=0.8240

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.1 (p=0.343)
   40%            +0.0 (p=1.000)        -0.0 (p=0.907)
   50%            +0.0 (p=1.000)        -0.0 (p=0.409)
   1% nat         +0.1 (p=1.000)        +0.0 (p=0.782)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.1  95% CI [+0.0, +0.2]  p=1.000
   MRR  :  +0.8  95% CI [-0.2, +1.7]  p=0.116

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (3%)
   Hit@1:  +0.0  p=1.000
   MRR  :  -0.0  p=0.961

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.1/-0.3 (p=0.478)  40%: -0.1/-0.0 (p=0.965)  50%: -0.1/+0.0 (p=0.991)  nat: +0.0/-0.1 (p=0.048)
   vs NQC-like spread      30%: -0.1/+0.3 (p=0.329)  40%: -0.1/+0.2 (p=0.469)  50%: -0.1/-0.0 (p=0.935)  nat: +0.0/-0.0 (p=0.606)
   vs WIG-like             30%: -0.1/-0.1 (p=0.828)  40%: -0.1/+0.2 (p=0.673)  50%: -0.1/+0.0 (p=0.961)  nat: +0.0/+0.0 (p=0.986)
   vs term coverage top1   30%: -0.1/-0.3 (p=0.370)  40%: -0.1/-0.3 (p=0.340)  50%: +0.0/-0.3 (p=0.348)  nat: +0.0/+0.0 (p=0.783)

G. each selector reranking 9 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +0.8  [-0.2, +1.7]  p=0.116
   BM25 margin           +0.7  [-0.2, +1.7]  p=0.125
   top5 vs rest          +0.9  [-0.1, +1.8]  p=0.072
   NQC-like spread       +0.8  [-0.1, +1.7]  p=0.103
   WIG-like              +0.8  [-0.2, +1.7]  p=0.116
   term coverage top1    +0.7  [-0.2, +1.7]  p=0.125

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              22.0*   22.1*   21.8*   21.7*   21.5*   21.3*   21.0*   20.9*   21.0*   21.1*   10%
   BM25 margin            22.1*   22.1*   21.8*   21.7*   21.5*   21.3*   21.0*   20.9*   21.0*   21.1*   10%
   top5 vs rest           22.1*   22.1*   22.0*   21.7*   21.5*   21.2*   21.1*   21.1*   21.1*   21.1*   10%
   NQC-like spread        21.8*   21.7*   21.5*   21.5*   21.5*   21.6*   21.5*   21.5*   21.3*   21.1*   10%
   WIG-like               22.1*   22.1*   21.8*   21.5*   21.4*   21.3*   20.9*   21.1*   21.2*   21.1*   10%
   term coverage top1     21.7*   22.0*   22.0*   22.0*   21.8*   21.8*   21.7*   21.6*   21.4*   21.1*   10%
   ORACLE                 25.2*   26.9*   27.7*   27.9*   27.9*   27.9*   27.5*   26.5*   24.6*   21.1*   10%
   random (expected)      21.8*   21.8*   21.7*   21.6*   21.5*   21.4*   21.4*   21.3*   21.2*   21.1*   10%
   (BM25 only 21.9; rerank ALL 21.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +0.9[ +0.0]#  +0.9[ +0.1]#  +0.7[ -0.1]#  +0.6[ -0.1]#  +0.3[ -0.3]#  +0.2[ -0.4]#  -0.1[ -0.6]#  -0.2[ -0.7]#  -0.1[ -0.4]#   10%   (point estimate: 10%)
   BM25 margin           +0.9[ +0.1]#  +0.9[ +0.1]#  +0.7[ -0.1]#  +0.6[ -0.1]#  +0.4[ -0.3]#  +0.2[ -0.4]#  -0.1[ -0.6]#  -0.2[ -0.7]#  -0.1[ -0.4]#   10%   (point estimate: 10%)
   top5 vs rest          +1.0[ +0.1]#  +1.0[ +0.1]#  +0.9[ +0.1]#  +0.6[ -0.1]#  +0.3[ -0.3]#  +0.1[ -0.4]#  -0.1[ -0.5]#  -0.0[ -0.4]#  -0.0[ -0.3]#   10%   (point estimate: 10%)
   NQC-like spread       +0.7[ -0.1]#  +0.6[ -0.2]#  +0.4[ -0.4]#  +0.4[ -0.3]#  +0.4[ -0.3]#  +0.4[ -0.2]#  +0.4[ -0.1]#  +0.4[ -0.0]#  +0.1[ -0.2]#   10%   (point estimate: 10%)
   WIG-like              +1.0[ +0.1]#  +1.0[ +0.2]#  +0.7[ -0.0]#  +0.4[ -0.3]#  +0.3[ -0.3]#  +0.1[ -0.4]#  -0.2[ -0.7]#  -0.0[ -0.4]#  +0.1[ -0.2]#   10%   (point estimate: 10%)
   term coverage top1    +0.6[ -0.2]#  +0.9[ +0.0]#  +0.9[ +0.2]#  +0.9[ +0.2]#  +0.7[ +0.0]#  +0.7[ +0.1]#  +0.6[ +0.1]#  +0.4[ +0.0]#  +0.3[ -0.0]#   10%   (point estimate: 10%)
   ORACLE                +4.1[ +3.4]#  +5.8[ +5.2]#  +6.6[ +6.0]#  +6.8[ +6.2]#  +6.8[ +6.2]#  +6.8[ +6.2]#  +6.4[ +5.8]#  +5.3[ +4.8]#  +3.5[ +2.9]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +0.9[ +0.0]#  +0.9[ +0.1]#  +0.7[ -0.1]#  +0.6[ -0.1]#  +0.3[ -0.3]#  +0.2[ -0.4]#  -0.1[ -0.6]   -0.2[ -0.7]   -0.1[ -0.4]#   90%   (point estimate: 10%)
   BM25 margin           +0.9[ +0.1]#  +0.9[ +0.1]#  +0.7[ -0.1]#  +0.6[ -0.1]#  +0.4[ -0.3]#  +0.2[ -0.4]#  -0.1[ -0.6]   -0.2[ -0.7]   -0.1[ -0.4]#   90%   (point estimate: 10%)
   top5 vs rest          +1.0[ +0.1]#  +1.0[ +0.1]#  +0.9[ +0.1]#  +0.6[ -0.1]#  +0.3[ -0.3]#  +0.1[ -0.4]#  -0.1[ -0.5]   -0.0[ -0.4]#  -0.0[ -0.3]#   80%   (point estimate: 10%)
   NQC-like spread       +0.7[ -0.1]#  +0.6[ -0.2]#  +0.4[ -0.4]#  +0.4[ -0.3]#  +0.4[ -0.3]#  +0.4[ -0.2]#  +0.4[ -0.1]#  +0.4[ -0.0]#  +0.1[ -0.2]#   10%   (point estimate: 10%)
   WIG-like              +1.0[ +0.1]#  +1.0[ +0.2]#  +0.7[ -0.0]#  +0.4[ -0.3]#  +0.3[ -0.3]#  +0.1[ -0.4]#  -0.2[ -0.7]   -0.0[ -0.4]#  +0.1[ -0.2]#   80%   (point estimate: 10%)
   term coverage top1    +0.6[ -0.2]#  +0.9[ +0.0]#  +0.9[ +0.2]#  +0.9[ +0.2]#  +0.7[ +0.0]#  +0.7[ +0.1]#  +0.6[ +0.1]#  +0.4[ +0.0]#  +0.3[ -0.0]#   10%   (point estimate: 10%)
   ORACLE                +4.1[ +3.4]#  +5.8[ +5.2]#  +6.6[ +6.0]#  +6.8[ +6.2]#  +6.8[ +6.2]#  +6.8[ +6.2]#  +6.4[ +5.8]#  +5.3[ +4.8]#  +3.5[ +2.9]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      47% (sd  37)   +0.40 MRR               0%     53%
   tag alarm               100      36% (sd  36)   +0.55 MRR               0%     64%
   tag alarm               200      18% (sd  21)   +0.74 MRR               0%     82%
   BM25 margin              50      46% (sd  39)   +0.45 MRR               0%     54%
   BM25 margin             100      34% (sd  34)   +0.58 MRR               0%     66%
   BM25 margin             200      25% (sd  30)   +0.70 MRR               0%     75%
   top5 vs rest             50      39% (sd  35)   +0.58 MRR               0%     61%
   top5 vs rest            100      31% (sd  32)   +0.68 MRR               0%     69%
   top5 vs rest            200      17% (sd  20)   +0.86 MRR               0%     83%
   NQC-like spread          50      36% (sd  33)   +0.51 MRR               0%     64%
   NQC-like spread         100      24% (sd  27)   +0.60 MRR               0%     76%
   NQC-like spread         200      14% (sd  14)   +0.67 MRR               0%     86%
   WIG-like                 50      40% (sd  36)   +0.59 MRR               0%     60%
   WIG-like                100      30% (sd  31)   +0.70 MRR               0%     70%
   WIG-like                200      20% (sd  24)   +0.87 MRR               0%     80%
   term coverage top1       50      40% (sd  36)   +0.45 MRR               0%     60%
   term coverage top1      100      29% (sd  30)   +0.55 MRR               0%     71%
   term coverage top1      200      19% (sd  22)   +0.63 MRR               0%     81%

## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.4  random  18.8  diff  +0.6  p=0.0776
   MRR  : tag  28.8  random  28.5  diff  +0.3  p=0.0999

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.0 (p=0.965)
   40%            +0.6 (p=0.212)        +0.3 (p=0.214)
   50%            -0.2 (p=0.789)        -0.1 (p=0.725)
   12% nat        +0.0 (p=1.000)        +0.3 (p=0.472)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.3  95% CI [-2.5, +1.8]  p=0.848
   MRR  :  -1.1  95% CI [-2.6, +0.4]  p=0.165

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +0.2  p=0.897
   MRR  :  +0.6  p=0.332

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.6/+0.5 (p=0.292)  40%: +2.0/+0.8 (p=0.194)  50%: +1.4/+0.3 (p=0.605)  nat: +0.7/+0.4 (p=0.263)
   vs NQC-like spread      30%: +1.8/+0.7 (p=0.153)  40%: +1.5/+0.5 (p=0.321)  50%: +1.4/+0.5 (p=0.373)  nat: +0.8/+0.5 (p=0.163)
   vs WIG-like             30%: +1.1/+0.1 (p=0.891)  40%: +0.8/-0.2 (p=0.669)  50%: +0.3/-0.5 (p=0.380)  nat: +0.8/+0.3 (p=0.496)
   vs term coverage top1   30%: +1.0/+0.0 (p=0.980)  40%: +1.3/+0.2 (p=0.762)  50%: +0.2/-0.6 (p=0.313)  nat: +0.2/-0.2 (p=0.646)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -1.1  [-2.6, +0.4]  p=0.165
   BM25 margin           -1.3  [-2.8, +0.1]  p=0.082
   top5 vs rest          -1.5  [-3.0, +0.1]  p=0.065
   NQC-like spread       -1.6  [-3.1, -0.0]  p=0.043
   WIG-like              -1.3  [-2.8, +0.2]  p=0.091
   term coverage top1    -0.9  [-2.4, +0.6]  p=0.246

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              28.8*   28.9*   28.9*   29.0*   29.1*   29.5*   29.5*   29.5*   29.8*   29.9*   10%
   BM25 margin            28.5*   28.8*   28.9*   28.6    29.2*   29.4*   29.4*   29.6*   29.8*   29.9*   50%
   top5 vs rest           28.4*   28.7*   28.4    28.2    28.8*   29.2*   29.5*   29.6*   29.5*   29.9*   50%
   NQC-like spread        28.3    28.5*   28.2    28.4    28.6    28.9*   29.4*   29.6*   29.7*   29.9*   60%
   WIG-like               28.6*   28.6*   28.8*   29.2*   29.6*   29.9*   30.1*   29.7*   29.6*   29.9*   10%
   term coverage top1     29.1*   29.2*   28.9*   28.8*   29.7*   29.8*   30.0*   30.4*   30.0*   29.9*   10%
   ORACLE                 33.9*   35.2*   35.5*   35.5*   35.5*   35.5*   35.5*   35.5*   34.7*   29.9*   10%
   random (expected)      28.5    28.6    28.8    28.9    29.1    29.3    29.4    29.6    29.7    29.9*   100%
   (BM25 only 28.3; rerank ALL 29.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.1[ -2.5]   -1.0[ -2.4]   -1.0[ -2.3]   -0.9[ -2.1]   -0.8[ -1.9]   -0.4[ -1.4]   -0.4[ -1.2]   -0.3[ -0.9]#  -0.1[ -0.4]#   80%   (point estimate: 30%)
   BM25 margin           -1.4[ -2.8]   -1.1[ -2.5]   -1.0[ -2.2]   -1.3[ -2.4]   -0.7[ -1.8]   -0.5[ -1.5]   -0.5[ -1.3]   -0.3[ -0.9]#  -0.1[ -0.4]#   80%   (point estimate: 50%)
   top5 vs rest          -1.5[ -3.0]   -1.2[ -2.6]   -1.5[ -2.9]   -1.7[ -3.0]   -1.1[ -2.3]   -0.7[ -1.7]   -0.4[ -1.4]   -0.3[ -1.1]   -0.4[ -0.9]#   90%   (point estimate: 60%)
   NQC-like spread       -1.6[ -3.1]   -1.4[ -2.9]   -1.7[ -3.1]   -1.5[ -2.7]   -1.3[ -2.5]   -1.0[ -2.0]   -0.5[ -1.3]   -0.3[ -1.0]#  -0.2[ -0.8]#   80%   (point estimate: 60%)
   WIG-like              -1.3[ -2.8]   -1.2[ -2.7]   -1.1[ -2.5]   -0.7[ -2.0]   -0.3[ -1.5]   -0.0[ -1.1]   +0.2[ -0.8]#  -0.2[ -1.0]   -0.3[ -1.0]#   90%   (point estimate: 40%)
   term coverage top1    -0.8[ -2.3]   -0.7[ -2.1]   -1.0[ -2.3]   -1.1[ -2.2]   -0.2[ -1.2]   -0.1[ -0.9]#  +0.1[ -0.6]#  +0.5[ -0.1]#  +0.2[ -0.2]#   60%   (point estimate: 50%)
   ORACLE                +4.0[ +3.1]#  +5.3[ +4.4]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +4.8[ +3.9]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -1.1[ -2.5]   -1.0[ -2.4]   -1.0[ -2.3]   -0.9[ -2.1]   -0.8[ -1.9]   -0.4[ -1.4]   -0.4[ -1.2]   -0.3[ -0.9]   -0.1[ -0.4]#   90%   (point estimate: 60%)
   BM25 margin           -1.4[ -2.8]   -1.1[ -2.5]   -1.0[ -2.2]   -1.3[ -2.4]   -0.7[ -1.8]   -0.5[ -1.5]   -0.5[ -1.3]   -0.3[ -0.9]   -0.1[ -0.4]#   90%   (point estimate: 70%)
   top5 vs rest          -1.5[ -3.0]   -1.2[ -2.6]   -1.5[ -2.9]   -1.7[ -3.0]   -1.1[ -2.3]   -0.7[ -1.7]   -0.4[ -1.4]   -0.3[ -1.1]   -0.4[ -0.9]    100%   (point estimate: 70%)
   NQC-like spread       -1.6[ -3.1]   -1.4[ -2.9]   -1.7[ -3.1]   -1.5[ -2.7]   -1.3[ -2.5]   -1.0[ -2.0]   -0.5[ -1.3]   -0.3[ -1.0]   -0.2[ -0.8]    100%   (point estimate: 70%)
   WIG-like              -1.3[ -2.8]   -1.2[ -2.7]   -1.1[ -2.5]   -0.7[ -2.0]   -0.3[ -1.5]   -0.0[ -1.1]   +0.2[ -0.8]   -0.2[ -1.0]   -0.3[ -1.0]    100%   (point estimate: 50%)
   term coverage top1    -0.8[ -2.3]   -0.7[ -2.1]   -1.0[ -2.3]   -1.1[ -2.2]   -0.2[ -1.2]   -0.1[ -0.9]   +0.1[ -0.6]   +0.5[ -0.1]#  +0.2[ -0.2]#   80%   (point estimate: 50%)
   ORACLE                +4.0[ +3.1]#  +5.3[ +4.4]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +5.6[ +4.7]#  +4.8[ +3.9]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      59% (sd  34)   -0.56 MRR              30%     41%
   tag alarm               100      55% (sd  33)   -0.64 MRR              33%     45%
   tag alarm               200      50% (sd  32)   -0.75 MRR              38%     50%
   BM25 margin              50      60% (sd  33)   -0.63 MRR              30%     40%
   BM25 margin             100      52% (sd  31)   -0.79 MRR              36%     48%
   BM25 margin             200      52% (sd  31)   -0.82 MRR              36%     48%
   top5 vs rest             50      60% (sd  37)   -0.81 MRR              42%     40%
   top5 vs rest            100      64% (sd  35)   -0.73 MRR              30%     36%
   top5 vs rest            200      61% (sd  33)   -0.85 MRR              40%     39%
   NQC-like spread          50      64% (sd  35)   -0.74 MRR              38%     36%
   NQC-like spread         100      67% (sd  32)   -0.70 MRR              32%     33%
   NQC-like spread         200      62% (sd  30)   -0.86 MRR              40%     38%
   WIG-like                 50      55% (sd  39)   -0.64 MRR              40%     45%
   WIG-like                100      56% (sd  37)   -0.59 MRR              35%     44%
   WIG-like                200      44% (sd  31)   -0.76 MRR              46%     56%
   term coverage top1       50      49% (sd  32)   -0.37 MRR              28%     51%
   term coverage top1      100      46% (sd  28)   -0.39 MRR              26%     54%
   term coverage top1      200      37% (sd  24)   -0.59 MRR              42%     63%

## POOLED over 5 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  18.3  random  17.9  diff  +0.4  p=0.0175
   MRR  : tag  32.0  random  31.8  diff  +0.2  p=0.0697

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  -0.2 (p=0.397)   MRR  -0.4 (p=0.065)
   40%      Hit@1  +0.2 (p=0.414)   MRR  +0.1 (p=0.737)
   50%      Hit@1  +0.0 (p=1.000)   MRR  -0.1 (p=0.611)
   natural  Hit@1  -0.1 (p=0.769)   MRR  -0.2 (p=0.398)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -1.8  95% CI [-2.8, -0.9]  p=0.000
   MRR  :  -2.0  95% CI [-2.8, -1.2]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +0.1  p=0.756
   MRR  :  +0.2  p=0.507

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.0/+0.3 (p=0.356)  40%: +1.4/+0.8 (p=0.011)  50%: +1.4/+0.8 (p=0.012)  nat: +0.4/+0.1 (p=0.770)
   vs NQC-like spread      30%: +0.7/+0.2 (p=0.398)  40%: +1.0/+0.6 (p=0.038)  50%: +1.1/+0.7 (p=0.022)  nat: +0.1/-0.1 (p=0.563)
   vs WIG-like             30%: +0.8/+0.2 (p=0.415)  40%: +1.0/+0.6 (p=0.073)  50%: +0.8/+0.4 (p=0.168)  nat: +0.6/+0.1 (p=0.448)
   vs term coverage top1   30%: +0.8/+0.2 (p=0.542)  40%: +1.1/+0.5 (p=0.111)  50%: +0.5/+0.1 (p=0.738)  nat: +0.2/+0.0 (p=0.898)
