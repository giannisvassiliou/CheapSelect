# groups46: WIG re-ranks the lowest 50% ; group loss = mean_g(gain * skipped), MRR points, 95% bootstrap CI

## amazon_testfull:mini43 (n = 1642; overall loss at 50% = -0.37)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           1642     50%               26% /  26%       -0.37 [-1.70, +0.93]
   tag alarm fired                765     49%               33% /  35%       -1.57 [-3.77, +0.72]
   tag alarm silent               877     51%               21% /  19%       +0.68 [-0.86, +2.23]
   length short (<= 14)           640     39%               24% /  18%       +1.13 [-0.47, +2.84]
   length medium                  472     47%               25% /  22%       -0.30 [-2.39, +1.88]
   length long (> 19)             530     66%               29% /  35%       -2.24 [-5.29, +0.69]

## mag_testfull:mini43 (n = 2665; overall loss at 50% = -1.17)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           2665     50%               17% /  28%       -1.17 [-1.95, -0.38]
   tag alarm fired                710     41%               27% /  32%       +0.73 [-0.98, +2.54]
   tag alarm silent              1955     53%               14% /  27%       -1.86 [-2.78, -0.96]
   length short (<= 13)          1020     30%               16% /  10%       +0.90 [-0.01, +1.78]
   length medium                  851     55%               19% /  28%       -1.62 [-3.23, -0.09]
   length long (> 19)             794     71%               15% /  38%       -3.34 [-5.08, -1.64]

## prime_testfull:mini43 (n = 2801; overall loss at 50% = -1.51)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           2801     50%               26% /  30%       -1.51 [-2.53, -0.51]
   tag alarm fired               1563     41%               29% /  30%       -0.22 [-1.49, +0.95]
   tag alarm silent              1238     61%               24% /  30%       -3.14 [-4.81, -1.53]
   length short (<= 11)           971     40%               34% /  20%       +2.48 [+1.06, +3.79]
   length medium                  926     53%               25% /  25%       -0.47 [-2.08, +1.13]
   length long (> 16)             904     58%               22% /  43%       -6.87 [-9.03, -4.76]

## dbpedia_test:mini43 (n = 400; overall loss at 50% = +7.68)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                            400     50%               32% /   5%       +7.68 [+5.53, +9.91]
   qtype=keyword                   84     39%               42% /   3%       +8.88 [+4.17, +14.39]
   qtype=list                     105     65%               43% /   4%      +15.05 [+9.42, +21.18]
   qtype=named entity              86     78%               13% /   7%       +3.21 [-0.86, +7.31]
   qtype=question                 125     26%               34% /   3%       +3.75 [+1.06, +7.03]
   tag alarm fired                 68     19%               54% /   8%       +6.87 [+2.21, +12.63]
   tag alarm silent               332     56%               30% /   5%       +7.84 [+5.39, +10.45]
   length short (<= 3)            163     65%               23% /   5%       +7.40 [+4.14, +11.15]
   length medium                  144     49%               39% /   6%       +9.00 [+4.92, +13.41]
   length long (> 5)               93     25%               48% /   4%       +6.09 [+2.51, +10.30]

