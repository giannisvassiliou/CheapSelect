## beir_arguana  (1401 questions; tag alarm fires on 9 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.2  diff  -0.1  p=0.8473
   MRR  : tag  22.0  random  22.1  diff  -0.1  p=0.8025

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.0 (p=0.736)
   40%            -0.1 (p=1.000)        -0.1 (p=0.167)
   50%            +0.0 (p=1.000)        -0.1 (p=0.248)
   1% nat         +0.0 (p=1.000)        +0.0 (p=0.531)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -18.6  95% CI [-20.7, -16.6]  p=0.000
   MRR  : -21.9  95% CI [-23.5, -20.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (17%)
   Hit@1:  +5.6  p=0.000
   MRR  :  +1.6  p=0.005

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.5/+0.9 (p=0.234)  40%: +1.2/+0.9 (p=0.312)  50%: +0.9/+0.5 (p=0.572)  nat: -0.1/-0.1 (p=0.240)
   vs NQC-like spread      30%: +0.6/+0.6 (p=0.340)  40%: +0.7/+0.6 (p=0.406)  50%: +0.6/+0.2 (p=0.809)  nat: +0.0/+0.0 (p=0.691)
   vs WIG-like             30%: +1.5/+0.8 (p=0.288)  40%: +1.6/+1.1 (p=0.179)  50%: +1.6/+1.0 (p=0.264)  nat: +0.0/+0.1 (p=0.361)
   vs term coverage top1   30%: +1.1/+0.5 (p=0.448)  40%: +1.9/+0.8 (p=0.256)  50%: +1.2/+0.3 (p=0.632)  nat: +0.1/+0.0 (p=0.824)

G. each selector reranking 9 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -21.9  [-23.5, -20.3]  p=0.000
   BM25 margin          -22.0  [-23.6, -20.4]  p=0.000
   top5 vs rest         -21.8  [-23.4, -20.2]  p=0.000
   NQC-like spread      -21.9  [-23.5, -20.4]  p=0.000
   WIG-like             -22.0  [-23.6, -20.4]  p=0.000
   term coverage top1   -21.9  [-23.5, -20.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              23.8    26.5    29.1    31.2    33.1    35.2    37.2    39.5    41.8    43.9*   100%
   BM25 margin            23.9    26.7    29.1    31.3    33.2    35.2    37.2    39.5    41.8    43.9*   100%
   top5 vs rest           24.1    26.3    28.1    30.3    32.6    34.7    36.5    38.8    41.3    43.9*   100%
   NQC-like spread        23.5    25.9    28.4    30.7    32.9    35.4    37.6    39.7    41.8    43.9*   100%
   WIG-like               24.2    26.1    28.3    30.1    32.1    34.2    36.2    38.7    41.5    43.9*   100%
   term coverage top1     24.1    26.7    28.6    30.5    32.8    35.2    37.2    39.9    41.9    43.9*   100%
   ORACLE                 30.5    36.0    40.1    43.0    44.9*   46.0*   46.3*   46.3*   46.0*   43.9*   50%
   random (expected)      24.1    26.3    28.5    30.7    32.9    35.1    37.3    39.5    41.7    43.9*   100%
   (BM25 only 21.9; rerank ALL 43.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.88 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -20.1[-21.8]  -17.4[-18.9]  -14.9[-16.3]  -12.7[-14.1]  -10.8[-12.1]   -8.7[ -9.9]   -6.7[ -7.8]   -4.4[ -5.3]   -2.1[ -2.7]    100%   (point estimate: 100%)
   BM25 margin          -20.0[-21.7]  -17.3[-18.8]  -14.8[-16.3]  -12.6[-14.0]  -10.8[-12.1]   -8.7[ -9.9]   -6.7[ -7.8]   -4.4[ -5.3]   -2.1[ -2.7]    100%   (point estimate: 100%)
   top5 vs rest         -19.8[-21.3]  -17.6[-19.1]  -15.8[-17.2]  -13.6[-15.0]  -11.3[-12.6]   -9.2[-10.5]   -7.4[ -8.5]   -5.1[ -6.1]   -2.6[ -3.3]    100%   (point estimate: 100%)
   NQC-like spread      -20.4[-22.0]  -18.0[-19.6]  -15.5[-16.9]  -13.2[-14.6]  -11.0[-12.3]   -8.6[ -9.7]   -6.3[ -7.3]   -4.2[ -5.0]   -2.1[ -2.7]    100%   (point estimate: 100%)
   WIG-like             -19.8[-21.3]  -17.8[-19.3]  -15.6[-17.1]  -13.8[-15.2]  -11.8[-13.1]   -9.7[-10.9]   -7.8[ -8.9]   -5.2[ -6.2]   -2.4[ -3.1]    100%   (point estimate: 100%)
   term coverage top1   -19.8[-21.4]  -17.2[-18.7]  -15.4[-16.8]  -13.5[-14.9]  -11.2[-12.5]   -8.7[ -9.8]   -6.7[ -7.7]   -4.0[ -4.8]   -2.1[ -2.6]    100%   (point estimate: 100%)
   ORACLE               -13.4[-14.6]   -7.9[ -8.8]   -3.8[ -4.6]   -0.9[ -1.5]   +1.0[ +0.6]#  +2.1[ +1.8]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.1[ +1.7]#   50%   (point estimate: 50%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.88): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      99% (sd   3)   -0.23 MRR              10%      1%
   BM25 margin             100      99% (sd   3)   -0.22 MRR              10%      1%
   top5 vs rest            100     100% (sd   2)   -0.14 MRR               5%      0%
   NQC-like spread         100     100% (sd   0)   +0.00 MRR               0%      0%
   WIG-like                100     100% (sd   0)   +0.00 MRR               0%      0%
   term coverage top1      100      98% (sd   4)   -0.33 MRR              15%      2%

