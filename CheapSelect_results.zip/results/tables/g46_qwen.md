# groups46: WIG re-ranks the lowest 50% ; group loss = mean_g(gain * skipped), MRR points, 95% bootstrap CI

## mag_testfull:qwen8b (n = 1000; overall loss at 50% = +3.42)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           1000     50%               26% /  16%       +3.42 [+1.93, +4.90]
   tag alarm fired                262     40%               42% /  13%       +8.37 [+5.21, +11.62]
   tag alarm silent               738     53%               22% /  17%       +1.66 [+0.13, +3.26]
   length short (<= 13)           362     31%               17% /  12%       +1.34 [-0.24, +2.96]
   length medium                  325     51%               26% /  20%       +1.66 [-1.32, +4.64]
   length long (> 19)             313     70%               31% /  15%       +7.64 [+4.69, +10.77]

## prime_testfull:qwen8b (n = 1000; overall loss at 50% = +4.30)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           1000     50%               36% /  19%       +4.30 [+2.54, +6.13]
   tag alarm fired                546     42%               44% /  17%       +6.56 [+4.29, +8.96]
   tag alarm silent               454     60%               30% /  21%       +1.58 [-0.99, +4.39]
   length short (<= 12)           413     40%               39% /  20%       +3.31 [+0.69, +5.75]
   length medium                  258     53%               36% /  18%       +5.33 [+1.68, +9.13]
   length long (> 16)             329     60%               33% /  19%       +4.73 [+1.53, +8.02]

## amazon_testfull:qwen8b (n = 500; overall loss at 50% = +2.40)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                            500     50%               30% /  20%       +2.40 [-0.04, +4.95]
   tag alarm fired                219     52%               39% /  23%       +3.71 [-0.91, +8.22]
   tag alarm silent               281     49%               22% /  18%       +1.38 [-1.21, +4.18]
   length short (<= 14)           194     40%               32% /  17%       +2.07 [-0.78, +5.28]
   length medium                  143     48%               28% /  20%       +2.35 [-2.51, +7.18]
   length long (> 19)             163     63%               29% /  23%       +2.85 [-2.27, +8.28]

## dbpedia_test:qwen8b (n = 400; overall loss at 50% = +8.57)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                            400     50%               34% /   7%       +8.57 [+6.00, +11.18]
   qtype=keyword                   84     39%               42% /   3%       +8.85 [+3.98, +14.51]
   qtype=list                     105     65%               44% /   9%      +15.71 [+9.61, +22.38]
   qtype=named entity              86     78%               18% /   3%       +6.16 [+2.36, +10.32]
   qtype=question                 125     26%               34% /  16%       +4.03 [+0.50, +8.00]
   tag alarm fired                 68     19%               46% /  31%       +4.11 [-1.16, +9.89]
   tag alarm silent               332     56%               33% /   5%       +9.48 [+6.76, +12.44]
   length short (<= 3)            163     65%               25% /   5%       +8.24 [+4.53, +12.21]
   length medium                  144     49%               42% /   8%      +11.27 [+6.35, +16.47]
   length long (> 5)               93     25%               43% /  13%       +4.95 [+1.35, +9.03]

## beir_scifact:qwen8b (n = 300; overall loss at 50% = +3.54)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                            300     50%               19% /   9%       +3.54 [+1.58, +5.73]
   tag alarm fired                 46     48%               23% /  14%       +4.60 [+0.18, +10.16]
   tag alarm silent               254     50%               19% /   8%       +3.35 [+1.18, +5.69]
   length short (<= 7)            102     49%               14% /  12%       +2.89 [-1.11, +7.41]
   length medium                   98     45%               18% /   9%       +2.23 [-0.11, +4.84]
   length long (> 10)             100     56%               25% /   5%       +5.49 [+1.97, +9.55]

## beir_nfcorpus:qwen8b (n = 323; overall loss at 50% = +2.82)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                            323     50%               22% /  12%       +2.82 [+0.67, +5.06]
   tag alarm fired                  8     62%                0% /  20%       -6.25 [-18.75, +0.00]
   tag alarm silent               315     50%               23% /  12%       +3.05 [+0.91, +5.25]
   length short (<= 2)            173     50%               15% /  14%       +0.83 [-1.87, +3.57]
   length medium                   48     58%               32% /  14%       +4.78 [-2.42, +12.93]
   length long (> 3)              102     45%               30% /   7%       +5.29 [+1.89, +9.00]

## beir_scidocs:qwen8b (n = 1000; overall loss at 50% = +4.61)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           1000     50%               45% /  16%       +4.61 [+3.21, +6.06]
   tag alarm fired                120     47%               43% /  12%       +5.53 [+1.86, +9.65]
   tag alarm silent               880     50%               45% /  17%       +4.48 [+2.99, +5.99]
   length short (<= 7)            479     49%               40% /  20%       +2.58 [+0.75, +4.54]
   length medium                  291     46%               46% /  14%       +5.38 [+2.95, +7.99]
   length long (> 9)              230     58%               51% /  13%       +7.86 [+4.60, +11.28]

