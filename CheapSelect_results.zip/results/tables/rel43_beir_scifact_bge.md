## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.3  random  55.8  diff  +0.5  p=0.3239
   MRR  : tag  65.0  random  64.7  diff  +0.3  p=0.2730

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.7 (p=0.727)        -0.6 (p=0.383)
   40%            -0.7 (p=0.502)        -0.6 (p=0.027)
   50%            +0.3 (p=1.000)        +0.1 (p=0.921)
   15% nat        -1.7 (p=0.381)        -1.4 (p=0.213)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.7  95% CI [-11.7, -3.7]  p=0.000
   MRR  :  -6.0  95% CI [-8.8, -3.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (27%)
   Hit@1:  +0.3  p=1.000
   MRR  :  -0.3  p=0.795

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +4.7/+2.9 (p=0.016)  40%: +5.3/+3.9 (p=0.002)  50%: +4.7/+3.3 (p=0.009)  nat: +1.3/+0.7 (p=0.424)
   vs NQC-like spread      30%: +2.7/+1.0 (p=0.343)  40%: +3.0/+1.8 (p=0.075)  50%: +2.7/+2.0 (p=0.046)  nat: -1.3/-1.4 (p=0.139)
   vs WIG-like             30%: +2.0/+1.1 (p=0.344)  40%: +2.0/+1.3 (p=0.259)  50%: +2.7/+2.2 (p=0.053)  nat: +0.3/-0.3 (p=0.799)
   vs term coverage top1   30%: +2.0/+1.5 (p=0.201)  40%: +2.3/+2.0 (p=0.089)  50%: +2.7/+2.3 (p=0.024)  nat: +0.0/+0.1 (p=0.893)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -6.0  [-8.8, -3.2]  p=0.000
   BM25 margin           -4.6  [-7.2, -2.1]  p=0.000
   top5 vs rest          -6.7  [-9.8, -3.6]  p=0.000
   NQC-like spread       -4.6  [-7.5, -1.8]  p=0.001
   WIG-like              -5.7  [-8.6, -2.9]  p=0.000
   term coverage top1    -6.1  [-8.9, -3.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              65.1    66.1    68.0    69.3    70.5*   70.6*   71.2*   71.0*   71.1*   71.0*   50%
   BM25 margin            65.0    67.5    68.6    69.9*   70.4*   70.9*   71.3*   71.0*   71.1*   71.0*   40%
   top5 vs rest           63.7    64.4    65.0    65.4    67.2    67.3    67.8    68.5    69.8*   71.0*   90%
   NQC-like spread        65.6    66.8    67.0    67.5    68.5    69.4*   70.3*   70.5*   70.8*   71.0*   60%
   WIG-like               65.0    66.4    66.9    68.0    68.3    68.7    69.1    69.5    70.7*   71.0*   90%
   term coverage top1     65.1    65.0    66.5    67.3    68.2    69.7*   69.9*   70.0    70.5*   71.0*   90%
   ORACLE                 70.8*   73.9*   74.0*   74.0*   74.0*   74.0*   74.0*   74.0*   74.0*   71.0*   10%
   random (expected)      64.3    65.1    65.8    66.5    67.3    68.0    68.8    69.5    70.3    71.0*   100%
   (BM25 only 63.6; rerank ALL 71.0)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.42 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.9[ -8.8]   -5.0[ -7.5]   -3.0[ -5.3]   -1.7[ -3.4]   -0.5[ -1.6]   -0.4[ -1.2]#  +0.1[ -0.3]#  -0.0[ -0.3]#  +0.1[ -0.0]#   60%   (point estimate: 50%)
   BM25 margin           -6.0[ -8.7]   -3.5[ -5.9]   -2.4[ -4.5]   -1.1[ -2.7]   -0.7[ -1.6]   -0.1[ -0.9]#  +0.3[ -0.2]#  +0.0[ -0.3]#  +0.1[ -0.0]#   60%   (point estimate: 40%)
   top5 vs rest          -7.3[-10.3]   -6.6[ -9.5]   -6.0[ -8.8]   -5.6[ -8.4]   -3.9[ -6.3]   -3.7[ -5.9]   -3.2[ -5.3]   -2.5[ -4.3]   -1.3[ -2.7]    100%   (point estimate: 90%)
   NQC-like spread       -5.5[ -8.3]   -4.2[ -6.8]   -4.1[ -6.2]   -3.5[ -5.6]   -2.6[ -4.5]   -1.6[ -3.4]   -0.7[ -1.8]   -0.5[ -1.5]   -0.2[ -0.7]#   90%   (point estimate: 70%)
   WIG-like              -6.0[ -8.9]   -4.6[ -7.3]   -4.1[ -6.5]   -3.0[ -5.1]   -2.7[ -4.7]   -2.3[ -4.1]   -1.9[ -3.5]   -1.5[ -2.8]   -0.3[ -0.8]#   90%   (point estimate: 90%)
   term coverage top1    -5.9[ -8.9]   -6.0[ -8.7]   -4.6[ -6.8]   -3.7[ -5.8]   -2.8[ -4.6]   -1.3[ -2.8]   -1.1[ -2.3]   -1.1[ -2.2]   -0.5[ -1.3]#   90%   (point estimate: 60%)
   ORACLE                -0.2[ -2.0]   +2.9[ +1.6]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#  +3.0[ +1.7]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.42): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      50% (sd  12)   -1.23 MRR              40%     50%
   BM25 margin             100      38% (sd  12)   -1.86 MRR              55%     62%
   top5 vs rest            100      89% (sd  17)   -1.56 MRR              45%     11%
   NQC-like spread         100      66% (sd  13)   -1.47 MRR              45%     34%
   WIG-like                100      68% (sd  25)   -2.30 MRR              50%     32%
   term coverage top1      100      66% (sd  20)   -2.12 MRR              50%     34%

