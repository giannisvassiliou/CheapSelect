## prime_testfull  (2801 questions; tag alarm fires on 1563 = 56%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  24.7  random  21.9  diff  +2.8  p=0.0001
   MRR  : tag  33.8  random  31.3  diff  +2.4  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.3 (p=0.000)        +2.0 (p=0.000)
   40%            +1.9 (p=0.000)        +1.8 (p=0.000)
   50%            +2.1 (p=0.000)        +2.1 (p=0.000)
   56% nat        +1.4 (p=0.013)        +1.6 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +2.1  95% CI [+1.0, +3.2]  p=0.000
   MRR  :  +0.7  95% CI [-0.1, +1.6]  p=0.086

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +0.4  p=0.494
   MRR  :  +0.2  p=0.662

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.8/+0.5 (p=0.194)  40%: +1.4/+0.9 (p=0.045)  50%: +1.6/+1.1 (p=0.009)  nat: +0.7/+0.6 (p=0.119)
   vs NQC-like spread      30%: +0.7/+0.5 (p=0.185)  40%: +0.6/+0.3 (p=0.401)  50%: +0.5/+0.3 (p=0.390)  nat: -0.3/-0.2 (p=0.610)
   vs WIG-like             30%: +0.6/+0.2 (p=0.542)  40%: +0.9/+0.4 (p=0.349)  50%: +1.1/+0.7 (p=0.085)  nat: +0.5/+0.3 (p=0.384)
   vs term coverage top1   30%: +1.5/+1.1 (p=0.010)  40%: +2.0/+1.5 (p=0.001)  50%: +2.5/+2.0 (p=0.000)  nat: +1.7/+1.4 (p=0.001)

G. each selector reranking 1563 questions (56%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +0.7  [-0.1, +1.6]  p=0.086
   BM25 margin           -0.9  [-1.8, -0.0]  p=0.041
   top5 vs rest          +0.1  [-0.8, +1.0]  p=0.828
   NQC-like spread       +0.9  [+0.0, +1.8]  p=0.045
   WIG-like              +0.4  [-0.5, +1.3]  p=0.431
   term coverage top1    -0.7  [-1.6, +0.2]  p=0.109

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              30.4    31.1    32.2*   32.9*   33.8*   33.6*   33.5*   33.6*   33.4*   33.1*   30%
   BM25 margin            29.5    29.8    30.2    31.1    31.7    32.6*   33.1*   33.5*   33.4*   33.1*   60%
   top5 vs rest           29.8    30.6    31.6    32.1*   32.8*   33.3*   33.7*   33.7*   33.2*   33.1*   40%
   NQC-like spread        29.7    30.7    31.6    32.6*   33.5*   33.9*   33.8*   33.6*   33.4*   33.1*   40%
   WIG-like               30.2    31.1    31.9*   32.5*   33.1*   33.6*   34.0*   33.8*   33.8*   33.1*   30%
   term coverage top1     29.5    30.6    31.1    31.5    31.9    32.4*   32.8*   32.9*   32.8*   33.1*   60%
   ORACLE                 37.0*   40.2*   40.9*   40.9*   40.9*   40.9*   40.9*   40.9*   39.6*   33.1*   10%
   random (expected)      29.5    29.9    30.3    30.7    31.1    31.5    31.9    32.3    32.7    33.1*   100%
   (BM25 only 29.1; rerank ALL 33.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.66 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.6[ -3.9]   -1.9[ -3.1]   -0.9[ -2.0]   -0.1[ -1.1]   +0.8[ -0.1]#  +0.5[ -0.2]#  +0.5[ -0.2]#  +0.5[ -0.0]#  +0.4[ -0.0]#   50%   (point estimate: 40%)
   BM25 margin           -3.6[ -4.8]   -3.2[ -4.4]   -2.8[ -4.0]   -1.9[ -2.9]   -1.4[ -2.3]   -0.5[ -1.3]   +0.0[ -0.7]   +0.5[ -0.1]#  +0.3[ -0.0]#   80%   (point estimate: 60%)
   top5 vs rest          -3.3[ -4.6]   -2.4[ -3.6]   -1.4[ -2.6]   -1.0[ -2.1]   -0.3[ -1.2]   +0.3[ -0.6]#  +0.7[ -0.1]#  +0.7[ +0.0]#  +0.1[ -0.3]#   60%   (point estimate: 50%)
   NQC-like spread       -3.4[ -4.6]   -2.4[ -3.6]   -1.4[ -2.5]   -0.5[ -1.6]   +0.5[ -0.5]#  +0.8[ -0.0]#  +0.8[ +0.0]#  +0.6[ -0.0]#  +0.4[ -0.0]#   50%   (point estimate: 40%)
   WIG-like              -2.9[ -4.2]   -1.9[ -3.1]   -1.1[ -2.2]   -0.5[ -1.5]   +0.1[ -0.9]   +0.5[ -0.4]#  +0.9[ +0.2]#  +0.7[ +0.1]#  +0.8[ +0.3]#   60%   (point estimate: 40%)
   term coverage top1    -3.5[ -4.8]   -2.5[ -3.7]   -2.0[ -3.1]   -1.6[ -2.6]   -1.2[ -2.1]   -0.7[ -1.5]   -0.3[ -1.0]   -0.1[ -0.7]   -0.3[ -0.7]    100%   (point estimate: 60%)
   ORACLE                +3.9[ +3.0]#  +7.2[ +6.4]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +6.5[ +5.8]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.66): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      52% (sd  30)   -0.51 MRR              30%     48%
   BM25 margin             100      64% (sd  31)   -0.87 MRR              35%     36%
   top5 vs rest            100      55% (sd  32)   -0.92 MRR              45%     45%
   NQC-like spread         100      56% (sd  35)   -0.95 MRR              40%     44%
   WIG-like                100      50% (sd  29)   -0.61 MRR              40%     50%
   term coverage top1      100      74% (sd  33)   -0.84 MRR              30%     26%

