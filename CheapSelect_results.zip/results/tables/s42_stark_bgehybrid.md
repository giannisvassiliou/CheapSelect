## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.8  random  53.6  diff  +3.2  p=0.0001
   MRR  : tag  66.8  random  64.3  diff  +2.5  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.2 (p=0.887)        +0.5 (p=0.466)
   40%            +1.2 (p=0.230)        +1.5 (p=0.033)
   50%            +2.7 (p=0.005)        +2.4 (p=0.001)
   47% nat        +2.0 (p=0.052)        +2.0 (p=0.007)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -6.5  95% CI [-8.3, -4.7]  p=0.000
   MRR  :  -6.2  95% CI [-7.5, -4.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (49%)
   Hit@1:  +4.6  p=0.000
   MRR  :  +3.1  p=0.000

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.3/-0.7 (p=0.350)  40%: +0.9/-0.1 (p=0.938)  50%: +1.0/-0.2 (p=0.734)  nat: +0.9/-0.1 (p=0.907)
   vs NQC-like spread      30%: -1.3/-1.7 (p=0.024)  40%: -0.1/-0.9 (p=0.210)  50%: +0.5/-0.7 (p=0.320)  nat: +0.1/-0.9 (p=0.212)
   vs WIG-like             30%: +0.4/-0.1 (p=0.850)  40%: +1.9/+1.0 (p=0.177)  50%: +2.1/+0.9 (p=0.184)  nat: +1.7/+0.8 (p=0.232)
   vs term coverage top1   30%: +0.7/+0.4 (p=0.552)  40%: +0.8/+0.6 (p=0.439)  50%: +1.5/+0.9 (p=0.192)  nat: +1.3/+0.9 (p=0.222)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -6.2  [-7.5, -4.8]  p=0.000
   BM25 margin           -8.2  [-9.6, -6.7]  p=0.000
   top5 vs rest          -6.1  [-7.5, -4.8]  p=0.000
   NQC-like spread       -5.3  [-6.6, -4.0]  p=0.000
   WIG-like              -7.0  [-8.3, -5.6]  p=0.000
   term coverage top1    -7.1  [-8.5, -5.7]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              59.0    61.0    63.0    65.5    67.4    68.8    69.8    70.7    72.1    72.9*   100%
   BM25 margin            59.2    60.9    62.5    64.0    65.0    66.9    68.7    70.4    72.1    72.9*   100%
   top5 vs rest           59.1    61.4    63.7    65.6    67.6    69.0    70.4    72.0    72.8*   72.9*   90%
   NQC-like spread        59.9    62.1    64.7    66.4    68.1    69.3    70.8    72.2*   72.8*   72.9*   80%
   WIG-like               59.4    60.9    63.1    64.5    66.5    68.1    69.7    71.4    72.7*   72.9*   90%
   term coverage top1     59.3    61.2    62.6    64.9    66.4    68.4    69.0    70.5    71.6    72.9*   100%
   ORACLE                 65.9    72.6*   77.1*   78.3*   78.3*   78.3*   78.3*   78.3*   78.1*   72.9*   20%
   random (expected)      58.4    60.0    61.6    63.2    64.9    66.5    68.1    69.7    71.3    72.9*   100%
   (BM25 only 56.8; rerank ALL 72.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -14.0[-15.7]  -11.9[-13.6]  -10.0[-11.6]   -7.4[ -8.8]   -5.6[ -6.9]   -4.1[ -5.3]   -3.2[ -4.2]   -2.2[ -3.1]   -0.8[ -1.4]    100%   (point estimate: 90%)
   BM25 margin          -13.8[-15.7]  -12.1[-13.9]  -10.4[-12.1]   -8.9[-10.5]   -7.9[ -9.4]   -6.1[ -7.4]   -4.2[ -5.4]   -2.6[ -3.4]   -0.8[ -1.3]    100%   (point estimate: 90%)
   top5 vs rest         -13.8[-15.6]  -11.6[-13.3]   -9.3[-11.0]   -7.4[ -8.9]   -5.3[ -6.6]   -3.9[ -5.1]   -2.5[ -3.5]   -1.0[ -1.7]   -0.1[ -0.6]#   90%   (point estimate: 80%)
   NQC-like spread      -13.0[-14.8]  -10.8[-12.5]   -8.3[ -9.8]   -6.5[ -8.0]   -4.9[ -6.2]   -3.7[ -4.8]   -2.1[ -3.1]   -0.7[ -1.5]   -0.1[ -0.7]#   90%   (point estimate: 80%)
   WIG-like             -13.5[-15.4]  -12.1[-13.8]   -9.8[-11.5]   -8.4[ -9.9]   -6.5[ -7.8]   -4.8[ -6.0]   -3.2[ -4.2]   -1.5[ -2.3]   -0.3[ -0.8]#   90%   (point estimate: 90%)
   term coverage top1   -13.6[-15.5]  -11.7[-13.5]  -10.4[-12.0]   -8.0[ -9.5]   -6.5[ -7.9]   -4.6[ -5.8]   -3.9[ -5.0]   -2.4[ -3.3]   -1.3[ -2.0]    100%   (point estimate: 100%)
   ORACLE                -7.0[ -8.5]   -0.4[ -1.4]   +4.1[ +3.3]#  +5.3[ +4.5]#  +5.3[ +4.5]#  +5.3[ +4.5]#  +5.3[ +4.5]#  +5.3[ +4.5]#  +5.2[ +4.3]#   30%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -14.0[-15.7]  -11.9[-13.6]  -10.0[-11.6]   -7.4[ -8.8]   -5.6[ -6.9]   -4.1[ -5.3]   -3.2[ -4.2]   -2.2[ -3.1]   -0.8[ -1.4]    100%   (point estimate: 100%)
   BM25 margin          -13.8[-15.7]  -12.1[-13.9]  -10.4[-12.1]   -8.9[-10.5]   -7.9[ -9.4]   -6.1[ -7.4]   -4.2[ -5.4]   -2.6[ -3.4]   -0.8[ -1.3]    100%   (point estimate: 100%)
   top5 vs rest         -13.8[-15.6]  -11.6[-13.3]   -9.3[-11.0]   -7.4[ -8.9]   -5.3[ -6.6]   -3.9[ -5.1]   -2.5[ -3.5]   -1.0[ -1.7]   -0.1[ -0.6]    100%   (point estimate: 90%)
   NQC-like spread      -13.0[-14.8]  -10.8[-12.5]   -8.3[ -9.8]   -6.5[ -8.0]   -4.9[ -6.2]   -3.7[ -4.8]   -2.1[ -3.1]   -0.7[ -1.5]   -0.1[ -0.7]    100%   (point estimate: 90%)
   WIG-like             -13.5[-15.4]  -12.1[-13.8]   -9.8[-11.5]   -8.4[ -9.9]   -6.5[ -7.8]   -4.8[ -6.0]   -3.2[ -4.2]   -1.5[ -2.3]   -0.3[ -0.8]    100%   (point estimate: 90%)
   term coverage top1   -13.6[-15.5]  -11.7[-13.5]  -10.4[-12.0]   -8.0[ -9.5]   -6.5[ -7.9]   -4.6[ -5.8]   -3.9[ -5.0]   -2.4[ -3.3]   -1.3[ -2.0]    100%   (point estimate: 100%)
   ORACLE                -7.0[ -8.5]   -0.4[ -1.4]   +4.1[ +3.3]#  +5.3[ +4.5]#  +5.3[ +4.5]#  +5.3[ +4.5]#  +5.3[ +4.5]#  +5.3[ +4.5]#  +5.2[ +4.3]#   30%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      87% (sd  16)   -1.36 MRR              29%     13%
   tag alarm               100      90% (sd  12)   -1.07 MRR              23%     10%
   tag alarm               200      91% (sd   8)   -0.92 MRR              20%      9%
   BM25 margin              50      91% (sd  11)   -1.07 MRR              22%      9%
   BM25 margin             100      92% (sd   9)   -0.89 MRR              19%      8%
   BM25 margin             200      93% (sd   7)   -0.74 MRR              12%      7%
   top5 vs rest             50      84% (sd  17)   -1.22 MRR              35%     16%
   top5 vs rest            100      85% (sd  11)   -0.90 MRR              37%     15%
   top5 vs rest            200      85% (sd   8)   -0.68 MRR              40%     15%
   NQC-like spread          50      83% (sd  18)   -1.24 MRR              26%     17%
   NQC-like spread         100      83% (sd  14)   -1.07 MRR              26%     17%
   NQC-like spread         200      83% (sd  11)   -0.89 MRR              20%     17%
   WIG-like                 50      86% (sd  17)   -1.30 MRR              34%     14%
   WIG-like                100      88% (sd  11)   -0.94 MRR              32%     12%
   WIG-like                200      88% (sd   9)   -0.85 MRR              33%     12%
   term coverage top1       50      90% (sd  14)   -1.24 MRR              47%     10%
   term coverage top1      100      94% (sd   9)   -0.79 MRR              38%      6%
   term coverage top1      200      95% (sd   8)   -0.67 MRR              35%      5%

## mag_testfull  (2665 questions; tag alarm fires on 1071 = 40%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  53.9  random  44.2  diff  +9.7  p=0.0001
   MRR  : tag  62.7  random  55.5  diff  +7.2  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +6.1 (p=0.000)        +4.8 (p=0.000)
   40%            +9.7 (p=0.000)        +7.9 (p=0.000)
   50%            +8.8 (p=0.000)        +7.2 (p=0.000)
   40% nat        +9.8 (p=0.000)        +8.0 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -2.0  95% CI [-3.2, -0.8]  p=0.001
   MRR  :  -2.7  95% CI [-3.6, -1.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (43%)
   Hit@1:  +6.2  p=0.000
   MRR  :  +4.7  p=0.000

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.6/+0.5 (p=0.337)  40%: +3.3/+2.6 (p=0.000)  50%: +1.7/+1.2 (p=0.013)  nat: +3.3/+2.6 (p=0.000)
   vs NQC-like spread      30%: -0.8/-0.5 (p=0.328)  40%: +2.6/+2.1 (p=0.000)  50%: +1.2/+0.8 (p=0.096)  nat: +2.5/+2.0 (p=0.000)
   vs WIG-like             30%: +3.7/+2.8 (p=0.000)  40%: +7.1/+5.6 (p=0.000)  50%: +6.7/+5.1 (p=0.000)  nat: +7.2/+5.7 (p=0.000)
   vs term coverage top1   30%: +0.5/+0.3 (p=0.519)  40%: +2.8/+2.3 (p=0.000)  50%: +1.3/+1.0 (p=0.038)  nat: +2.8/+2.3 (p=0.000)

G. each selector reranking 1071 questions (40%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.7  [-3.6, -1.8]  p=0.000
   BM25 margin          -10.7  [-11.8, -9.5]  p=0.000
   top5 vs rest          -5.3  [-6.3, -4.3]  p=0.000
   NQC-like spread       -4.7  [-5.7, -3.7]  p=0.000
   WIG-like              -8.4  [-9.5, -7.2]  p=0.000
   term coverage top1    -4.9  [-5.9, -3.9]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              52.8    55.3    58.5    62.7    63.2    63.2    63.5    64.0    64.8    65.4*   100%
   BM25 margin            51.8    52.9    53.6    54.7    56.0    57.5    59.3    61.4    63.4    65.4*   100%
   top5 vs rest           52.2    55.9    58.0    60.1    61.9    63.4    64.3    65.0*   65.5*   65.4*   80%
   NQC-like spread        53.4    56.9    59.0    60.6    62.3    63.9    64.4    65.1*   65.4*   65.4*   80%
   WIG-like               51.2    53.3    55.7    57.0    58.0    59.3    60.7    62.5    64.2    65.4*   100%
   term coverage top1     52.6    55.5    58.2    60.4    62.2    63.5    64.6    65.2*   65.4*   65.4*   80%
   ORACLE                 57.8    64.4    68.8*   69.9*   69.9*   69.9*   69.9*   69.9*   69.7*   65.4*   30%
   random (expected)      50.5    52.2    53.8    55.5    57.1    58.8    60.4    62.1    63.7    65.4*   100%
   (BM25 only 48.9; rerank ALL 65.4)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.6[-14.0]  -10.0[-11.3]   -6.9[ -8.0]   -2.7[ -3.6]   -2.2[ -3.0]   -2.1[ -2.8]   -1.8[ -2.4]   -1.3[ -1.8]   -0.6[ -0.9]#   90%   (point estimate: 90%)
   BM25 margin          -13.6[-14.9]  -12.5[-13.8]  -11.7[-12.9]  -10.7[-11.8]   -9.4[-10.5]   -7.9[ -8.9]   -6.1[ -7.0]   -3.9[ -4.7]   -2.0[ -2.5]    100%   (point estimate: 100%)
   top5 vs rest         -13.2[-14.5]   -9.5[-10.7]   -7.4[ -8.6]   -5.3[ -6.4]   -3.4[ -4.4]   -2.0[ -2.9]   -1.1[ -1.8]   -0.3[ -0.9]#  +0.1[ -0.3]#   80%   (point estimate: 80%)
   NQC-like spread      -12.0[-13.3]   -8.5[ -9.7]   -6.3[ -7.5]   -4.8[ -5.8]   -3.0[ -4.0]   -1.5[ -2.3]   -1.0[ -1.7]   -0.3[ -0.8]#  -0.0[ -0.4]#   80%   (point estimate: 80%)
   WIG-like             -14.2[-15.5]  -12.1[-13.4]   -9.7[-10.9]   -8.4[ -9.5]   -7.4[ -8.4]   -6.0[ -7.0]   -4.7[ -5.5]   -2.9[ -3.6]   -1.2[ -1.7]    100%   (point estimate: 100%)
   term coverage top1   -12.8[-14.1]   -9.8[-11.1]   -7.2[ -8.3]   -5.0[ -6.0]   -3.2[ -4.1]   -1.9[ -2.6]   -0.8[ -1.4]   -0.2[ -0.6]#  +0.0[ -0.3]#   80%   (point estimate: 70%)
   ORACLE                -7.6[ -8.7]   -0.9[ -1.7]   +3.5[ +2.9]#  +4.5[ +4.0]#  +4.5[ +4.0]#  +4.5[ +4.0]#  +4.5[ +4.0]#  +4.5[ +4.0]#  +4.4[ +3.8]#   30%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -12.6[-14.0]  -10.0[-11.3]   -6.9[ -8.0]   -2.7[ -3.6]   -2.2[ -3.0]   -2.1[ -2.8]   -1.8[ -2.4]   -1.3[ -1.8]   -0.6[ -0.9]    100%   (point estimate: 100%)
   BM25 margin          -13.6[-14.9]  -12.5[-13.8]  -11.7[-12.9]  -10.7[-11.8]   -9.4[-10.5]   -7.9[ -8.9]   -6.1[ -7.0]   -3.9[ -4.7]   -2.0[ -2.5]    100%   (point estimate: 100%)
   top5 vs rest         -13.2[-14.5]   -9.5[-10.7]   -7.4[ -8.6]   -5.3[ -6.4]   -3.4[ -4.4]   -2.0[ -2.9]   -1.1[ -1.8]   -0.3[ -0.9]   +0.1[ -0.3]#   90%   (point estimate: 80%)
   NQC-like spread      -12.0[-13.3]   -8.5[ -9.7]   -6.3[ -7.5]   -4.8[ -5.8]   -3.0[ -4.0]   -1.5[ -2.3]   -1.0[ -1.7]   -0.3[ -0.8]   -0.0[ -0.4]#   90%   (point estimate: 80%)
   WIG-like             -14.2[-15.5]  -12.1[-13.4]   -9.7[-10.9]   -8.4[ -9.5]   -7.4[ -8.4]   -6.0[ -7.0]   -4.7[ -5.5]   -2.9[ -3.6]   -1.2[ -1.7]    100%   (point estimate: 100%)
   term coverage top1   -12.8[-14.1]   -9.8[-11.1]   -7.2[ -8.3]   -5.0[ -6.0]   -3.2[ -4.1]   -1.9[ -2.6]   -0.8[ -1.4]   -0.2[ -0.6]   +0.0[ -0.3]#   90%   (point estimate: 80%)
   ORACLE                -7.6[ -8.7]   -0.9[ -1.7]   +3.5[ +2.9]#  +4.5[ +4.0]#  +4.5[ +4.0]#  +4.5[ +4.0]#  +4.5[ +4.0]#  +4.5[ +4.0]#  +4.4[ +3.8]#   30%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      78% (sd  23)   -1.26 MRR              46%     22%
   tag alarm               100      81% (sd  20)   -1.21 MRR              44%     19%
   tag alarm               200      81% (sd  17)   -1.10 MRR              44%     19%
   BM25 margin              50      94% (sd  12)   -1.09 MRR              32%      6%
   BM25 margin             100      98% (sd   4)   -0.39 MRR              18%      2%
   BM25 margin             200      98% (sd   4)   -0.33 MRR              16%      2%
   top5 vs rest             50      74% (sd  22)   -1.59 MRR              47%     26%
   top5 vs rest            100      78% (sd  17)   -0.99 MRR              40%     22%
   top5 vs rest            200      76% (sd  14)   -0.94 MRR              48%     24%
   NQC-like spread          50      74% (sd  22)   -1.33 MRR              44%     26%
   NQC-like spread         100      76% (sd  19)   -1.09 MRR              44%     24%
   NQC-like spread         200      76% (sd  15)   -0.88 MRR              42%     24%
   WIG-like                 50      93% (sd  11)   -0.98 MRR              40%      7%
   WIG-like                100      95% (sd   8)   -0.74 MRR              40%      5%
   WIG-like                200      95% (sd   6)   -0.64 MRR              42%      5%
   term coverage top1       50      75% (sd  20)   -1.26 MRR              32%     25%
   term coverage top1      100      73% (sd  17)   -1.13 MRR              35%     27%
   term coverage top1      200      75% (sd  14)   -0.85 MRR              26%     25%

## prime_testfull  (2801 questions; tag alarm fires on 1443 = 52%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  21.8  random  19.8  diff  +2.0  p=0.0001
   MRR  : tag  31.5  random  29.7  diff  +1.8  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.9 (p=0.000)        +1.4 (p=0.000)
   40%            +2.1 (p=0.000)        +1.6 (p=0.000)
   50%            +1.9 (p=0.003)        +1.6 (p=0.001)
   52% nat        +2.4 (p=0.000)        +2.0 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.7  95% CI [-1.9, +0.4]  p=0.246
   MRR  :  -1.9  95% CI [-2.8, -1.0]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (52%)
   Hit@1:  +2.5  p=0.000
   MRR  :  +1.3  p=0.004

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/+0.5 (p=0.294)  40%: +0.2/+0.4 (p=0.396)  50%: +0.3/+0.6 (p=0.178)  nat: +0.5/+0.8 (p=0.104)
   vs NQC-like spread      30%: +0.2/+0.4 (p=0.426)  40%: +0.0/+0.3 (p=0.531)  50%: +0.1/+0.3 (p=0.493)  nat: +0.2/+0.5 (p=0.312)
   vs WIG-like             30%: +0.5/+0.6 (p=0.142)  40%: +0.4/+0.7 (p=0.144)  50%: +0.6/+0.9 (p=0.057)  nat: +1.0/+1.1 (p=0.012)
   vs term coverage top1   30%: +0.8/+0.5 (p=0.326)  40%: +0.6/+0.2 (p=0.642)  50%: +0.9/+0.5 (p=0.277)  nat: +1.0/+0.6 (p=0.221)

G. each selector reranking 1443 questions (52%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -1.9  [-2.8, -1.0]  p=0.000
   BM25 margin           -3.9  [-4.8, -3.0]  p=0.000
   top5 vs rest          -2.7  [-3.7, -1.7]  p=0.000
   NQC-like spread       -2.4  [-3.4, -1.4]  p=0.000
   WIG-like              -3.1  [-4.0, -2.1]  p=0.000
   term coverage top1    -2.5  [-3.5, -1.6]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              26.9    27.9    28.9    30.1    31.2    31.7    31.8    32.7    33.1*   33.4*   90%
   BM25 margin            26.3    27.2    27.5    28.4    29.6    30.3    31.1    32.1    32.8    33.4*   100%
   top5 vs rest           26.5    27.5    28.4    29.6    30.5    31.5    32.4    33.1*   33.2*   33.4*   80%
   NQC-like spread        26.8    27.6    28.5    29.8    30.8    31.8    32.6*   33.2*   33.8*   33.4*   70%
   WIG-like               26.7    27.4    28.3    29.4    30.3    31.3    31.9    32.4    32.9    33.4*   100%
   term coverage top1     26.4    27.5    28.5    29.8    30.6    31.6    32.0    32.6    33.1*   33.4*   90%
   ORACLE                 34.3*   38.5*   40.0*   40.1*   40.1*   40.1*   40.1*   40.1*   39.4*   33.4*   10%
   random (expected)      26.5    27.3    28.1    28.8    29.6    30.3    31.1    31.9    32.6    33.4*   100%
   (BM25 only 25.8; rerank ALL 33.4)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -6.5[ -7.8]   -5.5[ -6.8]   -4.5[ -5.6]   -3.3[ -4.3]   -2.2[ -3.2]   -1.7[ -2.5]   -1.6[ -2.2]   -0.7[ -1.3]   -0.3[ -0.6]#   90%   (point estimate: 80%)
   BM25 margin           -7.1[ -8.3]   -6.2[ -7.4]   -5.9[ -7.0]   -4.9[ -6.0]   -3.8[ -4.7]   -3.1[ -3.9]   -2.3[ -3.0]   -1.3[ -1.9]   -0.6[ -1.0]    100%   (point estimate: 90%)
   top5 vs rest          -6.9[ -8.2]   -5.9[ -7.2]   -5.0[ -6.2]   -3.8[ -4.8]   -2.9[ -3.9]   -1.9[ -2.7]   -1.0[ -1.8]   -0.3[ -0.9]#  -0.2[ -0.6]#   80%   (point estimate: 70%)
   NQC-like spread       -6.6[ -7.9]   -5.8[ -7.0]   -4.8[ -6.0]   -3.6[ -4.7]   -2.6[ -3.5]   -1.6[ -2.5]   -0.7[ -1.5]   -0.2[ -0.9]#  +0.4[ -0.0]#   80%   (point estimate: 70%)
   WIG-like              -6.7[ -8.0]   -6.0[ -7.3]   -5.1[ -6.3]   -4.0[ -5.0]   -3.1[ -4.0]   -2.1[ -2.9]   -1.5[ -2.2]   -1.0[ -1.6]   -0.5[ -0.9]#   90%   (point estimate: 80%)
   term coverage top1    -7.0[ -8.3]   -5.9[ -7.1]   -4.9[ -6.1]   -3.5[ -4.6]   -2.8[ -3.8]   -1.8[ -2.7]   -1.4[ -2.2]   -0.8[ -1.4]   -0.3[ -0.7]#   90%   (point estimate: 80%)
   ORACLE                +0.9[ +0.0]#  +5.1[ +4.4]#  +6.6[ +5.9]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.0[ +5.3]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -6.5[ -7.8]   -5.5[ -6.8]   -4.5[ -5.6]   -3.3[ -4.3]   -2.2[ -3.2]   -1.7[ -2.5]   -1.6[ -2.2]   -0.7[ -1.3]   -0.3[ -0.6]    100%   (point estimate: 90%)
   BM25 margin           -7.1[ -8.3]   -6.2[ -7.4]   -5.9[ -7.0]   -4.9[ -6.0]   -3.8[ -4.7]   -3.1[ -3.9]   -2.3[ -3.0]   -1.3[ -1.9]   -0.6[ -1.0]    100%   (point estimate: 100%)
   top5 vs rest          -6.9[ -8.2]   -5.9[ -7.2]   -5.0[ -6.2]   -3.8[ -4.8]   -2.9[ -3.9]   -1.9[ -2.7]   -1.0[ -1.8]   -0.3[ -0.9]   -0.2[ -0.6]    100%   (point estimate: 80%)
   NQC-like spread       -6.6[ -7.9]   -5.8[ -7.0]   -4.8[ -6.0]   -3.6[ -4.7]   -2.6[ -3.5]   -1.6[ -2.5]   -0.7[ -1.5]   -0.2[ -0.9]   +0.4[ -0.0]#   90%   (point estimate: 80%)
   WIG-like              -6.7[ -8.0]   -6.0[ -7.3]   -5.1[ -6.3]   -4.0[ -5.0]   -3.1[ -4.0]   -2.1[ -2.9]   -1.5[ -2.2]   -1.0[ -1.6]   -0.5[ -0.9]    100%   (point estimate: 90%)
   term coverage top1    -7.0[ -8.3]   -5.9[ -7.1]   -4.9[ -6.1]   -3.5[ -4.6]   -2.8[ -3.8]   -1.8[ -2.7]   -1.4[ -2.2]   -0.8[ -1.4]   -0.3[ -0.7]    100%   (point estimate: 90%)
   ORACLE                +0.9[ +0.0]#  +5.1[ +4.4]#  +6.6[ +5.9]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.0[ +5.3]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      77% (sd  27)   -1.26 MRR              32%     23%
   tag alarm               100      79% (sd  20)   -0.99 MRR              33%     21%
   tag alarm               200      76% (sd  19)   -1.09 MRR              36%     24%
   BM25 margin              50      81% (sd  22)   -1.42 MRR              42%     19%
   BM25 margin             100      84% (sd  19)   -1.24 MRR              36%     16%
   BM25 margin             200      86% (sd  15)   -1.04 MRR              38%     14%
   top5 vs rest             50      75% (sd  28)   -1.38 MRR              28%     25%
   top5 vs rest            100      77% (sd  25)   -1.22 MRR              26%     23%
   top5 vs rest            200      72% (sd  20)   -1.31 MRR              38%     28%
   NQC-like spread          50      72% (sd  27)   -1.28 MRR              36%     28%
   NQC-like spread         100      73% (sd  24)   -1.10 MRR              31%     27%
   NQC-like spread         200      71% (sd  17)   -1.03 MRR              34%     29%
   WIG-like                 50      81% (sd  23)   -1.12 MRR              26%     19%
   WIG-like                100      82% (sd  22)   -1.07 MRR              31%     18%
   WIG-like                200      83% (sd  17)   -0.97 MRR              32%     17%
   term coverage top1       50      74% (sd  28)   -1.57 MRR              36%     26%
   term coverage top1      100      78% (sd  25)   -1.30 MRR              32%     22%
   term coverage top1      200      78% (sd  22)   -1.20 MRR              34%     22%

## dbpedia_test  (400 questions; tag alarm fires on 69 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.2  random  54.4  diff  +1.8  p=0.0456
   MRR  : tag  67.9  random  66.4  diff  +1.5  p=0.0185

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.0 (p=0.637)        +1.5 (p=0.181)
   40%            +1.0 (p=0.598)        +1.6 (p=0.125)
   50%            +2.2 (p=0.123)        +1.9 (p=0.054)
   17% nat        +2.2 (p=0.209)        +1.8 (p=0.124)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -13.2  95% CI [-18.0, -8.5]  p=0.000
   MRR  : -10.1  95% CI [-13.4, -6.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (53%)
   Hit@1:  +4.8  p=0.013
   MRR  :  +3.3  p=0.011

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -1.0/-0.9 (p=0.537)  40%: -2.0/-2.0 (p=0.182)  50%: -3.0/-2.8 (p=0.072)  nat: -0.2/-0.2 (p=0.854)
   vs NQC-like spread      30%: -1.8/-1.6 (p=0.227)  40%: -1.2/-1.3 (p=0.358)  50%: -2.5/-2.7 (p=0.073)  nat: -0.2/-0.5 (p=0.690)
   vs WIG-like             30%: +0.5/-0.2 (p=0.859)  40%: +1.8/+0.6 (p=0.654)  50%: +0.2/-0.8 (p=0.576)  nat: +1.0/+0.5 (p=0.642)
   vs term coverage top1   30%: +1.8/+0.9 (p=0.428)  40%: +1.5/+0.7 (p=0.511)  50%: +0.8/-0.5 (p=0.696)  nat: +1.8/+1.2 (p=0.291)

G. each selector reranking 69 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -10.1  [-13.4, -6.8]  p=0.000
   BM25 margin          -11.9  [-15.4, -8.5]  p=0.000
   top5 vs rest          -9.9  [-13.2, -6.6]  p=0.000
   NQC-like spread       -9.6  [-12.8, -6.3]  p=0.000
   WIG-like             -10.6  [-14.0, -7.2]  p=0.000
   term coverage top1   -11.3  [-14.6, -8.0]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              66.2    67.9    69.1    70.0    70.9    71.7    73.2    75.0    76.6    78.0*   100%
   BM25 margin            65.3    66.3    67.6    68.4    69.0    70.8    72.7    75.0    75.8    78.0*   100%
   top5 vs rest           66.7    68.6    70.0    72.0    73.6    74.5    76.7*   76.8*   77.8*   78.0*   70%
   NQC-like spread        67.0    69.2    70.8    71.3    73.6    75.0    76.6*   77.0*   77.7*   78.0*   70%
   WIG-like               66.8    67.9    69.4    69.4    71.7    73.2    74.5    76.3    77.2*   78.0*   90%
   term coverage top1     65.7    67.1    68.2    69.3    71.4    74.1    74.7    76.5    77.3*   78.0*   90%
   ORACLE                 72.6    78.5*   82.8*   83.5*   83.5*   83.5*   83.5*   83.5*   83.3*   78.0*   20%
   random (expected)      65.4    66.8    68.2    69.6    71.0    72.4    73.8    75.2    76.6    78.0*   100%
   (BM25 only 63.9; rerank ALL 78.0)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -11.8[-15.3]  -10.1[-13.3]   -8.9[-11.9]   -8.0[-10.9]   -7.1[ -9.8]   -6.3[ -8.8]   -4.8[ -7.0]   -3.0[ -4.8]   -1.4[ -2.8]    100%   (point estimate: 100%)
   BM25 margin          -12.7[-16.2]  -11.7[-15.2]  -10.4[-13.6]   -9.6[-12.7]   -9.0[-11.9]   -7.2[ -9.8]   -5.3[ -7.6]   -3.0[ -4.9]   -2.2[ -3.7]    100%   (point estimate: 100%)
   top5 vs rest         -11.3[-14.8]   -9.4[-12.7]   -8.0[-11.0]   -6.0[ -8.8]   -4.4[ -6.7]   -3.5[ -5.6]   -1.3[ -3.0]   -1.2[ -2.6]   -0.2[ -1.1]    100%   (point estimate: 90%)
   NQC-like spread      -11.0[-14.4]   -8.8[-11.9]   -7.2[-10.2]   -6.7[ -9.4]   -4.4[ -6.8]   -3.0[ -5.0]   -1.4[ -3.1]   -1.0[ -2.3]   -0.3[ -1.1]    100%   (point estimate: 80%)
   WIG-like             -11.2[-14.8]  -10.1[-13.5]   -8.6[-11.7]   -8.6[-11.4]   -6.3[ -8.8]   -4.8[ -7.0]   -3.5[ -5.3]   -1.7[ -3.1]   -0.8[ -1.9]    100%   (point estimate: 90%)
   term coverage top1   -12.3[-15.9]  -10.9[-14.3]   -9.8[-13.0]   -8.7[-11.4]   -6.6[ -9.0]   -3.9[ -5.7]   -3.3[ -5.0]   -1.5[ -2.7]   -0.7[ -1.6]    100%   (point estimate: 90%)
   ORACLE                -5.4[ -8.4]   +0.5[ -1.7]   +4.8[ +3.1]#  +5.5[ +3.8]#  +5.5[ +3.8]#  +5.5[ +3.8]#  +5.5[ +3.8]#  +5.5[ +3.8]#  +5.3[ +3.7]#   30%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -11.8[-15.3]  -10.1[-13.3]   -8.9[-11.9]   -8.0[-10.9]   -7.1[ -9.8]   -6.3[ -8.8]   -4.8[ -7.0]   -3.0[ -4.8]   -1.4[ -2.8]    100%   (point estimate: 100%)
   BM25 margin          -12.7[-16.2]  -11.7[-15.2]  -10.4[-13.6]   -9.6[-12.7]   -9.0[-11.9]   -7.2[ -9.8]   -5.3[ -7.6]   -3.0[ -4.9]   -2.2[ -3.7]    100%   (point estimate: 100%)
   top5 vs rest         -11.3[-14.8]   -9.4[-12.7]   -8.0[-11.0]   -6.0[ -8.8]   -4.4[ -6.7]   -3.5[ -5.6]   -1.3[ -3.0]   -1.2[ -2.6]   -0.2[ -1.1]    100%   (point estimate: 90%)
   NQC-like spread      -11.0[-14.4]   -8.8[-11.9]   -7.2[-10.2]   -6.7[ -9.4]   -4.4[ -6.8]   -3.0[ -5.0]   -1.4[ -3.1]   -1.0[ -2.3]   -0.3[ -1.1]    100%   (point estimate: 90%)
   WIG-like             -11.2[-14.8]  -10.1[-13.5]   -8.6[-11.7]   -8.6[-11.4]   -6.3[ -8.8]   -4.8[ -7.0]   -3.5[ -5.3]   -1.7[ -3.1]   -0.8[ -1.9]    100%   (point estimate: 100%)
   term coverage top1   -12.3[-15.9]  -10.9[-14.3]   -9.8[-13.0]   -8.7[-11.4]   -6.6[ -9.0]   -3.9[ -5.7]   -3.3[ -5.0]   -1.5[ -2.7]   -0.7[ -1.6]    100%   (point estimate: 100%)
   ORACLE                -5.4[ -8.4]   +0.5[ -1.7]   +4.8[ +3.1]#  +5.5[ +3.8]#  +5.5[ +3.8]#  +5.5[ +3.8]#  +5.5[ +3.8]#  +5.5[ +3.8]#  +5.3[ +3.7]#   30%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      92% (sd  13)   -1.28 MRR              41%      8%
   tag alarm               100      96% (sd   8)   -0.77 MRR              30%      4%
   tag alarm               200      97% (sd   5)   -0.70 MRR              31%      3%
   BM25 margin              50      95% (sd  11)   -1.03 MRR              28%      5%
   BM25 margin             100      97% (sd   6)   -0.61 MRR              19%      3%
   BM25 margin             200      99% (sd   3)   -0.26 MRR               8%      1%
   top5 vs rest             50      83% (sd  19)   -1.34 MRR              39%     17%
   top5 vs rest            100      85% (sd  13)   -0.98 MRR              38%     15%
   top5 vs rest            200      85% (sd  10)   -0.95 MRR              36%     15%
   NQC-like spread          50      83% (sd  17)   -1.14 MRR              37%     17%
   NQC-like spread         100      82% (sd  14)   -1.23 MRR              46%     18%
   NQC-like spread         200      82% (sd   9)   -1.03 MRR              46%     18%
   WIG-like                 50      90% (sd  12)   -1.09 MRR              28%     10%
   WIG-like                100      91% (sd  10)   -0.96 MRR              32%      9%
   WIG-like                200      92% (sd   6)   -0.83 MRR              32%      8%
   term coverage top1       50      93% (sd  11)   -0.76 MRR              29%      7%
   term coverage top1      100      92% (sd  10)   -0.89 MRR              35%      8%
   term coverage top1      200      95% (sd   6)   -0.59 MRR              28%      5%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  24%  MRR  68.1 | vs BM25 margin: +6.4 (p=0.009)  vs top5 vs rest: -0.0 (p=0.991)  vs NQC-like spread: +0.4 (p=0.882)  vs WIG-like: +1.9 (p=0.481)  vs term coverage top1: +1.9 (p=0.461)
   list           n= 105  fires  18%  MRR  69.8 | vs BM25 margin: +0.7 (p=0.775)  vs top5 vs rest: +2.3 (p=0.292)  vs NQC-like spread: +1.0 (p=0.676)  vs WIG-like: +2.9 (p=0.162)  vs term coverage top1: +3.2 (p=0.103)
   question       n= 125  fires  18%  MRR  59.9 | vs BM25 margin: +2.6 (p=0.247)  vs top5 vs rest: -0.8 (p=0.758)  vs NQC-like spread: -1.3 (p=0.626)  vs WIG-like: -1.9 (p=0.407)  vs term coverage top1: +0.7 (p=0.769)
   named entity   n=  86  fires   9%  MRR  76.9 | vs BM25 margin: -2.6 (p=0.233)  vs top5 vs rest: -2.8 (p=0.123)  vs NQC-like spread: -2.2 (p=0.247)  vs WIG-like: -0.2 (p=1.000)  vs term coverage top1: -1.4 (p=0.402)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR -1.2  [-4.0, +1.5]  p=0.393  (n=211)

## POOLED over 4 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  42.7  random  37.7  diff  +5.0  p=0.0001
   MRR  : tag  52.2  random  48.4  diff  +3.8  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +2.9 (p=0.000)   MRR  +2.4 (p=0.000)
   40%      Hit@1  +4.5 (p=0.000)   MRR  +3.8 (p=0.000)
   50%      Hit@1  +4.5 (p=0.000)   MRR  +3.8 (p=0.000)
   natural  Hit@1  +4.9 (p=0.000)   MRR  +4.1 (p=0.000)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -3.1  95% CI [-3.9, -2.3]  p=0.000
   MRR  :  -3.6  95% CI [-4.1, -3.0]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +4.4  p=0.000
   MRR  :  +3.0  p=0.000

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +0.2/+0.2 (p=0.594)  40%: +1.3/+1.0 (p=0.003)  50%: +0.8/+0.5 (p=0.123)  nat: +1.6/+1.2 (p=0.000)
   vs NQC-like spread      30%: -0.6/-0.5 (p=0.099)  40%: +0.8/+0.6 (p=0.063)  50%: +0.4/+0.1 (p=0.709)  nat: +1.0/+0.7 (p=0.020)
   vs WIG-like             30%: +1.6/+1.2 (p=0.000)  40%: +3.2/+2.5 (p=0.000)  50%: +3.1/+2.3 (p=0.000)  nat: +3.4/+2.7 (p=0.000)
   vs term coverage top1   30%: +0.7/+0.4 (p=0.161)  40%: +1.5/+1.1 (p=0.000)  50%: +1.2/+0.7 (p=0.017)  nat: +1.7/+1.3 (p=0.000)
