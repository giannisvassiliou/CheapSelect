# holdout48: revised checklist (v2) on a second held-out set (200 splits, n = 200)

## held-out-2 (THE TEST): 14 pairs, 84 cells; hindsight best saves 16.2

strategy       | mean saving | P(violation) | mean regret | P(correct)
---------------|------------:|-------------:|------------:|-----------:
v2             |         9.4 |        0.021 |         7.1 |       0.51
v1             |         8.7 |        0.046 |         8.2 |       0.38
choose_split   |        10.6 |        0.064 |         6.9 |       0.52
always_wig     |         7.5 |        0.044 |         9.6 |       0.34
always_random  |         6.2 |        0.013 |        10.2 |       0.29
always_all     |         0.0 |        0.000 |        16.2 |       0.18

v2 - v1 saving per cell: mean +0.7, v2 higher in 52, equal in 3, lower in 29 of 84 cells

per pair at MRR, delta = 1: saving / P(violation)
pair                             rho  hind |            v2 (chosen)           |            v1 |  choose_split
beir_cqa_physics:h48mini         6.5  14.9 |   9.4 / 0.000 (BM25 margin 0.74) |   6.2 / 0.100 |  11.5 / 0.045
beir_cqa_physics:h48bge          5.4  16.8 |   8.2 / 0.015 (BM25 margin 0.59) |   7.3 / 0.050 |  13.1 / 0.030
beir_cqa_physics:h48monot5      11.2   9.5 |   6.1 / 0.005 (BM25 margin 0.56) |   1.5 / 0.070 |   9.7 / 0.025
beir_cqa_unix:h48mini            6.8  13.2 |   8.5 / 0.070 (BM25 margin 0.44) |   8.7 / 0.055 |   8.5 / 0.140
beir_cqa_unix:h48bge             7.0  16.0 |  10.6 / 0.025 (BM25 margin 0.74) |  10.6 / 0.065 |  10.3 / 0.065
beir_cqa_unix:h48monot5         12.0   9.4 |   7.7 / 0.075 (BM25 margin 0.57) |   5.0 / 0.025 |   8.6 / 0.175
beir_cqa_tex:h48mini             4.8  18.7 |  11.9 / 0.010 (BM25 margin 0.71) |  10.6 / 0.115 |  12.6 / 0.055
beir_cqa_tex:h48bge              2.3  40.5 |  12.9 / 0.005 (BM25 margin 0.47) |  22.8 / 0.055 |  16.6 / 0.045
beir_cqa_tex:h48monot5           7.6  14.3 |   9.3 / 0.030 (BM25 margin 0.72) |   6.3 / 0.055 |  10.1 / 0.090
beir_cqa_programmers:h48mini     7.8  17.3 |  13.0 / 0.015 (BM25 margin 0.92) |   6.2 / 0.020 |  14.8 / 0.095
beir_cqa_programmers:h48bge      7.1  22.1 |   8.7 / 0.000 (BM25 margin 0.69) |  10.3 / 0.065 |  11.8 / 0.060
beir_cqa_programmers:h48monot5  12.5  12.8 |   9.4 / 0.000 (BM25 margin 0.86) |   1.0 / 0.040 |  11.2 / 0.035
beir_fever:h48mini              29.7   4.8 |   3.5 / 0.005 (all 0.62) |   0.0 / 0.000 |   5.1 / 0.040
beir_fever:h48bge               33.5   3.4 |   1.6 / 0.010 (all 0.81) |   0.0 / 0.000 |   2.9 / 0.015

skipped: none
