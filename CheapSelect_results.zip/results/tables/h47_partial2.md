# holdout47: practitioner checklist on held-out collections (200 splits, n = 200 labels, rule UCB95, boundaries 1*delta and 15*delta, correct = no violation and regret <= 5 points)

## held-out: 14 pairs, 84 pair x metric x delta cells

strategy        | mean saving | P(violation) | mean regret | P(correct) | P(same family as hindsight)
----------------|------------:|-------------:|------------:|-----------:|---------------------------:
checklist       |         5.9 |        0.039 |         9.7 |       0.47 |       0.46
no_regime       |         6.0 |        0.043 |         9.7 |       0.47 |       0.21
always_wig      |         4.2 |        0.037 |        11.6 |       0.40 |       0.61
always_random   |         4.7 |        0.010 |        10.6 |       0.44 |       0.04
always_all      |         0.0 |        0.000 |        15.2 |       0.36 |       0.36
hindsight best  |        15.2 |   (uses test labels: upper bound)

regime called from 200 labels = regime from all labels: 0.94 of splits

pair                             metric delta  gain  rho  regime | C: low/mid/high | checklist save viol regret correct | hindsight save family (top selector)
beir_cqa_english:h47mini         MRR    0.5    6.0  11.9 middle | 0.01/0.76/0.23 |   1.5 0.070   6.9 0.42 |   7.8 selector (BM25 margin)
beir_cqa_english:h47mini         MRR    1.0    6.0   6.0 middle | 0.01/0.99/0.00 |   9.1 0.060   7.9 0.43 |  16.1 selector (BM25 margin)
beir_cqa_english:h47mini         MRR    2.0    6.0   3.0 middle | 0.01/0.98/0.00 |  20.7 0.110   9.7 0.33 |  28.3 selector (BM25 margin)
beir_cqa_english:h47mini         ndcg   0.5    3.5   7.0 middle | 0.01/0.99/0.00 |   7.4 0.085   7.0 0.45 |  13.2 selector (BM25 margin)
beir_cqa_english:h47mini         ndcg   1.0    3.5   3.5 middle | 0.01/0.99/0.00 |  18.4 0.100   7.3 0.39 |  24.3 selector (NQC-like spread)
beir_cqa_english:h47mini         ndcg   2.0    3.5   1.7 middle | 0.07/0.94/0.00 |  38.3 0.080   8.7 0.35 |  44.3 selector (NQC-like spread)
beir_cqa_english:h47bge          MRR    0.5    6.0  12.1 middle | 0.01/0.76/0.24 |   2.5 0.075   9.9 0.33 |  11.0 selector (BM25 margin)
beir_cqa_english:h47bge          MRR    1.0    6.0   6.0 middle | 0.01/0.99/0.00 |  10.2 0.075  13.1 0.23 |  21.7 selector (BM25 margin)
beir_cqa_english:h47bge          MRR    2.0    6.0   3.0 middle | 0.04/0.96/0.00 |  23.8 0.135  15.1 0.16 |  36.1 selector (BM25 margin)
beir_cqa_english:h47bge          ndcg   0.5    3.8   7.6 middle | 0.01/0.99/0.01 |   7.1 0.070  10.4 0.27 |  16.1 selector (NQC-like spread)
beir_cqa_english:h47bge          ndcg   1.0    3.8   3.8 middle | 0.01/0.99/0.00 |  19.9 0.090  10.9 0.28 |  28.6 selector (NQC-like spread)
beir_cqa_english:h47bge          ndcg   2.0    3.8   1.9 middle | 0.09/0.92/0.00 |  38.0 0.090  11.3 0.21 |  47.4 selector (NQC-like spread)
beir_cqa_english:h47monot5       MRR    0.5   11.0  22.1 high   | 0.00/0.05/0.95 |   0.1 0.010   4.0 0.61 |   4.0 all (BM25 margin)
beir_cqa_english:h47monot5       MRR    1.0   11.0  11.0 middle | 0.00/0.98/0.02 |   2.4 0.085   9.2 0.25 |  10.7 selector (BM25 margin)
beir_cqa_english:h47monot5       MRR    2.0   11.0   5.5 middle | 0.00/1.00/0.00 |  12.5 0.090   8.3 0.28 |  19.8 selector (BM25 margin)
beir_cqa_english:h47monot5       ndcg   0.5    6.6  13.1 middle | 0.00/0.80/0.20 |   1.7 0.060   5.7 0.43 |   6.9 selector (BM25 margin)
beir_cqa_english:h47monot5       ndcg   1.0    6.6   6.6 middle | 0.00/1.00/0.00 |  11.5 0.085   6.1 0.39 |  16.8 selector (BM25 margin)
beir_cqa_english:h47monot5       ndcg   2.0    6.6   3.3 middle | 0.00/1.00/0.00 |  24.0 0.095   7.9 0.32 |  30.5 selector (NQC-like spread)
beir_cqa_gaming:h47mini          MRR    0.5    7.9  15.8 high   | 0.00/0.42/0.58 |   0.1 0.005  10.3 0.27 |  10.4 selector (BM25 margin)
beir_cqa_gaming:h47mini          MRR    1.0    7.9   7.9 middle | 0.00/1.00/0.00 |   3.9 0.065  14.5 0.10 |  17.6 selector (BM25 margin)
beir_cqa_gaming:h47mini          MRR    2.0    7.9   3.9 middle | 0.00/1.00/0.00 |  15.3 0.045  16.3 0.12 |  30.8 selector (BM25 margin)
beir_cqa_gaming:h47mini          ndcg   0.5    5.0   9.9 middle | 0.00/0.99/0.01 |   2.0 0.090  12.8 0.13 |  13.7 selector (BM25 margin)
beir_cqa_gaming:h47mini          ndcg   1.0    5.0   5.0 middle | 0.00/1.00/0.00 |  13.2 0.060  13.2 0.19 |  25.4 selector (BM25 margin)
beir_cqa_gaming:h47mini          ndcg   2.0    5.0   2.5 middle | 0.00/1.00/0.00 |  30.3 0.080  13.6 0.12 |  43.0 selector (BM25 margin)
beir_cqa_gaming:h47bge           MRR    0.5    8.1  16.1 high   | 0.00/0.39/0.61 |   0.5 0.025  12.8 0.10 |  12.7 selector (BM25 margin)
beir_cqa_gaming:h47bge           MRR    1.0    8.1   8.1 middle | 0.00/1.00/0.00 |   3.6 0.065  16.1 0.08 |  18.9 selector (BM25 margin)
beir_cqa_gaming:h47bge           MRR    2.0    8.1   4.0 middle | 0.01/0.99/0.00 |  15.2 0.050  18.5 0.10 |  32.8 selector (BM25 margin)
beir_cqa_gaming:h47bge           ndcg   0.5    5.1  10.2 middle | 0.00/0.99/0.01 |   1.4 0.110  13.2 0.09 |  13.4 selector (BM25 margin)
beir_cqa_gaming:h47bge           ndcg   1.0    5.1   5.1 middle | 0.00/1.00/0.00 |  12.3 0.080  13.9 0.17 |  25.1 selector (BM25 margin)
beir_cqa_gaming:h47bge           ndcg   2.0    5.1   2.6 middle | 0.01/0.99/0.00 |  29.1 0.060  14.3 0.14 |  42.6 selector (BM25 margin)
beir_cqa_gaming:h47monot5        MRR    0.5   13.5  27.0 high   | 0.00/0.01/0.99 |   0.0 0.000   9.8 0.17 |   9.8 selector (BM25 margin)
beir_cqa_gaming:h47monot5        MRR    1.0   13.5  13.5 middle | 0.00/0.78/0.23 |   0.6 0.050  13.9 0.06 |  13.9 selector (BM25 margin)
beir_cqa_gaming:h47monot5        MRR    2.0   13.5   6.8 middle | 0.00/1.00/0.00 |   9.8 0.045  12.2 0.17 |  21.5 selector (BM25 margin)
beir_cqa_gaming:h47monot5        ndcg   0.5    8.6  17.2 high   | 0.00/0.18/0.82 |   0.2 0.015  10.4 0.20 |  10.4 selector (BM25 margin)
beir_cqa_gaming:h47monot5        ndcg   1.0    8.6   8.6 middle | 0.00/1.00/0.00 |   4.8 0.055  13.3 0.11 |  17.4 selector (BM25 margin)
beir_cqa_gaming:h47monot5        ndcg   2.0    8.6   4.3 middle | 0.00/1.00/0.00 |  15.9 0.025  16.1 0.07 |  31.5 selector (BM25 margin)
beir_climate-fever:h47mini       MRR    0.5   12.7  25.5 high   | 0.00/0.01/0.99 |   0.0 0.000   0.1 0.98 |   0.1 all (BM25 margin)
beir_climate-fever:h47mini       MRR    1.0   12.7  12.7 middle | 0.00/0.85/0.15 |   0.1 0.010   1.7 0.81 |   1.7 all (BM25 margin)
beir_climate-fever:h47mini       MRR    2.0   12.7   6.4 middle | 0.00/1.00/0.00 |   9.3 0.050   2.1 0.78 |  11.5 selector (BM25 margin)
beir_climate-fever:h47mini       ndcg   0.5    9.5  19.1 high   | 0.00/0.04/0.96 |   0.0 0.000   0.1 0.98 |   0.1 all (BM25 margin)
beir_climate-fever:h47mini       ndcg   1.0    9.5   9.5 middle | 0.00/1.00/0.00 |   0.8 0.045   3.8 0.56 |   4.2 all (BM25 margin)
beir_climate-fever:h47mini       ndcg   2.0    9.5   4.8 middle | 0.00/1.00/0.00 |  10.5 0.080   4.7 0.55 |  14.9 selector (BM25 margin)
beir_climate-fever:h47bge        MRR    0.5   18.4  36.7 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_climate-fever:h47bge        MRR    1.0   18.4  18.4 high   | 0.00/0.07/0.93 |   0.0 0.000   0.3 0.96 |   0.3 all (BM25 margin)
beir_climate-fever:h47bge        MRR    2.0   18.4   9.2 middle | 0.00/1.00/0.00 |   1.5 0.035   3.5 0.60 |   4.7 all (BM25 margin)
beir_climate-fever:h47bge        ndcg   0.5   13.5  26.9 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_climate-fever:h47bge        ndcg   1.0   13.5  13.5 middle | 0.00/0.84/0.15 |   0.0 0.005   0.6 0.92 |   0.6 all (BM25 margin)
beir_climate-fever:h47bge        ndcg   2.0   13.5   6.7 middle | 0.00/1.00/0.00 |   9.9 0.050   0.9 0.91 |  10.8 random (BM25 margin)
beir_climate-fever:h47monot5     MRR    0.5   16.5  33.1 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_climate-fever:h47monot5     MRR    1.0   16.5  16.5 high   | 0.00/0.22/0.78 |   0.0 0.000   0.3 0.96 |   0.3 all (BM25 margin)
beir_climate-fever:h47monot5     MRR    2.0   16.5   8.3 middle | 0.00/1.00/0.00 |   3.8 0.035   3.9 0.57 |   7.6 selector (BM25 margin)
beir_climate-fever:h47monot5     ndcg   0.5   11.8  23.5 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_climate-fever:h47monot5     ndcg   1.0   11.8  11.8 middle | 0.00/0.99/0.01 |   0.1 0.015   1.6 0.80 |   1.5 all (BM25 margin)
beir_climate-fever:h47monot5     ndcg   2.0   11.8   5.9 middle | 0.00/1.00/0.00 |   9.9 0.050   1.7 0.86 |  11.6 selector (BM25 margin)
beir_hotpotqa:h47mini            MRR    0.5   14.3  28.5 high   | 0.00/0.00/1.00 |   0.0 0.000  25.5 0.04 |  25.5 selector (BM25 margin)
beir_hotpotqa:h47mini            MRR    1.0   14.3  14.3 middle | 0.00/0.64/0.36 |   0.6 0.050  34.2 0.01 |  34.3 selector (BM25 margin)
beir_hotpotqa:h47mini            MRR    2.0   14.3   7.1 middle | 0.00/1.00/0.00 |   8.8 0.065  34.9 0.00 |  43.0 selector (BM25 margin)
beir_hotpotqa:h47mini            ndcg   0.5   13.1  26.2 high   | 0.00/0.00/1.00 |   0.0 0.000   2.5 0.74 |   2.5 all (BM25 margin)
beir_hotpotqa:h47mini            ndcg   1.0   13.1  13.1 middle | 0.00/0.87/0.13 |   0.6 0.045  10.2 0.14 |  10.3 selector (BM25 margin)
beir_hotpotqa:h47mini            ndcg   2.0   13.1   6.6 middle | 0.00/1.00/0.00 |  10.0 0.030  16.6 0.07 |  26.3 selector (BM25 margin)
beir_hotpotqa:h47bge             MRR    0.5   18.1  36.2 high   | 0.00/0.00/1.00 |   0.0 0.000  23.5 0.03 |  23.5 selector (BM25 margin)
beir_hotpotqa:h47bge             MRR    1.0   18.1  18.1 high   | 0.00/0.07/0.93 |   0.1 0.010  30.5 0.00 |  30.5 selector (BM25 margin)
beir_hotpotqa:h47bge             MRR    2.0   18.1   9.1 middle | 0.00/1.00/0.00 |   3.9 0.035  36.2 0.00 |  39.7 selector (BM25 margin)
beir_hotpotqa:h47bge             ndcg   0.5   19.2  38.5 high   | 0.00/0.00/1.00 |   0.0 0.000   0.1 1.00 |   0.1 all (BM25 margin)
beir_hotpotqa:h47bge             ndcg   1.0   19.2  19.2 high   | 0.00/0.00/1.00 |   0.0 0.000   3.5 0.62 |   3.5 all (BM25 margin)
beir_hotpotqa:h47bge             ndcg   2.0   19.2   9.6 middle | 0.00/1.00/0.00 |   1.4 0.050  13.1 0.09 |  14.1 selector (BM25 margin)
beir_hotpotqa:h47monot5          MRR    0.5   12.3  24.6 high   | 0.00/0.01/0.98 |   0.0 0.000  40.6 0.01 |  40.6 selector (BM25 margin)
beir_hotpotqa:h47monot5          MRR    1.0   12.3  12.3 middle | 0.00/0.84/0.15 |   0.4 0.035  45.2 0.00 |  45.3 selector (BM25 margin)
beir_hotpotqa:h47monot5          MRR    2.0   12.3   6.1 middle | 0.00/1.00/0.00 |   9.1 0.025  41.7 0.00 |  50.7 selector (BM25 margin)
beir_hotpotqa:h47monot5          ndcg   0.5   14.3  28.6 high   | 0.00/0.00/1.00 |   0.0 0.000   2.1 0.78 |   2.1 all (BM25 margin)
beir_hotpotqa:h47monot5          ndcg   1.0   14.3  14.3 middle | 0.00/0.62/0.38 |   0.2 0.015  10.2 0.12 |  10.2 selector (BM25 margin)
beir_hotpotqa:h47monot5          ndcg   2.0   14.3   7.2 middle | 0.00/1.00/0.00 |   8.8 0.050  16.2 0.11 |  24.8 selector (BM25 margin)
beir_nq:h47mini                  MRR    0.5   24.1  48.2 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_nq:h47mini                  MRR    1.0   24.1  24.1 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_nq:h47mini                  MRR    2.0   24.1  12.1 middle | 0.00/1.00/0.00 |   0.3 0.025   0.4 0.94 |   0.4 all (BM25 margin)
beir_nq:h47mini                  ndcg   0.5   24.5  48.9 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_nq:h47mini                  ndcg   1.0   24.5  24.5 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_nq:h47mini                  ndcg   2.0   24.5  12.2 middle | 0.00/0.99/0.01 |   0.4 0.035   0.4 0.92 |   0.5 all (tag alarm)
beir_nq:h47bge                   MRR    0.5   29.2  58.4 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_nq:h47bge                   MRR    1.0   29.2  29.2 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_nq:h47bge                   MRR    2.0   29.2  14.6 middle | 0.00/0.64/0.36 |   0.1 0.010   0.3 0.95 |   0.3 all (BM25 margin)
beir_nq:h47bge                   ndcg   0.5   29.0  58.0 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_nq:h47bge                   ndcg   1.0   29.0  29.0 high   | 0.00/0.00/1.00 |   0.0 0.000   0.0 1.00 |   0.0 all ()
beir_nq:h47bge                   ndcg   2.0   29.0  14.5 middle | 0.00/0.65/0.35 |   0.2 0.020   0.2 0.95 |   0.2 all (tag alarm)

## by rho = mean gain / delta (whole collection)

group     rho bucket    cells | hindsight save  P(all/random/selector best) | random save | WIG save viol | checklist save correct
held-out  (1, 3]            5 |           41.1  0.01/0.04/0.96               |        26.5 |     28.1 0.063 |           31.3 0.23
held-out  (3, 7]           21 |           23.8  0.01/0.12/0.88               |        10.8 |      8.2 0.057 |           13.2 0.33
held-out  (7, 15]          29 |           13.5  0.33/0.02/0.66               |         1.3 |      1.3 0.043 |            2.2 0.37
held-out  (15, 30]         21 |            7.3  0.64/0.00/0.36               |         0.0 |      0.2 0.016 |            0.1 0.64
held-out  (30, inf]         8 |            2.9  0.88/0.00/0.12               |         0.0 |      0.0 0.002 |            0.0 0.88

skipped: none
