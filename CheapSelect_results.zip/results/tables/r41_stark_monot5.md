# router41: label-free signals vs pre-retrieval vs trained routers  (deltas [1.0, 0.5] MRR points)

## amazon_testfull (tag monot5; n=1642; mean gain +14.3 MRR; helped 35% hurt 13%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.07   rho(gain) +0.01
   avgIDF   rho(quality) +0.25   rho(gain) -0.15
   maxIDF   rho(quality) +0.29   rho(gain) -0.13
   avgICTF  rho(quality) +0.25   rho(gain) -0.14
   avgSCQ   rho(quality) +0.18   rho(gain) -0.12
   maxSCQ   rho(quality) +0.14   rho(gain) -0.05
   SCS      rho(quality) +0.16   rho(gain) -0.11

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/80          90/90           +20             -4.6     -0.2 (0.761)
   tag alarm                                 90/90          90/90           +10             -4.6     -0.2 (0.778)
   top5 vs rest                              90/80         100/90           +20             -3.2     +1.2 (0.063)
   NQC-like spread                           90/70         100/90           +30             -2.8     +1.6 (0.008)
   WIG-like                                 100/90         100/100          +10             -4.4          -
   term coverage top1                       100/100        100/100           +0             -8.0     -3.7 (0.000)
   pre:qlen                                 100/100        100/100           +0             -6.9     -2.5 (0.002)
   pre:avgIDF                               100/90         100/100          +10             -4.4     -0.1 (0.905)
   pre:maxIDF                               100/80         100/90           +20             -5.0     -0.7 (0.291)
   pre:avgICTF                               90/90         100/90           +10             -5.0     -0.6 (0.354)
   pre:avgSCQ                               100/100        100/100           +0             -5.2     -0.8 (0.161)
   pre:maxSCQ                               100/100        100/100           +0             -6.0     -1.6 (0.004)
   pre:SCS                                  100/90         100/100          +10             -5.7     -1.3 (0.061)
   router ridge S (5-fold CV)                80/70         100/80           +30             -2.2     +2.2 (0.000)
   router gbm S (5-fold CV)                 100/90         100/100          +10             -4.1     +0.3 (0.657)
   router ridge S+P (5-fold CV)              80/70         100/80           +30             -2.3     +2.1 (0.000)
   router gbm S+P (5-fold CV)               100/90         100/100          +10             -4.6     -0.2 (0.764)
   router ridge S (other collections)       100/90         100/100          +10             -4.2     +0.2 (0.780)
   router gbm S (other collections)         100/90         100/100          +10             -4.2     +0.2 (0.742)
   router ridge S+P (other collections)     100/90         100/100          +10             -4.5     -0.1 (0.895)
   router gbm S+P (other collections)       100/90         100/100          +10             -4.4     -0.0 (0.942)
   ORACLE                                    20/20          20/20           +80             +5.6    +10.0 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.160, tag alarm +0.115, top5 vs rest -0.127, NQC-like spread -0.080, WIG-like -0.152, term coverage top1 +0.045
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.171, tag alarm +0.102, top5 vs rest -0.100, NQC-like spread -0.141, WIG-like -0.228, term coverage top1 +0.099, qlen +0.173, avgIDF -0.135, maxIDF +0.034, avgICTF +0.017, avgSCQ -0.021, maxSCQ +0.080, SCS +0.233

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -7.5   -4.4   -2.0
   n=  50  router ridge S+P        -7.4   -4.2   -1.9   P(router > WIG-like @50%) = 63%
   n=  50  router gbm   S+P        -8.0   -4.7   -2.5   P(router > WIG-like @50%) = 46%
   n= 100  WIG-like                 -7.6   -4.4   -2.0
   n= 100  router ridge S+P        -6.8   -3.5   -1.5   P(router > WIG-like @50%) = 86%
   n= 100  router gbm   S+P        -7.8   -4.8   -2.5   P(router > WIG-like @50%) = 32%
   n= 200  WIG-like                 -7.6   -4.4   -2.0
   n= 200  router ridge S+P        -6.4   -3.1   -1.2   P(router > WIG-like @50%) = 97%
   n= 200  router gbm   S+P        -7.9   -4.9   -2.5   P(router > WIG-like @50%) = 30%

## mag_testfull (tag monot5; n=2665; mean gain +7.5 MRR; helped 26% hurt 15%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.31   rho(gain) +0.05
   avgIDF   rho(quality) +0.20   rho(gain) +0.02
   maxIDF   rho(quality) +0.07   rho(gain) -0.02
   avgICTF  rho(quality) +0.18   rho(gain) +0.03
   avgSCQ   rho(quality) +0.10   rho(gain) +0.01
   maxSCQ   rho(quality) +0.01   rho(gain) +0.01
   SCS      rho(quality) +0.28   rho(gain) +0.04

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               70/70          80/70           +20             -2.4     -0.2 (0.701)
   tag alarm                                 70/50          80/70           +40             -1.0     +1.2 (0.011)
   top5 vs rest                             100/90         100/100           +0             -3.2     -1.0 (0.005)
   NQC-like spread                           90/90         100/100           +0             -2.9     -0.7 (0.065)
   WIG-like                                  90/80         100/80           +10             -2.2          -
   term coverage top1                        80/60          90/80           +30             -1.0     +1.2 (0.003)
   pre:qlen                                 100/100        100/100          -10             -4.5     -2.3 (0.000)
   pre:avgIDF                               100/90         100/100           +0             -4.2     -2.0 (0.000)
   pre:maxIDF                                90/90         100/100           +0             -3.5     -1.3 (0.008)
   pre:avgICTF                              100/90         100/100           +0             -4.3     -2.1 (0.000)
   pre:avgSCQ                                90/90         100/100           +0             -4.2     -2.0 (0.000)
   pre:maxSCQ                                90/90         100/100           +0             -3.7     -1.5 (0.000)
   pre:SCS                                  100/90         100/100           +0             -4.4     -2.2 (0.000)
   router ridge S (5-fold CV)                50/40          60/50           +50             -0.1     +2.1 (0.000)
   router gbm S (5-fold CV)                  70/60         100/70           +30             -1.1     +1.1 (0.018)
   router ridge S+P (5-fold CV)              50/40          80/50           +50             -0.1     +2.1 (0.000)
   router gbm S+P (5-fold CV)                70/50         100/70           +40             -1.0     +1.2 (0.005)
   router ridge S (other collections)        90/70         100/90           +20             -1.4     +0.8 (0.015)
   router gbm S (other collections)          80/70         100/80           +20             -2.1     +0.1 (0.776)
   router ridge S+P (other collections)      90/70         100/90           +20             -1.5     +0.7 (0.044)
   router gbm S+P (other collections)        90/80         100/90           +10             -2.1     +0.1 (0.797)
   ORACLE                                    10/10          10/10           +80             +6.1     +8.3 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.098, tag alarm +0.260, top5 vs rest +0.030, NQC-like spread +0.043, WIG-like -0.135, term coverage top1 -0.110
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.094, tag alarm +0.267, top5 vs rest +0.057, NQC-like spread +0.010, WIG-like -0.120, term coverage top1 -0.133, qlen -0.015, avgIDF +0.051, maxIDF -0.011, avgICTF -0.171, avgSCQ +0.006, maxSCQ +0.063, SCS +0.137

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -3.0   -2.2   -1.1
   n=  50  router ridge S+P        -3.2   -1.6   -0.7   P(router > WIG-like @50%) = 73%
   n=  50  router gbm   S+P        -4.1   -2.5   -1.3   P(router > WIG-like @50%) = 41%
   n= 100  WIG-like                 -3.0   -2.2   -1.1
   n= 100  router ridge S+P        -2.8   -1.4   -0.5   P(router > WIG-like @50%) = 91%
   n= 100  router gbm   S+P        -3.5   -2.0   -0.9   P(router > WIG-like @50%) = 66%
   n= 200  WIG-like                 -3.0   -2.2   -1.1
   n= 200  router ridge S+P        -2.3   -0.9   -0.2   P(router > WIG-like @50%) = 100%
   n= 200  router gbm   S+P        -3.3   -1.8   -0.8   P(router > WIG-like @50%) = 82%

## prime_testfull (tag monot5; n=2801; mean gain +7.1 MRR; helped 30% hurt 17%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.24   rho(gain) +0.08
   avgIDF   rho(quality) +0.10   rho(gain) +0.02
   maxIDF   rho(quality) +0.10   rho(gain) -0.01
   avgICTF  rho(quality) +0.07   rho(gain) +0.02
   avgSCQ   rho(quality) +0.14   rho(gain) -0.02
   maxSCQ   rho(quality) +0.28   rho(gain) -0.02
   SCS      rho(quality) -0.03   rho(gain) +0.06

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               80/80          90/80           +10             -3.0     -1.3 (0.008)
   tag alarm                                 70/50          90/70           +40             -1.0     +0.7 (0.074)
   top5 vs rest                              90/70         100/80           +20             -2.0     -0.3 (0.343)
   NQC-like spread                           90/60         100/80           +30             -1.3     +0.5 (0.126)
   WIG-like                                  70/60          90/70           +30             -1.7          -
   term coverage top1                        90/80         100/90           +10             -3.0     -1.2 (0.002)
   pre:qlen                                 100/100        100/100          -10             -4.5     -2.8 (0.000)
   pre:avgIDF                               100/90         100/100           +0             -3.8     -2.1 (0.000)
   pre:maxIDF                               100/90         100/100           +0             -3.0     -1.3 (0.012)
   pre:avgICTF                              100/90         100/100           +0             -3.8     -2.1 (0.000)
   pre:avgSCQ                               100/80         100/100          +10             -3.2     -1.5 (0.001)
   pre:maxSCQ                               100/90         100/100           +0             -3.5     -1.7 (0.000)
   pre:SCS                                  100/100        100/100          -10             -4.3     -2.6 (0.000)
   router ridge S (5-fold CV)                80/50          90/60           +40             -0.9     +0.8 (0.016)
   router gbm S (5-fold CV)                  90/70         100/90           +20             -2.1     -0.4 (0.295)
   router ridge S+P (5-fold CV)              60/50          80/60           +40             -0.5     +1.2 (0.000)
   router gbm S+P (5-fold CV)                80/60          90/70           +30             -1.5     +0.2 (0.605)
   router ridge S (other collections)        70/50          80/60           +40             -0.9     +0.8 (0.016)
   router gbm S (other collections)          80/60          90/80           +30             -1.1     +0.6 (0.106)
   router ridge S+P (other collections)      70/60          80/60           +30             -1.0     +0.7 (0.036)
   router gbm S+P (other collections)        70/50          80/70           +40             -0.9     +0.8 (0.034)
   ORACLE                                    10/10          10/10           +80             +6.2     +8.0 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.008, tag alarm +0.141, top5 vs rest +0.053, NQC-like spread -0.105, WIG-like -0.084, term coverage top1 +0.012
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.001, tag alarm +0.166, top5 vs rest +0.046, NQC-like spread -0.158, WIG-like -0.030, term coverage top1 -0.004, qlen +0.013, avgIDF +0.381, maxIDF -0.077, avgICTF -0.484, avgSCQ -0.084, maxSCQ +0.058, SCS +0.257

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -3.6   -1.7   -0.2
   n=  50  router ridge S+P        -4.0   -2.2   -1.0   P(router > WIG-like @50%) = 29%
   n=  50  router gbm   S+P        -4.2   -2.7   -1.4   P(router > WIG-like @50%) = 11%
   n= 100  WIG-like                 -3.6   -1.7   -0.2
   n= 100  router ridge S+P        -3.7   -2.0   -0.7   P(router > WIG-like @50%) = 43%
   n= 100  router gbm   S+P        -4.2   -2.6   -1.3   P(router > WIG-like @50%) = 6%
   n= 200  WIG-like                 -3.6   -1.7   -0.2
   n= 200  router ridge S+P        -3.3   -1.5   -0.3   P(router > WIG-like @50%) = 73%
   n= 200  router gbm   S+P        -4.1   -2.5   -1.1   P(router > WIG-like @50%) = 7%

## dbpedia_test (tag monot5; n=400; mean gain +19.7 MRR; helped 40% hurt 8%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.22   rho(gain) -0.17
   avgIDF   rho(quality) +0.18   rho(gain) -0.12
   maxIDF   rho(quality) +0.02   rho(gain) -0.01
   avgICTF  rho(quality) +0.16   rho(gain) -0.10
   avgSCQ   rho(quality) +0.25   rho(gain) -0.12
   maxSCQ   rho(quality) +0.11   rho(gain) -0.03
   SCS      rho(quality) +0.20   rho(gain) -0.15

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/90         100/100          +10             -8.2     -0.7 (0.642)
   tag alarm                                 90/90         100/90           +10             -7.8     -0.2 (0.865)
   top5 vs rest                             100/100        100/100           +0             -8.8     -1.2 (0.353)
   NQC-like spread                          100/100        100/100           +0             -8.7     -1.1 (0.405)
   WIG-like                                 100/90         100/100          +10             -7.6          -
   term coverage top1                       100/100        100/100           +0             -6.5     +1.0 (0.404)
   pre:qlen                                 100/90         100/90           +10             -7.8     -0.2 (0.846)
   pre:avgIDF                               100/100        100/100           +0             -7.3     +0.2 (0.850)
   pre:maxIDF                               100/100        100/100           +0             -9.5     -1.9 (0.162)
   pre:avgICTF                              100/100        100/100           +0             -8.1     -0.6 (0.661)
   pre:avgSCQ                               100/90         100/100          +10             -7.6     -0.1 (0.951)
   pre:maxSCQ                               100/100        100/100           +0             -8.5     -0.9 (0.501)
   pre:SCS                                  100/90         100/100          +10             -7.1     +0.4 (0.740)
   router ridge S (5-fold CV)               100/90         100/100          +10             -8.1     -0.6 (0.603)
   router gbm S (5-fold CV)                 100/100        100/100           +0             -8.2     -0.6 (0.645)
   router ridge S+P (5-fold CV)             100/100        100/100           +0             -7.2     +0.4 (0.761)
   router gbm S+P (5-fold CV)               100/100        100/100           +0             -8.7     -1.1 (0.406)
   router ridge S (other collections)       100/90         100/100          +10             -6.6     +1.0 (0.230)
   router gbm S (other collections)         100/90         100/100          +10             -6.5     +1.1 (0.382)
   router ridge S+P (other collections)      90/90         100/90           +10             -7.0     +0.6 (0.549)
   router gbm S+P (other collections)       100/100        100/100           +0             -7.5     +0.0 (0.996)
   ORACLE                                    30/30          30/30           +70             +3.1    +10.7 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.100, tag alarm +0.263, top5 vs rest +0.072, NQC-like spread -0.051, WIG-like -0.087, term coverage top1 -0.112
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.075, tag alarm +0.265, top5 vs rest +0.081, NQC-like spread -0.031, WIG-like -0.006, term coverage top1 -0.165, qlen -0.032, avgIDF -0.279, maxIDF -0.019, avgICTF +0.252, avgSCQ -0.050, maxSCQ -0.009, SCS -0.070

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                -11.2   -7.7   -4.1
   n=  50  router ridge S+P       -12.1   -8.1   -4.3   P(router > WIG-like @50%) = 37%
   n=  50  router gbm   S+P       -12.7   -8.4   -4.7   P(router > WIG-like @50%) = 36%
   n= 100  WIG-like                -11.3   -7.7   -4.1
   n= 100  router ridge S+P       -11.8   -7.7   -4.3   P(router > WIG-like @50%) = 51%
   n= 100  router gbm   S+P       -12.6   -8.4   -4.9   P(router > WIG-like @50%) = 32%
   n= 200  WIG-like                -11.3   -7.8   -4.3
   n= 200  router ridge S+P       -11.5   -7.4   -3.9   P(router > WIG-like @50%) = 66%
   n= 200  router gbm   S+P       -12.5   -8.5   -4.8   P(router > WIG-like @50%) = 28%

