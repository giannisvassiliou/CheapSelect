## amazon_testfull  (1642 questions; tag alarm fires on 883 = 54%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  47.9  random  41.8  diff  +6.1  p=0.0001
   MRR  : tag  56.2  random  51.2  diff  +5.0  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.7 (p=0.001)        +2.3 (p=0.001)
   40%            +3.8 (p=0.000)        +3.1 (p=0.000)
   50%            +4.1 (p=0.000)        +3.3 (p=0.000)
   54% nat        +4.0 (p=0.000)        +3.1 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.1  95% CI [-8.8, -5.4]  p=0.000
   MRR  :  -7.1  95% CI [-8.3, -5.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (56%)
   Hit@1:  +4.1  p=0.000
   MRR  :  +1.8  p=0.025

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.1/+2.2 (p=0.006)  40%: +3.6/+2.5 (p=0.002)  50%: +4.3/+3.0 (p=0.000)  nat: +4.3/+3.0 (p=0.000)
   vs NQC-like spread      30%: +3.4/+2.6 (p=0.001)  40%: +4.1/+3.1 (p=0.000)  50%: +4.5/+3.3 (p=0.000)  nat: +4.3/+3.0 (p=0.000)
   vs WIG-like             30%: +3.4/+2.8 (p=0.001)  40%: +4.1/+3.3 (p=0.000)  50%: +4.3/+3.6 (p=0.000)  nat: +4.3/+3.3 (p=0.000)
   vs term coverage top1   30%: -0.8/-0.7 (p=0.354)  40%: +0.1/-0.1 (p=0.936)  50%: +0.3/+0.1 (p=0.929)  nat: +0.6/+0.2 (p=0.786)

G. each selector reranking 883 questions (54%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -7.1  [-8.3, -5.8]  p=0.000
   BM25 margin          -10.1  [-11.6, -8.7]  p=0.000
   top5 vs rest         -10.1  [-11.6, -8.6]  p=0.000
   NQC-like spread      -10.1  [-11.6, -8.7]  p=0.000
   WIG-like             -10.4  [-11.9, -8.9]  p=0.000
   term coverage top1    -7.3  [-8.6, -5.9]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              41.3    44.4    48.1    51.7    55.2    57.4    59.1    61.3    62.6    63.3*   100%
   BM25 margin            39.7    42.8    45.8    48.6    51.9    54.8    57.1    60.0    62.3    63.3*   100%
   top5 vs rest           39.6    42.2    45.8    49.2    52.1    55.3    57.2    59.7    61.9    63.3*   100%
   NQC-like spread        39.3    42.2    45.4    48.6    51.8    54.9    57.1    59.7    61.8    63.3*   100%
   WIG-like               40.2    42.7    45.3    48.4    51.6    54.2    56.6    59.4    61.8    63.3*   100%
   term coverage top1     41.8    45.1    48.8    51.8    55.1    57.6    59.2    61.1    62.2    63.3*   100%
   ORACLE                 46.7    55.3    61.5    65.6*   66.6*   66.6*   66.6*   66.6*   66.6*   63.3*   40%
   random (expected)      39.7    42.3    45.0    47.6    50.2    52.8    55.4    58.0    60.7    63.3*   100%
   (BM25 only 37.1; rerank ALL 63.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -21.9[-24.0]  -18.9[-20.8]  -15.2[-16.9]  -11.6[-13.2]   -8.1[ -9.6]   -5.9[ -7.1]   -4.2[ -5.3]   -2.0[ -2.8]   -0.7[ -1.1]    100%   (point estimate: 90%)
   BM25 margin          -23.5[-25.6]  -20.5[-22.4]  -17.5[-19.3]  -14.7[-16.4]  -11.4[-12.9]   -8.5[ -9.8]   -6.1[ -7.3]   -3.3[ -4.2]   -1.0[ -1.5]    100%   (point estimate: 90%)
   top5 vs rest         -23.7[-25.6]  -21.1[-23.0]  -17.5[-19.2]  -14.0[-15.6]  -11.1[-12.6]   -8.0[ -9.4]   -6.1[ -7.3]   -3.6[ -4.5]   -1.4[ -2.1]    100%   (point estimate: 100%)
   NQC-like spread      -24.0[-26.0]  -21.1[-23.0]  -17.8[-19.7]  -14.6[-16.3]  -11.4[-12.9]   -8.4[ -9.8]   -6.2[ -7.4]   -3.6[ -4.6]   -1.5[ -2.1]    100%   (point estimate: 100%)
   WIG-like             -23.0[-25.1]  -20.6[-22.6]  -18.0[-19.8]  -14.9[-16.6]  -11.7[-13.2]   -9.1[-10.5]   -6.7[ -8.0]   -3.9[ -4.9]   -1.5[ -2.2]    100%   (point estimate: 100%)
   term coverage top1   -21.5[-23.5]  -18.2[-20.0]  -14.5[-16.2]  -11.5[-13.1]   -8.2[ -9.7]   -5.7[ -7.0]   -4.1[ -5.2]   -2.1[ -2.9]   -1.0[ -1.6]    100%   (point estimate: 100%)
   ORACLE               -16.6[-18.2]   -8.0[ -9.2]   -1.8[ -2.7]   +2.4[ +1.7]#  +3.3[ +2.7]#  +3.3[ +2.7]#  +3.3[ +2.7]#  +3.3[ +2.7]#  +3.3[ +2.7]#   40%   (point estimate: 40%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -21.9[-24.0]  -18.9[-20.8]  -15.2[-16.9]  -11.6[-13.2]   -8.1[ -9.6]   -5.9[ -7.1]   -4.2[ -5.3]   -2.0[ -2.8]   -0.7[ -1.1]    100%   (point estimate: 100%)
   BM25 margin          -23.5[-25.6]  -20.5[-22.4]  -17.5[-19.3]  -14.7[-16.4]  -11.4[-12.9]   -8.5[ -9.8]   -6.1[ -7.3]   -3.3[ -4.2]   -1.0[ -1.5]    100%   (point estimate: 100%)
   top5 vs rest         -23.7[-25.6]  -21.1[-23.0]  -17.5[-19.2]  -14.0[-15.6]  -11.1[-12.6]   -8.0[ -9.4]   -6.1[ -7.3]   -3.6[ -4.5]   -1.4[ -2.1]    100%   (point estimate: 100%)
   NQC-like spread      -24.0[-26.0]  -21.1[-23.0]  -17.8[-19.7]  -14.6[-16.3]  -11.4[-12.9]   -8.4[ -9.8]   -6.2[ -7.4]   -3.6[ -4.6]   -1.5[ -2.1]    100%   (point estimate: 100%)
   WIG-like             -23.0[-25.1]  -20.6[-22.6]  -18.0[-19.8]  -14.9[-16.6]  -11.7[-13.2]   -9.1[-10.5]   -6.7[ -8.0]   -3.9[ -4.9]   -1.5[ -2.2]    100%   (point estimate: 100%)
   term coverage top1   -21.5[-23.5]  -18.2[-20.0]  -14.5[-16.2]  -11.5[-13.1]   -8.2[ -9.7]   -5.7[ -7.0]   -4.1[ -5.2]   -2.1[ -2.9]   -1.0[ -1.6]    100%   (point estimate: 100%)
   ORACLE               -16.6[-18.2]   -8.0[ -9.2]   -1.8[ -2.7]   +2.4[ +1.7]#  +3.3[ +2.7]#  +3.3[ +2.7]#  +3.3[ +2.7]#  +3.3[ +2.7]#  +3.3[ +2.7]#   40%   (point estimate: 40%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      90% (sd  11)   -1.04 MRR              28%     10%
   tag alarm               100      91% (sd   9)   -0.88 MRR              22%      9%
   tag alarm               200      93% (sd   6)   -0.58 MRR              10%      7%
   BM25 margin              50      92% (sd   9)   -1.11 MRR              26%      8%
   BM25 margin             100      93% (sd   7)   -0.80 MRR              28%      7%
   BM25 margin             200      94% (sd   5)   -0.60 MRR              27%      6%
   top5 vs rest             50      94% (sd   9)   -1.02 MRR              36%      6%
   top5 vs rest            100      95% (sd   7)   -0.75 MRR              36%      5%
   top5 vs rest            200      97% (sd   5)   -0.53 MRR              32%      3%
   NQC-like spread          50      95% (sd   8)   -0.92 MRR              38%      5%
   NQC-like spread         100      97% (sd   5)   -0.49 MRR              26%      3%
   NQC-like spread         200      97% (sd   5)   -0.52 MRR              31%      3%
   WIG-like                 50      95% (sd   8)   -0.94 MRR              40%      5%
   WIG-like                100      97% (sd   5)   -0.53 MRR              28%      3%
   WIG-like                200      97% (sd   4)   -0.43 MRR              27%      3%
   term coverage top1       50      91% (sd  13)   -1.21 MRR              49%      9%
   term coverage top1      100      92% (sd   9)   -0.95 MRR              48%      8%
   term coverage top1      200      93% (sd   7)   -0.75 MRR              52%      7%

## mag_testfull  (2665 questions; tag alarm fires on 1277 = 48%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  38.2  random  30.1  diff  +8.1  p=0.0001
   MRR  : tag  44.4  random  37.8  diff  +6.6  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +5.4 (p=0.000)        +4.3 (p=0.000)
   40%            +6.2 (p=0.000)        +4.9 (p=0.000)
   50%            +5.7 (p=0.000)        +4.6 (p=0.000)
   48% nat        +6.2 (p=0.000)        +5.0 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.1  95% CI [-5.3, -3.0]  p=0.000
   MRR  :  -5.0  95% CI [-5.9, -4.1]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (52%)
   Hit@1:  +2.9  p=0.000
   MRR  :  +1.3  p=0.021

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +6.1/+4.5 (p=0.000)  40%: +7.8/+6.0 (p=0.000)  50%: +7.5/+5.6 (p=0.000)  nat: +7.9/+6.0 (p=0.000)
   vs NQC-like spread      30%: +6.3/+4.9 (p=0.000)  40%: +7.7/+6.0 (p=0.000)  50%: +7.4/+5.6 (p=0.000)  nat: +7.9/+6.1 (p=0.000)
   vs WIG-like             30%: +8.4/+6.8 (p=0.000)  40%: +11.2/+9.0 (p=0.000)  50%: +10.5/+8.4 (p=0.000)  nat: +11.0/+8.8 (p=0.000)
   vs term coverage top1   30%: +2.7/+2.3 (p=0.000)  40%: +3.1/+2.7 (p=0.000)  50%: +2.7/+2.3 (p=0.000)  nat: +3.2/+2.7 (p=0.000)

G. each selector reranking 1277 questions (48%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -5.0  [-5.9, -4.1]  p=0.000
   BM25 margin          -10.0  [-11.1, -8.9]  p=0.000
   top5 vs rest         -10.9  [-12.1, -9.8]  p=0.000
   NQC-like spread      -11.1  [-12.2, -9.9]  p=0.000
   WIG-like             -13.8  [-15.0, -12.6]  p=0.000
   term coverage top1    -7.7  [-8.7, -6.6]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              31.5    34.9    38.6    42.3    44.6    45.6    47.1    48.2    48.8    49.4*   100%
   BM25 margin            29.5    32.0    34.3    37.4    40.0    42.5    44.9    46.9    48.5    49.4*   100%
   top5 vs rest           28.9    31.4    34.0    36.3    38.9    41.3    43.3    45.2    47.9    49.4*   100%
   NQC-like spread        28.9    31.1    33.7    36.3    39.0    41.1    43.2    45.4    47.7    49.4*   100%
   WIG-like               28.5    30.2    31.7    33.3    36.2    38.7    41.0    43.5    46.3    49.4*   100%
   term coverage top1     29.8    33.0    36.2    39.6    42.3    45.0    47.0    48.3    49.2*   49.4*   90%
   ORACLE                 36.8    45.1    50.2*   51.8*   51.8*   51.8*   51.8*   51.8*   51.8*   49.4*   30%
   random (expected)      29.3    31.6    33.8    36.0    38.2    40.5    42.7    44.9    47.1    49.4*   100%
   (BM25 only 27.1; rerank ALL 49.4)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -17.9[-19.3]  -14.4[-15.8]  -10.8[-12.0]   -7.1[ -8.0]   -4.8[ -5.7]   -3.7[ -4.5]   -2.3[ -2.9]   -1.2[ -1.7]   -0.5[ -0.9]#   90%   (point estimate: 90%)
   BM25 margin          -19.8[-21.3]  -17.4[-18.9]  -15.1[-16.5]  -11.9[-13.2]   -9.4[-10.5]   -6.9[ -7.8]   -4.5[ -5.2]   -2.5[ -3.1]   -0.8[ -1.2]    100%   (point estimate: 90%)
   top5 vs rest         -20.5[-22.0]  -18.0[-19.4]  -15.3[-16.7]  -13.0[-14.3]  -10.4[-11.6]   -8.1[ -9.2]   -6.0[ -7.0]   -4.1[ -4.9]   -1.5[ -2.0]    100%   (point estimate: 100%)
   NQC-like spread      -20.4[-21.9]  -18.3[-19.7]  -15.7[-17.1]  -13.0[-14.4]  -10.3[-11.6]   -8.2[ -9.3]   -6.1[ -7.1]   -3.9[ -4.7]   -1.7[ -2.2]    100%   (point estimate: 100%)
   WIG-like             -20.9[-22.4]  -19.1[-20.6]  -17.6[-19.1]  -16.0[-17.4]  -13.2[-14.5]  -10.6[-11.8]   -8.4[ -9.4]   -5.9[ -6.8]   -3.1[ -3.7]    100%   (point estimate: 100%)
   term coverage top1   -19.6[-21.1]  -16.3[-17.7]  -13.2[-14.5]   -9.8[-10.9]   -7.1[ -8.1]   -4.3[ -5.2]   -2.3[ -3.1]   -1.1[ -1.7]   -0.2[ -0.6]#   90%   (point estimate: 90%)
   ORACLE               -12.5[-13.8]   -4.2[ -5.1]   +0.8[ +0.4]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.4[ +2.0]#   30%   (point estimate: 30%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -17.9[-19.3]  -14.4[-15.8]  -10.8[-12.0]   -7.1[ -8.0]   -4.8[ -5.7]   -3.7[ -4.5]   -2.3[ -2.9]   -1.2[ -1.7]   -0.5[ -0.9]    100%   (point estimate: 100%)
   BM25 margin          -19.8[-21.3]  -17.4[-18.9]  -15.1[-16.5]  -11.9[-13.2]   -9.4[-10.5]   -6.9[ -7.8]   -4.5[ -5.2]   -2.5[ -3.1]   -0.8[ -1.2]    100%   (point estimate: 100%)
   top5 vs rest         -20.5[-22.0]  -18.0[-19.4]  -15.3[-16.7]  -13.0[-14.3]  -10.4[-11.6]   -8.1[ -9.2]   -6.0[ -7.0]   -4.1[ -4.9]   -1.5[ -2.0]    100%   (point estimate: 100%)
   NQC-like spread      -20.4[-21.9]  -18.3[-19.7]  -15.7[-17.1]  -13.0[-14.4]  -10.3[-11.6]   -8.2[ -9.3]   -6.1[ -7.1]   -3.9[ -4.7]   -1.7[ -2.2]    100%   (point estimate: 100%)
   WIG-like             -20.9[-22.4]  -19.1[-20.6]  -17.6[-19.1]  -16.0[-17.4]  -13.2[-14.5]  -10.6[-11.8]   -8.4[ -9.4]   -5.9[ -6.8]   -3.1[ -3.7]    100%   (point estimate: 100%)
   term coverage top1   -19.6[-21.1]  -16.3[-17.7]  -13.2[-14.5]   -9.8[-10.9]   -7.1[ -8.1]   -4.3[ -5.2]   -2.3[ -3.1]   -1.1[ -1.7]   -0.2[ -0.6]    100%   (point estimate: 90%)
   ORACLE               -12.5[-13.8]   -4.2[ -5.1]   +0.8[ +0.4]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.4[ +2.0]#  +2.4[ +2.0]#   30%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      85% (sd  16)   -1.23 MRR              39%     15%
   tag alarm               100      86% (sd  14)   -1.09 MRR              36%     14%
   tag alarm               200      87% (sd  10)   -0.88 MRR              36%     13%
   BM25 margin              50      89% (sd  10)   -1.35 MRR              32%     11%
   BM25 margin             100      91% (sd   9)   -0.98 MRR              20%      9%
   BM25 margin             200      93% (sd   6)   -0.70 MRR               8%      7%
   top5 vs rest             50      95% (sd   8)   -0.93 MRR              36%      5%
   top5 vs rest            100      96% (sd   6)   -0.62 MRR              34%      4%
   top5 vs rest            200      97% (sd   5)   -0.53 MRR              30%      3%
   NQC-like spread          50      95% (sd   9)   -0.91 MRR              33%      5%
   NQC-like spread         100      97% (sd   5)   -0.46 MRR              25%      3%
   NQC-like spread         200      98% (sd   4)   -0.39 MRR              22%      2%
   WIG-like                 50      99% (sd   4)   -0.39 MRR              10%      1%
   WIG-like                100     100% (sd   2)   -0.16 MRR               5%      0%
   WIG-like                200     100% (sd   1)   -0.03 MRR               1%      0%
   term coverage top1       50      85% (sd  14)   -1.15 MRR              46%     15%
   term coverage top1      100      85% (sd  12)   -0.90 MRR              44%     15%
   term coverage top1      200      86% (sd   9)   -0.74 MRR              42%     14%

## prime_testfull  (2801 questions; tag alarm fires on 1530 = 55%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  17.3  random  15.3  diff  +1.9  p=0.0001
   MRR  : tag  24.5  random  22.9  diff  +1.6  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.1 (p=0.007)        +0.9 (p=0.005)
   40%            +1.8 (p=0.000)        +1.5 (p=0.000)
   50%            +1.6 (p=0.002)        +1.5 (p=0.001)
   55% nat        +1.4 (p=0.011)        +1.4 (p=0.002)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -2.5  95% CI [-3.5, -1.5]  p=0.000
   MRR  :  -3.8  95% CI [-4.6, -3.0]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (56%)
   Hit@1:  +0.9  p=0.118
   MRR  :  +0.5  p=0.307

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.5/+1.5 (p=0.000)  40%: +1.5/+1.4 (p=0.001)  50%: +1.5/+1.4 (p=0.001)  nat: +1.2/+1.3 (p=0.003)
   vs NQC-like spread      30%: +1.3/+1.4 (p=0.000)  40%: +1.6/+1.6 (p=0.000)  50%: +1.8/+1.7 (p=0.000)  nat: +1.2/+1.4 (p=0.001)
   vs WIG-like             30%: +0.4/+0.3 (p=0.443)  40%: +0.8/+0.7 (p=0.120)  50%: +1.2/+1.0 (p=0.023)  nat: +0.8/+0.8 (p=0.071)
   vs term coverage top1   30%: +0.5/+0.4 (p=0.310)  40%: +0.5/+0.4 (p=0.343)  50%: +0.5/+0.5 (p=0.268)  nat: +0.1/+0.4 (p=0.431)

G. each selector reranking 1530 questions (55%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -3.8  [-4.6, -3.0]  p=0.000
   BM25 margin           -5.2  [-6.1, -4.4]  p=0.000
   top5 vs rest          -5.1  [-6.1, -4.1]  p=0.000
   NQC-like spread       -5.3  [-6.2, -4.3]  p=0.000
   WIG-like              -4.6  [-5.5, -3.7]  p=0.000
   term coverage top1    -4.2  [-5.1, -3.2]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              18.1    19.2    20.8    22.5    24.1    24.9    25.8    26.7    27.5    28.3*   100%
   BM25 margin            17.4    18.5    19.8    20.9    22.5    23.7    25.0    26.4    27.4    28.3*   100%
   top5 vs rest           17.1    18.1    19.3    21.0    22.6    24.0    25.5    26.8    27.6    28.3*   100%
   NQC-like spread        17.0    18.2    19.4    20.8    22.4    23.8    25.3    26.4    27.7    28.3*   100%
   WIG-like               17.6    19.1    20.5    21.8    23.1    24.3    25.7    26.4    27.5    28.3*   100%
   term coverage top1     17.4    19.0    20.4    22.0    23.6    25.0    26.2    27.2    27.9*   28.3*   90%
   ORACLE                 25.6    30.2*   31.7*   31.8*   31.8*   31.8*   31.8*   31.8*   31.8*   28.3*   20%
   random (expected)      17.6    18.8    20.0    21.2    22.4    23.6    24.7    25.9    27.1    28.3*   100%
   (BM25 only 16.4; rerank ALL 28.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -10.3[-11.5]   -9.1[-10.2]   -7.6[ -8.6]   -5.9[ -6.8]   -4.2[ -5.1]   -3.4[ -4.1]   -2.6[ -3.2]   -1.6[ -2.2]   -0.8[ -1.2]    100%   (point estimate: 90%)
   BM25 margin          -10.9[-12.0]   -9.8[-11.0]   -8.5[ -9.6]   -7.4[ -8.4]   -5.8[ -6.7]   -4.6[ -5.5]   -3.3[ -4.0]   -1.9[ -2.4]   -0.9[ -1.3]    100%   (point estimate: 90%)
   top5 vs rest         -11.2[-12.4]  -10.2[-11.4]   -9.0[-10.1]   -7.3[ -8.3]   -5.7[ -6.6]   -4.3[ -5.2]   -2.8[ -3.5]   -1.5[ -2.1]   -0.7[ -1.2]    100%   (point estimate: 90%)
   NQC-like spread      -11.3[-12.4]  -10.1[-11.3]   -8.9[-10.0]   -7.5[ -8.5]   -6.0[ -6.9]   -4.6[ -5.4]   -3.0[ -3.8]   -1.9[ -2.5]   -0.7[ -1.1]    100%   (point estimate: 90%)
   WIG-like             -10.8[-12.0]   -9.2[-10.4]   -7.9[ -8.9]   -6.5[ -7.5]   -5.2[ -6.1]   -4.0[ -4.8]   -2.7[ -3.4]   -1.9[ -2.6]   -0.8[ -1.2]    100%   (point estimate: 90%)
   term coverage top1   -11.0[-12.2]   -9.3[-10.4]   -8.0[ -9.1]   -6.3[ -7.3]   -4.7[ -5.7]   -3.3[ -4.2]   -2.1[ -2.9]   -1.2[ -1.8]   -0.4[ -0.8]#   90%   (point estimate: 90%)
   ORACLE                -2.8[ -3.5]   +1.9[ +1.3]#  +3.4[ +2.9]#  +3.4[ +3.0]#  +3.4[ +3.0]#  +3.4[ +3.0]#  +3.4[ +3.0]#  +3.4[ +3.0]#  +3.4[ +3.0]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -10.3[-11.5]   -9.1[-10.2]   -7.6[ -8.6]   -5.9[ -6.8]   -4.2[ -5.1]   -3.4[ -4.1]   -2.6[ -3.2]   -1.6[ -2.2]   -0.8[ -1.2]    100%   (point estimate: 100%)
   BM25 margin          -10.9[-12.0]   -9.8[-11.0]   -8.5[ -9.6]   -7.4[ -8.4]   -5.8[ -6.7]   -4.6[ -5.5]   -3.3[ -4.0]   -1.9[ -2.4]   -0.9[ -1.3]    100%   (point estimate: 100%)
   top5 vs rest         -11.2[-12.4]  -10.2[-11.4]   -9.0[-10.1]   -7.3[ -8.3]   -5.7[ -6.6]   -4.3[ -5.2]   -2.8[ -3.5]   -1.5[ -2.1]   -0.7[ -1.2]    100%   (point estimate: 100%)
   NQC-like spread      -11.3[-12.4]  -10.1[-11.3]   -8.9[-10.0]   -7.5[ -8.5]   -6.0[ -6.9]   -4.6[ -5.4]   -3.0[ -3.8]   -1.9[ -2.5]   -0.7[ -1.1]    100%   (point estimate: 100%)
   WIG-like             -10.8[-12.0]   -9.2[-10.4]   -7.9[ -8.9]   -6.5[ -7.5]   -5.2[ -6.1]   -4.0[ -4.8]   -2.7[ -3.4]   -1.9[ -2.6]   -0.8[ -1.2]    100%   (point estimate: 100%)
   term coverage top1   -11.0[-12.2]   -9.3[-10.4]   -8.0[ -9.1]   -6.3[ -7.3]   -4.7[ -5.7]   -3.3[ -4.2]   -2.1[ -2.9]   -1.2[ -1.8]   -0.4[ -0.8]    100%   (point estimate: 90%)
   ORACLE                -2.8[ -3.5]   +1.9[ +1.3]#  +3.4[ +2.9]#  +3.4[ +3.0]#  +3.4[ +3.0]#  +3.4[ +3.0]#  +3.4[ +3.0]#  +3.4[ +3.0]#  +3.4[ +3.0]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      84% (sd  21)   -1.47 MRR              32%     16%
   tag alarm               100      88% (sd  15)   -1.03 MRR              30%     12%
   tag alarm               200      89% (sd  12)   -0.92 MRR              28%     11%
   BM25 margin              50      88% (sd  14)   -1.21 MRR              28%     12%
   BM25 margin             100      91% (sd  11)   -0.95 MRR              27%      9%
   BM25 margin             200      93% (sd   8)   -0.74 MRR              19%      7%
   top5 vs rest             50      86% (sd  18)   -1.41 MRR              36%     14%
   top5 vs rest            100      86% (sd  14)   -1.27 MRR              36%     14%
   top5 vs rest            200      90% (sd  10)   -0.85 MRR              30%     10%
   NQC-like spread          50      86% (sd  15)   -1.37 MRR              38%     14%
   NQC-like spread         100      90% (sd  13)   -0.97 MRR              24%     10%
   NQC-like spread         200      89% (sd   9)   -0.95 MRR              26%     11%
   WIG-like                 50      88% (sd  14)   -1.09 MRR              30%     12%
   WIG-like                100      89% (sd  13)   -1.04 MRR              28%     11%
   WIG-like                200      93% (sd   8)   -0.64 MRR              12%      7%
   term coverage top1       50      81% (sd  19)   -1.49 MRR              49%     19%
   term coverage top1      100      85% (sd  15)   -1.04 MRR              41%     15%
   term coverage top1      200      85% (sd  13)   -1.00 MRR              44%     15%

## dbpedia_test  (400 questions; tag alarm fires on 86 = 22%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  61.5  random  58.6  diff  +2.9  p=0.0064
   MRR  : tag  69.9  random  68.0  diff  +1.8  p=0.0106

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.4 (p=0.704)
   40%            +1.0 (p=0.615)        +1.0 (p=0.329)
   50%            +1.2 (p=0.461)        +0.8 (p=0.385)
   22% nat        +0.5 (p=0.883)        -0.1 (p=0.948)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -5.8  95% CI [-10.5, -1.0]  p=0.022
   MRR  :  -5.9  95% CI [-9.1, -2.6]  p=0.001

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (50%)
   Hit@1:  +2.0  p=0.299
   MRR  :  +1.5  p=0.200

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.5/-0.8 (p=0.556)  40%: +3.0/+1.3 (p=0.363)  50%: +3.2/+0.8 (p=0.521)  nat: -0.8/-1.4 (p=0.268)
   vs NQC-like spread      30%: -0.8/-1.5 (p=0.277)  40%: +2.5/+1.1 (p=0.415)  50%: +2.8/+0.7 (p=0.590)  nat: -0.5/-1.2 (p=0.360)
   vs WIG-like             30%: +2.2/+0.7 (p=0.580)  40%: +3.5/+1.4 (p=0.272)  50%: +3.8/+1.3 (p=0.324)  nat: +1.5/+0.5 (p=0.692)
   vs term coverage top1   30%: +0.5/-0.4 (p=0.769)  40%: +1.2/-0.1 (p=0.935)  50%: +2.0/-0.1 (p=0.902)  nat: -0.5/-0.7 (p=0.536)

G. each selector reranking 86 questions (22%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -5.9  [-9.1, -2.6]  p=0.001
   BM25 margin           -5.8  [-9.1, -2.5]  p=0.000
   top5 vs rest          -4.5  [-7.6, -1.4]  p=0.004
   NQC-like spread       -4.7  [-7.8, -1.5]  p=0.003
   WIG-like              -6.3  [-9.6, -3.1]  p=0.000
   term coverage top1    -5.2  [-8.4, -2.0]  p=0.002

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              68.3    70.1    71.3    73.5*   73.9*   74.3*   74.4*   75.7*   76.3*   75.8*   40%
   BM25 margin            67.9    70.2    71.8    72.4    73.0    73.4    74.4*   75.6*   76.3*   75.8*   70%
   top5 vs rest           68.2    71.3    72.1    72.2    73.0    73.0    74.4*   74.6    75.9*   75.8*   90%
   NQC-like spread        68.3    71.1    72.8    72.4    73.2    73.8*   74.4*   75.0*   75.6*   75.8*   60%
   WIG-like               67.8    69.3    70.7    72.1    72.6    73.0    73.5    74.7*   75.4*   75.8*   80%
   term coverage top1     69.2    70.6    71.7    73.6*   74.0*   74.3*   73.9    74.5*   75.1*   75.8*   80%
   ORACLE                 74.7*   80.0*   82.8*   82.8*   82.8*   82.8*   82.8*   82.8*   82.1*   75.8*   10%
   random (expected)      66.9    67.9    68.9    69.9    70.8    71.8    72.8    73.8    74.8    75.8*   100%
   (BM25 only 65.9; rerank ALL 75.8)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.5[-11.1]   -5.7[ -9.0]   -4.4[ -7.5]   -2.3[ -5.0]   -1.9[ -4.3]   -1.5[ -3.4]   -1.4[ -3.1]   -0.1[ -1.4]   +0.5[ -0.5]#   90%   (point estimate: 80%)
   BM25 margin           -7.9[-11.4]   -5.6[ -8.7]   -4.0[ -7.0]   -3.4[ -6.0]   -2.7[ -5.2]   -2.4[ -4.6]   -1.4[ -3.3]   -0.2[ -1.7]   +0.5[ -0.5]#   90%   (point estimate: 80%)
   top5 vs rest          -7.5[-11.1]   -4.5[ -7.6]   -3.6[ -6.4]   -3.6[ -6.1]   -2.7[ -4.9]   -2.8[ -4.8]   -1.4[ -3.0]   -1.1[ -2.3]   +0.1[ -0.5]#   90%   (point estimate: 90%)
   NQC-like spread       -7.5[-11.1]   -4.7[ -7.9]   -3.0[ -5.7]   -3.4[ -5.8]   -2.6[ -4.8]   -2.0[ -3.9]   -1.4[ -2.9]   -0.8[ -1.9]   -0.2[ -0.8]#   90%   (point estimate: 80%)
   WIG-like              -7.9[-11.5]   -6.5[ -9.7]   -5.1[ -8.2]   -3.7[ -6.3]   -3.2[ -5.6]   -2.8[ -4.8]   -2.3[ -4.1]   -1.0[ -2.5]   -0.4[ -1.5]    100%   (point estimate: 90%)
   term coverage top1    -6.5[-10.0]   -5.2[ -8.5]   -4.1[ -6.8]   -2.2[ -4.7]   -1.7[ -4.1]   -1.4[ -3.3]   -1.9[ -3.4]   -1.3[ -2.7]   -0.6[ -1.4]    100%   (point estimate: 90%)
   ORACLE                -1.1[ -3.9]   +4.2[ +2.0]#  +7.0[ +5.2]#  +7.1[ +5.2]#  +7.1[ +5.2]#  +7.1[ +5.2]#  +7.1[ +5.2]#  +7.1[ +5.2]#  +6.3[ +4.5]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.5[-11.1]   -5.7[ -9.0]   -4.4[ -7.5]   -2.3[ -5.0]   -1.9[ -4.3]   -1.5[ -3.4]   -1.4[ -3.1]   -0.1[ -1.4]   +0.5[ -0.5]#   90%   (point estimate: 80%)
   BM25 margin           -7.9[-11.4]   -5.6[ -8.7]   -4.0[ -7.0]   -3.4[ -6.0]   -2.7[ -5.2]   -2.4[ -4.6]   -1.4[ -3.3]   -0.2[ -1.7]   +0.5[ -0.5]#   90%   (point estimate: 80%)
   top5 vs rest          -7.5[-11.1]   -4.5[ -7.6]   -3.6[ -6.4]   -3.6[ -6.1]   -2.7[ -4.9]   -2.8[ -4.8]   -1.4[ -3.0]   -1.1[ -2.3]   +0.1[ -0.5]    100%   (point estimate: 90%)
   NQC-like spread       -7.5[-11.1]   -4.7[ -7.9]   -3.0[ -5.7]   -3.4[ -5.8]   -2.6[ -4.8]   -2.0[ -3.9]   -1.4[ -2.9]   -0.8[ -1.9]   -0.2[ -0.8]    100%   (point estimate: 90%)
   WIG-like              -7.9[-11.5]   -6.5[ -9.7]   -5.1[ -8.2]   -3.7[ -6.3]   -3.2[ -5.6]   -2.8[ -4.8]   -2.3[ -4.1]   -1.0[ -2.5]   -0.4[ -1.5]    100%   (point estimate: 90%)
   term coverage top1    -6.5[-10.0]   -5.2[ -8.5]   -4.1[ -6.8]   -2.2[ -4.7]   -1.7[ -4.1]   -1.4[ -3.3]   -1.9[ -3.4]   -1.3[ -2.7]   -0.6[ -1.4]    100%   (point estimate: 100%)
   ORACLE                -1.1[ -3.9]   +4.2[ +2.0]#  +7.0[ +5.2]#  +7.1[ +5.2]#  +7.1[ +5.2]#  +7.1[ +5.2]#  +7.1[ +5.2]#  +7.1[ +5.2]#  +6.3[ +4.5]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      66% (sd  27)   -1.72 MRR              50%     34%
   tag alarm               100      70% (sd  22)   -1.23 MRR              44%     30%
   tag alarm               200      71% (sd  15)   -1.02 MRR              42%     29%
   BM25 margin              50      74% (sd  24)   -1.19 MRR              38%     26%
   BM25 margin             100      74% (sd  19)   -1.13 MRR              40%     26%
   BM25 margin             200      75% (sd  13)   -1.08 MRR              43%     25%
   top5 vs rest             50      79% (sd  23)   -1.22 MRR              43%     21%
   top5 vs rest            100      79% (sd  18)   -1.15 MRR              46%     21%
   top5 vs rest            200      82% (sd  11)   -0.95 MRR              40%     18%
   NQC-like spread          50      75% (sd  25)   -1.45 MRR              42%     25%
   NQC-like spread         100      78% (sd  18)   -1.06 MRR              30%     22%
   NQC-like spread         200      75% (sd  15)   -1.36 MRR              42%     25%
   WIG-like                 50      81% (sd  22)   -1.44 MRR              40%     19%
   WIG-like                100      81% (sd  20)   -1.50 MRR              43%     19%
   WIG-like                200      86% (sd  12)   -1.04 MRR              40%     14%
   term coverage top1       50      77% (sd  28)   -1.52 MRR              42%     23%
   term coverage top1      100      81% (sd  22)   -1.24 MRR              40%     19%
   term coverage top1      200      84% (sd  14)   -1.00 MRR              40%     16%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  23%  MRR  61.6 | vs BM25 margin: -5.8 (p=0.034)  vs top5 vs rest: -6.9 (p=0.029)  vs NQC-like spread: -7.7 (p=0.021)  vs WIG-like: -3.4 (p=0.155)  vs term coverage top1: -5.1 (p=0.024)
   list           n= 105  fires  25%  MRR  74.2 | vs BM25 margin: +4.2 (p=0.088)  vs top5 vs rest: +2.7 (p=0.217)  vs NQC-like spread: +3.0 (p=0.204)  vs WIG-like: +2.6 (p=0.173)  vs term coverage top1: -0.6 (p=0.817)
   question       n= 125  fires  28%  MRR  65.6 | vs BM25 margin: +1.9 (p=0.444)  vs top5 vs rest: -1.7 (p=0.498)  vs NQC-like spread: -1.0 (p=0.702)  vs WIG-like: +0.5 (p=0.871)  vs term coverage top1: +1.7 (p=0.513)
   named entity   n=  86  fires   7%  MRR  79.0 | vs BM25 margin: -2.6 (p=0.253)  vs top5 vs rest: -0.5 (p=0.817)  vs NQC-like spread: -0.4 (p=0.910)  vs WIG-like: +1.5 (p=0.251)  vs term coverage top1: -0.1 (p=1.000)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR +0.9  [-2.6, +4.4]  p=0.603  (n=211)

## POOLED over 4 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  33.8  random  28.7  diff  +5.1  p=0.0001
   MRR  : tag  40.9  random  36.8  diff  +4.1  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +2.9 (p=0.000)   MRR  +2.3 (p=0.000)
   40%      Hit@1  +3.7 (p=0.000)   MRR  +3.0 (p=0.000)
   50%      Hit@1  +3.6 (p=0.000)   MRR  +3.0 (p=0.000)
   natural  Hit@1  +3.6 (p=0.000)   MRR  +3.0 (p=0.000)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -4.2  95% CI [-4.9, -3.5]  p=0.000
   MRR  :  -5.1  95% CI [-5.6, -4.5]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +2.4  p=0.000
   MRR  :  +1.1  p=0.001

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +3.4/+2.6 (p=0.000)  40%: +4.3/+3.2 (p=0.000)  50%: +4.3/+3.2 (p=0.000)  nat: +4.2/+3.2 (p=0.000)
   vs NQC-like spread      30%: +3.4/+2.7 (p=0.000)  40%: +4.4/+3.5 (p=0.000)  50%: +4.4/+3.4 (p=0.000)  nat: +4.2/+3.3 (p=0.000)
   vs WIG-like             30%: +4.0/+3.2 (p=0.000)  40%: +5.3/+4.2 (p=0.000)  50%: +5.3/+4.2 (p=0.000)  nat: +5.2/+4.2 (p=0.000)
   vs term coverage top1   30%: +1.0/+0.8 (p=0.011)  40%: +1.4/+1.1 (p=0.001)  50%: +1.3/+1.0 (p=0.001)  nat: +1.3/+1.1 (p=0.001)
