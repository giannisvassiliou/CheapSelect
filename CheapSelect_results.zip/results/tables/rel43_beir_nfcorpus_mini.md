## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  44.3  random  44.1  diff  +0.2  p=0.4392
   MRR  : tag  52.3  random  52.3  diff  +0.0  p=0.4839

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.6 (p=0.630)        +0.1 (p=0.783)
   40%            +0.3 (p=1.000)        +0.1 (p=0.816)
   50%            +0.6 (p=0.503)        +0.3 (p=0.378)
   2% nat         +0.3 (p=1.000)        +0.1 (p=0.878)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.3  95% CI [-8.7, +0.0]  p=0.064
   MRR  :  -4.5  95% CI [-7.4, -1.7]  p=0.002

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (44%)
   Hit@1:  +0.3  p=1.000
   MRR  :  -0.3  p=0.813

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.4/+1.9 (p=0.088)  40%: +2.5/+2.1 (p=0.084)  50%: +3.1/+2.0 (p=0.089)  nat: +0.3/+0.1 (p=0.878)
   vs NQC-like spread      30%: +2.8/+1.2 (p=0.264)  40%: +1.5/+1.0 (p=0.399)  50%: +3.1/+1.7 (p=0.116)  nat: +0.3/+0.1 (p=0.878)
   vs WIG-like             30%: +2.8/+1.7 (p=0.128)  40%: +1.9/+1.6 (p=0.159)  50%: +1.9/+1.2 (p=0.292)  nat: +0.3/+0.1 (p=0.878)
   vs term coverage top1   30%: +2.8/+1.0 (p=0.350)  40%: +1.5/+0.6 (p=0.628)  50%: +0.3/-0.1 (p=0.910)  nat: +0.3/+0.1 (p=0.878)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -4.5  [-7.4, -1.7]  p=0.002
   BM25 margin           -4.7  [-7.7, -1.8]  p=0.002
   top5 vs rest          -4.7  [-7.7, -1.8]  p=0.002
   NQC-like spread       -4.7  [-7.7, -1.8]  p=0.002
   WIG-like              -4.7  [-7.7, -1.8]  p=0.002
   term coverage top1    -4.7  [-7.7, -1.8]  p=0.002

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              52.2    53.1    54.6    55.2*   55.9*   55.6*   56.1*   56.2*   56.7*   56.8*   40%
   BM25 margin            51.9    53.2    54.5    55.1*   55.6*   55.6*   56.1*   56.2*   56.7*   56.8*   40%
   top5 vs rest           51.7    51.7    52.7    53.0    53.9    54.5    55.7*   56.4*   57.2*   56.8*   70%
   NQC-like spread        51.6    53.5    53.4    54.2    54.3    55.8*   56.5*   56.7*   56.5*   56.8*   60%
   WIG-like               52.1    51.8    52.9    53.5    54.7    55.8*   56.0*   56.2*   56.6*   56.8*   60%
   term coverage top1     52.2    52.9    53.6    54.6    56.0*   55.8*   55.4    55.8*   56.3*   56.8*   80%
   ORACLE                 58.6*   61.1*   61.1*   61.1*   61.1*   61.1*   61.1*   61.1*   61.1*   56.8*   10%
   random (expected)      52.6    53.1    53.5    54.0    54.5    54.9    55.4    55.9    56.3    56.8*   100%
   (BM25 only 52.1; rerank ALL 56.8)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.14 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.6[ -7.4]   -3.7[ -6.2]   -2.2[ -4.4]   -1.6[ -3.6]   -0.9[ -2.5]   -1.2[ -2.7]   -0.7[ -1.8]   -0.6[ -1.4]   -0.1[ -0.5]#   90%   (point estimate: 70%)
   BM25 margin           -4.9[ -7.7]   -3.6[ -6.2]   -2.3[ -4.6]   -1.7[ -3.7]   -1.2[ -2.8]   -1.2[ -2.6]   -0.7[ -1.8]   -0.6[ -1.4]   -0.1[ -0.5]#   90%   (point estimate: 70%)
   top5 vs rest          -5.1[ -7.9]   -5.1[ -7.8]   -4.1[ -6.7]   -3.8[ -6.1]   -2.9[ -4.9]   -2.3[ -4.2]   -1.1[ -2.7]   -0.4[ -1.5]   +0.4[ -0.4]#   90%   (point estimate: 80%)
   NQC-like spread       -5.2[ -8.1]   -3.3[ -5.8]   -3.4[ -5.8]   -2.6[ -4.8]   -2.5[ -4.3]   -1.0[ -2.3]   -0.3[ -1.4]   -0.1[ -0.7]#  -0.3[ -0.8]#   80%   (point estimate: 60%)
   WIG-like              -4.7[ -7.5]   -5.0[ -7.5]   -3.9[ -6.4]   -3.3[ -5.5]   -2.1[ -4.1]   -1.0[ -2.8]   -0.8[ -2.1]   -0.6[ -1.7]   -0.2[ -0.7]#   90%   (point estimate: 60%)
   term coverage top1    -4.6[ -7.4]   -3.9[ -6.5]   -3.2[ -5.8]   -2.2[ -4.4]   -0.8[ -2.5]   -1.0[ -2.7]   -1.3[ -2.6]   -1.0[ -2.2]   -0.5[ -1.6]    100%   (point estimate: 80%)
   ORACLE                +1.8[ -0.1]#  +4.3[ +2.7]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.8]#  +4.3[ +2.7]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.14): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      63% (sd  20)   -1.19 MRR              35%     37%
   BM25 margin             100      54% (sd  21)   -1.73 MRR              40%     46%
   top5 vs rest            100      74% (sd  11)   -0.83 MRR              35%     26%
   NQC-like spread         100      64% (sd  15)   -1.16 MRR              40%     36%
   WIG-like                100      63% (sd  22)   -1.68 MRR              45%     37%
   term coverage top1      100      63% (sd  25)   -1.37 MRR              35%     37%

