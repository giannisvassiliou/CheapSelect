## dbpedia_test  (400 questions; tag alarm fires on 68 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  49.8  random  46.6  diff  +3.1  p=0.0008
   MRR  : tag  60.2  random  57.3  diff  +2.8  p=0.0002

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +3.2 (p=0.035)        +2.8 (p=0.014)
   40%            +1.0 (p=0.552)        +1.2 (p=0.220)
   50%            +0.2 (p=1.000)        +0.4 (p=0.625)
   17% nat        +2.8 (p=0.152)        +2.8 (p=0.046)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -15.8  95% CI [-20.2, -11.2]  p=0.000
   MRR  : -13.5  95% CI [-16.8, -10.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (52%)
   Hit@1:  +3.5  p=0.079
   MRR  :  +2.2  p=0.118

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +5.0/+3.6 (p=0.007)  40%: +4.5/+3.0 (p=0.041)  50%: +2.0/+1.0 (p=0.535)  nat: +4.8/+3.7 (p=0.004)
   vs NQC-like spread      30%: +5.5/+3.8 (p=0.006)  40%: +5.8/+3.5 (p=0.020)  50%: +2.5/+0.9 (p=0.591)  nat: +4.0/+3.2 (p=0.012)
   vs WIG-like             30%: +1.2/+0.5 (p=0.716)  40%: +1.0/+0.4 (p=0.763)  50%: +0.8/-0.2 (p=0.862)  nat: +2.5/+1.7 (p=0.165)
   vs term coverage top1   30%: +0.8/+0.6 (p=0.631)  40%: +0.5/+0.2 (p=0.860)  50%: -1.2/-1.3 (p=0.345)  nat: +1.8/+1.8 (p=0.121)

G. each selector reranking 68 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -13.5  [-16.8, -10.3]  p=0.000
   BM25 margin          -16.3  [-19.7, -12.9]  p=0.000
   top5 vs rest         -17.3  [-20.7, -13.8]  p=0.000
   NQC-like spread      -16.7  [-20.2, -13.3]  p=0.000
   WIG-like             -15.3  [-18.7, -12.0]  p=0.000
   term coverage top1   -15.3  [-18.7, -12.1]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              58.2    60.9    63.0    64.5    65.9    67.8    69.9    71.9    73.4*   73.7*   90%
   BM25 margin            56.3    58.4    60.2    63.3    65.5    67.0    69.0    71.3    72.7    73.7*   100%
   top5 vs rest           55.3    57.2    59.3    61.5    64.9    66.7    68.4    70.8    72.2    73.7*   100%
   NQC-like spread        55.5    57.4    59.1    61.0    65.0    67.7    69.5    71.2    72.1    73.7*   100%
   WIG-like               57.1    58.9    62.4    64.1    66.1    67.8    69.6    71.9    72.7    73.7*   100%
   term coverage top1     56.8    59.2    62.3    64.3    67.2    69.3    70.2    71.7    72.2    73.7*   100%
   ORACLE                 63.2    70.5    75.2*   76.9*   76.9*   76.9*   76.9*   76.9*   76.9*   73.7*   30%
   random (expected)      55.9    57.9    59.9    61.9    63.8    65.8    67.8    69.8    71.7    73.7*   100%
   (BM25 only 54.0; rerank ALL 73.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -15.5[-18.9]  -12.8[-16.0]  -10.8[-13.5]   -9.2[-11.9]   -7.8[-10.2]   -5.9[ -8.0]   -3.9[ -5.6]   -1.8[ -3.2]   -0.3[ -0.7]#   90%   (point estimate: 90%)
   BM25 margin          -17.4[-21.0]  -15.3[-18.5]  -13.5[-16.5]  -10.4[-13.0]   -8.2[-10.8]   -6.7[ -8.8]   -4.7[ -6.5]   -2.4[ -3.9]   -1.0[ -1.7]    100%   (point estimate: 90%)
   top5 vs rest         -18.4[-22.1]  -16.5[-20.0]  -14.4[-17.7]  -12.2[-15.1]   -8.8[-11.3]   -7.0[ -9.3]   -5.3[ -7.4]   -2.9[ -4.5]   -1.5[ -2.6]    100%   (point estimate: 100%)
   NQC-like spread      -18.2[-21.9]  -16.3[-19.8]  -14.6[-17.8]  -12.7[-15.9]   -8.7[-11.2]   -6.0[ -8.1]   -4.2[ -6.1]   -2.5[ -4.1]   -1.6[ -2.8]    100%   (point estimate: 100%)
   WIG-like             -16.6[-20.1]  -14.8[-18.1]  -11.3[-14.2]   -9.6[-12.3]   -7.6[-10.0]   -5.9[ -8.0]   -4.1[ -5.8]   -1.8[ -2.9]   -1.0[ -1.9]    100%   (point estimate: 90%)
   term coverage top1   -16.9[-20.4]  -14.5[-17.9]  -11.4[-14.2]   -9.4[-12.1]   -6.5[ -8.9]   -4.4[ -6.5]   -3.5[ -5.4]   -2.0[ -3.4]   -1.5[ -2.7]    100%   (point estimate: 100%)
   ORACLE               -10.5[-13.4]   -3.2[ -5.4]   +1.5[ +0.1]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#   30%   (point estimate: 30%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -15.5[-18.9]  -12.8[-16.0]  -10.8[-13.5]   -9.2[-11.9]   -7.8[-10.2]   -5.9[ -8.0]   -3.9[ -5.6]   -1.8[ -3.2]   -0.3[ -0.7]    100%   (point estimate: 90%)
   BM25 margin          -17.4[-21.0]  -15.3[-18.5]  -13.5[-16.5]  -10.4[-13.0]   -8.2[-10.8]   -6.7[ -8.8]   -4.7[ -6.5]   -2.4[ -3.9]   -1.0[ -1.7]    100%   (point estimate: 100%)
   top5 vs rest         -18.4[-22.1]  -16.5[-20.0]  -14.4[-17.7]  -12.2[-15.1]   -8.8[-11.3]   -7.0[ -9.3]   -5.3[ -7.4]   -2.9[ -4.5]   -1.5[ -2.6]    100%   (point estimate: 100%)
   NQC-like spread      -18.2[-21.9]  -16.3[-19.8]  -14.6[-17.8]  -12.7[-15.9]   -8.7[-11.2]   -6.0[ -8.1]   -4.2[ -6.1]   -2.5[ -4.1]   -1.6[ -2.8]    100%   (point estimate: 100%)
   WIG-like             -16.6[-20.1]  -14.8[-18.1]  -11.3[-14.2]   -9.6[-12.3]   -7.6[-10.0]   -5.9[ -8.0]   -4.1[ -5.8]   -1.8[ -2.9]   -1.0[ -1.9]    100%   (point estimate: 100%)
   term coverage top1   -16.9[-20.4]  -14.5[-17.9]  -11.4[-14.2]   -9.4[-12.1]   -6.5[ -8.9]   -4.4[ -6.5]   -3.5[ -5.4]   -2.0[ -3.4]   -1.5[ -2.7]    100%   (point estimate: 100%)
   ORACLE               -10.5[-13.4]   -3.2[ -5.4]   +1.5[ +0.1]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#  +3.1[ +1.9]#   30%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      89% (sd   9)   -0.95 MRR              30%     11%
   tag alarm               100      89% (sd   7)   -0.74 MRR              21%     11%
   tag alarm               200      90% (sd   4)   -0.62 MRR              12%     10%
   BM25 margin              50      94% (sd   9)   -0.77 MRR              28%      6%
   BM25 margin             100      93% (sd   7)   -0.89 MRR              38%      7%
   BM25 margin             200      93% (sd   6)   -0.90 MRR              46%      7%
   top5 vs rest             50      95% (sd   9)   -0.92 MRR              36%      5%
   top5 vs rest            100      96% (sd   6)   -0.66 MRR              31%      4%
   top5 vs rest            200      98% (sd   5)   -0.50 MRR              21%      2%
   NQC-like spread          50      93% (sd  10)   -1.14 MRR              42%      7%
   NQC-like spread         100      95% (sd   7)   -0.86 MRR              38%      5%
   NQC-like spread         200      97% (sd   5)   -0.56 MRR              24%      3%
   WIG-like                 50      93% (sd   9)   -0.79 MRR              37%      7%
   WIG-like                100      93% (sd   7)   -0.83 MRR              48%      7%
   WIG-like                200      94% (sd   6)   -0.73 MRR              42%      6%
   term coverage top1       50      90% (sd  13)   -1.23 MRR              43%     10%
   term coverage top1      100      92% (sd  10)   -0.96 MRR              40%      8%
   term coverage top1      200      94% (sd   7)   -0.71 MRR              30%      6%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  15%  MRR  56.7 | vs BM25 margin: +5.9 (p=0.014)  vs top5 vs rest: +2.8 (p=0.293)  vs NQC-like spread: +4.0 (p=0.098)  vs WIG-like: +2.0 (p=0.447)  vs term coverage top1: +1.1 (p=0.709)
   list           n= 105  fires  16%  MRR  62.5 | vs BM25 margin: -1.8 (p=0.543)  vs top5 vs rest: +5.3 (p=0.068)  vs NQC-like spread: +4.1 (p=0.173)  vs WIG-like: +4.0 (p=0.136)  vs term coverage top1: +4.7 (p=0.052)
   question       n= 125  fires  22%  MRR  47.1 | vs BM25 margin: +4.3 (p=0.148)  vs top5 vs rest: +4.4 (p=0.086)  vs NQC-like spread: +3.3 (p=0.181)  vs WIG-like: -0.9 (p=0.739)  vs term coverage top1: -0.1 (p=0.980)
   named entity   n=  86  fires  12%  MRR  79.7 | vs BM25 margin: +2.9 (p=0.187)  vs top5 vs rest: +1.6 (p=0.412)  vs NQC-like spread: +1.0 (p=0.582)  vs WIG-like: +2.6 (p=0.248)  vs term coverage top1: +1.7 (p=0.493)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR +0.5  [-2.8, +3.8]  p=0.765  (n=211)

