# groups46: WIG re-ranks the lowest 50% ; group loss = mean_g(gain * skipped), MRR points, 95% bootstrap CI

## amazon_testfull:monot5 (n = 1642; overall loss at 50% = +4.37)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           1642     50%               31% /  16%       +4.37 [+3.07, +5.67]
   tag alarm fired                765     49%               38% /  20%       +5.37 [+3.18, +7.57]
   tag alarm silent               877     51%               24% /  13%       +3.50 [+1.88, +5.15]
   length short (<= 14)           640     39%               28% /  15%       +2.79 [+1.07, +4.60]
   length medium                  472     47%               27% /  17%       +3.07 [+0.59, +5.63]
   length long (> 19)             530     66%               34% /  17%       +7.44 [+4.73, +10.39]

## mag_testfull:monot5 (n = 2665; overall loss at 50% = +2.19)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           2665     50%               26% /  20%       +2.19 [+1.22, +3.16]
   tag alarm fired                710     41%               40% /  20%       +5.18 [+3.10, +7.31]
   tag alarm silent              1955     53%               21% /  20%       +1.11 [+0.04, +2.18]
   length short (<= 13)          1020     30%               17% /  10%       +1.47 [+0.55, +2.44]
   length medium                  851     55%               25% /  22%       +2.52 [+0.78, +4.39]
   length long (> 19)             794     71%               30% /  24%       +2.77 [+0.46, +5.06]

## prime_testfull:monot5 (n = 2801; overall loss at 50% = +1.71)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                           2801     50%               30% /  23%       +1.71 [+0.70, +2.66]
   tag alarm fired               1563     41%               34% /  22%       +2.92 [+1.75, +4.17]
   tag alarm silent              1238     61%               26% /  24%       +0.19 [-1.33, +1.75]
   length short (<= 11)           971     40%               34% /  20%       +2.88 [+1.45, +4.31]
   length medium                  926     53%               29% /  21%       +1.83 [+0.09, +3.62]
   length long (> 16)             904     58%               27% /  27%       +0.33 [-1.51, +2.19]

## dbpedia_test:monot5 (n = 400; overall loss at 50% = +7.56)
   group                         n   skipped  helped/hurt among skipped   group loss [95% CI]
   all                            400     50%               33% /   6%       +7.56 [+5.31, +9.98]
   qtype=keyword                   84     39%               39% /   0%       +7.19 [+2.91, +12.54]
   qtype=list                     105     65%               46% /   1%      +16.50 [+11.06, +22.56]
   qtype=named entity              86     78%               13% /  12%       +1.71 [-2.70, +6.08]
   qtype=question                 125     26%               41% /   9%       +4.33 [+0.92, +8.41]
   tag alarm fired                 68     19%               54% /   8%       +6.50 [+1.23, +12.26]
   tag alarm silent               332     56%               32% /   6%       +7.78 [+5.35, +10.41]
   length short (<= 3)            163     65%               25% /   8%       +6.67 [+3.10, +10.61]
   length medium                  144     49%               41% /   4%       +9.55 [+5.41, +14.25]
   length long (> 5)               93     25%               48% /   0%       +6.03 [+2.51, +10.36]

