## mag_testfull  (2665 questions; tag alarm fires on 710 = 27%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.2  random  51.8  diff  +4.4  p=0.0001
   MRR  : tag  65.3  random  62.0  diff  +3.3  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +3.5 (p=0.000)        +2.7 (p=0.000)
   40%            +2.5 (p=0.000)        +2.0 (p=0.000)
   50%            +2.0 (p=0.000)        +1.6 (p=0.000)
   27% nat        +3.5 (p=0.000)        +2.7 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.5  95% CI [-0.9, +1.8]  p=0.558
   MRR  :  +0.0  95% CI [-0.9, +1.0]  p=0.927

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (38%)
   Hit@1:  +1.9  p=0.002
   MRR  :  +1.1  p=0.009

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.5/+2.5 (p=0.000)  40%: +2.7/+1.8 (p=0.000)  50%: +2.4/+1.7 (p=0.000)  nat: +3.2/+2.4 (p=0.000)
   vs NQC-like spread      30%: +2.8/+1.9 (p=0.000)  40%: +2.0/+1.3 (p=0.002)  50%: +2.2/+1.5 (p=0.001)  nat: +3.0/+2.1 (p=0.000)
   vs WIG-like             30%: +1.0/+0.7 (p=0.095)  40%: +0.6/+0.5 (p=0.291)  50%: +0.6/+0.4 (p=0.416)  nat: +1.1/+0.7 (p=0.060)
   vs term coverage top1   30%: +2.0/+1.1 (p=0.006)  40%: +0.8/+0.2 (p=0.679)  50%: +0.5/-0.0 (p=0.917)  nat: +2.2/+1.3 (p=0.001)

G. each selector reranking 710 questions (27%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +0.0  [-0.9, +1.0]  p=0.927
   BM25 margin           -2.7  [-3.7, -1.7]  p=0.000
   top5 vs rest          -2.3  [-3.3, -1.3]  p=0.000
   NQC-like spread       -2.0  [-3.0, -1.1]  p=0.000
   WIG-like              -0.7  [-1.7, +0.3]  p=0.185
   term coverage top1    -1.2  [-2.3, -0.2]  p=0.023

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              62.7    64.5*   65.3*   65.3*   65.5*   65.6*   65.7*   65.6*   65.4*   65.2*   20%
   BM25 margin            61.6    62.0    62.6    63.4    64.0    64.7*   65.3*   65.4*   65.3*   65.2*   60%
   top5 vs rest           61.2    62.3    62.8    63.5    63.9    64.2    64.1    64.4    64.8    65.2*   100%
   NQC-like spread        61.4    62.7    63.4    64.0    64.0    64.2    64.2    64.6    64.9*   65.2*   90%
   WIG-like               63.1    64.2*   64.7*   64.9*   65.2*   65.4*   65.9*   65.8*   65.7*   65.2*   20%
   term coverage top1     62.4    63.3    64.2*   65.2*   65.6*   65.7*   65.8*   65.9*   65.9*   65.2*   30%
   ORACLE                 68.2*   71.7*   71.9*   71.9*   71.9*   71.9*   71.9*   71.9*   71.1*   65.2*   10%
   random (expected)      61.2    61.7    62.1    62.6    63.0    63.4    63.9    64.3    64.8    65.2*   100%
   (BM25 only 60.8; rerank ALL 65.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.3 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.5[ -3.6]   -0.7[ -1.7]   +0.1[ -0.8]#  +0.1[ -0.7]#  +0.3[ -0.4]#  +0.4[ -0.2]#  +0.5[ -0.0]#  +0.4[ +0.1]#  +0.2[ +0.0]#   30%   (point estimate: 20%)
   BM25 margin           -3.6[ -4.7]   -3.2[ -4.3]   -2.6[ -3.6]   -1.8[ -2.7]   -1.2[ -2.0]   -0.5[ -1.1]#  +0.1[ -0.4]#  +0.2[ -0.2]#  +0.1[ -0.0]#   60%   (point estimate: 50%)
   top5 vs rest          -4.0[ -5.1]   -2.9[ -3.9]   -2.4[ -3.3]   -1.7[ -2.6]   -1.3[ -2.1]   -1.0[ -1.8]   -1.1[ -1.8]   -0.8[ -1.3]   -0.5[ -0.8]#   90%   (point estimate: 60%)
   NQC-like spread       -3.8[ -4.9]   -2.6[ -3.6]   -1.8[ -2.7]   -1.2[ -2.0]   -1.2[ -1.9]   -1.0[ -1.6]   -1.0[ -1.6]   -0.7[ -1.2]#  -0.3[ -0.6]#   80%   (point estimate: 40%)
   WIG-like              -2.1[ -3.2]   -1.0[ -2.0]   -0.5[ -1.5]   -0.3[ -1.3]#  -0.0[ -0.9]#  +0.2[ -0.6]#  +0.6[ -0.0]#  +0.5[ -0.0]#  +0.5[ +0.1]#   40%   (point estimate: 20%)
   term coverage top1    -2.8[ -4.0]   -1.9[ -3.0]   -1.0[ -2.0]   -0.1[ -0.9]#  +0.4[ -0.5]#  +0.5[ -0.3]#  +0.5[ -0.2]#  +0.7[ +0.2]#  +0.7[ +0.2]#   40%   (point estimate: 30%)
   ORACLE                +3.0[ +2.1]#  +6.5[ +5.8]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +5.9[ +5.2]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.3): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      34% (sd  23)   -0.71 MRR              25%     66%
   BM25 margin             100      53% (sd  21)   -1.09 MRR              35%     47%
   top5 vs rest            100      60% (sd  35)   -1.47 MRR              45%     40%
   NQC-like spread         100      74% (sd  18)   -0.79 MRR               5%     26%
   WIG-like                100      38% (sd  32)   -0.99 MRR              45%     62%
   term coverage top1      100      44% (sd  31)   -0.87 MRR              40%     56%

