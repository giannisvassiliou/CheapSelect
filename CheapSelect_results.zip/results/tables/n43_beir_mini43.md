## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.7  random  54.7  diff  +2.0  p=0.0272
   MRR  : tag  67.3  random  66.7  diff  +0.6  p=0.1307

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.4 (p=0.624)
   40%            +0.3 (p=1.000)        -0.7 (p=0.140)
   50%            +0.0 (p=1.000)        -0.8 (p=0.124)
   15% nat        +1.3 (p=0.501)        +0.2 (p=0.828)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.0  95% CI [-4.7, +4.7]  p=1.000
   MRR  :  -0.9  95% CI [-3.6, +1.9]  p=0.548

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (30%)
   Hit@1:  -1.3  p=0.570
   MRR  :  -0.3  p=0.752

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.3/+1.3 (p=0.229)  40%: +4.7/+2.0 (p=0.106)  50%: +4.3/+2.2 (p=0.080)  nat: +2.3/+0.5 (p=0.481)
   vs NQC-like spread      30%: +1.3/-0.9 (p=0.363)  40%: +2.0/-0.4 (p=0.659)  50%: +2.0/+0.4 (p=0.685)  nat: +0.3/-1.0 (p=0.181)
   vs WIG-like             30%: +2.3/+0.2 (p=0.835)  40%: +2.7/+0.4 (p=0.696)  50%: +3.3/+1.6 (p=0.119)  nat: +2.7/+0.4 (p=0.679)
   vs term coverage top1   30%: +1.0/-0.2 (p=0.889)  40%: +2.7/+1.2 (p=0.243)  50%: +3.0/+1.7 (p=0.068)  nat: +0.3/-0.7 (p=0.409)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.9  [-3.6, +1.9]  p=0.548
   BM25 margin           -1.1  [-3.8, +1.7]  p=0.453
   top5 vs rest          -1.4  [-4.3, +1.6]  p=0.364
   NQC-like spread       +0.2  [-2.5, +2.9]  p=0.903
   WIG-like              -1.3  [-3.9, +1.4]  p=0.357
   term coverage top1    -0.1  [-2.8, +2.5]  p=0.930

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              67.7*   67.6*   67.9*   68.7*   69.5*   69.8*   69.2*   68.7*   68.5*   68.2*   10%
   BM25 margin            66.4*   67.5*   68.3*   69.4*   70.3*   69.3*   69.2*   68.6*   68.5*   68.2*   10%
   top5 vs rest           66.6*   66.7*   66.7*   66.7*   67.3*   67.4*   68.0*   68.0*   68.1*   68.2*   10%
   NQC-like spread        67.4*   68.6*   68.8*   69.1*   69.2*   68.9*   68.8*   68.4*   68.4*   68.2*   10%
   WIG-like               67.1*   67.6*   67.7*   68.3*   67.9*   67.7*   67.4*   67.3*   68.4*   68.2*   10%
   term coverage top1     67.5*   67.4*   68.1*   67.6*   67.9*   68.0*   68.3*   68.2*   67.8*   68.2*   10%
   ORACLE                 72.0*   74.5*   74.5*   74.5*   74.5*   74.5*   74.5*   74.5*   73.1*   68.2*   10%
   random (expected)      66.6    66.8    67.0    67.1    67.3    67.5    67.7    67.8    68.0    68.2*   100%
   (BM25 only 66.4; rerank ALL 68.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.5[ -3.4]   -0.6[ -3.4]   -0.3[ -2.7]   +0.5[ -1.5]   +1.4[ -0.2]#  +1.6[ +0.4]#  +1.0[ +0.2]#  +0.5[ -0.1]#  +0.3[ -0.0]#   50%   (point estimate: 10%)
   BM25 margin           -1.7[ -4.6]   -0.7[ -3.4]   +0.1[ -2.2]   +1.2[ -0.7]#  +2.1[ +0.8]#  +1.1[ +0.2]#  +1.0[ +0.2]#  +0.4[ -0.1]#  +0.3[ -0.0]#   40%   (point estimate: 20%)
   top5 vs rest          -1.6[ -4.6]   -1.5[ -4.4]   -1.5[ -4.4]   -1.5[ -4.3]   -0.9[ -3.2]   -0.8[ -3.0]   -0.2[ -2.2]   -0.2[ -1.6]   -0.1[ -1.1]    100%   (point estimate: 50%)
   NQC-like spread       -0.8[ -3.7]   +0.4[ -2.1]   +0.6[ -1.7]   +0.9[ -1.3]   +1.0[ -0.8]#  +0.7[ -0.8]#  +0.7[ -0.6]#  +0.2[ -0.8]#  +0.2[ -0.3]#   50%   (point estimate: 10%)
   WIG-like              -1.1[ -3.9]   -0.6[ -3.2]   -0.5[ -2.8]   +0.1[ -1.9]   -0.3[ -2.0]   -0.5[ -2.2]   -0.8[ -2.1]   -0.9[ -2.1]   +0.2[ -0.6]#   90%   (point estimate: 20%)
   term coverage top1    -0.7[ -3.5]   -0.8[ -3.4]   -0.1[ -2.2]   -0.6[ -2.5]   -0.3[ -1.9]   -0.2[ -1.4]   +0.1[ -1.0]   +0.0[ -1.0]   -0.4[ -1.2]    100%   (point estimate: 10%)
   ORACLE                +3.8[ +1.8]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +4.9[ +3.3]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.5[ -3.4]   -0.6[ -3.4]   -0.3[ -2.7]   +0.5[ -1.5]   +1.4[ -0.2]#  +1.6[ +0.4]#  +1.0[ +0.2]#  +0.5[ -0.1]#  +0.3[ -0.0]#   50%   (point estimate: 30%)
   BM25 margin           -1.7[ -4.6]   -0.7[ -3.4]   +0.1[ -2.2]   +1.2[ -0.7]   +2.1[ +0.8]#  +1.1[ +0.2]#  +1.0[ +0.2]#  +0.4[ -0.1]#  +0.3[ -0.0]#   50%   (point estimate: 30%)
   top5 vs rest          -1.6[ -4.6]   -1.5[ -4.4]   -1.5[ -4.4]   -1.5[ -4.3]   -0.9[ -3.2]   -0.8[ -3.0]   -0.2[ -2.2]   -0.2[ -1.6]   -0.1[ -1.1]    100%   (point estimate: 70%)
   NQC-like spread       -0.8[ -3.7]   +0.4[ -2.1]   +0.6[ -1.7]   +0.9[ -1.3]   +1.0[ -0.8]   +0.7[ -0.8]   +0.7[ -0.6]   +0.2[ -0.8]   +0.2[ -0.3]#   90%   (point estimate: 20%)
   WIG-like              -1.1[ -3.9]   -0.6[ -3.2]   -0.5[ -2.8]   +0.1[ -1.9]   -0.3[ -2.0]   -0.5[ -2.2]   -0.8[ -2.1]   -0.9[ -2.1]   +0.2[ -0.6]    100%   (point estimate: 90%)
   term coverage top1    -0.7[ -3.5]   -0.8[ -3.4]   -0.1[ -2.2]   -0.6[ -2.5]   -0.3[ -1.9]   -0.2[ -1.4]   +0.1[ -1.0]   +0.0[ -1.0]   -0.4[ -1.2]    100%   (point estimate: 50%)
   ORACLE                +3.8[ +1.8]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +6.3[ +4.6]#  +4.9[ +3.3]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      28% (sd  19)   -0.09 MRR              26%     72%
   tag alarm               100      26% (sd  17)   -0.18 MRR              31%     74%
   tag alarm               200      22% (sd  14)   -0.45 MRR              36%     78%
   BM25 margin              50      29% (sd  19)   -0.29 MRR              40%     71%
   BM25 margin             100      24% (sd  13)   -0.55 MRR              41%     76%
   BM25 margin             200      22% (sd   9)   -0.68 MRR              41%     78%
   top5 vs rest             50      59% (sd  36)   -0.88 MRR              41%     41%
   top5 vs rest            100      62% (sd  31)   -0.86 MRR              38%     38%
   top5 vs rest            200      52% (sd  26)   -1.21 MRR              45%     48%
   NQC-like spread          50      34% (sd  30)   -0.32 MRR              39%     66%
   NQC-like spread         100      24% (sd  21)   -0.37 MRR              38%     76%
   NQC-like spread         200      16% (sd   8)   -0.48 MRR              43%     84%
   WIG-like                 50      59% (sd  37)   -0.63 MRR              28%     41%
   WIG-like                100      52% (sd  36)   -0.72 MRR              34%     48%
   WIG-like                200      46% (sd  35)   -0.86 MRR              38%     54%
   term coverage top1       50      44% (sd  31)   -0.56 MRR              25%     56%
   term coverage top1      100      46% (sd  35)   -0.66 MRR              32%     54%
   term coverage top1      200      27% (sd  21)   -1.01 MRR              46%     73%

## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  44.3  random  44.1  diff  +0.2  p=0.4349
   MRR  : tag  30.9  random  31.0  diff  -0.1  p=0.7880

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.6 (p=0.630)        -0.0 (p=1.000)
   40%            +0.3 (p=1.000)        -0.2 (p=0.239)
   50%            +0.6 (p=0.503)        +0.1 (p=0.246)
   2% nat         +0.3 (p=1.000)        -0.0 (p=1.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.3  95% CI [-8.7, +0.0]  p=0.064
   MRR  :  -3.2  95% CI [-4.6, -1.9]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (44%)
   Hit@1:  +0.3  p=1.000
   MRR  :  -0.0  p=0.927

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.4/+0.4 (p=0.388)  40%: +2.5/+0.3 (p=0.629)  50%: +3.1/+0.3 (p=0.529)  nat: +0.3/-0.0 (p=1.000)
   vs NQC-like spread      30%: +2.8/-0.1 (p=0.911)  40%: +1.5/-0.2 (p=0.736)  50%: +3.1/-0.1 (p=0.859)  nat: +0.3/-0.0 (p=1.000)
   vs WIG-like             30%: +2.8/+0.7 (p=0.090)  40%: +1.9/+0.5 (p=0.332)  50%: +1.9/+0.2 (p=0.769)  nat: +0.3/-0.0 (p=1.000)
   vs term coverage top1   30%: +2.8/-0.2 (p=0.720)  40%: +1.5/-0.3 (p=0.635)  50%: +0.3/-0.2 (p=0.629)  nat: +0.3/-0.0 (p=1.000)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -3.2  [-4.6, -1.9]  p=0.000
   BM25 margin           -3.2  [-4.6, -1.8]  p=0.000
   top5 vs rest          -3.2  [-4.6, -1.8]  p=0.000
   NQC-like spread       -3.2  [-4.6, -1.8]  p=0.000
   WIG-like              -3.2  [-4.6, -1.8]  p=0.000
   term coverage top1    -3.2  [-4.6, -1.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              30.9    31.3    31.8    32.1    32.8    32.8    33.1    33.4    34.0*   34.1*   90%
   BM25 margin            30.8    31.3    31.8    32.4    32.7    33.0    33.0    33.4    34.0*   34.1*   90%
   top5 vs rest           30.8    30.9    31.4    31.8    32.4    32.9    33.5    33.9*   34.3*   34.1*   80%
   NQC-like spread        30.8    31.6    31.9    32.3    32.9    33.7*   34.0*   34.1*   34.0*   34.1*   60%
   WIG-like               30.9    30.8    31.1    31.6    32.6    33.2    33.4    33.6*   34.2*   34.1*   80%
   term coverage top1     31.0    31.5    32.0    32.4    33.0    33.1    33.3    33.5    33.8*   34.1*   90%
   ORACLE                 34.1*   35.4*   36.0*   36.1*   36.1*   36.1*   36.1*   36.1*   35.7*   34.1*   10%
   random (expected)      31.2    31.6    31.9    32.2    32.5    32.8    33.2    33.5    33.8    34.1*   100%
   (BM25 only 30.9; rerank ALL 34.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -3.2[ -4.6]   -2.8[ -4.1]   -2.3[ -3.6]   -2.0[ -3.2]   -1.4[ -2.3]   -1.3[ -2.3]   -1.0[ -1.8]   -0.7[ -1.4]   -0.1[ -0.6]#   90%   (point estimate: 80%)
   BM25 margin           -3.3[ -4.7]   -2.8[ -4.1]   -2.3[ -3.5]   -1.8[ -2.9]   -1.4[ -2.4]   -1.1[ -1.9]   -1.1[ -1.9]   -0.7[ -1.5]   -0.1[ -0.6]#   90%   (point estimate: 80%)
   top5 vs rest          -3.3[ -4.7]   -3.2[ -4.5]   -2.8[ -4.0]   -2.3[ -3.2]   -1.7[ -2.6]   -1.2[ -2.0]   -0.6[ -1.1]   -0.3[ -0.7]#  +0.2[ -0.1]#   80%   (point estimate: 70%)
   NQC-like spread       -3.3[ -4.7]   -2.5[ -3.7]   -2.3[ -3.3]   -1.8[ -2.7]   -1.3[ -2.1]   -0.4[ -1.0]   -0.1[ -0.6]#  +0.0[ -0.3]#  -0.1[ -0.4]#   70%   (point estimate: 60%)
   WIG-like              -3.2[ -4.6]   -3.4[ -4.7]   -3.0[ -4.3]   -2.5[ -3.7]   -1.5[ -2.4]   -0.9[ -1.7]   -0.7[ -1.4]   -0.5[ -1.0]   +0.0[ -0.2]#   90%   (point estimate: 60%)
   term coverage top1    -3.1[ -4.5]   -2.6[ -3.9]   -2.1[ -3.4]   -1.7[ -2.7]   -1.1[ -1.9]   -1.0[ -1.8]   -0.8[ -1.4]   -0.6[ -1.2]   -0.3[ -0.7]#   90%   (point estimate: 60%)
   ORACLE                -0.0[ -0.8]#  +1.3[ +0.7]#  +1.9[ +1.4]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +1.6[ +1.1]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -3.2[ -4.6]   -2.8[ -4.1]   -2.3[ -3.6]   -2.0[ -3.2]   -1.4[ -2.3]   -1.3[ -2.3]   -1.0[ -1.8]   -0.7[ -1.4]   -0.1[ -0.6]    100%   (point estimate: 90%)
   BM25 margin           -3.3[ -4.7]   -2.8[ -4.1]   -2.3[ -3.5]   -1.8[ -2.9]   -1.4[ -2.4]   -1.1[ -1.9]   -1.1[ -1.9]   -0.7[ -1.5]   -0.1[ -0.6]    100%   (point estimate: 90%)
   top5 vs rest          -3.3[ -4.7]   -3.2[ -4.5]   -2.8[ -4.0]   -2.3[ -3.2]   -1.7[ -2.6]   -1.2[ -2.0]   -0.6[ -1.1]   -0.3[ -0.7]   +0.2[ -0.1]#   90%   (point estimate: 80%)
   NQC-like spread       -3.3[ -4.7]   -2.5[ -3.7]   -2.3[ -3.3]   -1.8[ -2.7]   -1.3[ -2.1]   -0.4[ -1.0]   -0.1[ -0.6]   +0.0[ -0.3]#  -0.1[ -0.4]#   80%   (point estimate: 60%)
   WIG-like              -3.2[ -4.6]   -3.4[ -4.7]   -3.0[ -4.3]   -2.5[ -3.7]   -1.5[ -2.4]   -0.9[ -1.7]   -0.7[ -1.4]   -0.5[ -1.0]   +0.0[ -0.2]#   90%   (point estimate: 80%)
   term coverage top1    -3.1[ -4.5]   -2.6[ -3.9]   -2.1[ -3.4]   -1.7[ -2.7]   -1.1[ -1.9]   -1.0[ -1.8]   -0.8[ -1.4]   -0.6[ -1.2]   -0.3[ -0.7]    100%   (point estimate: 90%)
   ORACLE                -0.0[ -0.8]   +1.3[ +0.7]#  +1.9[ +1.4]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +2.0[ +1.4]#  +1.6[ +1.1]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      71% (sd  24)   -0.99 MRR              44%     29%
   tag alarm               100      68% (sd  19)   -1.06 MRR              54%     32%
   tag alarm               200      72% (sd  14)   -1.00 MRR              44%     28%
   BM25 margin              50      67% (sd  26)   -1.13 MRR              48%     33%
   BM25 margin             100      72% (sd  20)   -0.97 MRR              42%     28%
   BM25 margin             200      72% (sd  14)   -1.02 MRR              48%     28%
   top5 vs rest             50      63% (sd  18)   -1.12 MRR              46%     37%
   top5 vs rest            100      66% (sd  11)   -0.91 MRR              39%     34%
   top5 vs rest            200      68% (sd   5)   -0.79 MRR              24%     32%
   NQC-like spread          50      55% (sd  17)   -0.94 MRR              40%     45%
   NQC-like spread         100      57% (sd  12)   -0.83 MRR              32%     43%
   NQC-like spread         200      59% (sd   5)   -0.67 MRR              22%     41%
   WIG-like                 50      66% (sd  19)   -1.03 MRR              35%     34%
   WIG-like                100      66% (sd  13)   -0.98 MRR              38%     34%
   WIG-like                200      67% (sd   8)   -0.87 MRR              38%     33%
   term coverage top1       50      61% (sd  24)   -1.09 MRR              44%     39%
   term coverage top1      100      62% (sd  17)   -0.99 MRR              40%     38%
   term coverage top1      200      63% (sd  13)   -1.02 MRR              44%     37%

## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  25.3  random  24.9  diff  +0.4  p=0.3320
   MRR  : tag  26.7  random  26.2  diff  +0.5  p=0.1074

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -1.7 (p=0.154)        -1.2 (p=0.054)
   40%            -0.2 (p=1.000)        +0.3 (p=0.558)
   50%            +0.0 (p=1.000)        +0.3 (p=0.464)
   25% nat        -1.5 (p=0.227)        -0.6 (p=0.399)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.9  95% CI [-10.8, -4.9]  p=0.000
   MRR  :  -7.0  95% CI [-8.7, -5.4]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (51%)
   Hit@1:  +0.9  p=0.472
   MRR  :  -0.3  p=0.609

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.2/+0.2 (p=0.819)  40%: +1.5/+1.2 (p=0.088)  50%: +2.3/+1.8 (p=0.014)  nat: -0.3/+0.4 (p=0.537)
   vs NQC-like spread      30%: -0.5/-0.2 (p=0.731)  40%: +1.9/+1.5 (p=0.031)  50%: +2.0/+1.6 (p=0.016)  nat: -0.8/-0.1 (p=0.884)
   vs WIG-like             30%: +0.6/-0.1 (p=0.859)  40%: +2.5/+1.1 (p=0.137)  50%: +2.0/+0.9 (p=0.209)  nat: +0.6/+0.0 (p=0.969)
   vs term coverage top1   30%: +1.2/+0.4 (p=0.519)  40%: +2.2/+1.2 (p=0.102)  50%: +1.2/+0.5 (p=0.489)  nat: +0.8/+0.6 (p=0.329)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -7.0  [-8.7, -5.4]  p=0.000
   BM25 margin           -6.5  [-8.0, -5.0]  p=0.000
   top5 vs rest          -7.4  [-9.1, -5.8]  p=0.000
   NQC-like spread       -7.0  [-8.6, -5.4]  p=0.000
   WIG-like              -7.1  [-8.7, -5.4]  p=0.000
   term coverage top1    -7.6  [-9.3, -6.1]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              25.1    26.1    27.0    28.8    29.9    30.8    31.4    32.0    33.3    33.7*   100%
   BM25 margin            24.9    26.6    28.2    28.6    29.5    30.1    30.9    32.3    33.0    33.7*   100%
   top5 vs rest           24.8    25.9    26.9    27.6    28.1    29.1    30.1    31.4    32.6    33.7*   100%
   NQC-like spread        25.1    26.6    27.3    27.4    28.2    29.4    30.2    31.2    32.7    33.7*   100%
   WIG-like               24.6    25.9    27.1    27.8    28.9    30.1    30.9    31.8    32.7    33.7*   100%
   term coverage top1     24.8    25.7    26.6    27.7    29.4    30.4    31.7    32.4    33.3*   33.7*   90%
   ORACLE                 29.6    33.3*   35.5*   36.3*   36.3*   36.3*   36.3*   36.3*   36.3*   33.7*   20%
   random (expected)      24.7    25.7    26.7    27.7    28.7    29.7    30.7    31.7    32.7    33.7*   100%
   (BM25 only 23.7; rerank ALL 33.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.6[-10.4]   -7.6[ -9.2]   -6.7[ -8.2]   -4.9[ -6.2]   -3.9[ -5.0]   -2.9[ -4.0]   -2.4[ -3.3]   -1.7[ -2.5]   -0.4[ -0.8]#   90%   (point estimate: 90%)
   BM25 margin           -8.8[-10.5]   -7.1[ -8.7]   -5.5[ -7.0]   -5.2[ -6.6]   -4.2[ -5.4]   -3.6[ -4.7]   -2.8[ -3.8]   -1.4[ -2.2]   -0.7[ -1.2]    100%   (point estimate: 90%)
   top5 vs rest          -8.9[-10.7]   -7.8[ -9.4]   -6.8[ -8.4]   -6.1[ -7.6]   -5.6[ -7.1]   -4.6[ -5.8]   -3.6[ -4.7]   -2.3[ -3.2]   -1.2[ -1.9]    100%   (point estimate: 100%)
   NQC-like spread       -8.6[-10.4]   -7.2[ -8.8]   -6.4[ -8.1]   -6.3[ -7.8]   -5.5[ -6.9]   -4.3[ -5.5]   -3.5[ -4.6]   -2.5[ -3.4]   -1.0[ -1.6]    100%   (point estimate: 90%)
   WIG-like              -9.1[-10.9]   -7.8[ -9.5]   -6.6[ -8.2]   -5.9[ -7.4]   -4.8[ -6.2]   -3.6[ -4.9]   -2.8[ -4.0]   -1.9[ -2.8]   -1.0[ -1.6]    100%   (point estimate: 90%)
   term coverage top1    -8.9[-10.7]   -8.0[ -9.7]   -7.1[ -8.6]   -6.0[ -7.4]   -4.4[ -5.6]   -3.3[ -4.4]   -2.0[ -2.9]   -1.3[ -2.1]   -0.4[ -1.0]    100%   (point estimate: 90%)
   ORACLE                -4.1[ -5.4]   -0.4[ -1.4]   +1.8[ +1.0]#  +2.6[ +1.9]#  +2.6[ +1.9]#  +2.6[ +1.9]#  +2.6[ +1.9]#  +2.6[ +1.9]#  +2.6[ +1.9]#   30%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -8.6[-10.4]   -7.6[ -9.2]   -6.7[ -8.2]   -4.9[ -6.2]   -3.9[ -5.0]   -2.9[ -4.0]   -2.4[ -3.3]   -1.7[ -2.5]   -0.4[ -0.8]    100%   (point estimate: 90%)
   BM25 margin           -8.8[-10.5]   -7.1[ -8.7]   -5.5[ -7.0]   -5.2[ -6.6]   -4.2[ -5.4]   -3.6[ -4.7]   -2.8[ -3.8]   -1.4[ -2.2]   -0.7[ -1.2]    100%   (point estimate: 100%)
   top5 vs rest          -8.9[-10.7]   -7.8[ -9.4]   -6.8[ -8.4]   -6.1[ -7.6]   -5.6[ -7.1]   -4.6[ -5.8]   -3.6[ -4.7]   -2.3[ -3.2]   -1.2[ -1.9]    100%   (point estimate: 100%)
   NQC-like spread       -8.6[-10.4]   -7.2[ -8.8]   -6.4[ -8.1]   -6.3[ -7.8]   -5.5[ -6.9]   -4.3[ -5.5]   -3.5[ -4.6]   -2.5[ -3.4]   -1.0[ -1.6]    100%   (point estimate: 100%)
   WIG-like              -9.1[-10.9]   -7.8[ -9.5]   -6.6[ -8.2]   -5.9[ -7.4]   -4.8[ -6.2]   -3.6[ -4.9]   -2.8[ -4.0]   -1.9[ -2.8]   -1.0[ -1.6]    100%   (point estimate: 100%)
   term coverage top1    -8.9[-10.7]   -8.0[ -9.7]   -7.1[ -8.6]   -6.0[ -7.4]   -4.4[ -5.6]   -3.3[ -4.4]   -2.0[ -2.9]   -1.3[ -2.1]   -0.4[ -1.0]    100%   (point estimate: 90%)
   ORACLE                -4.1[ -5.4]   -0.4[ -1.4]   +1.8[ +1.0]#  +2.6[ +1.9]#  +2.6[ +1.9]#  +2.6[ +1.9]#  +2.6[ +1.9]#  +2.6[ +1.9]#  +2.6[ +1.9]#   30%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      84% (sd  17)   -1.26 MRR              38%     16%
   tag alarm               100      87% (sd  11)   -0.93 MRR              26%     13%
   tag alarm               200      89% (sd   5)   -0.67 MRR              14%     11%
   BM25 margin              50      87% (sd  15)   -1.13 MRR              30%     13%
   BM25 margin             100      90% (sd   8)   -0.84 MRR              20%     10%
   BM25 margin             200      90% (sd   5)   -0.79 MRR              14%     10%
   top5 vs rest             50      92% (sd  12)   -0.95 MRR              48%      8%
   top5 vs rest            100      94% (sd   7)   -0.73 MRR              44%      6%
   top5 vs rest            200      95% (sd   6)   -0.62 MRR              44%      5%
   NQC-like spread          50      93% (sd   8)   -0.77 MRR              34%      7%
   NQC-like spread         100      94% (sd   8)   -0.70 MRR              32%      6%
   NQC-like spread         200      94% (sd   5)   -0.63 MRR              33%      6%
   WIG-like                 50      90% (sd  15)   -1.04 MRR              32%     10%
   WIG-like                100      92% (sd  11)   -0.86 MRR              32%      8%
   WIG-like                200      94% (sd   7)   -0.69 MRR              40%      6%
   term coverage top1       50      86% (sd  15)   -0.97 MRR              39%     14%
   term coverage top1      100      86% (sd  12)   -0.91 MRR              40%     14%
   term coverage top1      200      87% (sd   8)   -0.79 MRR              40%     13%

## beir_arguana  (1401 questions; tag alarm fires on 9 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.1  diff  +0.0  p=0.9927
   MRR  : tag  32.1  random  32.1  diff  -0.1  p=0.8511

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        -0.1 (p=0.243)
   40%            +0.0 (p=1.000)        -0.1 (p=0.407)
   50%            +0.0 (p=1.000)        -0.1 (p=0.282)
   1% nat         +0.1 (p=1.000)        +0.0 (p=0.866)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.1  95% CI [+0.0, +0.2]  p=1.000
   MRR  :  +1.5  95% CI [+0.2, +2.8]  p=0.031

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (3%)
   Hit@1:  +0.0  p=1.000
   MRR  :  -0.1  p=0.507

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.1/-0.3 (p=0.567)  40%: -0.1/-0.1 (p=0.874)  50%: -0.1/+0.1 (p=0.932)  nat: +0.0/-0.2 (p=0.017)
   vs NQC-like spread      30%: -0.1/+0.3 (p=0.528)  40%: -0.1/+0.1 (p=0.906)  50%: -0.1/-0.2 (p=0.727)  nat: +0.0/-0.1 (p=0.397)
   vs WIG-like             30%: -0.1/+0.0 (p=0.927)  40%: -0.1/+0.1 (p=0.812)  50%: -0.1/+0.0 (p=0.966)  nat: +0.0/-0.0 (p=0.897)
   vs term coverage top1   30%: -0.1/-0.1 (p=0.768)  40%: -0.1/-0.2 (p=0.598)  50%: +0.0/-0.4 (p=0.384)  nat: +0.0/+0.0 (p=0.697)

G. each selector reranking 9 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +1.5  [+0.2, +2.8]  p=0.031
   BM25 margin           +1.5  [+0.2, +2.8]  p=0.034
   top5 vs rest          +1.7  [+0.3, +3.0]  p=0.016
   NQC-like spread       +1.5  [+0.2, +2.9]  p=0.026
   WIG-like              +1.5  [+0.2, +2.8]  p=0.031
   term coverage top1    +1.4  [+0.1, +2.8]  p=0.035

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              32.4*   32.5*   32.1*   31.8*   31.4*   31.0*   30.5*   30.3*   30.4*   30.6*   10%
   BM25 margin            32.5*   32.5*   32.2*   31.9*   31.5*   31.1*   30.5*   30.3*   30.4*   30.6*   10%
   top5 vs rest           32.5*   32.7*   32.4*   31.9*   31.4*   30.9*   30.6*   30.5*   30.5*   30.6*   10%
   NQC-like spread        32.2*   32.1*   31.8*   31.8*   31.6*   31.6*   31.3*   31.1*   30.6*   30.6*   10%
   WIG-like               32.5*   32.5*   32.1*   31.7*   31.4*   31.1*   30.6*   30.7*   30.7*   30.6*   10%
   term coverage top1     32.0*   32.2*   32.2*   32.1*   31.9*   31.5*   31.3*   31.2*   30.9*   30.6*   10%
   ORACLE                 36.6*   39.2*   40.3*   40.3*   40.3*   40.3*   40.0*   38.5*   35.4*   30.6*   10%
   random (expected)      32.0*   31.8*   31.7*   31.5*   31.4*   31.2*   31.1*   30.9*   30.7*   30.6*   10%
   (BM25 only 32.1; rerank ALL 30.6)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +1.8[ +0.6]#  +1.9[ +0.7]#  +1.5[ +0.4]#  +1.2[ +0.2]#  +0.8[ -0.1]#  +0.4[ -0.4]#  -0.0[ -0.8]#  -0.3[ -0.9]#  -0.2[ -0.6]#   10%   (point estimate: 10%)
   BM25 margin           +1.9[ +0.7]#  +1.9[ +0.7]#  +1.6[ +0.5]#  +1.3[ +0.2]#  +0.9[ -0.0]#  +0.5[ -0.4]#  -0.0[ -0.8]#  -0.3[ -0.9]#  -0.2[ -0.6]#   10%   (point estimate: 10%)
   top5 vs rest          +1.9[ +0.7]#  +2.1[ +0.9]#  +1.8[ +0.7]#  +1.3[ +0.3]#  +0.8[ -0.1]#  +0.3[ -0.5]#  +0.0[ -0.6]#  -0.1[ -0.6]#  -0.1[ -0.4]#   10%   (point estimate: 10%)
   NQC-like spread       +1.7[ +0.4]#  +1.6[ +0.4]#  +1.2[ +0.2]#  +1.2[ +0.2]#  +1.0[ +0.1]#  +1.0[ +0.2]#  +0.7[ -0.1]#  +0.6[ -0.1]#  +0.1[ -0.4]#   10%   (point estimate: 10%)
   WIG-like              +1.9[ +0.6]#  +1.9[ +0.8]#  +1.5[ +0.4]#  +1.1[ +0.1]#  +0.8[ -0.1]#  +0.5[ -0.3]#  -0.0[ -0.7]#  +0.1[ -0.4]#  +0.1[ -0.3]#   10%   (point estimate: 10%)
   term coverage top1    +1.4[ +0.1]#  +1.6[ +0.4]#  +1.6[ +0.6]#  +1.5[ +0.5]#  +1.3[ +0.4]#  +1.0[ +0.2]#  +0.7[ +0.0]#  +0.6[ -0.0]#  +0.3[ -0.1]#   10%   (point estimate: 10%)
   ORACLE                +6.0[ +5.0]#  +8.6[ +7.8]#  +9.7[ +8.9]#  +9.7[ +8.9]#  +9.7[ +8.9]#  +9.7[ +8.9]#  +9.4[ +8.6]#  +7.9[ +7.1]#  +4.8[ +4.1]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +1.8[ +0.6]#  +1.9[ +0.7]#  +1.5[ +0.4]#  +1.2[ +0.2]#  +0.8[ -0.1]#  +0.4[ -0.4]#  -0.0[ -0.8]   -0.3[ -0.9]   -0.2[ -0.6]    100%   (point estimate: 10%)
   BM25 margin           +1.9[ +0.7]#  +1.9[ +0.7]#  +1.6[ +0.5]#  +1.3[ +0.2]#  +0.9[ -0.0]#  +0.5[ -0.4]#  -0.0[ -0.8]   -0.3[ -0.9]   -0.2[ -0.6]    100%   (point estimate: 10%)
   top5 vs rest          +1.9[ +0.7]#  +2.1[ +0.9]#  +1.8[ +0.7]#  +1.3[ +0.3]#  +0.8[ -0.1]#  +0.3[ -0.5]   +0.0[ -0.6]   -0.1[ -0.6]   -0.1[ -0.4]#   90%   (point estimate: 10%)
   NQC-like spread       +1.7[ +0.4]#  +1.6[ +0.4]#  +1.2[ +0.2]#  +1.2[ +0.2]#  +1.0[ +0.1]#  +1.0[ +0.2]#  +0.7[ -0.1]#  +0.6[ -0.1]#  +0.1[ -0.4]#   10%   (point estimate: 10%)
   WIG-like              +1.9[ +0.6]#  +1.9[ +0.8]#  +1.5[ +0.4]#  +1.1[ +0.1]#  +0.8[ -0.1]#  +0.5[ -0.3]#  -0.0[ -0.7]   +0.1[ -0.4]#  +0.1[ -0.3]#   80%   (point estimate: 10%)
   term coverage top1    +1.4[ +0.1]#  +1.6[ +0.4]#  +1.6[ +0.6]#  +1.5[ +0.5]#  +1.3[ +0.4]#  +1.0[ +0.2]#  +0.7[ +0.0]#  +0.6[ -0.0]#  +0.3[ -0.1]#   10%   (point estimate: 10%)
   ORACLE                +6.0[ +5.0]#  +8.6[ +7.8]#  +9.7[ +8.9]#  +9.7[ +8.9]#  +9.7[ +8.9]#  +9.7[ +8.9]#  +9.4[ +8.6]#  +7.9[ +7.1]#  +4.8[ +4.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      56% (sd  40)   +0.72 MRR               0%     44%
   tag alarm               100      44% (sd  41)   +1.00 MRR               0%     56%
   tag alarm               200      27% (sd  32)   +1.35 MRR               0%     73%
   BM25 margin              50      56% (sd  41)   +0.74 MRR               0%     44%
   BM25 margin             100      40% (sd  39)   +1.10 MRR               0%     60%
   BM25 margin             200      34% (sd  36)   +1.24 MRR               0%     66%
   top5 vs rest             50      48% (sd  39)   +0.96 MRR               0%     52%
   top5 vs rest            100      40% (sd  37)   +1.15 MRR               0%     60%
   top5 vs rest            200      23% (sd  29)   +1.56 MRR               0%     77%
   NQC-like spread          50      41% (sd  38)   +1.07 MRR               0%     59%
   NQC-like spread         100      29% (sd  32)   +1.30 MRR               0%     71%
   NQC-like spread         200      15% (sd  18)   +1.55 MRR               0%     85%
   WIG-like                 50      45% (sd  39)   +1.06 MRR               0%     55%
   WIG-like                100      36% (sd  35)   +1.25 MRR               0%     64%
   WIG-like                200      22% (sd  27)   +1.60 MRR               0%     78%
   term coverage top1       50      50% (sd  39)   +0.73 MRR               0%     50%
   term coverage top1      100      34% (sd  33)   +0.97 MRR               0%     66%
   term coverage top1      200      20% (sd  24)   +1.16 MRR               0%     80%

## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.4  random  18.8  diff  +0.6  p=0.0776
   MRR  : tag  15.5  random  15.4  diff  +0.1  p=0.2351

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.0 (p=0.990)
   40%            +0.6 (p=0.212)        +0.1 (p=0.378)
   50%            -0.2 (p=0.789)        +0.0 (p=0.889)
   12% nat        +0.0 (p=1.000)        +0.2 (p=0.127)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -0.3  95% CI [-2.5, +1.8]  p=0.848
   MRR  :  -0.8  95% CI [-1.5, -0.2]  p=0.012

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +0.2  p=0.897
   MRR  :  +0.4  p=0.145

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +1.6/-0.1 (p=0.518)  40%: +2.0/-0.1 (p=0.788)  50%: +1.4/-0.3 (p=0.316)  nat: +0.7/+0.1 (p=0.610)
   vs NQC-like spread      30%: +1.8/+0.0 (p=0.877)  40%: +1.5/-0.0 (p=0.953)  50%: +1.4/+0.1 (p=0.839)  nat: +0.8/+0.1 (p=0.440)
   vs WIG-like             30%: +1.1/-0.3 (p=0.138)  40%: +0.8/-0.4 (p=0.154)  50%: +0.3/-0.4 (p=0.155)  nat: +0.8/-0.1 (p=0.459)
   vs term coverage top1   30%: +1.0/-0.4 (p=0.067)  40%: +1.3/-0.3 (p=0.183)  50%: +0.2/-0.4 (p=0.098)  nat: +0.2/-0.2 (p=0.252)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.8  [-1.5, -0.2]  p=0.012
   BM25 margin           -1.1  [-1.8, -0.4]  p=0.002
   top5 vs rest          -0.9  [-1.6, -0.3]  p=0.006
   NQC-like spread       -1.0  [-1.6, -0.3]  p=0.005
   WIG-like              -0.7  [-1.4, -0.1]  p=0.032
   term coverage top1    -0.7  [-1.3, -0.0]  p=0.047

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              15.5    15.4    15.4    15.5    15.6    15.8    16.0*   16.0    16.1    16.3*   100%
   BM25 margin            15.3    15.3    15.4    15.4    15.6    15.8    15.9    15.9    16.2*   16.3*   90%
   top5 vs rest           15.3    15.6    15.5    15.5    15.9*   16.0*   16.1*   16.2*   16.3*   16.3*   50%
   NQC-like spread        15.3    15.4    15.3    15.5    15.6    15.7    16.0*   16.2*   16.2*   16.3*   70%
   WIG-like               15.6    15.7    15.7*   15.8*   16.0*   16.2*   16.4*   16.3*   16.3*   16.3*   30%
   term coverage top1     15.7    15.9*   15.8*   15.8    16.0*   16.1*   16.2*   16.4*   16.3*   16.3*   50%
   ORACLE                 17.6*   18.7*   18.9*   18.9*   18.9*   18.9*   18.9*   18.9*   18.3*   16.3*   10%
   random (expected)      15.4    15.5    15.6    15.7    15.8    15.9    16.0    16.1    16.2    16.3*   100%
   (BM25 only 15.3; rerank ALL 16.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.8[ -1.5]   -0.9[ -1.5]   -0.9[ -1.5]   -0.9[ -1.4]   -0.7[ -1.2]   -0.5[ -0.9]#  -0.4[ -0.7]#  -0.3[ -0.7]#  -0.2[ -0.5]#   60%   (point estimate: 10%)
   BM25 margin           -1.1[ -1.7]   -1.0[ -1.6]   -1.0[ -1.5]   -1.0[ -1.5]   -0.7[ -1.2]   -0.5[ -0.9]#  -0.5[ -0.8]#  -0.4[ -0.7]#  -0.2[ -0.4]#   60%   (point estimate: 20%)
   top5 vs rest          -1.0[ -1.6]   -0.7[ -1.3]   -0.8[ -1.4]   -0.8[ -1.3]   -0.4[ -0.9]#  -0.3[ -0.8]#  -0.2[ -0.5]#  -0.1[ -0.4]#  -0.1[ -0.3]#   50%   (point estimate: 10%)
   NQC-like spread       -1.0[ -1.6]   -0.9[ -1.5]   -1.0[ -1.6]   -0.8[ -1.4]   -0.7[ -1.2]   -0.6[ -1.0]   -0.4[ -0.7]#  -0.1[ -0.5]#  -0.1[ -0.3]#   70%   (point estimate: 10%)
   WIG-like              -0.7[ -1.4]   -0.7[ -1.3]   -0.6[ -1.2]   -0.5[ -1.0]   -0.3[ -0.8]#  -0.1[ -0.6]#  +0.1[ -0.3]#  -0.1[ -0.4]#  -0.0[ -0.3]#   50%   (point estimate: 10%)
   term coverage top1    -0.7[ -1.3]   -0.4[ -1.0]   -0.5[ -1.1]   -0.5[ -1.0]   -0.3[ -0.7]#  -0.2[ -0.6]#  -0.1[ -0.4]#  +0.0[ -0.2]#  +0.0[ -0.2]#   50%   (point estimate: 10%)
   ORACLE                +1.2[ +0.7]#  +2.4[ +1.9]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.0[ +1.6]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.8[ -1.5]   -0.9[ -1.5]   -0.9[ -1.5]   -0.9[ -1.4]   -0.7[ -1.2]   -0.5[ -0.9]   -0.4[ -0.7]   -0.3[ -0.7]   -0.2[ -0.5]#   90%   (point estimate: 60%)
   BM25 margin           -1.1[ -1.7]   -1.0[ -1.6]   -1.0[ -1.5]   -1.0[ -1.5]   -0.7[ -1.2]   -0.5[ -0.9]   -0.5[ -0.8]   -0.4[ -0.7]   -0.2[ -0.4]#   90%   (point estimate: 70%)
   top5 vs rest          -1.0[ -1.6]   -0.7[ -1.3]   -0.8[ -1.4]   -0.8[ -1.3]   -0.4[ -0.9]   -0.3[ -0.8]   -0.2[ -0.5]   -0.1[ -0.4]#  -0.1[ -0.3]#   80%   (point estimate: 50%)
   NQC-like spread       -1.0[ -1.6]   -0.9[ -1.5]   -1.0[ -1.6]   -0.8[ -1.4]   -0.7[ -1.2]   -0.6[ -1.0]   -0.4[ -0.7]   -0.1[ -0.5]#  -0.1[ -0.3]#   80%   (point estimate: 70%)
   WIG-like              -0.7[ -1.4]   -0.7[ -1.3]   -0.6[ -1.2]   -0.5[ -1.0]   -0.3[ -0.8]   -0.1[ -0.6]   +0.1[ -0.3]#  -0.1[ -0.4]#  -0.0[ -0.3]#   70%   (point estimate: 40%)
   term coverage top1    -0.7[ -1.3]   -0.4[ -1.0]   -0.5[ -1.1]   -0.5[ -1.0]   -0.3[ -0.7]   -0.2[ -0.6]   -0.1[ -0.4]#  +0.0[ -0.2]#  +0.0[ -0.2]#   70%   (point estimate: 50%)
   ORACLE                +1.2[ +0.7]#  +2.4[ +1.9]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.6[ +2.2]#  +2.0[ +1.6]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      51% (sd  34)   -0.58 MRR               2%     49%
   tag alarm               100      46% (sd  31)   -0.63 MRR              10%     54%
   tag alarm               200      36% (sd  27)   -0.73 MRR              20%     64%
   BM25 margin              50      48% (sd  32)   -0.69 MRR              35%     52%
   BM25 margin             100      40% (sd  28)   -0.81 MRR              42%     60%
   BM25 margin             200      38% (sd  24)   -0.84 MRR              41%     62%
   top5 vs rest             50      37% (sd  30)   -0.68 MRR              38%     63%
   top5 vs rest            100      37% (sd  27)   -0.64 MRR              30%     63%
   top5 vs rest            200      28% (sd  22)   -0.77 MRR              45%     72%
   NQC-like spread          50      47% (sd  32)   -0.63 MRR              29%     53%
   NQC-like spread         100      45% (sd  30)   -0.66 MRR              34%     55%
   NQC-like spread         200      39% (sd  26)   -0.76 MRR              37%     61%
   WIG-like                 50      35% (sd  30)   -0.50 MRR               0%     65%
   WIG-like                100      31% (sd  25)   -0.53 MRR               2%     69%
   WIG-like                200      24% (sd  20)   -0.60 MRR              10%     76%
   term coverage top1       50      35% (sd  27)   -0.44 MRR               0%     65%
   term coverage top1      100      25% (sd  20)   -0.55 MRR               0%     75%
   term coverage top1      200      19% (sd  16)   -0.61 MRR               5%     81%

## POOLED over 5 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  18.3  random  17.9  diff  +0.4  p=0.0175
   MRR  : tag  29.4  random  29.2  diff  +0.1  p=0.0762

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  -0.2 (p=0.397)   MRR  -0.3 (p=0.034)
   40%      Hit@1  +0.2 (p=0.414)   MRR  -0.0 (p=0.864)
   50%      Hit@1  +0.0 (p=1.000)   MRR  -0.0 (p=0.802)
   natural  Hit@1  -0.1 (p=0.769)   MRR  -0.0 (p=0.926)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -1.8  95% CI [-2.8, -0.9]  p=0.000
   MRR  :  -1.3  95% CI [-1.9, -0.6]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +0.1  p=0.756
   MRR  :  -0.0  p=0.938

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.0/+0.0 (p=0.946)  40%: +1.4/+0.3 (p=0.237)  50%: +1.4/+0.5 (p=0.124)  nat: +0.4/+0.1 (p=0.630)
   vs NQC-like spread      30%: +0.7/-0.0 (p=0.960)  40%: +1.0/+0.2 (p=0.345)  50%: +1.1/+0.3 (p=0.249)  nat: +0.1/-0.1 (p=0.485)
   vs WIG-like             30%: +0.8/-0.0 (p=0.944)  40%: +1.0/+0.2 (p=0.428)  50%: +0.8/+0.2 (p=0.459)  nat: +0.6/-0.0 (p=0.992)
   vs term coverage top1   30%: +0.8/-0.1 (p=0.597)  40%: +1.1/+0.1 (p=0.706)  50%: +0.5/-0.1 (p=0.791)  nat: +0.2/+0.0 (p=0.982)
