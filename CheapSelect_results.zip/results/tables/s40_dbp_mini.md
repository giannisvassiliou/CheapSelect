## dbpedia_test  (400 questions; tag alarm fires on 68 = 17%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  48.5  random  46.5  diff  +2.0  p=0.0180
   MRR  : tag  59.2  random  57.2  diff  +2.0  p=0.0025

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.0 (p=0.201)        +2.0 (p=0.062)
   40%            +0.5 (p=0.826)        +0.8 (p=0.355)
   50%            +0.0 (p=1.000)        +0.3 (p=0.715)
   17% nat        +1.2 (p=0.541)        +1.9 (p=0.148)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -16.0  95% CI [-20.2, -11.8]  p=0.000
   MRR  : -13.9  95% CI [-17.1, -10.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (55%)
   Hit@1:  +2.8  p=0.172
   MRR  :  +1.5  p=0.292

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.8/+2.4 (p=0.061)  40%: +3.8/+2.3 (p=0.102)  50%: +2.5/+1.0 (p=0.489)  nat: +3.2/+2.6 (p=0.041)
   vs NQC-like spread      30%: +4.5/+2.9 (p=0.025)  40%: +4.0/+2.2 (p=0.125)  50%: +2.2/+0.4 (p=0.779)  nat: +3.0/+2.3 (p=0.067)
   vs WIG-like             30%: +0.8/-0.3 (p=0.846)  40%: +1.0/+0.0 (p=0.989)  50%: +1.5/+0.0 (p=0.983)  nat: +1.2/+0.8 (p=0.515)
   vs term coverage top1   30%: +0.5/+0.2 (p=0.872)  40%: +0.5/-0.0 (p=0.981)  50%: -1.0/-1.4 (p=0.291)  nat: +0.8/+0.6 (p=0.558)

G. each selector reranking 68 questions (17%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -13.9  [-17.1, -10.8]  p=0.000
   BM25 margin          -15.9  [-19.2, -12.6]  p=0.000
   top5 vs rest         -16.5  [-19.8, -13.3]  p=0.000
   NQC-like spread      -16.2  [-19.5, -13.0]  p=0.000
   WIG-like             -14.7  [-17.9, -11.5]  p=0.000
   term coverage top1   -14.6  [-18.0, -11.4]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              57.4    60.2    62.1    64.0    65.5    67.5    69.6    71.2    72.9*   73.2*   90%
   BM25 margin            56.0    58.0    60.1    63.2    65.2    67.1    69.0    70.9    72.4*   73.2*   90%
   top5 vs rest           55.4    57.0    59.8    61.7    64.5    66.3    67.8    70.3    71.9    73.2*   100%
   NQC-like spread        55.5    57.1    59.2    61.7    65.1    67.3    68.5    70.6    72.0    73.2*   100%
   WIG-like               57.1    58.9    62.4    63.9    65.5    67.3    68.9    71.4    72.2    73.2*   100%
   term coverage top1     56.9    59.2    61.9    64.0    66.9    68.9    70.3    71.0    72.0    73.2*   100%
   ORACLE                 63.1    70.0    74.3*   75.8*   75.8*   75.8*   75.8*   75.8*   75.8*   73.2*   30%
   random (expected)      55.9    57.8    59.7    61.7    63.6    65.5    67.4    69.3    71.3    73.2*   100%
   (BM25 only 54.0; rerank ALL 73.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -15.8[-19.2]  -13.0[-16.0]  -11.1[-13.9]   -9.2[-11.8]   -7.6[-10.1]   -5.7[ -7.8]   -3.6[ -5.4]   -2.0[ -3.5]   -0.3[ -0.9]#   90%   (point estimate: 90%)
   BM25 margin          -17.2[-20.7]  -15.2[-18.4]  -13.1[-16.0]  -10.0[-12.7]   -7.9[-10.4]   -6.1[ -8.2]   -4.2[ -6.0]   -2.3[ -3.8]   -0.8[ -1.7]    100%   (point estimate: 90%)
   top5 vs rest         -17.8[-21.1]  -16.2[-19.4]  -13.4[-16.4]  -11.5[-14.1]   -8.7[-11.0]   -6.9[ -9.0]   -5.4[ -7.3]   -2.9[ -4.4]   -1.3[ -2.5]    100%   (point estimate: 100%)
   NQC-like spread      -17.7[-21.1]  -16.1[-19.3]  -14.0[-17.0]  -11.5[-14.2]   -8.1[-10.4]   -5.9[ -7.9]   -4.6[ -6.5]   -2.6[ -4.2]   -1.2[ -2.4]    100%   (point estimate: 100%)
   WIG-like             -16.1[-19.5]  -14.3[-17.5]  -10.8[-13.5]   -9.3[-11.8]   -7.7[ -9.9]   -5.9[ -8.0]   -4.3[ -6.0]   -1.8[ -3.0]   -1.0[ -1.9]    100%   (point estimate: 90%)
   term coverage top1   -16.3[-19.8]  -14.0[-17.3]  -11.3[-14.0]   -9.2[-11.8]   -6.2[ -8.5]   -4.3[ -6.2]   -2.8[ -4.4]   -2.2[ -3.5]   -1.2[ -2.3]    100%   (point estimate: 100%)
   ORACLE               -10.0[-12.7]   -3.2[ -5.1]   +1.1[ -0.1]#  +2.6[ +1.5]#  +2.6[ +1.5]#  +2.6[ +1.5]#  +2.6[ +1.5]#  +2.6[ +1.5]#  +2.6[ +1.5]#   30%   (point estimate: 30%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -15.8[-19.2]  -13.0[-16.0]  -11.1[-13.9]   -9.2[-11.8]   -7.6[-10.1]   -5.7[ -7.8]   -3.6[ -5.4]   -2.0[ -3.5]   -0.3[ -0.9]    100%   (point estimate: 90%)
   BM25 margin          -17.2[-20.7]  -15.2[-18.4]  -13.1[-16.0]  -10.0[-12.7]   -7.9[-10.4]   -6.1[ -8.2]   -4.2[ -6.0]   -2.3[ -3.8]   -0.8[ -1.7]    100%   (point estimate: 100%)
   top5 vs rest         -17.8[-21.1]  -16.2[-19.4]  -13.4[-16.4]  -11.5[-14.1]   -8.7[-11.0]   -6.9[ -9.0]   -5.4[ -7.3]   -2.9[ -4.4]   -1.3[ -2.5]    100%   (point estimate: 100%)
   NQC-like spread      -17.7[-21.1]  -16.1[-19.3]  -14.0[-17.0]  -11.5[-14.2]   -8.1[-10.4]   -5.9[ -7.9]   -4.6[ -6.5]   -2.6[ -4.2]   -1.2[ -2.4]    100%   (point estimate: 100%)
   WIG-like             -16.1[-19.5]  -14.3[-17.5]  -10.8[-13.5]   -9.3[-11.8]   -7.7[ -9.9]   -5.9[ -8.0]   -4.3[ -6.0]   -1.8[ -3.0]   -1.0[ -1.9]    100%   (point estimate: 100%)
   term coverage top1   -16.3[-19.8]  -14.0[-17.3]  -11.3[-14.0]   -9.2[-11.8]   -6.2[ -8.5]   -4.3[ -6.2]   -2.8[ -4.4]   -2.2[ -3.5]   -1.2[ -2.3]    100%   (point estimate: 100%)
   ORACLE               -10.0[-12.7]   -3.2[ -5.1]   +1.1[ -0.1]#  +2.6[ +1.5]#  +2.6[ +1.5]#  +2.6[ +1.5]#  +2.6[ +1.5]#  +2.6[ +1.5]#  +2.6[ +1.5]#   30%   (point estimate: 30%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      88% (sd  11)   -1.15 MRR              33%     12%
   tag alarm               100      90% (sd   7)   -0.82 MRR              24%     10%
   tag alarm               200      90% (sd   5)   -0.63 MRR              16%     10%
   BM25 margin              50      93% (sd   9)   -0.79 MRR              16%      7%
   BM25 margin             100      91% (sd   7)   -0.96 MRR              29%      9%
   BM25 margin             200      92% (sd   5)   -0.88 MRR              32%      8%
   top5 vs rest             50      94% (sd   9)   -0.99 MRR              43%      6%
   top5 vs rest            100      96% (sd   6)   -0.62 MRR              35%      4%
   top5 vs rest            200      96% (sd   5)   -0.66 MRR              34%      4%
   NQC-like spread          50      91% (sd  11)   -1.31 MRR              44%      9%
   NQC-like spread         100      93% (sd   7)   -0.94 MRR              48%      7%
   NQC-like spread         200      95% (sd   5)   -0.73 MRR              42%      5%
   WIG-like                 50      93% (sd   9)   -0.83 MRR              37%      7%
   WIG-like                100      92% (sd   7)   -0.86 MRR              48%      8%
   WIG-like                200      94% (sd   6)   -0.78 MRR              41%      6%
   term coverage top1       50      91% (sd  12)   -1.01 MRR              38%      9%
   term coverage top1      100      93% (sd   9)   -0.84 MRR              34%      7%
   term coverage top1      200      94% (sd   6)   -0.73 MRR              32%      6%

F. tag alarm vs other selectors WITHIN each query type (same total budget; MRR diff, p)
   keyword        n=  84  fires  15%  MRR  54.1 | vs BM25 margin: +3.1 (p=0.195)  vs top5 vs rest: -1.5 (p=0.589)  vs NQC-like spread: -0.4 (p=0.875)  vs WIG-like: -2.4 (p=0.365)  vs term coverage top1: -1.8 (p=0.511)
   list           n= 105  fires  16%  MRR  61.0 | vs BM25 margin: -3.0 (p=0.269)  vs top5 vs rest: +3.5 (p=0.205)  vs NQC-like spread: +2.7 (p=0.349)  vs WIG-like: +3.2 (p=0.222)  vs term coverage top1: +3.6 (p=0.118)
   question       n= 125  fires  22%  MRR  47.9 | vs BM25 margin: +5.4 (p=0.064)  vs top5 vs rest: +5.7 (p=0.023)  vs NQC-like spread: +4.6 (p=0.057)  vs WIG-like: +0.3 (p=0.909)  vs term coverage top1: -0.2 (p=0.921)
   named entity   n=  86  fires  12%  MRR  78.6 | vs BM25 margin: +1.7 (p=0.313)  vs top5 vs rest: +1.0 (p=0.540)  vs NQC-like spread: +1.0 (p=0.540)  vs WIG-like: +1.5 (p=0.188)  vs term coverage top1: +0.6 (p=0.493)
   PRIMARY (pre-registered): named entity + question, tag alarm vs WIG-like, MRR +0.8  [-2.0, +3.6]  p=0.586  (n=211)

