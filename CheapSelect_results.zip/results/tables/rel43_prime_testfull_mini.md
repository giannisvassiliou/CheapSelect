## prime_testfull  (2801 questions; tag alarm fires on 1563 = 56%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  22.7  random  20.4  diff  +2.3  p=0.0001
   MRR  : tag  31.1  random  29.3  diff  +1.8  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.9 (p=0.036)        +0.5 (p=0.139)
   40%            +1.0 (p=0.039)        +0.7 (p=0.053)
   50%            +0.9 (p=0.128)        +0.7 (p=0.089)
   56% nat        +0.3 (p=0.611)        +0.5 (p=0.300)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +2.8  95% CI [+1.7, +4.0]  p=0.000
   MRR  :  +1.6  95% CI [+0.8, +2.5]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (55%)
   Hit@1:  -0.4  p=0.506
   MRR  :  -0.5  p=0.226

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/-0.1 (p=0.846)  40%: +1.2/+0.6 (p=0.168)  50%: +1.7/+1.1 (p=0.007)  nat: +1.1/+0.8 (p=0.053)
   vs NQC-like spread      30%: +0.1/-0.1 (p=0.762)  40%: +0.6/+0.3 (p=0.494)  50%: +0.8/+0.6 (p=0.157)  nat: +0.4/+0.4 (p=0.359)
   vs WIG-like             30%: -0.5/-0.7 (p=0.083)  40%: +0.2/-0.1 (p=0.735)  50%: +0.6/+0.4 (p=0.395)  nat: +0.3/+0.2 (p=0.634)
   vs term coverage top1   30%: +0.2/+0.1 (p=0.890)  40%: +1.1/+0.7 (p=0.134)  50%: +1.2/+0.9 (p=0.050)  nat: +0.9/+0.7 (p=0.126)

G. each selector reranking 1563 questions (56%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +1.6  [+0.8, +2.5]  p=0.000
   BM25 margin           +1.2  [+0.3, +2.0]  p=0.009
   top5 vs rest          +0.8  [-0.1, +1.8]  p=0.074
   NQC-like spread       +1.3  [+0.3, +2.2]  p=0.007
   WIG-like              +1.4  [+0.5, +2.3]  p=0.003
   term coverage top1    +0.9  [+0.1, +1.8]  p=0.030

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              29.5*   29.8*   30.3*   31.0*   31.4*   31.0*   31.1*   30.7*   30.3*   29.5*   10%
   BM25 margin            29.4*   29.7*   29.8*   30.2*   30.6*   30.8*   30.7*   30.8*   30.3*   29.5*   10%
   top5 vs rest           29.4*   29.8*   30.4*   30.4*   30.2*   30.2*   30.3*   29.7*   29.5*   29.5*   10%
   NQC-like spread        29.3*   29.8*   30.5*   30.7*   30.8*   30.7*   30.4*   30.0*   29.7*   29.5*   10%
   WIG-like               30.0*   30.7*   31.0*   31.1*   31.0*   30.9*   31.2*   30.7*   30.4*   29.5*   10%
   term coverage top1     29.5*   30.1*   30.3*   30.3*   30.5*   30.1*   30.3*   30.0*   29.8*   29.5*   10%
   ORACLE                 36.4*   38.7*   38.9*   38.9*   38.9*   38.9*   38.9*   38.9*   36.7*   29.5*   10%
   random (expected)      29.2    29.2    29.2    29.3    29.3    29.4    29.4    29.4    29.5    29.5*   100%
   (BM25 only 29.1; rerank ALL 29.5)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.59 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.0[ -1.3]   +0.3[ -0.9]   +0.8[ -0.2]#  +1.5[ +0.5]#  +1.9[ +0.9]#  +1.5[ +0.7]#  +1.6[ +0.9]#  +1.2[ +0.6]#  +0.8[ +0.4]#   30%   (point estimate: 10%)
   BM25 margin           -0.1[ -1.4]   +0.2[ -1.0]   +0.3[ -0.8]   +0.8[ -0.3]#  +1.1[ +0.2]#  +1.3[ +0.5]#  +1.2[ +0.5]#  +1.3[ +0.8]#  +0.8[ +0.5]#   40%   (point estimate: 10%)
   top5 vs rest          -0.1[ -1.4]   +0.3[ -0.9]   +0.9[ -0.2]#  +0.9[ -0.1]#  +0.7[ -0.2]#  +0.7[ -0.1]#  +0.8[ -0.0]#  +0.2[ -0.5]#  -0.0[ -0.5]#   30%   (point estimate: 10%)
   NQC-like spread       -0.2[ -1.4]   +0.3[ -0.9]   +1.0[ -0.1]#  +1.2[ +0.2]#  +1.3[ +0.3]#  +1.2[ +0.3]#  +0.9[ +0.1]#  +0.5[ -0.0]#  +0.2[ -0.2]#   30%   (point estimate: 10%)
   WIG-like              +0.5[ -0.7]   +1.2[ +0.0]#  +1.5[ +0.3]#  +1.6[ +0.6]#  +1.5[ +0.5]#  +1.4[ +0.6]#  +1.7[ +0.9]#  +1.2[ +0.6]#  +0.9[ +0.5]#   20%   (point estimate: 10%)
   term coverage top1    +0.0[ -1.2]   +0.6[ -0.6]   +0.8[ -0.3]#  +0.8[ -0.2]#  +1.0[ +0.0]#  +0.6[ -0.1]#  +0.8[ +0.1]#  +0.5[ -0.0]#  +0.3[ -0.1]#   30%   (point estimate: 10%)
   ORACLE                +6.9[ +6.0]#  +9.2[ +8.4]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.5]#  +7.2[ +6.4]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.59): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      28% (sd  27)   +0.40 MRR               0%     72%
   BM25 margin             100      46% (sd  31)   +0.57 MRR               0%     54%
   top5 vs rest            100      56% (sd  36)   +0.26 MRR               0%     44%
   NQC-like spread         100      46% (sd  38)   +0.09 MRR               0%     54%
   WIG-like                100      47% (sd  36)   +0.81 MRR               0%     53%
   term coverage top1      100      66% (sd  37)   +0.25 MRR               0%     34%

