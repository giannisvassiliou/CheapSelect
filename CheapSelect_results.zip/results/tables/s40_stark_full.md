## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.4  random  55.3  diff  +2.2  p=0.0004
   MRR  : tag  67.2  random  65.3  diff  +1.9  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.2 (p=0.127)        +0.7 (p=0.225)
   40%            +0.1 (p=1.000)        +0.3 (p=0.641)
   50%            -0.8 (p=0.413)        -0.1 (p=0.856)
   47% nat        -0.2 (p=0.839)        +0.2 (p=0.726)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.7  95% CI [-6.4, -3.0]  p=0.000
   MRR  :  -4.4  95% CI [-5.7, -3.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +1.6  p=0.084
   MRR  :  +1.1  p=0.103

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.1/-1.1 (p=0.105)  40%: -0.7/-1.3 (p=0.069)  50%: -1.0/-1.4 (p=0.048)  nat: -0.8/-1.4 (p=0.056)
   vs NQC-like spread      30%: -0.4/-1.3 (p=0.051)  40%: -1.3/-1.6 (p=0.021)  50%: -1.4/-1.7 (p=0.014)  nat: -1.8/-2.0 (p=0.005)
   vs WIG-like             30%: +0.6/-0.4 (p=0.571)  40%: +0.2/-0.3 (p=0.664)  50%: -0.4/-0.7 (p=0.306)  nat: +0.1/-0.6 (p=0.385)
   vs term coverage top1   30%: +3.2/+2.3 (p=0.001)  40%: +3.5/+3.1 (p=0.000)  50%: +3.0/+2.9 (p=0.000)  nat: +2.9/+2.8 (p=0.000)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -4.4  [-5.7, -3.2]  p=0.000
   BM25 margin           -4.7  [-6.0, -3.4]  p=0.000
   top5 vs rest          -3.1  [-4.3, -1.8]  p=0.000
   NQC-like spread       -2.5  [-3.7, -1.2]  p=0.000
   WIG-like              -3.8  [-5.2, -2.5]  p=0.000
   term coverage top1    -7.2  [-8.8, -5.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              61.4    63.3    65.3    66.6    67.6    68.7    69.5    70.6    71.6*   71.6*   90%
   BM25 margin            61.5    63.3    64.6    66.3    67.7    69.1    70.0    71.1*   71.7*   71.6*   80%
   top5 vs rest           61.7    64.1    66.4    67.9    69.0    70.0    70.5    71.4*   71.6*   71.6*   80%
   NQC-like spread        61.7    64.2    66.7    68.2    69.3    70.4    70.5    71.3*   71.8*   71.6*   80%
   WIG-like               62.2    64.1    65.7    66.9    68.3    69.5    70.7*   71.0*   71.0*   71.6*   70%
   term coverage top1     60.7    62.0    63.0    63.5    64.7    66.3    67.4    68.4    69.8    71.6*   100%
   ORACLE                 68.9    74.6*   77.6*   77.8*   77.8*   77.8*   77.8*   77.8*   77.4*   71.6*   20%
   random (expected)      61.0    62.2    63.4    64.5    65.7    66.9    68.1    69.2    70.4    71.6*   100%
   (BM25 only 59.8; rerank ALL 71.6)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -10.2[-11.8]   -8.3[ -9.8]   -6.3[ -7.8]   -5.0[ -6.2]   -4.0[ -5.1]   -2.9[ -3.9]   -2.1[ -2.9]   -1.0[ -1.6]   +0.0[ -0.2]#   90%   (point estimate: 80%)
   BM25 margin          -10.1[-11.9]   -8.3[-10.0]   -7.0[ -8.5]   -5.3[ -6.7]   -3.9[ -5.1]   -2.5[ -3.7]   -1.6[ -2.5]   -0.5[ -1.1]   +0.1[ -0.1]#   90%   (point estimate: 80%)
   top5 vs rest          -9.9[-11.6]   -7.5[ -9.1]   -5.2[ -6.6]   -3.7[ -5.1]   -2.6[ -3.8]   -1.6[ -2.7]   -1.1[ -2.0]   -0.2[ -0.9]#  +0.0[ -0.5]#   80%   (point estimate: 80%)
   NQC-like spread       -9.9[-11.6]   -7.4[ -9.0]   -4.9[ -6.3]   -3.4[ -4.7]   -2.3[ -3.5]   -1.2[ -2.3]   -1.1[ -1.9]   -0.2[ -0.9]#  +0.2[ -0.3]#   80%   (point estimate: 80%)
   WIG-like              -9.4[-11.1]   -7.5[ -9.1]   -5.9[ -7.5]   -4.7[ -6.1]   -3.3[ -4.6]   -2.0[ -3.3]   -0.9[ -2.0]   -0.6[ -1.5]   -0.6[ -1.3]    100%   (point estimate: 70%)
   term coverage top1   -10.9[-12.7]   -9.6[-11.3]   -8.6[-10.2]   -8.1[ -9.6]   -6.9[ -8.3]   -5.3[ -6.5]   -4.2[ -5.3]   -3.2[ -4.1]   -1.8[ -2.5]    100%   (point estimate: 100%)
   ORACLE                -2.7[ -4.1]   +3.0[ +2.0]#  +6.0[ +5.2]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +5.8[ +4.9]#   20%   (point estimate: 20%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -10.2[-11.8]   -8.3[ -9.8]   -6.3[ -7.8]   -5.0[ -6.2]   -4.0[ -5.1]   -2.9[ -3.9]   -2.1[ -2.9]   -1.0[ -1.6]   +0.0[ -0.2]#   90%   (point estimate: 90%)
   BM25 margin          -10.1[-11.9]   -8.3[-10.0]   -7.0[ -8.5]   -5.3[ -6.7]   -3.9[ -5.1]   -2.5[ -3.7]   -1.6[ -2.5]   -0.5[ -1.1]   +0.1[ -0.1]#   90%   (point estimate: 90%)
   top5 vs rest          -9.9[-11.6]   -7.5[ -9.1]   -5.2[ -6.6]   -3.7[ -5.1]   -2.6[ -3.8]   -1.6[ -2.7]   -1.1[ -2.0]   -0.2[ -0.9]   +0.0[ -0.5]#   90%   (point estimate: 80%)
   NQC-like spread       -9.9[-11.6]   -7.4[ -9.0]   -4.9[ -6.3]   -3.4[ -4.7]   -2.3[ -3.5]   -1.2[ -2.3]   -1.1[ -1.9]   -0.2[ -0.9]   +0.2[ -0.3]#   90%   (point estimate: 80%)
   WIG-like              -9.4[-11.1]   -7.5[ -9.1]   -5.9[ -7.5]   -4.7[ -6.1]   -3.3[ -4.6]   -2.0[ -3.3]   -0.9[ -2.0]   -0.6[ -1.5]   -0.6[ -1.3]    100%   (point estimate: 100%)
   term coverage top1   -10.9[-12.7]   -9.6[-11.3]   -8.6[-10.2]   -8.1[ -9.6]   -6.9[ -8.3]   -5.3[ -6.5]   -4.2[ -5.3]   -3.2[ -4.1]   -1.8[ -2.5]    100%   (point estimate: 100%)
   ORACLE                -2.7[ -4.1]   +3.0[ +2.0]#  +6.0[ +5.2]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +5.8[ +4.9]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      80% (sd  18)   -1.21 MRR              41%     20%
   tag alarm               100      81% (sd  14)   -1.02 MRR              44%     19%
   tag alarm               200      83% (sd  11)   -0.72 MRR              36%     17%
   BM25 margin              50      75% (sd  19)   -1.48 MRR              44%     25%
   BM25 margin             100      78% (sd  14)   -1.00 MRR              31%     22%
   BM25 margin             200      79% (sd  10)   -0.84 MRR              28%     21%
   top5 vs rest             50      75% (sd  23)   -1.28 MRR              38%     25%
   top5 vs rest            100      74% (sd  19)   -1.11 MRR              46%     26%
   top5 vs rest            200      72% (sd  16)   -1.13 MRR              52%     28%
   NQC-like spread          50      72% (sd  27)   -1.61 MRR              40%     28%
   NQC-like spread         100      74% (sd  21)   -1.06 MRR              38%     26%
   NQC-like spread         200      71% (sd  17)   -1.06 MRR              48%     29%
   WIG-like                 50      79% (sd  24)   -1.34 MRR              25%     21%
   WIG-like                100      78% (sd  21)   -1.24 MRR              29%     22%
   WIG-like                200      80% (sd  19)   -1.12 MRR              24%     20%
   term coverage top1       50      94% (sd  14)   -0.95 MRR              29%      6%
   term coverage top1      100      96% (sd   9)   -0.60 MRR              24%      4%
   term coverage top1      200      98% (sd   5)   -0.38 MRR              18%      2%

## mag_testfull  (2665 questions; tag alarm fires on 710 = 27%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.2  random  51.9  diff  +4.4  p=0.0001
   MRR  : tag  65.3  random  62.0  diff  +3.3  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +3.5 (p=0.000)        +2.7 (p=0.000)
   40%            +2.5 (p=0.000)        +2.0 (p=0.000)
   50%            +2.0 (p=0.000)        +1.6 (p=0.000)
   27% nat        +3.5 (p=0.000)        +2.7 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +0.5  95% CI [-0.9, +1.8]  p=0.558
   MRR  :  +0.0  95% CI [-0.9, +1.0]  p=0.927

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (38%)
   Hit@1:  +1.9  p=0.002
   MRR  :  +1.1  p=0.009

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.5/+2.5 (p=0.000)  40%: +2.7/+1.8 (p=0.000)  50%: +2.4/+1.7 (p=0.000)  nat: +3.2/+2.4 (p=0.000)
   vs NQC-like spread      30%: +2.8/+1.9 (p=0.000)  40%: +2.0/+1.3 (p=0.002)  50%: +2.2/+1.5 (p=0.001)  nat: +3.0/+2.1 (p=0.000)
   vs WIG-like             30%: +1.0/+0.7 (p=0.095)  40%: +0.6/+0.5 (p=0.291)  50%: +0.6/+0.4 (p=0.416)  nat: +1.1/+0.7 (p=0.060)
   vs term coverage top1   30%: +2.0/+1.1 (p=0.006)  40%: +0.8/+0.2 (p=0.679)  50%: +0.5/-0.0 (p=0.917)  nat: +2.2/+1.3 (p=0.001)

G. each selector reranking 710 questions (27%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +0.0  [-0.9, +1.0]  p=0.927
   BM25 margin           -2.7  [-3.7, -1.7]  p=0.000
   top5 vs rest          -2.3  [-3.3, -1.3]  p=0.000
   NQC-like spread       -2.0  [-3.0, -1.1]  p=0.000
   WIG-like              -0.7  [-1.7, +0.3]  p=0.185
   term coverage top1    -1.2  [-2.3, -0.2]  p=0.023

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              62.7    64.5*   65.3*   65.3*   65.5*   65.6*   65.7*   65.6*   65.4*   65.2*   20%
   BM25 margin            61.6    62.0    62.6    63.4    64.0    64.7*   65.3*   65.4*   65.3*   65.2*   60%
   top5 vs rest           61.2    62.3    62.8    63.5    63.9    64.2    64.1    64.4    64.8    65.2*   100%
   NQC-like spread        61.4    62.7    63.4    64.0    64.0    64.2    64.2    64.6    64.9*   65.2*   90%
   WIG-like               63.1    64.2*   64.7*   64.9*   65.2*   65.4*   65.9*   65.8*   65.7*   65.2*   20%
   term coverage top1     62.4    63.3    64.2*   65.2*   65.6*   65.7*   65.8*   65.9*   65.9*   65.2*   30%
   ORACLE                 68.2*   71.7*   71.9*   71.9*   71.9*   71.9*   71.9*   71.9*   71.1*   65.2*   10%
   random (expected)      61.2    61.7    62.1    62.6    63.0    63.4    63.9    64.3    64.8    65.2*   100%
   (BM25 only 60.8; rerank ALL 65.2)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.5[ -3.6]   -0.7[ -1.7]   +0.1[ -0.8]#  +0.1[ -0.7]#  +0.3[ -0.4]#  +0.4[ -0.2]#  +0.5[ -0.0]#  +0.4[ +0.1]#  +0.2[ +0.0]#   30%   (point estimate: 20%)
   BM25 margin           -3.6[ -4.7]   -3.2[ -4.3]   -2.6[ -3.6]   -1.8[ -2.7]   -1.2[ -2.0]   -0.5[ -1.1]   +0.1[ -0.4]#  +0.2[ -0.2]#  +0.1[ -0.0]#   70%   (point estimate: 60%)
   top5 vs rest          -4.0[ -5.1]   -2.9[ -3.9]   -2.4[ -3.3]   -1.7[ -2.6]   -1.3[ -2.1]   -1.0[ -1.8]   -1.1[ -1.8]   -0.8[ -1.3]   -0.5[ -0.8]#   90%   (point estimate: 80%)
   NQC-like spread       -3.8[ -4.9]   -2.6[ -3.6]   -1.8[ -2.7]   -1.2[ -2.0]   -1.2[ -1.9]   -1.0[ -1.6]   -1.0[ -1.6]   -0.7[ -1.2]   -0.3[ -0.6]#   90%   (point estimate: 80%)
   WIG-like              -2.1[ -3.2]   -1.0[ -2.0]   -0.5[ -1.5]   -0.3[ -1.3]   -0.0[ -0.9]#  +0.2[ -0.6]#  +0.6[ -0.0]#  +0.5[ -0.0]#  +0.5[ +0.1]#   50%   (point estimate: 20%)
   term coverage top1    -2.8[ -4.0]   -1.9[ -3.0]   -1.0[ -2.0]   -0.1[ -0.9]#  +0.4[ -0.5]#  +0.5[ -0.3]#  +0.5[ -0.2]#  +0.7[ +0.2]#  +0.7[ +0.2]#   40%   (point estimate: 30%)
   ORACLE                +3.0[ +2.1]#  +6.5[ +5.8]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +5.9[ +5.2]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.5[ -3.6]   -0.7[ -1.7]   +0.1[ -0.8]   +0.1[ -0.7]   +0.3[ -0.4]#  +0.4[ -0.2]#  +0.5[ -0.0]#  +0.4[ +0.1]#  +0.2[ +0.0]#   50%   (point estimate: 30%)
   BM25 margin           -3.6[ -4.7]   -3.2[ -4.3]   -2.6[ -3.6]   -1.8[ -2.7]   -1.2[ -2.0]   -0.5[ -1.1]   +0.1[ -0.4]#  +0.2[ -0.2]#  +0.1[ -0.0]#   70%   (point estimate: 60%)
   top5 vs rest          -4.0[ -5.1]   -2.9[ -3.9]   -2.4[ -3.3]   -1.7[ -2.6]   -1.3[ -2.1]   -1.0[ -1.8]   -1.1[ -1.8]   -0.8[ -1.3]   -0.5[ -0.8]    100%   (point estimate: 90%)
   NQC-like spread       -3.8[ -4.9]   -2.6[ -3.6]   -1.8[ -2.7]   -1.2[ -2.0]   -1.2[ -1.9]   -1.0[ -1.6]   -1.0[ -1.6]   -0.7[ -1.2]   -0.3[ -0.6]    100%   (point estimate: 90%)
   WIG-like              -2.1[ -3.2]   -1.0[ -2.0]   -0.5[ -1.5]   -0.3[ -1.3]   -0.0[ -0.9]   +0.2[ -0.6]   +0.6[ -0.0]#  +0.5[ -0.0]#  +0.5[ +0.1]#   70%   (point estimate: 40%)
   term coverage top1    -2.8[ -4.0]   -1.9[ -3.0]   -1.0[ -2.0]   -0.1[ -0.9]   +0.4[ -0.5]#  +0.5[ -0.3]#  +0.5[ -0.2]#  +0.7[ +0.2]#  +0.7[ +0.2]#   50%   (point estimate: 40%)
   ORACLE                +3.0[ +2.1]#  +6.5[ +5.8]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +6.7[ +6.0]#  +5.9[ +5.2]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      46% (sd  30)   -0.55 MRR              26%     54%
   tag alarm               100      40% (sd  27)   -0.66 MRR              28%     60%
   tag alarm               200      32% (sd  22)   -0.75 MRR              26%     68%
   BM25 margin              50      59% (sd  28)   -0.99 MRR              36%     41%
   BM25 margin             100      54% (sd  24)   -1.09 MRR              42%     46%
   BM25 margin             200      52% (sd  19)   -1.16 MRR              50%     48%
   top5 vs rest             50      72% (sd  33)   -1.11 MRR              38%     28%
   top5 vs rest            100      73% (sd  29)   -1.01 MRR              39%     27%
   top5 vs rest            200      68% (sd  29)   -1.18 MRR              46%     32%
   NQC-like spread          50      72% (sd  31)   -0.92 MRR              34%     28%
   NQC-like spread         100      68% (sd  32)   -1.06 MRR              38%     32%
   NQC-like spread         200      69% (sd  28)   -0.95 MRR              38%     31%
   WIG-like                 50      54% (sd  35)   -0.50 MRR              28%     46%
   WIG-like                100      46% (sd  33)   -0.66 MRR              36%     54%
   WIG-like                200      38% (sd  28)   -0.80 MRR              44%     62%
   term coverage top1       50      50% (sd  34)   -0.75 MRR              37%     50%
   term coverage top1      100      43% (sd  29)   -0.83 MRR              44%     57%
   term coverage top1      200      41% (sd  25)   -0.76 MRR              44%     59%

## prime_testfull  (2801 questions; tag alarm fires on 1563 = 56%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  24.7  random  21.9  diff  +2.8  p=0.0001
   MRR  : tag  33.8  random  31.3  diff  +2.4  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.3 (p=0.000)        +2.0 (p=0.000)
   40%            +1.9 (p=0.000)        +1.8 (p=0.000)
   50%            +2.1 (p=0.000)        +2.1 (p=0.000)
   56% nat        +1.4 (p=0.013)        +1.6 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +2.1  95% CI [+1.0, +3.2]  p=0.000
   MRR  :  +0.7  95% CI [-0.1, +1.6]  p=0.086

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +0.4  p=0.494
   MRR  :  +0.2  p=0.662

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.8/+0.5 (p=0.194)  40%: +1.4/+0.9 (p=0.045)  50%: +1.6/+1.1 (p=0.009)  nat: +0.7/+0.6 (p=0.119)
   vs NQC-like spread      30%: +0.7/+0.5 (p=0.185)  40%: +0.6/+0.3 (p=0.401)  50%: +0.5/+0.3 (p=0.390)  nat: -0.3/-0.2 (p=0.610)
   vs WIG-like             30%: +0.6/+0.2 (p=0.542)  40%: +0.9/+0.4 (p=0.349)  50%: +1.1/+0.7 (p=0.085)  nat: +0.5/+0.3 (p=0.384)
   vs term coverage top1   30%: +1.5/+1.1 (p=0.010)  40%: +2.0/+1.5 (p=0.001)  50%: +2.5/+2.0 (p=0.000)  nat: +1.7/+1.4 (p=0.001)

G. each selector reranking 1563 questions (56%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +0.7  [-0.1, +1.6]  p=0.086
   BM25 margin           -0.9  [-1.8, -0.0]  p=0.041
   top5 vs rest          +0.1  [-0.8, +1.0]  p=0.828
   NQC-like spread       +0.9  [+0.0, +1.8]  p=0.045
   WIG-like              +0.4  [-0.5, +1.3]  p=0.431
   term coverage top1    -0.7  [-1.6, +0.2]  p=0.109

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              30.4    31.1    32.2*   32.9*   33.8*   33.6*   33.5*   33.6*   33.4*   33.1*   30%
   BM25 margin            29.5    29.8    30.2    31.1    31.7    32.6*   33.1*   33.5*   33.4*   33.1*   60%
   top5 vs rest           29.8    30.6    31.6    32.1*   32.8*   33.3*   33.7*   33.7*   33.2*   33.1*   40%
   NQC-like spread        29.7    30.7    31.6    32.6*   33.5*   33.9*   33.8*   33.6*   33.4*   33.1*   40%
   WIG-like               30.2    31.1    31.9*   32.5*   33.1*   33.6*   34.0*   33.8*   33.8*   33.1*   30%
   term coverage top1     29.5    30.6    31.1    31.5    31.9    32.4*   32.8*   32.9*   32.8*   33.1*   60%
   ORACLE                 37.0*   40.2*   40.9*   40.9*   40.9*   40.9*   40.9*   40.9*   39.6*   33.1*   10%
   random (expected)      29.5    29.9    30.3    30.7    31.1    31.5    31.9    32.3    32.7    33.1*   100%
   (BM25 only 29.1; rerank ALL 33.1)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.6[ -3.9]   -1.9[ -3.1]   -0.9[ -2.0]   -0.1[ -1.1]   +0.8[ -0.1]#  +0.5[ -0.2]#  +0.5[ -0.2]#  +0.5[ -0.0]#  +0.4[ -0.0]#   50%   (point estimate: 30%)
   BM25 margin           -3.6[ -4.8]   -3.2[ -4.4]   -2.8[ -4.0]   -1.9[ -2.9]   -1.4[ -2.3]   -0.5[ -1.3]   +0.0[ -0.7]#  +0.5[ -0.1]#  +0.3[ -0.0]#   70%   (point estimate: 60%)
   top5 vs rest          -3.3[ -4.6]   -2.4[ -3.6]   -1.4[ -2.6]   -1.0[ -2.1]   -0.3[ -1.2]   +0.3[ -0.6]#  +0.7[ -0.1]#  +0.7[ +0.0]#  +0.1[ -0.3]#   60%   (point estimate: 40%)
   NQC-like spread       -3.4[ -4.6]   -2.4[ -3.6]   -1.4[ -2.5]   -0.5[ -1.6]   +0.5[ -0.5]#  +0.8[ -0.0]#  +0.8[ +0.0]#  +0.6[ -0.0]#  +0.4[ -0.0]#   50%   (point estimate: 40%)
   WIG-like              -2.9[ -4.2]   -1.9[ -3.1]   -1.1[ -2.2]   -0.5[ -1.5]   +0.1[ -0.9]#  +0.5[ -0.4]#  +0.9[ +0.2]#  +0.7[ +0.1]#  +0.8[ +0.3]#   50%   (point estimate: 40%)
   term coverage top1    -3.5[ -4.8]   -2.5[ -3.7]   -2.0[ -3.1]   -1.6[ -2.6]   -1.2[ -2.1]   -0.7[ -1.5]   -0.3[ -1.0]#  -0.1[ -0.7]#  -0.3[ -0.7]#   70%   (point estimate: 60%)
   ORACLE                +3.9[ +3.0]#  +7.2[ +6.4]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +6.5[ +5.8]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -2.6[ -3.9]   -1.9[ -3.1]   -0.9[ -2.0]   -0.1[ -1.1]   +0.8[ -0.1]#  +0.5[ -0.2]#  +0.5[ -0.2]#  +0.5[ -0.0]#  +0.4[ -0.0]#   50%   (point estimate: 40%)
   BM25 margin           -3.6[ -4.8]   -3.2[ -4.4]   -2.8[ -4.0]   -1.9[ -2.9]   -1.4[ -2.3]   -0.5[ -1.3]   +0.0[ -0.7]   +0.5[ -0.1]#  +0.3[ -0.0]#   80%   (point estimate: 60%)
   top5 vs rest          -3.3[ -4.6]   -2.4[ -3.6]   -1.4[ -2.6]   -1.0[ -2.1]   -0.3[ -1.2]   +0.3[ -0.6]   +0.7[ -0.1]#  +0.7[ +0.0]#  +0.1[ -0.3]#   70%   (point estimate: 50%)
   NQC-like spread       -3.4[ -4.6]   -2.4[ -3.6]   -1.4[ -2.5]   -0.5[ -1.6]   +0.5[ -0.5]   +0.8[ -0.0]#  +0.8[ +0.0]#  +0.6[ -0.0]#  +0.4[ -0.0]#   60%   (point estimate: 40%)
   WIG-like              -2.9[ -4.2]   -1.9[ -3.1]   -1.1[ -2.2]   -0.5[ -1.5]   +0.1[ -0.9]   +0.5[ -0.4]#  +0.9[ +0.2]#  +0.7[ +0.1]#  +0.8[ +0.3]#   60%   (point estimate: 50%)
   term coverage top1    -3.5[ -4.8]   -2.5[ -3.7]   -2.0[ -3.1]   -1.6[ -2.6]   -1.2[ -2.1]   -0.7[ -1.5]   -0.3[ -1.0]   -0.1[ -0.7]   -0.3[ -0.7]    100%   (point estimate: 70%)
   ORACLE                +3.9[ +3.0]#  +7.2[ +6.4]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +7.8[ +7.0]#  +6.5[ +5.8]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      56% (sd  35)   -0.59 MRR              29%     44%
   tag alarm               100      50% (sd  32)   -0.64 MRR              30%     50%
   tag alarm               200      39% (sd  25)   -0.82 MRR              34%     61%
   BM25 margin              50      63% (sd  31)   -0.93 MRR              34%     37%
   BM25 margin             100      58% (sd  30)   -1.17 MRR              42%     42%
   BM25 margin             200      56% (sd  23)   -1.07 MRR              44%     44%
   top5 vs rest             50      61% (sd  34)   -0.77 MRR              30%     39%
   top5 vs rest            100      50% (sd  34)   -1.17 MRR              46%     50%
   top5 vs rest            200      44% (sd  25)   -1.07 MRR              47%     56%
   NQC-like spread          50      55% (sd  35)   -0.92 MRR              36%     45%
   NQC-like spread         100      48% (sd  32)   -1.03 MRR              41%     52%
   NQC-like spread         200      42% (sd  25)   -0.99 MRR              44%     58%
   WIG-like                 50      58% (sd  35)   -0.63 MRR              32%     42%
   WIG-like                100      47% (sd  31)   -0.81 MRR              43%     53%
   WIG-like                200      42% (sd  26)   -0.83 MRR              48%     58%
   term coverage top1       50      64% (sd  34)   -1.08 MRR              36%     36%
   term coverage top1      100      68% (sd  32)   -0.95 MRR              32%     32%
   term coverage top1      200      64% (sd  30)   -0.99 MRR              32%     36%

## POOLED over 3 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  44.1  random  40.8  diff  +3.2  p=0.0001
   MRR  : tag  53.3  random  50.7  diff  +2.6  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +2.5 (p=0.000)   MRR  +2.0 (p=0.000)
   40%      Hit@1  +1.7 (p=0.000)   MRR  +1.5 (p=0.000)
   50%      Hit@1  +1.4 (p=0.000)   MRR  +1.4 (p=0.000)
   natural  Hit@1  +1.8 (p=0.000)   MRR  +1.7 (p=0.000)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -0.1  95% CI [-0.9, +0.7]  p=0.858
   MRR  :  -0.7  95% CI [-1.3, -0.2]  p=0.011

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +1.3  p=0.001
   MRR  :  +0.8  p=0.008

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.6/+0.9 (p=0.002)  40%: +1.4/+0.7 (p=0.013)  50%: +1.3/+0.7 (p=0.009)  nat: +1.3/+0.8 (p=0.003)
   vs NQC-like spread      30%: +1.3/+0.6 (p=0.027)  40%: +0.7/+0.3 (p=0.346)  50%: +0.7/+0.3 (p=0.231)  nat: +0.6/+0.3 (p=0.348)
   vs WIG-like             30%: +0.8/+0.2 (p=0.363)  40%: +0.6/+0.3 (p=0.369)  50%: +0.5/+0.2 (p=0.377)  nat: +0.6/+0.3 (p=0.313)
   vs term coverage top1   30%: +2.1/+1.4 (p=0.000)  40%: +1.9/+1.4 (p=0.000)  50%: +1.9/+1.4 (p=0.000)  nat: +2.2/+1.7 (p=0.000)
