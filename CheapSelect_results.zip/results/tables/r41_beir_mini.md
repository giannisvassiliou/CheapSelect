# router41: label-free signals vs pre-retrieval vs trained routers  (deltas [1.0, 0.5] MRR points)

## beir_scifact (tag mini; n=300; mean gain +2.0 MRR; helped 23% hurt 17%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.00   rho(gain) -0.09
   avgIDF   rho(quality) +0.11   rho(gain) -0.09
   maxIDF   rho(quality) +0.10   rho(gain) -0.07
   avgICTF  rho(quality) +0.06   rho(gain) -0.07
   avgSCQ   rho(quality) +0.04   rho(gain) +0.13
   maxSCQ   rho(quality) +0.10   rho(gain) +0.02
   SCS      rho(quality) +0.03   rho(gain) -0.09

Budgets (share of questions reranked). random expected point budget: delta 1.0: 60%, delta 0.5: 80%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               40/20          50/30           +40             +2.5     +3.1 (0.009)
   tag alarm                                 50/10          50/10           +50             +1.9     +2.5 (0.045)
   top5 vs rest                             100/70         100/90           -10             -1.0     -0.3 (0.772)
   NQC-like spread                           90/20         100/20           +40             +0.9     +1.5 (0.045)
   WIG-like                                  90/90         100/90           -30             -0.6          -
   term coverage top1                       100/50         100/60           +10             -0.6     +0.1 (0.945)
   pre:qlen                                  80/30          90/30           +30             +0.5     +1.2 (0.399)
   pre:avgIDF                                90/30          90/40           +30             +0.1     +0.7 (0.630)
   pre:maxIDF                               100/10         100/20           +50             +0.7     +1.3 (0.390)
   pre:avgICTF                               90/50          90/50           +10             -0.4     +0.2 (0.876)
   pre:avgSCQ                               100/90         100/90           -30             -3.6     -3.0 (0.000)
   pre:maxSCQ                               100/90         100/90           -30             -1.6     -1.0 (0.315)
   pre:SCS                                   80/30          80/40           +30             +0.0     +0.7 (0.637)
   router ridge S (5-fold CV)                70/10          80/20           +50             +0.4     +1.0 (0.434)
   router gbm S (5-fold CV)                 100/80         100/100          -20             -1.8     -1.1 (0.280)
   router ridge S+P (5-fold CV)              30/10          50/20           +50             +2.0     +2.7 (0.037)
   router gbm S+P (5-fold CV)                90/30          90/50           +30             -0.2     +0.5 (0.687)
   router ridge S (other collections)        50/20          90/20           +40             +0.7     +1.3 (0.142)
   router gbm S (other collections)         100/40         100/40           +20             +0.1     +0.7 (0.519)
   router ridge S+P (other collections)      30/10          40/10           +50             +1.7     +2.4 (0.036)
   router gbm S+P (other collections)        80/60          90/70            +0             -2.5     -1.9 (0.112)
   ORACLE                                    10/10          10/10           +50             +7.0     +7.6 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.207, tag alarm +0.115, top5 vs rest -0.117, NQC-like spread -0.133, WIG-like +0.164, term coverage top1 -0.019
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.184, tag alarm +0.085, top5 vs rest -0.082, NQC-like spread -0.296, WIG-like +0.038, term coverage top1 +0.086, qlen +0.230, avgIDF -0.159, maxIDF -0.010, avgICTF +0.218, avgSCQ +0.259, maxSCQ +0.041, SCS +0.137

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -0.9   -0.7   -0.9
   n=  50  router ridge S+P        +0.1   +0.8   +1.1   P(router > WIG-like @50%) = 86%
   n=  50  router gbm   S+P        -0.1   +0.7   +0.9   P(router > WIG-like @50%) = 85%
   n= 100  WIG-like                 -0.9   -0.8   -0.9
   n= 100  router ridge S+P        +0.6   +1.6   +1.8   P(router > WIG-like @50%) = 98%
   n= 100  router gbm   S+P        -0.1   +0.5   +0.7   P(router > WIG-like @50%) = 88%
   n= 200  WIG-like                 -0.5   -0.5   -0.7
   n= 200  router ridge S+P        +1.3   +2.1   +2.5   P(router > WIG-like @50%) = 90%
   n= 200  router gbm   S+P        -0.1   +0.2   +0.6   P(router > WIG-like @50%) = 62%

## beir_nfcorpus (tag mini; n=323; mean gain +4.7 MRR; helped 23% hurt 13%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.02   rho(gain) -0.16
   avgIDF   rho(quality) -0.19   rho(gain) -0.14
   maxIDF   rho(quality) -0.33   rho(gain) -0.10
   avgICTF  rho(quality) -0.25   rho(gain) -0.12
   avgSCQ   rho(quality) +0.51   rho(gain) +0.05
   maxSCQ   rho(quality) +0.36   rho(gain) +0.11
   SCS      rho(quality) -0.21   rho(gain) -0.14

Budgets (share of questions reranked). random expected point budget: delta 1.0: 80%, delta 0.5: 90%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               90/70         100/90           +10             -1.2     +0.9 (0.426)
   tag alarm                                 90/70         100/90           +10             -0.9     +1.2 (0.291)
   top5 vs rest                              90/80          90/80            +0             -2.9     -0.8 (0.310)
   NQC-like spread                           80/60         100/70           +20             -2.5     -0.5 (0.580)
   WIG-like                                  90/60         100/90           +20             -2.1          -
   term coverage top1                       100/90         100/100          -10             -0.8     +1.3 (0.070)
   pre:qlen                                  80/50          90/70           +30             -0.4     +1.7 (0.048)
   pre:avgIDF                                80/50          90/70           +30             -1.0     +1.1 (0.323)
   pre:maxIDF                               100/80         100/100           +0             -1.3     +0.8 (0.532)
   pre:avgICTF                               80/60         100/80           +20             -1.0     +1.0 (0.364)
   pre:avgSCQ                                80/70          90/80           +10             -3.1     -1.0 (0.177)
   pre:maxSCQ                               100/100        100/100          -20             -3.7     -1.7 (0.043)
   pre:SCS                                   70/60         100/60           +20             -1.2     +0.9 (0.426)
   router ridge S (5-fold CV)                90/90         100/90           -10             -2.4     -0.3 (0.774)
   router gbm S (5-fold CV)                  90/30         100/90           +50             +0.2     +2.2 (0.036)
   router ridge S+P (5-fold CV)              70/60          80/70           +20             -1.4     +0.7 (0.481)
   router gbm S+P (5-fold CV)               100/50         100/50           +30             +0.2     +2.3 (0.044)
   router ridge S (other collections)       100/40         100/90           +40             -1.0     +1.1 (0.229)
   router gbm S (other collections)         100/60         100/70           +20             -1.2     +0.9 (0.448)
   router ridge S+P (other collections)      80/30          90/40           +50             -0.4     +1.6 (0.081)
   router gbm S+P (other collections)       100/60         100/90           +20             -1.7     +0.4 (0.743)
   ORACLE                                    10/10          10/10           +70             +4.3     +6.4 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.039, tag alarm -0.007, top5 vs rest +0.090, NQC-like spread -0.031, WIG-like -0.033, term coverage top1 -0.039
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.131, tag alarm -0.063, top5 vs rest +0.022, NQC-like spread +0.084, WIG-like -0.174, term coverage top1 +0.040, qlen +0.185, avgIDF -0.139, maxIDF -0.039, avgICTF +0.162, avgSCQ +0.075, maxSCQ +0.079, SCS +0.004

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -3.8   -2.1   -0.8
   n=  50  router ridge S+P        -2.7   -1.6   -0.8   P(router > WIG-like @50%) = 67%
   n=  50  router gbm   S+P        -2.4   -1.5   -0.8   P(router > WIG-like @50%) = 72%
   n= 100  WIG-like                 -3.8   -2.1   -0.8
   n= 100  router ridge S+P        -2.5   -1.6   -0.8   P(router > WIG-like @50%) = 62%
   n= 100  router gbm   S+P        -2.2   -1.4   -1.0   P(router > WIG-like @50%) = 71%
   n= 200  WIG-like                 -3.8   -2.1   -0.8
   n= 200  router ridge S+P        -2.1   -1.2   -0.6   P(router > WIG-like @50%) = 76%
   n= 200  router gbm   S+P        -1.7   -0.8   -0.4   P(router > WIG-like @50%) = 87%

## beir_fiqa (tag mini; n=648; mean gain +11.8 MRR; helped 39% hurt 12%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.09   rho(gain) +0.02
   avgIDF   rho(quality) +0.04   rho(gain) +0.02
   maxIDF   rho(quality) +0.03   rho(gain) -0.05
   avgICTF  rho(quality) +0.04   rho(gain) +0.02
   avgSCQ   rho(quality) +0.07   rho(gain) +0.04
   maxSCQ   rho(quality) +0.12   rho(gain) +0.02
   SCS      rho(quality) -0.00   rho(gain) +0.01

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/90         100/100          +10             -4.1     +1.5 (0.111)
   tag alarm                                 90/90         100/90           +10             -4.1     +1.5 (0.111)
   top5 vs rest                             100/100        100/100           +0             -5.9     -0.3 (0.678)
   NQC-like spread                          100/100        100/100           +0             -5.7     -0.2 (0.825)
   WIG-like                                 100/90         100/100          +10             -5.6          -
   term coverage top1                       100/90         100/90           +10             -5.1     +0.4 (0.641)
   pre:qlen                                 100/90         100/90           +10             -5.9     -0.4 (0.678)
   pre:avgIDF                               100/100        100/100           +0             -6.5     -0.9 (0.300)
   pre:maxIDF                               100/90         100/100          +10             -5.4     +0.2 (0.845)
   pre:avgICTF                              100/100        100/100           +0             -6.4     -0.8 (0.378)
   pre:avgSCQ                               100/100        100/100           +0             -6.6     -1.1 (0.207)
   pre:maxSCQ                               100/100        100/100           +0             -6.1     -0.6 (0.496)
   pre:SCS                                  100/100        100/100           +0             -6.4     -0.8 (0.358)
   router ridge S (5-fold CV)               100/90         100/100          +10             -5.5     +0.0 (0.976)
   router gbm S (5-fold CV)                 100/100        100/100           +0             -6.4     -0.8 (0.426)
   router ridge S+P (5-fold CV)             100/90         100/100          +10             -4.6     +1.0 (0.299)
   router gbm S+P (5-fold CV)               100/100        100/100           +0             -6.8     -1.3 (0.161)
   router ridge S (other collections)        90/80         100/90           +20             -5.6     -0.0 (0.968)
   router gbm S (other collections)         100/90         100/100          +10             -4.7     +0.9 (0.335)
   router ridge S+P (other collections)     100/90         100/90           +10             -4.5     +1.1 (0.198)
   router gbm S+P (other collections)       100/90         100/100          +10             -5.2     +0.4 (0.653)
   ORACLE                                    20/20          20/20           +80             +3.6     +9.2 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.151, tag alarm +0.005, top5 vs rest -0.093, NQC-like spread +0.059, WIG-like +0.017, term coverage top1 -0.052
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.147, tag alarm +0.013, top5 vs rest -0.098, NQC-like spread +0.050, WIG-like -0.042, term coverage top1 -0.035, qlen -0.063, avgIDF +0.111, maxIDF -0.144, avgICTF +0.144, avgSCQ +0.034, maxSCQ +0.050, SCS -0.164

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -7.8   -5.5   -3.4
   n=  50  router ridge S+P        -7.7   -5.2   -3.0   P(router > WIG-like @50%) = 62%
   n=  50  router gbm   S+P        -8.1   -5.6   -3.1   P(router > WIG-like @50%) = 46%
   n= 100  WIG-like                 -7.8   -5.6   -3.4
   n= 100  router ridge S+P        -7.6   -4.9   -2.8   P(router > WIG-like @50%) = 76%
   n= 100  router gbm   S+P        -7.7   -5.4   -3.2   P(router > WIG-like @50%) = 60%
   n= 200  WIG-like                 -7.8   -5.6   -3.4
   n= 200  router ridge S+P        -7.4   -4.9   -2.7   P(router > WIG-like @50%) = 80%
   n= 200  router gbm   S+P        -7.9   -5.6   -3.3   P(router > WIG-like @50%) = 57%

## beir_arguana (tag mini; n=1401; mean gain -0.8 MRR; helped 38% hurt 41%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.01   rho(gain) +0.01
   avgIDF   rho(quality) +0.08   rho(gain) +0.01
   maxIDF   rho(quality) -0.02   rho(gain) -0.01
   avgICTF  rho(quality) +0.07   rho(gain) +0.00
   avgSCQ   rho(quality) +0.05   rho(gain) +0.02
   maxSCQ   rho(quality) +0.06   rho(gain) +0.03
   SCS      rho(quality) +0.09   rho(gain) +0.02

Budgets (share of questions reranked). random expected point budget: delta 1.0: 10%, delta 0.5: 10%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               10/10          90/10            +0             +0.4     +0.1 (0.876)
   tag alarm                                 10/10          90/10            +0             +0.3     +0.0 (0.960)
   top5 vs rest                              10/10          80/10            +0             +0.3     +0.0 (0.942)
   NQC-like spread                           10/10          10/10            +0             +0.4     +0.0 (0.888)
   WIG-like                                  10/10          80/10            +0             +0.3          -
   term coverage top1                        10/10          10/10            +0             +0.7     +0.3 (0.307)
   pre:qlen                                  10/10          90/10            +0             +0.7     +0.3 (0.367)
   pre:avgIDF                                10/10          10/10            +0             +0.2     -0.1 (0.685)
   pre:maxIDF                                10/10          10/10            +0             +0.6     +0.3 (0.423)
   pre:avgICTF                               10/10          10/10            +0             +0.3     -0.1 (0.801)
   pre:avgSCQ                                10/10          10/10            +0             +0.3     -0.0 (0.989)
   pre:maxSCQ                                10/10          60/10            +0             +0.0     -0.3 (0.311)
   pre:SCS                                   10/10          90/10            +0             +0.3     -0.0 (0.883)
   router ridge S (5-fold CV)                10/10          90/10            +0             -0.1     -0.4 (0.226)
   router gbm S (5-fold CV)                  10/10          10/10            +0             +1.3     +0.9 (0.005)
   router ridge S+P (5-fold CV)              10/10          60/10            +0             +0.1     -0.3 (0.472)
   router gbm S+P (5-fold CV)                10/10          10/10            +0             +1.5     +1.2 (0.001)
   router ridge S (other collections)        10/10          90/10            +0             +0.4     +0.1 (0.872)
   router gbm S (other collections)          10/10          10/10            +0             +0.5     +0.2 (0.578)
   router ridge S+P (other collections)      10/10          10/10            +0             +0.4     +0.1 (0.809)
   router gbm S+P (other collections)        10/10          10/10            +0             +0.5     +0.2 (0.653)
   ORACLE                                    10/10          10/10            +0             +6.8     +6.5 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.010, tag alarm -0.076, top5 vs rest -0.001, NQC-like spread -0.008, WIG-like +0.012, term coverage top1 +0.063
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin +0.005, tag alarm -0.074, top5 vs rest -0.035, NQC-like spread -0.019, WIG-like +0.036, term coverage top1 +0.065, qlen +0.023, avgIDF +0.013, maxIDF -0.013, avgICTF -0.042, avgSCQ -0.012, maxSCQ +0.027, SCS +0.059

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 +0.7   +0.3   -0.2
   n=  50  router ridge S+P        +0.6   +0.4   +0.2   P(router > WIG-like @50%) = 55%
   n=  50  router gbm   S+P        +0.6   +0.4   +0.3   P(router > WIG-like @50%) = 64%
   n= 100  WIG-like                 +0.7   +0.3   -0.2
   n= 100  router ridge S+P        +0.5   +0.3   +0.1   P(router > WIG-like @50%) = 49%
   n= 100  router gbm   S+P        +0.7   +0.5   +0.4   P(router > WIG-like @50%) = 77%
   n= 200  WIG-like                 +0.7   +0.3   -0.2
   n= 200  router ridge S+P        +0.5   +0.3   +0.1   P(router > WIG-like @50%) = 46%
   n= 200  router gbm   S+P        +0.8   +0.7   +0.5   P(router > WIG-like @50%) = 91%

## beir_scidocs (tag mini; n=1000; mean gain +1.6 MRR; helped 32% hurt 26%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.15   rho(gain) -0.04
   avgIDF   rho(quality) +0.10   rho(gain) +0.04
   maxIDF   rho(quality) +0.05   rho(gain) +0.06
   avgICTF  rho(quality) +0.08   rho(gain) +0.05
   avgSCQ   rho(quality) +0.15   rho(gain) -0.03
   maxSCQ   rho(quality) +0.20   rho(gain) -0.04
   SCS      rho(quality) +0.02   rho(gain) +0.03

Budgets (share of questions reranked). random expected point budget: delta 1.0: 40%, delta 0.5: 70%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               80/50          90/70           -10             -0.7     -0.4 (0.476)
   tag alarm                                 80/30          90/60           +10             -0.8     -0.5 (0.386)
   top5 vs rest                              90/60         100/70           -20             -1.1     -0.9 (0.058)
   NQC-like spread                           80/60         100/70           -20             -1.3     -1.1 (0.014)
   WIG-like                                  90/40         100/50            +0             -0.3          -
   term coverage top1                        60/50          80/50           -10             -0.2     +0.0 (0.948)
   pre:qlen                                  70/40         100/60            +0             -0.6     -0.3 (0.602)
   pre:avgIDF                                90/80         100/90           -40             -1.6     -1.3 (0.017)
   pre:maxIDF                                90/70         100/100          -30             -1.4     -1.1 (0.053)
   pre:avgICTF                               90/80         100/90           -40             -1.7     -1.5 (0.008)
   pre:avgSCQ                               100/60         100/100          -20             -1.2     -1.0 (0.048)
   pre:maxSCQ                                90/60          90/80           -20             -1.4     -1.1 (0.040)
   pre:SCS                                   90/70         100/90           -30             -1.4     -1.1 (0.038)
   router ridge S (5-fold CV)                80/40          90/60            +0             -0.6     -0.3 (0.502)
   router gbm S (5-fold CV)                  80/10         100/80           +30             -0.8     -0.5 (0.391)
   router ridge S+P (5-fold CV)              80/50          90/60           -10             -0.9     -0.7 (0.180)
   router gbm S+P (5-fold CV)                90/20         100/80           +20             -0.6     -0.3 (0.555)
   router ridge S (other collections)        80/30          90/70           +10             -0.7     -0.4 (0.462)
   router gbm S (other collections)          70/10         100/50           +30             -0.4     -0.2 (0.750)
   router ridge S+P (other collections)      70/40         100/50            +0             -0.5     -0.2 (0.683)
   router gbm S+P (other collections)        70/30         100/60           +10             -0.5     -0.3 (0.607)
   ORACLE                                    10/10          10/10           +30             +5.6     +5.9 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.023, tag alarm +0.052, top5 vs rest -0.038, NQC-like spread +0.113, WIG-like -0.072, term coverage top1 -0.018
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.029, tag alarm +0.051, top5 vs rest -0.029, NQC-like spread +0.089, WIG-like -0.094, term coverage top1 +0.012, qlen -0.038, avgIDF +0.087, maxIDF -0.005, avgICTF +0.101, avgSCQ +0.016, maxSCQ +0.015, SCS -0.164

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -1.0   -0.2   +0.3
   n=  50  router ridge S+P        -1.0   -0.7   -0.4   P(router > WIG-like @50%) = 13%
   n=  50  router gbm   S+P        -1.1   -0.7   -0.4   P(router > WIG-like @50%) = 15%
   n= 100  WIG-like                 -1.1   -0.2   +0.2
   n= 100  router ridge S+P        -1.1   -0.7   -0.4   P(router > WIG-like @50%) = 15%
   n= 100  router gbm   S+P        -1.1   -0.8   -0.5   P(router > WIG-like @50%) = 12%
   n= 200  WIG-like                 -1.1   -0.3   +0.3
   n= 200  router ridge S+P        -1.1   -0.8   -0.4   P(router > WIG-like @50%) = 12%
   n= 200  router gbm   S+P        -1.1   -0.8   -0.5   P(router > WIG-like @50%) = 14%

