## mag_testfull  (2665 questions; tag alarm fires on 710 = 27%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.2  random  53.0  diff  +4.2  p=0.0001
   MRR  : tag  66.0  random  62.8  diff  +3.2  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.7 (p=0.000)        +2.3 (p=0.000)
   40%            +2.1 (p=0.000)        +1.7 (p=0.000)
   50%            +1.7 (p=0.000)        +1.4 (p=0.000)
   27% nat        +2.9 (p=0.000)        +2.4 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -3.0  95% CI [-4.5, -1.6]  p=0.000
   MRR  :  -2.3  95% CI [-3.3, -1.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (38%)
   Hit@1:  +3.8  p=0.000
   MRR  :  +2.4  p=0.000

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.2/+2.2 (p=0.000)  40%: +3.2/+2.0 (p=0.000)  50%: +3.2/+2.2 (p=0.000)  nat: +3.1/+2.3 (p=0.000)
   vs NQC-like spread      30%: +2.1/+1.5 (p=0.002)  40%: +2.1/+1.4 (p=0.002)  50%: +2.7/+1.9 (p=0.000)  nat: +2.7/+1.8 (p=0.000)
   vs WIG-like             30%: +1.1/+0.8 (p=0.063)  40%: +1.4/+1.0 (p=0.029)  50%: +1.7/+1.2 (p=0.010)  nat: +1.1/+0.8 (p=0.048)
   vs term coverage top1   30%: +1.5/+0.8 (p=0.072)  40%: +1.0/+0.4 (p=0.434)  50%: +0.5/+0.0 (p=0.940)  nat: +1.8/+1.1 (p=0.012)

G. each selector reranking 710 questions (27%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.3  [-3.3, -1.3]  p=0.000
   BM25 margin           -4.7  [-5.9, -3.7]  p=0.000
   top5 vs rest          -4.6  [-5.7, -3.5]  p=0.000
   NQC-like spread       -4.1  [-5.2, -3.0]  p=0.000
   WIG-like              -3.1  [-4.2, -2.0]  p=0.000
   term coverage top1    -3.4  [-4.5, -2.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              62.9    65.1    66.1    66.7    67.3    67.8*   68.3*   68.5*   68.4*   68.3*   60%
   BM25 margin            61.9    62.7    63.8    64.9    65.9    67.0    67.8*   68.3*   68.4*   68.3*   70%
   top5 vs rest           61.9    63.0    63.9    64.6    65.1    65.4    65.8    66.5    67.5    68.3*   100%
   NQC-like spread        62.0    63.3    64.7    65.2    65.4    65.8    66.2    66.9    67.8    68.3*   100%
   WIG-like               63.1    64.7    65.3    65.6    66.1    66.8    67.2    67.9*   68.2*   68.3*   80%
   term coverage top1     62.7    64.0    65.3    66.3    67.3    67.5*   67.8*   68.3*   68.5*   68.3*   60%
   ORACLE                 69.1*   73.7*   74.4*   74.4*   74.4*   74.4*   74.4*   74.4*   73.9*   68.3*   10%
   random (expected)      61.5    62.3    63.0    63.8    64.5    65.3    66.0    66.8    67.5    68.3*   100%
   (BM25 only 60.8; rerank ALL 68.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.37 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -5.4[ -6.6]   -3.2[ -4.3]   -2.2[ -3.2]   -1.6[ -2.6]   -1.0[ -1.8]   -0.5[ -1.2]#  +0.0[ -0.5]#  +0.2[ -0.0]#  +0.1[ +0.0]#   60%   (point estimate: 50%)
   BM25 margin           -6.4[ -7.7]   -5.6[ -6.8]   -4.5[ -5.6]   -3.4[ -4.4]   -2.4[ -3.2]   -1.3[ -2.0]   -0.5[ -1.0]#  +0.1[ -0.3]#  +0.1[ -0.1]#   70%   (point estimate: 60%)
   top5 vs rest          -6.4[ -7.7]   -5.3[ -6.5]   -4.4[ -5.5]   -3.7[ -4.6]   -3.2[ -4.1]   -2.9[ -3.7]   -2.5[ -3.3]   -1.8[ -2.4]   -0.8[ -1.1]#   90%   (point estimate: 90%)
   NQC-like spread       -6.3[ -7.6]   -5.0[ -6.2]   -3.6[ -4.7]   -3.1[ -4.0]   -2.9[ -3.7]   -2.5[ -3.3]   -2.1[ -2.8]   -1.4[ -2.0]   -0.5[ -0.9]#   90%   (point estimate: 90%)
   WIG-like              -5.1[ -6.4]   -3.6[ -4.7]   -3.0[ -4.1]   -2.6[ -3.6]   -2.2[ -3.1]   -1.5[ -2.4]   -1.1[ -1.8]   -0.4[ -1.0]#  -0.1[ -0.6]#   80%   (point estimate: 70%)
   term coverage top1    -5.6[ -6.8]   -4.3[ -5.4]   -3.0[ -4.0]   -2.0[ -3.0]   -1.0[ -1.9]   -0.8[ -1.6]   -0.5[ -1.3]#  -0.0[ -0.6]#  +0.2[ -0.2]#   70%   (point estimate: 50%)
   ORACLE                +0.8[ -0.1]#  +5.4[ +4.8]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +6.1[ +5.4]#  +5.6[ +5.0]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.37): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      51% (sd  22)   -1.28 MRR              45%     49%
   BM25 margin             100      64% (sd  17)   -1.23 MRR              25%     36%
   top5 vs rest            100      84% (sd  21)   -1.07 MRR              20%     16%
   NQC-like spread         100      78% (sd  22)   -1.34 MRR              40%     22%
   WIG-like                100      62% (sd  34)   -1.77 MRR              50%     38%
   term coverage top1      100      54% (sd  28)   -1.72 MRR              40%     46%

