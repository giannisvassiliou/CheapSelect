## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  43.3  random  44.2  diff  -0.8  p=0.9986
   MRR  : tag  51.8  random  52.3  diff  -0.6  p=0.9898

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.6 (p=0.498)        -0.4 (p=0.249)
   40%            -0.9 (p=0.253)        -0.7 (p=0.253)
   50%            +0.0 (p=1.000)        -0.0 (p=1.000)
   2% nat         -0.6 (p=0.498)        -0.4 (p=0.498)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -9.0  95% CI [-13.3, -4.6]  p=0.000
   MRR  :  -7.5  95% CI [-10.7, -4.4]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +0.9  p=0.713
   MRR  :  -0.0  p=0.997

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/-0.0 (p=0.995)  40%: +0.3/+0.8 (p=0.548)  50%: +1.2/+1.2 (p=0.331)  nat: -0.6/-0.4 (p=0.498)
   vs NQC-like spread      30%: -0.3/-0.7 (p=0.495)  40%: -1.5/-0.7 (p=0.545)  50%: +1.2/+0.6 (p=0.588)  nat: -0.6/-0.4 (p=0.498)
   vs WIG-like             30%: -1.2/-0.9 (p=0.419)  40%: -2.2/-0.8 (p=0.516)  50%: -0.9/-0.3 (p=0.791)  nat: -0.6/-0.4 (p=0.498)
   vs term coverage top1   30%: -0.3/-0.9 (p=0.441)  40%: -1.5/-1.2 (p=0.312)  50%: -1.2/-1.2 (p=0.242)  nat: -0.6/-0.4 (p=0.498)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -7.5  [-10.7, -4.4]  p=0.000
   BM25 margin           -7.2  [-10.4, -3.9]  p=0.000
   top5 vs rest          -7.2  [-10.4, -3.9]  p=0.000
   NQC-like spread       -7.2  [-10.4, -3.9]  p=0.000
   WIG-like              -7.2  [-10.4, -3.9]  p=0.000
   term coverage top1    -7.2  [-10.4, -3.9]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              51.7    53.2    54.6    55.8    57.4    57.7*   57.9*   58.0*   58.7*   59.3*   60%
   BM25 margin            51.9    53.5    55.0    56.5    57.4    58.0*   57.8*   58.0*   58.7*   59.3*   60%
   top5 vs rest           52.0    53.2    54.6    55.1    56.2    57.1    57.6*   58.5*   59.4*   59.3*   70%
   NQC-like spread        51.6    54.6    55.3    56.6    56.8    57.7    58.4*   58.7*   58.9*   59.3*   70%
   WIG-like               52.1    53.0    55.5    56.6    57.7*   58.8*   58.9*   59.0*   59.1*   59.3*   50%
   term coverage top1     52.7    54.2    55.5    57.0*   58.5*   58.1*   58.5*   58.8*   58.8*   59.3*   40%
   ORACLE                 59.7*   62.8*   62.8*   62.8*   62.8*   62.8*   62.8*   62.8*   62.8*   59.3*   10%
   random (expected)      52.9    53.6    54.3    55.0    55.7    56.4    57.2    57.9    58.6    59.3*   100%
   (BM25 only 52.1; rerank ALL 59.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.19 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.6[-10.8]   -6.1[ -9.0]   -4.7[ -7.2]   -3.5[ -5.8]   -1.9[ -3.9]   -1.6[ -3.4]   -1.4[ -3.1]   -1.3[ -2.7]   -0.6[ -1.3]    100%   (point estimate: 90%)
   BM25 margin           -7.4[-10.7]   -5.8[ -8.6]   -4.3[ -6.9]   -2.8[ -5.1]   -1.9[ -3.9]   -1.3[ -3.2]   -1.5[ -3.1]   -1.3[ -2.7]   -0.6[ -1.3]    100%   (point estimate: 90%)
   top5 vs rest          -7.3[-10.5]   -6.1[ -9.1]   -4.7[ -7.5]   -4.3[ -6.7]   -3.1[ -5.3]   -2.2[ -4.2]   -1.7[ -3.3]   -0.8[ -1.9]   +0.1[ -0.7]#   90%   (point estimate: 80%)
   NQC-like spread       -7.7[-10.8]   -4.7[ -7.6]   -4.0[ -6.6]   -2.7[ -5.2]   -2.5[ -4.4]   -1.6[ -3.0]   -0.9[ -2.1]   -0.6[ -1.5]   -0.4[ -0.9]#   90%   (point estimate: 70%)
   WIG-like              -7.2[-10.4]   -6.3[ -9.4]   -3.8[ -6.5]   -2.7[ -5.3]   -1.6[ -3.9]   -0.5[ -2.6]   -0.4[ -2.0]   -0.3[ -1.6]   -0.2[ -0.8]#   90%   (point estimate: 60%)
   term coverage top1    -6.6[ -9.7]   -5.1[ -8.0]   -3.8[ -6.6]   -2.3[ -4.7]   -0.8[ -2.9]   -1.2[ -3.2]   -0.8[ -2.3]   -0.5[ -1.8]   -0.5[ -1.6]    100%   (point estimate: 70%)
   ORACLE                +0.4[ -1.6]   +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.19): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      82% (sd  15)   -1.10 MRR              45%     18%
   BM25 margin             100      72% (sd  26)   -1.77 MRR              55%     28%
   top5 vs rest            100      76% (sd  16)   -1.27 MRR              35%     24%
   NQC-like spread         100      67% (sd  17)   -1.53 MRR              35%     33%
   WIG-like                100      55% (sd  21)   -2.14 MRR              50%     45%
   term coverage top1      100      60% (sd  24)   -1.87 MRR              45%     40%

