## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  53.4  random  52.4  diff  +1.0  p=0.0608
   MRR  : tag  63.5  random  62.5  diff  +1.0  p=0.0198

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=0.743)        -0.3 (p=0.554)
   40%            -1.6 (p=0.065)        -1.1 (p=0.095)
   50%            -2.3 (p=0.012)        -1.3 (p=0.062)
   47% nat        -2.1 (p=0.026)        -1.2 (p=0.078)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -2.5  95% CI [-4.2, -0.9]  p=0.005
   MRR  :  -2.1  95% CI [-3.3, -0.8]  p=0.002

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +0.3  p=0.771
   MRR  :  -0.4  p=0.504

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.5/-1.0 (p=0.140)  40%: -1.2/-1.3 (p=0.050)  50%: -1.4/-1.5 (p=0.038)  nat: -1.9/-1.9 (p=0.008)
   vs NQC-like spread      30%: -0.7/-1.2 (p=0.062)  40%: -1.5/-1.6 (p=0.016)  50%: -1.6/-1.7 (p=0.015)  nat: -2.1/-2.0 (p=0.003)
   vs WIG-like             30%: -0.9/-1.4 (p=0.045)  40%: -1.5/-1.8 (p=0.013)  50%: -2.0/-2.0 (p=0.007)  nat: -2.2/-2.2 (p=0.002)
   vs term coverage top1   30%: +1.9/+1.6 (p=0.023)  40%: +2.5/+2.2 (p=0.002)  50%: +1.8/+2.0 (p=0.007)  nat: +1.5/+1.7 (p=0.017)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -2.1  [-3.3, -0.8]  p=0.002
   BM25 margin           -0.9  [-2.2, +0.5]  p=0.201
   top5 vs rest          -0.2  [-1.5, +1.1]  p=0.745
   NQC-like spread       -0.0  [-1.3, +1.2]  p=0.939
   WIG-like              +0.2  [-1.2, +1.5]  p=0.828
   term coverage top1    -3.8  [-5.3, -2.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              60.7    61.5    62.8    63.4    64.0    65.0*   65.4*   65.9*   66.2*   65.6*   60%
   BM25 margin            60.9    62.2    63.2    64.5*   65.3*   65.7*   66.1*   66.5*   66.3*   65.6*   40%
   top5 vs rest           61.2    62.8    63.8    64.8*   65.5*   65.6*   65.7*   65.9*   66.0*   65.6*   40%
   NQC-like spread        61.1    62.8    64.1*   65.1*   65.7*   66.2*   65.8*   65.9*   66.0*   65.6*   30%
   WIG-like               61.6    62.9    64.3*   65.2*   66.0*   66.0*   66.5*   66.2*   65.8*   65.6*   30%
   term coverage top1     60.2    60.9    61.3    61.3    62.0    62.8    63.5    63.8    64.5    65.6*   100%
   ORACLE                 68.4*   73.3*   74.7*   74.7*   74.7*   74.7*   74.7*   74.7*   72.7*   65.6*   10%
   random (expected)      60.4    61.0    61.6    62.2    62.7    63.3    63.9    64.5    65.0    65.6*   100%
   (BM25 only 59.8; rerank ALL 65.6)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.9[ -6.7]   -4.1[ -5.8]   -2.8[ -4.3]   -2.2[ -3.5]   -1.6[ -2.8]   -0.6[ -1.6]   -0.2[ -1.1]   +0.3[ -0.3]#  +0.6[ +0.3]#   80%   (point estimate: 60%)
   BM25 margin           -4.7[ -6.6]   -3.4[ -5.2]   -2.5[ -4.0]   -1.1[ -2.5]   -0.4[ -1.7]   +0.0[ -1.1]   +0.5[ -0.4]#  +0.9[ +0.2]#  +0.6[ +0.3]#   70%   (point estimate: 50%)
   top5 vs rest          -4.4[ -6.3]   -2.8[ -4.5]   -1.8[ -3.3]   -0.8[ -2.3]   -0.2[ -1.4]   -0.1[ -1.3]   +0.1[ -0.8]#  +0.3[ -0.5]#  +0.4[ -0.2]#   70%   (point estimate: 40%)
   NQC-like spread       -4.5[ -6.4]   -2.9[ -4.5]   -1.6[ -3.1]   -0.5[ -2.0]   +0.0[ -1.2]   +0.6[ -0.5]#  +0.2[ -0.8]#  +0.3[ -0.5]#  +0.4[ -0.1]#   60%   (point estimate: 40%)
   WIG-like              -4.0[ -5.9]   -2.7[ -4.4]   -1.3[ -2.9]   -0.4[ -1.8]   +0.4[ -1.0]#  +0.4[ -0.8]#  +0.9[ -0.2]#  +0.6[ -0.4]#  +0.2[ -0.5]#   50%   (point estimate: 40%)
   term coverage top1    -5.4[ -7.3]   -4.8[ -6.5]   -4.3[ -6.0]   -4.4[ -5.9]   -3.6[ -5.0]   -2.8[ -4.1]   -2.1[ -3.3]   -1.8[ -2.8]   -1.1[ -1.9]    100%   (point estimate: 100%)
   ORACLE                +2.8[ +1.3]#  +7.7[ +6.5]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +7.1[ +6.1]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.9[ -6.7]   -4.1[ -5.8]   -2.8[ -4.3]   -2.2[ -3.5]   -1.6[ -2.8]   -0.6[ -1.6]   -0.2[ -1.1]   +0.3[ -0.3]#  +0.6[ +0.3]#   80%   (point estimate: 70%)
   BM25 margin           -4.7[ -6.6]   -3.4[ -5.2]   -2.5[ -4.0]   -1.1[ -2.5]   -0.4[ -1.7]   +0.0[ -1.1]   +0.5[ -0.4]#  +0.9[ +0.2]#  +0.6[ +0.3]#   70%   (point estimate: 50%)
   top5 vs rest          -4.4[ -6.3]   -2.8[ -4.5]   -1.8[ -3.3]   -0.8[ -2.3]   -0.2[ -1.4]   -0.1[ -1.3]   +0.1[ -0.8]   +0.3[ -0.5]#  +0.4[ -0.2]#   80%   (point estimate: 50%)
   NQC-like spread       -4.5[ -6.4]   -2.9[ -4.5]   -1.6[ -3.1]   -0.5[ -2.0]   +0.0[ -1.2]   +0.6[ -0.5]   +0.2[ -0.8]   +0.3[ -0.5]#  +0.4[ -0.1]#   80%   (point estimate: 50%)
   WIG-like              -4.0[ -5.9]   -2.7[ -4.4]   -1.3[ -2.9]   -0.4[ -1.8]   +0.4[ -1.0]   +0.4[ -0.8]   +0.9[ -0.2]#  +0.6[ -0.4]#  +0.2[ -0.5]#   70%   (point estimate: 40%)
   term coverage top1    -5.4[ -7.3]   -4.8[ -6.5]   -4.3[ -6.0]   -4.4[ -5.9]   -3.6[ -5.0]   -2.8[ -4.1]   -2.1[ -3.3]   -1.8[ -2.8]   -1.1[ -1.9]    100%   (point estimate: 100%)
   ORACLE                +2.8[ +1.3]#  +7.7[ +6.5]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +9.1[ +8.0]#  +7.1[ +6.1]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      61% (sd  28)   -1.08 MRR              35%     39%
   tag alarm               100      59% (sd  25)   -1.13 MRR              37%     41%
   tag alarm               200      59% (sd  19)   -1.05 MRR              35%     41%
   BM25 margin              50      57% (sd  27)   -0.81 MRR              34%     43%
   BM25 margin             100      56% (sd  25)   -0.78 MRR              35%     44%
   BM25 margin             200      51% (sd  20)   -0.86 MRR              44%     49%
   top5 vs rest             50      62% (sd  33)   -0.96 MRR              26%     38%
   top5 vs rest            100      55% (sd  30)   -1.05 MRR              32%     45%
   top5 vs rest            200      47% (sd  25)   -1.20 MRR              38%     53%
   NQC-like spread          50      57% (sd  33)   -1.11 MRR              34%     43%
   NQC-like spread         100      53% (sd  30)   -1.05 MRR              34%     47%
   NQC-like spread         200      45% (sd  25)   -1.13 MRR              39%     55%
   WIG-like                 50      61% (sd  35)   -0.86 MRR              31%     39%
   WIG-like                100      49% (sd  32)   -1.19 MRR              40%     51%
   WIG-like                200      48% (sd  27)   -0.87 MRR              38%     52%
   term coverage top1       50      84% (sd  27)   -1.22 MRR              46%     16%
   term coverage top1      100      89% (sd  21)   -0.93 MRR              40%     11%
   term coverage top1      200      89% (sd  18)   -0.96 MRR              45%     11%

## mag_testfull  (2665 questions; tag alarm fires on 710 = 27%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  54.3  random  51.0  diff  +3.3  p=0.0001
   MRR  : tag  63.1  random  60.8  diff  +2.3  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +2.3 (p=0.000)        +1.7 (p=0.000)
   40%            +2.0 (p=0.000)        +1.4 (p=0.000)
   50%            +1.5 (p=0.000)        +1.1 (p=0.001)
   27% nat        +2.1 (p=0.000)        +1.6 (p=0.000)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +1.8  95% CI [+0.5, +3.1]  p=0.010
   MRR  :  +2.2  95% CI [+1.3, +3.1]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (37%)
   Hit@1:  +1.3  p=0.034
   MRR  :  +0.8  p=0.055

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.4/+2.1 (p=0.000)  40%: +2.9/+1.5 (p=0.000)  50%: +2.8/+1.5 (p=0.000)  nat: +3.1/+2.0 (p=0.000)
   vs NQC-like spread      30%: +2.6/+1.8 (p=0.000)  40%: +2.5/+1.4 (p=0.000)  50%: +2.6/+1.5 (p=0.000)  nat: +2.8/+1.8 (p=0.000)
   vs WIG-like             30%: +1.4/+0.6 (p=0.113)  40%: +1.4/+0.5 (p=0.275)  50%: +1.7/+0.6 (p=0.161)  nat: +1.3/+0.5 (p=0.160)
   vs term coverage top1   30%: +1.5/+0.8 (p=0.031)  40%: +0.7/+0.2 (p=0.535)  50%: +0.5/+0.1 (p=0.859)  nat: +1.5/+0.8 (p=0.025)

G. each selector reranking 710 questions (27%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +2.2  [+1.3, +3.1]  p=0.000
   BM25 margin           +0.6  [-0.4, +1.6]  p=0.241
   top5 vs rest          +0.3  [-0.7, +1.2]  p=0.615
   NQC-like spread       +0.5  [-0.5, +1.4]  p=0.336
   WIG-like              +1.7  [+0.7, +2.7]  p=0.001
   term coverage top1    +1.4  [+0.4, +2.4]  p=0.006

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              61.9*   62.8*   63.2*   62.9*   62.6*   62.5*   62.0*   61.6*   61.2*   60.9*   10%
   BM25 margin            61.0*   61.2*   61.5*   61.5*   61.6*   61.6*   61.7*   61.5*   61.2*   60.9*   10%
   top5 vs rest           60.8*   60.9*   61.0*   61.3*   61.1*   60.9*   60.7*   60.8*   60.8*   60.9*   10%
   NQC-like spread        60.9*   61.3*   61.4*   61.5*   61.1*   61.0*   60.8*   60.8*   60.8*   60.9*   10%
   WIG-like               62.0*   62.7*   62.6*   62.4*   62.0*   62.0*   62.1*   61.8*   61.4*   60.9*   10%
   term coverage top1     61.7*   62.0*   62.4*   62.6*   62.6*   62.5*   62.2*   62.1*   61.6*   60.9*   10%
   ORACLE                 67.5*   69.1*   69.1*   69.1*   69.1*   69.1*   69.1*   69.1*   67.4*   60.9*   10%
   random (expected)      60.8    60.8    60.8    60.8    60.8    60.8    60.8    60.8    60.9    60.9*   100%
   (BM25 only 60.8; rerank ALL 60.9)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +1.1[ -0.1]#  +2.0[ +1.0]#  +2.3[ +1.4]#  +2.0[ +1.3]#  +1.8[ +1.1]#  +1.6[ +1.0]#  +1.1[ +0.7]#  +0.8[ +0.4]#  +0.3[ +0.2]#   10%   (point estimate: 10%)
   BM25 margin           +0.2[ -1.0]   +0.4[ -0.7]#  +0.6[ -0.4]#  +0.6[ -0.3]#  +0.7[ -0.1]#  +0.8[ +0.1]#  +0.8[ +0.4]#  +0.6[ +0.3]#  +0.3[ +0.2]#   20%   (point estimate: 10%)
   top5 vs rest          -0.1[ -1.2]   +0.1[ -1.0]#  +0.2[ -0.8]#  +0.5[ -0.4]#  +0.2[ -0.6]#  +0.1[ -0.7]#  -0.2[ -0.7]#  -0.1[ -0.6]#  -0.1[ -0.4]#   20%   (point estimate: 10%)
   NQC-like spread       +0.0[ -1.1]   +0.5[ -0.5]#  +0.6[ -0.4]#  +0.6[ -0.2]#  +0.2[ -0.5]#  +0.2[ -0.5]#  -0.0[ -0.6]#  -0.1[ -0.5]#  -0.1[ -0.4]#   20%   (point estimate: 10%)
   WIG-like              +1.2[ +0.0]#  +1.9[ +0.9]#  +1.7[ +0.8]#  +1.6[ +0.7]#  +1.2[ +0.4]#  +1.2[ +0.5]#  +1.3[ +0.7]#  +1.0[ +0.4]#  +0.5[ +0.2]#   10%   (point estimate: 10%)
   term coverage top1    +0.8[ -0.4]#  +1.2[ +0.1]#  +1.5[ +0.5]#  +1.8[ +0.9]#  +1.7[ +0.8]#  +1.6[ +0.9]#  +1.4[ +0.7]#  +1.2[ +0.7]#  +0.7[ +0.3]#   10%   (point estimate: 10%)
   ORACLE                +6.6[ +5.8]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.2[ +7.4]#  +6.5[ +5.7]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             +1.1[ -0.1]#  +2.0[ +1.0]#  +2.3[ +1.4]#  +2.0[ +1.3]#  +1.8[ +1.1]#  +1.6[ +1.0]#  +1.1[ +0.7]#  +0.8[ +0.4]#  +0.3[ +0.2]#   10%   (point estimate: 10%)
   BM25 margin           +0.2[ -1.0]   +0.4[ -0.7]   +0.6[ -0.4]#  +0.6[ -0.3]#  +0.7[ -0.1]#  +0.8[ +0.1]#  +0.8[ +0.4]#  +0.6[ +0.3]#  +0.3[ +0.2]#   30%   (point estimate: 10%)
   top5 vs rest          -0.1[ -1.2]   +0.1[ -1.0]   +0.2[ -0.8]   +0.5[ -0.4]#  +0.2[ -0.6]   +0.1[ -0.7]   -0.2[ -0.7]   -0.1[ -0.6]   -0.1[ -0.4]#   90%   (point estimate: 10%)
   NQC-like spread       +0.0[ -1.1]   +0.5[ -0.5]   +0.6[ -0.4]#  +0.6[ -0.2]#  +0.2[ -0.5]   +0.2[ -0.5]   -0.0[ -0.6]   -0.1[ -0.5]#  -0.1[ -0.4]#   80%   (point estimate: 10%)
   WIG-like              +1.2[ +0.0]#  +1.9[ +0.9]#  +1.7[ +0.8]#  +1.6[ +0.7]#  +1.2[ +0.4]#  +1.2[ +0.5]#  +1.3[ +0.7]#  +1.0[ +0.4]#  +0.5[ +0.2]#   10%   (point estimate: 10%)
   term coverage top1    +0.8[ -0.4]#  +1.2[ +0.1]#  +1.5[ +0.5]#  +1.8[ +0.9]#  +1.7[ +0.8]#  +1.6[ +0.9]#  +1.4[ +0.7]#  +1.2[ +0.7]#  +0.7[ +0.3]#   10%   (point estimate: 10%)
   ORACLE                +6.6[ +5.8]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.3[ +7.5]#  +8.2[ +7.4]#  +6.5[ +5.7]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      27% (sd  27)   +1.20 MRR               0%     73%
   tag alarm               100      20% (sd  19)   +1.29 MRR               0%     80%
   tag alarm               200      12% (sd   8)   +1.20 MRR               0%     88%
   BM25 margin              50      39% (sd  31)   +0.38 MRR               0%     61%
   BM25 margin             100      29% (sd  26)   +0.34 MRR               0%     71%
   BM25 margin             200      22% (sd  19)   +0.31 MRR               0%     78%
   top5 vs rest             50      53% (sd  39)   -0.04 MRR               0%     47%
   top5 vs rest            100      46% (sd  37)   -0.02 MRR               0%     54%
   top5 vs rest            200      41% (sd  35)   -0.02 MRR               0%     59%
   NQC-like spread          50      56% (sd  38)   +0.04 MRR               0%     44%
   NQC-like spread         100      45% (sd  37)   +0.06 MRR               0%     55%
   NQC-like spread         200      35% (sd  34)   +0.01 MRR               0%     65%
   WIG-like                 50      39% (sd  36)   +1.01 MRR               0%     61%
   WIG-like                100      30% (sd  32)   +1.07 MRR               0%     70%
   WIG-like                200      20% (sd  24)   +1.14 MRR               0%     80%
   term coverage top1       50      33% (sd  33)   +0.89 MRR               0%     67%
   term coverage top1      100      30% (sd  29)   +1.00 MRR               0%     70%
   term coverage top1      200      17% (sd  18)   +0.93 MRR               0%     83%

## prime_testfull  (2801 questions; tag alarm fires on 1563 = 56%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  22.7  random  20.4  diff  +2.3  p=0.0001
   MRR  : tag  31.1  random  29.3  diff  +1.8  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.9 (p=0.036)        +0.5 (p=0.139)
   40%            +1.0 (p=0.039)        +0.7 (p=0.053)
   50%            +0.9 (p=0.128)        +0.7 (p=0.089)
   56% nat        +0.3 (p=0.611)        +0.5 (p=0.300)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  +2.8  95% CI [+1.7, +4.0]  p=0.000
   MRR  :  +1.6  95% CI [+0.8, +2.5]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (55%)
   Hit@1:  -0.4  p=0.506
   MRR  :  -0.5  p=0.226

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/-0.1 (p=0.846)  40%: +1.2/+0.6 (p=0.168)  50%: +1.7/+1.1 (p=0.007)  nat: +1.1/+0.8 (p=0.053)
   vs NQC-like spread      30%: +0.1/-0.1 (p=0.762)  40%: +0.6/+0.3 (p=0.494)  50%: +0.8/+0.6 (p=0.157)  nat: +0.4/+0.4 (p=0.359)
   vs WIG-like             30%: -0.5/-0.7 (p=0.083)  40%: +0.2/-0.1 (p=0.735)  50%: +0.6/+0.4 (p=0.395)  nat: +0.3/+0.2 (p=0.634)
   vs term coverage top1   30%: +0.2/+0.1 (p=0.890)  40%: +1.1/+0.7 (p=0.134)  50%: +1.2/+0.9 (p=0.050)  nat: +0.9/+0.7 (p=0.126)

G. each selector reranking 1563 questions (56%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             +1.6  [+0.8, +2.5]  p=0.000
   BM25 margin           +1.2  [+0.3, +2.0]  p=0.009
   top5 vs rest          +0.8  [-0.1, +1.8]  p=0.074
   NQC-like spread       +1.3  [+0.3, +2.2]  p=0.007
   WIG-like              +1.4  [+0.5, +2.3]  p=0.003
   term coverage top1    +0.9  [+0.1, +1.8]  p=0.030

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              29.5*   29.8*   30.3*   31.0*   31.4*   31.0*   31.1*   30.7*   30.3*   29.5*   10%
   BM25 margin            29.4*   29.7*   29.8*   30.2*   30.6*   30.8*   30.7*   30.8*   30.3*   29.5*   10%
   top5 vs rest           29.4*   29.8*   30.4*   30.4*   30.2*   30.2*   30.3*   29.7*   29.5*   29.5*   10%
   NQC-like spread        29.3*   29.8*   30.5*   30.7*   30.8*   30.7*   30.4*   30.0*   29.7*   29.5*   10%
   WIG-like               30.0*   30.7*   31.0*   31.1*   31.0*   30.9*   31.2*   30.7*   30.4*   29.5*   10%
   term coverage top1     29.5*   30.1*   30.3*   30.3*   30.5*   30.1*   30.3*   30.0*   29.8*   29.5*   10%
   ORACLE                 36.4*   38.7*   38.9*   38.9*   38.9*   38.9*   38.9*   38.9*   36.7*   29.5*   10%
   random (expected)      29.2    29.2    29.2    29.3    29.3    29.4    29.4    29.4    29.5    29.5*   100%
   (BM25 only 29.1; rerank ALL 29.5)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.0[ -1.3]   +0.3[ -0.9]#  +0.8[ -0.2]#  +1.5[ +0.5]#  +1.9[ +0.9]#  +1.5[ +0.7]#  +1.6[ +0.9]#  +1.2[ +0.6]#  +0.8[ +0.4]#   20%   (point estimate: 10%)
   BM25 margin           -0.1[ -1.4]   +0.2[ -1.0]   +0.3[ -0.8]#  +0.8[ -0.3]#  +1.1[ +0.2]#  +1.3[ +0.5]#  +1.2[ +0.5]#  +1.3[ +0.8]#  +0.8[ +0.5]#   30%   (point estimate: 10%)
   top5 vs rest          -0.1[ -1.4]   +0.3[ -0.9]#  +0.9[ -0.2]#  +0.9[ -0.1]#  +0.7[ -0.2]#  +0.7[ -0.1]#  +0.8[ -0.0]#  +0.2[ -0.5]#  -0.0[ -0.5]#   20%   (point estimate: 10%)
   NQC-like spread       -0.2[ -1.4]   +0.3[ -0.9]#  +1.0[ -0.1]#  +1.2[ +0.2]#  +1.3[ +0.3]#  +1.2[ +0.3]#  +0.9[ +0.1]#  +0.5[ -0.0]#  +0.2[ -0.2]#   20%   (point estimate: 10%)
   WIG-like              +0.5[ -0.7]#  +1.2[ +0.0]#  +1.5[ +0.3]#  +1.6[ +0.6]#  +1.5[ +0.5]#  +1.4[ +0.6]#  +1.7[ +0.9]#  +1.2[ +0.6]#  +0.9[ +0.5]#   10%   (point estimate: 10%)
   term coverage top1    +0.0[ -1.2]   +0.6[ -0.6]#  +0.8[ -0.3]#  +0.8[ -0.2]#  +1.0[ +0.0]#  +0.6[ -0.1]#  +0.8[ +0.1]#  +0.5[ -0.0]#  +0.3[ -0.1]#   20%   (point estimate: 10%)
   ORACLE                +6.9[ +6.0]#  +9.2[ +8.4]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.5]#  +7.2[ +6.4]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.0[ -1.3]   +0.3[ -0.9]   +0.8[ -0.2]#  +1.5[ +0.5]#  +1.9[ +0.9]#  +1.5[ +0.7]#  +1.6[ +0.9]#  +1.2[ +0.6]#  +0.8[ +0.4]#   30%   (point estimate: 10%)
   BM25 margin           -0.1[ -1.4]   +0.2[ -1.0]   +0.3[ -0.8]   +0.8[ -0.3]#  +1.1[ +0.2]#  +1.3[ +0.5]#  +1.2[ +0.5]#  +1.3[ +0.8]#  +0.8[ +0.5]#   40%   (point estimate: 10%)
   top5 vs rest          -0.1[ -1.4]   +0.3[ -0.9]   +0.9[ -0.2]#  +0.9[ -0.1]#  +0.7[ -0.2]#  +0.7[ -0.1]#  +0.8[ -0.0]#  +0.2[ -0.5]#  -0.0[ -0.5]#   30%   (point estimate: 10%)
   NQC-like spread       -0.2[ -1.4]   +0.3[ -0.9]   +1.0[ -0.1]#  +1.2[ +0.2]#  +1.3[ +0.3]#  +1.2[ +0.3]#  +0.9[ +0.1]#  +0.5[ -0.0]#  +0.2[ -0.2]#   30%   (point estimate: 10%)
   WIG-like              +0.5[ -0.7]   +1.2[ +0.0]#  +1.5[ +0.3]#  +1.6[ +0.6]#  +1.5[ +0.5]#  +1.4[ +0.6]#  +1.7[ +0.9]#  +1.2[ +0.6]#  +0.9[ +0.5]#   20%   (point estimate: 10%)
   term coverage top1    +0.0[ -1.2]   +0.6[ -0.6]   +0.8[ -0.3]#  +0.8[ -0.2]#  +1.0[ +0.0]#  +0.6[ -0.1]#  +0.8[ +0.1]#  +0.5[ -0.0]#  +0.3[ -0.1]#   30%   (point estimate: 10%)
   ORACLE                +6.9[ +6.0]#  +9.2[ +8.4]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.6]#  +9.4[ +8.5]#  +7.2[ +6.4]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      43% (sd  35)   +0.49 MRR               0%     57%
   tag alarm               100      32% (sd  28)   +0.52 MRR               0%     68%
   tag alarm               200      23% (sd  21)   +0.36 MRR               0%     77%
   BM25 margin              50      45% (sd  34)   +0.41 MRR               0%     55%
   BM25 margin             100      35% (sd  30)   +0.32 MRR               0%     65%
   BM25 margin             200      26% (sd  22)   +0.26 MRR               0%     74%
   top5 vs rest             50      59% (sd  40)   +0.08 MRR               0%     41%
   top5 vs rest            100      47% (sd  39)   +0.08 MRR               0%     53%
   top5 vs rest            200      34% (sd  34)   +0.07 MRR               0%     66%
   NQC-like spread          50      47% (sd  39)   +0.13 MRR               0%     53%
   NQC-like spread         100      39% (sd  36)   +0.15 MRR               0%     61%
   NQC-like spread         200      29% (sd  30)   +0.12 MRR               0%     71%
   WIG-like                 50      44% (sd  37)   +0.72 MRR               0%     56%
   WIG-like                100      31% (sd  32)   +0.76 MRR               0%     69%
   WIG-like                200      20% (sd  22)   +0.67 MRR               0%     80%
   term coverage top1       50      51% (sd  37)   +0.27 MRR               0%     49%
   term coverage top1      100      45% (sd  36)   +0.28 MRR               0%     55%
   term coverage top1      200      29% (sd  30)   +0.20 MRR               0%     71%

## POOLED over 3 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  41.6  random  39.2  diff  +2.4  p=0.0001
   MRR  : tag  50.6  random  48.8  diff  +1.8  p=0.0001

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  +1.1 (p=0.001)   MRR  +0.8 (p=0.002)
   40%      Hit@1  +0.8 (p=0.021)   MRR  +0.6 (p=0.025)
   50%      Hit@1  +0.4 (p=0.284)   MRR  +0.4 (p=0.118)
   natural  Hit@1  +0.5 (p=0.243)   MRR  +0.5 (p=0.070)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  +1.2  95% CI [+0.4, +1.9]  p=0.003
   MRR  :  +1.0  95% CI [+0.4, +1.6]  p=0.001

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +0.4  p=0.294
   MRR  :  +0.0  p=0.993

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +1.3/+0.5 (p=0.046)  40%: +1.3/+0.5 (p=0.073)  50%: +1.4/+0.7 (p=0.015)  nat: +1.2/+0.6 (p=0.025)
   vs NQC-like spread      30%: +0.8/+0.3 (p=0.208)  40%: +0.8/+0.3 (p=0.331)  50%: +0.9/+0.4 (p=0.121)  nat: +0.7/+0.3 (p=0.213)
   vs WIG-like             30%: +0.1/-0.4 (p=0.157)  40%: +0.3/-0.3 (p=0.286)  50%: +0.4/-0.1 (p=0.736)  nat: +0.1/-0.2 (p=0.375)
   vs term coverage top1   30%: +1.1/+0.7 (p=0.010)  40%: +1.3/+0.9 (p=0.002)  50%: +1.1/+0.8 (p=0.004)  nat: +1.3/+1.0 (p=0.000)
