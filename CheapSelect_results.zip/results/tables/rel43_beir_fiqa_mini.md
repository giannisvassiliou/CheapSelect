## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  25.3  random  24.9  diff  +0.4  p=0.3258
   MRR  : tag  33.4  random  33.2  diff  +0.2  p=0.3490

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -1.7 (p=0.154)        -1.8 (p=0.032)
   40%            -0.2 (p=1.000)        -0.1 (p=0.850)
   50%            +0.0 (p=1.000)        +0.0 (p=0.992)
   25% nat        -1.5 (p=0.227)        -1.8 (p=0.066)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -7.9  95% CI [-10.8, -4.9]  p=0.000
   MRR  :  -8.7  95% CI [-10.9, -6.3]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (51%)
   Hit@1:  +0.9  p=0.472
   MRR  :  +0.4  p=0.593

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.2/-0.5 (p=0.591)  40%: +1.5/+1.1 (p=0.232)  50%: +2.3/+1.9 (p=0.050)  nat: -0.3/-0.6 (p=0.464)
   vs NQC-like spread      30%: -0.5/-0.9 (p=0.322)  40%: +1.9/+1.4 (p=0.137)  50%: +2.0/+1.7 (p=0.064)  nat: -0.8/-1.2 (p=0.175)
   vs WIG-like             30%: +0.6/-0.1 (p=0.933)  40%: +2.5/+1.7 (p=0.075)  50%: +2.0/+1.5 (p=0.112)  nat: +0.6/-0.2 (p=0.849)
   vs term coverage top1   30%: +1.2/+0.6 (p=0.435)  40%: +2.2/+1.8 (p=0.053)  50%: +1.2/+1.1 (p=0.265)  nat: +0.8/+0.4 (p=0.598)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -8.7  [-10.9, -6.3]  p=0.000
   BM25 margin           -6.9  [-9.0, -4.8]  p=0.000
   top5 vs rest          -8.0  [-10.3, -5.8]  p=0.000
   NQC-like spread       -7.5  [-9.7, -5.4]  p=0.000
   WIG-like              -8.5  [-10.8, -6.2]  p=0.000
   term coverage top1    -9.0  [-11.4, -6.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              32.0    33.0    34.2    36.7    38.0    39.3    39.7    40.6    41.7*   42.0*   90%
   BM25 margin            32.0    34.4    36.1    36.8    38.0    38.4    39.4    40.7    41.3    42.0*   100%
   top5 vs rest           31.7    33.6    34.7    35.5    36.1    37.0    38.3    39.4    40.7    42.0*   100%
   NQC-like spread        32.5    34.2    35.1    35.3    36.3    37.5    38.4    39.3    40.9    42.0*   100%
   WIG-like               31.5    32.7    34.3    35.0    36.5    37.8    38.7    39.8    41.1    42.0*   100%
   term coverage top1     31.5    32.5    33.6    34.9    36.9    38.5    40.0    40.7    41.7*   42.0*   90%
   ORACLE                 38.9    43.7*   45.4*   45.7*   45.7*   45.7*   45.7*   45.7*   45.6*   42.0*   20%
   random (expected)      31.4    32.6    33.8    35.0    36.1    37.3    38.5    39.7    40.9    42.0*   100%
   (BM25 only 30.3; rerank ALL 42.0)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.84 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -10.0[-12.5]   -9.1[-11.4]   -7.8[-10.0]   -5.4[ -7.2]   -4.1[ -5.6]   -2.8[ -4.2]   -2.4[ -3.6]   -1.4[ -2.4]   -0.3[ -0.8]#   90%   (point estimate: 90%)
   BM25 margin          -10.0[-12.4]   -7.6[ -9.7]   -6.0[ -7.9]   -5.2[ -7.0]   -4.1[ -5.7]   -3.6[ -5.0]   -2.6[ -3.8]   -1.3[ -2.2]   -0.7[ -1.3]    100%   (point estimate: 90%)
   top5 vs rest         -10.4[-12.8]   -8.5[-10.7]   -7.3[ -9.3]   -6.5[ -8.5]   -5.9[ -7.8]   -5.1[ -6.8]   -3.8[ -5.3]   -2.6[ -4.0]   -1.4[ -2.2]    100%   (point estimate: 100%)
   NQC-like spread       -9.6[-11.9]   -7.9[-10.1]   -6.9[ -8.9]   -6.7[ -8.7]   -5.7[ -7.6]   -4.5[ -6.2]   -3.7[ -5.2]   -2.8[ -4.0]   -1.2[ -2.0]    100%   (point estimate: 100%)
   WIG-like             -10.6[-12.9]   -9.4[-11.6]   -7.8[-10.0]   -7.0[ -9.1]   -5.6[ -7.5]   -4.3[ -6.0]   -3.3[ -4.9]   -2.3[ -3.7]   -1.0[ -1.9]    100%   (point estimate: 100%)
   term coverage top1   -10.5[-12.8]   -9.6[-11.9]   -8.4[-10.6]   -7.2[ -9.2]   -5.1[ -7.0]   -3.5[ -5.1]   -2.1[ -3.4]   -1.4[ -2.5]   -0.4[ -1.2]    100%   (point estimate: 90%)
   ORACLE                -3.2[ -4.8]   +1.7[ +0.5]#  +3.4[ +2.3]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#  +3.6[ +2.6]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.84): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      87% (sd  16)   -0.91 MRR              25%     13%
   BM25 margin             100      88% (sd  11)   -1.01 MRR              35%     12%
   top5 vs rest            100      94% (sd   7)   -0.85 MRR              45%      6%
   NQC-like spread         100      92% (sd  12)   -1.11 MRR              40%      8%
   WIG-like                100      94% (sd  10)   -0.71 MRR              40%      6%
   term coverage top1      100      89% (sd  13)   -0.84 MRR              30%     11%

