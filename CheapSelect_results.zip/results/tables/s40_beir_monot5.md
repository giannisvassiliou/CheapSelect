## beir_scifact  (300 questions; tag alarm fires on 46 = 15%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  56.7  random  55.7  diff  +1.0  p=0.1558
   MRR  : tag  65.3  random  64.8  diff  +0.5  p=0.1691

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.2 (p=0.710)
   40%            -0.3 (p=1.000)        -0.4 (p=0.164)
   50%            +0.0 (p=1.000)        -0.3 (p=0.454)
   15% nat        -1.3 (p=0.473)        -1.4 (p=0.181)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -6.7  95% CI [-10.7, -3.0]  p=0.001
   MRR  :  -6.4  95% CI [-9.2, -3.6]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (27%)
   Hit@1:  +1.3  p=0.481
   MRR  :  +1.7  p=0.099

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +3.3/+2.3 (p=0.035)  40%: +3.0/+2.3 (p=0.066)  50%: +2.7/+1.9 (p=0.138)  nat: +1.3/+0.7 (p=0.432)
   vs NQC-like spread      30%: +2.0/+0.5 (p=0.655)  40%: +2.0/+0.4 (p=0.656)  50%: +1.0/+0.4 (p=0.682)  nat: -0.3/-0.9 (p=0.321)
   vs WIG-like             30%: +1.0/+0.1 (p=0.913)  40%: +1.0/+0.2 (p=0.876)  50%: +1.3/+0.9 (p=0.395)  nat: +0.7/-0.1 (p=0.896)
   vs term coverage top1   30%: +1.0/+0.7 (p=0.569)  40%: +0.0/-0.0 (p=0.991)  50%: +0.0/+0.1 (p=0.917)  nat: -1.0/-0.8 (p=0.361)

G. each selector reranking 46 questions (15%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -6.4  [-9.2, -3.6]  p=0.000
   BM25 margin           -5.0  [-7.6, -2.5]  p=0.000
   top5 vs rest          -7.0  [-10.0, -4.1]  p=0.000
   NQC-like spread       -5.4  [-8.3, -2.7]  p=0.000
   WIG-like              -6.2  [-9.1, -3.5]  p=0.000
   term coverage top1    -5.6  [-8.4, -2.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              65.4    66.4    68.0    68.5    69.6    70.3    71.3*   71.5*   71.7*   71.7*   70%
   BM25 margin            65.2    66.8    67.8    68.9    69.9    70.9    71.5*   71.5*   71.7*   71.7*   70%
   top5 vs rest           63.9    64.7    65.7    66.1    67.7    68.4    68.4    69.4    70.7*   71.7*   90%
   NQC-like spread        65.6    66.7    67.5    68.0    69.2    69.8    70.6*   71.1*   71.4*   71.7*   70%
   WIG-like               64.9    67.0    67.9    68.3    68.6    69.1    69.6    70.0    71.5*   71.7*   90%
   term coverage top1     65.3    66.5    67.4    68.5    69.5    70.3*   70.5*   70.6    71.2*   71.7*   90%
   ORACLE                 70.8*   73.9*   74.3*   74.3*   74.3*   74.3*   74.3*   74.3*   74.3*   71.7*   10%
   random (expected)      64.4    65.2    66.0    66.8    67.6    68.4    69.3    70.1    70.9    71.7*   100%
   (BM25 only 63.6; rerank ALL 71.7)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -6.4[ -9.2]   -5.3[ -8.1]   -3.7[ -6.2]   -3.2[ -5.2]   -2.1[ -3.6]   -1.4[ -2.6]   -0.4[ -1.1]   -0.2[ -0.8]#  +0.0[ -0.2]#   80%   (point estimate: 70%)
   BM25 margin           -6.6[ -9.4]   -4.9[ -7.5]   -3.9[ -6.1]   -2.8[ -4.6]   -1.8[ -3.0]   -0.8[ -1.6]   -0.2[ -0.8]#  -0.2[ -0.8]#  +0.0[ -0.2]#   70%   (point estimate: 60%)
   top5 vs rest          -7.8[-10.9]   -7.0[ -9.8]   -6.0[ -8.8]   -5.6[ -8.3]   -4.0[ -6.5]   -3.3[ -5.6]   -3.3[ -5.4]   -2.3[ -4.1]   -1.1[ -2.4]    100%   (point estimate: 100%)
   NQC-like spread       -6.1[ -9.2]   -5.0[ -7.7]   -4.2[ -6.7]   -3.7[ -5.9]   -2.5[ -4.4]   -1.9[ -3.6]   -1.1[ -2.4]   -0.6[ -1.6]   -0.3[ -0.8]#   90%   (point estimate: 80%)
   WIG-like              -6.9[ -9.9]   -4.7[ -7.3]   -3.8[ -6.3]   -3.4[ -5.5]   -3.1[ -5.0]   -2.6[ -4.5]   -2.1[ -3.9]   -1.8[ -3.1]   -0.2[ -0.9]#   90%   (point estimate: 90%)
   term coverage top1    -6.4[ -9.3]   -5.3[ -8.0]   -4.3[ -6.7]   -3.2[ -5.2]   -2.2[ -4.0]   -1.4[ -3.0]   -1.2[ -2.5]   -1.1[ -2.3]   -0.5[ -1.3]    100%   (point estimate: 90%)
   ORACLE                -0.9[ -2.7]   +2.2[ +1.0]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#   20%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -6.4[ -9.2]   -5.3[ -8.1]   -3.7[ -6.2]   -3.2[ -5.2]   -2.1[ -3.6]   -1.4[ -2.6]   -0.4[ -1.1]   -0.2[ -0.8]   +0.0[ -0.2]#   90%   (point estimate: 70%)
   BM25 margin           -6.6[ -9.4]   -4.9[ -7.5]   -3.9[ -6.1]   -2.8[ -4.6]   -1.8[ -3.0]   -0.8[ -1.6]   -0.2[ -0.8]   -0.2[ -0.8]   +0.0[ -0.2]#   90%   (point estimate: 70%)
   top5 vs rest          -7.8[-10.9]   -7.0[ -9.8]   -6.0[ -8.8]   -5.6[ -8.3]   -4.0[ -6.5]   -3.3[ -5.6]   -3.3[ -5.4]   -2.3[ -4.1]   -1.1[ -2.4]    100%   (point estimate: 100%)
   NQC-like spread       -6.1[ -9.2]   -5.0[ -7.7]   -4.2[ -6.7]   -3.7[ -5.9]   -2.5[ -4.4]   -1.9[ -3.6]   -1.1[ -2.4]   -0.6[ -1.6]   -0.3[ -0.8]    100%   (point estimate: 90%)
   WIG-like              -6.9[ -9.9]   -4.7[ -7.3]   -3.8[ -6.3]   -3.4[ -5.5]   -3.1[ -5.0]   -2.6[ -4.5]   -2.1[ -3.9]   -1.8[ -3.1]   -0.2[ -0.9]    100%   (point estimate: 90%)
   term coverage top1    -6.4[ -9.3]   -5.3[ -8.0]   -4.3[ -6.7]   -3.2[ -5.2]   -2.2[ -4.0]   -1.4[ -3.0]   -1.2[ -2.5]   -1.1[ -2.3]   -0.5[ -1.3]    100%   (point estimate: 100%)
   ORACLE                -0.9[ -2.7]   +2.2[ +1.0]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#  +2.6[ +1.4]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      65% (sd  18)   -1.35 MRR              45%     35%
   tag alarm               100      67% (sd  11)   -0.94 MRR              34%     33%
   tag alarm               200      67% (sd   5)   -0.87 MRR              34%     33%
   BM25 margin              50      61% (sd  16)   -1.21 MRR              34%     39%
   BM25 margin             100      61% (sd  10)   -0.92 MRR              23%     39%
   BM25 margin             200      62% (sd   5)   -0.82 MRR              38%     38%
   top5 vs rest             50      88% (sd  18)   -1.34 MRR              48%     12%
   top5 vs rest            100      93% (sd   9)   -0.90 MRR              43%      7%
   top5 vs rest            200      95% (sd   5)   -0.84 MRR              42%      5%
   NQC-like spread          50      74% (sd  22)   -1.39 MRR              42%     26%
   NQC-like spread         100      74% (sd  15)   -1.24 MRR              44%     26%
   NQC-like spread         200      76% (sd   9)   -1.10 MRR              44%     24%
   WIG-like                 50      82% (sd  22)   -1.24 MRR              37%     18%
   WIG-like                100      86% (sd  12)   -0.87 MRR              26%     14%
   WIG-like                200      89% (sd   5)   -0.67 MRR              20%     11%
   term coverage top1       50      77% (sd  21)   -1.25 MRR              49%     23%
   term coverage top1      100      79% (sd  17)   -1.15 MRR              49%     21%
   term coverage top1      200      84% (sd  10)   -0.80 MRR              32%     16%

## beir_nfcorpus  (323 questions; tag alarm fires on 8 = 2%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  43.3  random  44.2  diff  -0.8  p=0.9990
   MRR  : tag  51.8  random  52.3  diff  -0.6  p=0.9889

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.6 (p=0.498)        -0.4 (p=0.249)
   40%            -0.9 (p=0.253)        -0.7 (p=0.253)
   50%            +0.0 (p=1.000)        -0.0 (p=1.000)
   2% nat         -0.6 (p=0.498)        -0.4 (p=0.498)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -9.0  95% CI [-13.3, -4.6]  p=0.000
   MRR  :  -7.5  95% CI [-10.7, -4.4]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (45%)
   Hit@1:  +0.9  p=0.713
   MRR  :  -0.0  p=0.997

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.3/-0.0 (p=0.995)  40%: +0.3/+0.8 (p=0.548)  50%: +1.2/+1.2 (p=0.331)  nat: -0.6/-0.4 (p=0.498)
   vs NQC-like spread      30%: -0.3/-0.7 (p=0.495)  40%: -1.5/-0.7 (p=0.545)  50%: +1.2/+0.6 (p=0.588)  nat: -0.6/-0.4 (p=0.498)
   vs WIG-like             30%: -1.2/-0.9 (p=0.419)  40%: -2.2/-0.8 (p=0.516)  50%: -0.9/-0.3 (p=0.791)  nat: -0.6/-0.4 (p=0.498)
   vs term coverage top1   30%: -0.3/-0.9 (p=0.441)  40%: -1.5/-1.2 (p=0.312)  50%: -1.2/-1.2 (p=0.242)  nat: -0.6/-0.4 (p=0.498)

G. each selector reranking 8 questions (2%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -7.5  [-10.7, -4.4]  p=0.000
   BM25 margin           -7.2  [-10.4, -3.9]  p=0.000
   top5 vs rest          -7.2  [-10.4, -3.9]  p=0.000
   NQC-like spread       -7.2  [-10.4, -3.9]  p=0.000
   WIG-like              -7.2  [-10.4, -3.9]  p=0.000
   term coverage top1    -7.2  [-10.4, -3.9]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              51.7    53.2    54.6    55.8    57.4    57.7*   57.9*   58.0*   58.7*   59.3*   60%
   BM25 margin            51.9    53.5    55.0    56.5    57.4    58.0*   57.8*   58.0*   58.7*   59.3*   60%
   top5 vs rest           52.0    53.2    54.6    55.1    56.2    57.1    57.6*   58.5*   59.4*   59.3*   70%
   NQC-like spread        51.6    54.6    55.3    56.6    56.8    57.7    58.4*   58.7*   58.9*   59.3*   70%
   WIG-like               52.1    53.0    55.5    56.6    57.7*   58.8*   58.9*   59.0*   59.1*   59.3*   50%
   term coverage top1     52.7    54.2    55.5    57.0*   58.5*   58.1*   58.5*   58.8*   58.8*   59.3*   40%
   ORACLE                 59.7*   62.8*   62.8*   62.8*   62.8*   62.8*   62.8*   62.8*   62.8*   59.3*   10%
   random (expected)      52.9    53.6    54.3    55.0    55.7    56.4    57.2    57.9    58.6    59.3*   100%
   (BM25 only 52.1; rerank ALL 59.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.6[-10.8]   -6.1[ -9.0]   -4.7[ -7.2]   -3.5[ -5.8]   -1.9[ -3.9]   -1.6[ -3.4]   -1.4[ -3.1]   -1.3[ -2.7]   -0.6[ -1.3]    100%   (point estimate: 90%)
   BM25 margin           -7.4[-10.7]   -5.8[ -8.6]   -4.3[ -6.9]   -2.8[ -5.1]   -1.9[ -3.9]   -1.3[ -3.2]   -1.5[ -3.1]   -1.3[ -2.7]   -0.6[ -1.3]    100%   (point estimate: 90%)
   top5 vs rest          -7.3[-10.5]   -6.1[ -9.1]   -4.7[ -7.5]   -4.3[ -6.7]   -3.1[ -5.3]   -2.2[ -4.2]   -1.7[ -3.3]   -0.8[ -1.9]   +0.1[ -0.7]#   90%   (point estimate: 80%)
   NQC-like spread       -7.7[-10.8]   -4.7[ -7.6]   -4.0[ -6.6]   -2.7[ -5.2]   -2.5[ -4.4]   -1.6[ -3.0]   -0.9[ -2.1]   -0.6[ -1.5]   -0.4[ -0.9]#   90%   (point estimate: 70%)
   WIG-like              -7.2[-10.4]   -6.3[ -9.4]   -3.8[ -6.5]   -2.7[ -5.3]   -1.6[ -3.9]   -0.5[ -2.6]   -0.4[ -2.0]   -0.3[ -1.6]   -0.2[ -0.8]#   90%   (point estimate: 60%)
   term coverage top1    -6.6[ -9.7]   -5.1[ -8.0]   -3.8[ -6.6]   -2.3[ -4.7]   -0.8[ -2.9]   -1.2[ -3.2]   -0.8[ -2.3]   -0.5[ -1.8]   -0.5[ -1.6]    100%   (point estimate: 70%)
   ORACLE                +0.4[ -1.6]   +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#   20%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -7.6[-10.8]   -6.1[ -9.0]   -4.7[ -7.2]   -3.5[ -5.8]   -1.9[ -3.9]   -1.6[ -3.4]   -1.4[ -3.1]   -1.3[ -2.7]   -0.6[ -1.3]    100%   (point estimate: 100%)
   BM25 margin           -7.4[-10.7]   -5.8[ -8.6]   -4.3[ -6.9]   -2.8[ -5.1]   -1.9[ -3.9]   -1.3[ -3.2]   -1.5[ -3.1]   -1.3[ -2.7]   -0.6[ -1.3]    100%   (point estimate: 100%)
   top5 vs rest          -7.3[-10.5]   -6.1[ -9.1]   -4.7[ -7.5]   -4.3[ -6.7]   -3.1[ -5.3]   -2.2[ -4.2]   -1.7[ -3.3]   -0.8[ -1.9]   +0.1[ -0.7]    100%   (point estimate: 90%)
   NQC-like spread       -7.7[-10.8]   -4.7[ -7.6]   -4.0[ -6.6]   -2.7[ -5.2]   -2.5[ -4.4]   -1.6[ -3.0]   -0.9[ -2.1]   -0.6[ -1.5]   -0.4[ -0.9]    100%   (point estimate: 90%)
   WIG-like              -7.2[-10.4]   -6.3[ -9.4]   -3.8[ -6.5]   -2.7[ -5.3]   -1.6[ -3.9]   -0.5[ -2.6]   -0.4[ -2.0]   -0.3[ -1.6]   -0.2[ -0.8]    100%   (point estimate: 70%)
   term coverage top1    -6.6[ -9.7]   -5.1[ -8.0]   -3.8[ -6.6]   -2.3[ -4.7]   -0.8[ -2.9]   -1.2[ -3.2]   -0.8[ -2.3]   -0.5[ -1.8]   -0.5[ -1.6]    100%   (point estimate: 80%)
   ORACLE                +0.4[ -1.6]   +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#  +3.5[ +2.1]#   20%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      80% (sd  23)   -1.31 MRR              40%     20%
   tag alarm               100      83% (sd  18)   -1.12 MRR              35%     17%
   tag alarm               200      85% (sd  11)   -0.98 MRR              30%     15%
   BM25 margin              50      76% (sd  25)   -1.45 MRR              48%     24%
   BM25 margin             100      82% (sd  18)   -1.04 MRR              36%     18%
   BM25 margin             200      83% (sd  15)   -1.12 MRR              35%     17%
   top5 vs rest             50      75% (sd  24)   -1.58 MRR              40%     25%
   top5 vs rest            100      77% (sd  15)   -1.28 MRR              40%     23%
   top5 vs rest            200      80% (sd   7)   -1.06 MRR              42%     20%
   NQC-like spread          50      75% (sd  23)   -1.26 MRR              36%     25%
   NQC-like spread         100      74% (sd  17)   -1.20 MRR              39%     26%
   NQC-like spread         200      72% (sd   9)   -1.14 MRR              44%     28%
   WIG-like                 50      73% (sd  24)   -1.09 MRR              25%     27%
   WIG-like                100      68% (sd  20)   -1.17 MRR              36%     32%
   WIG-like                200      66% (sd  15)   -1.00 MRR              31%     34%
   term coverage top1       50      75% (sd  26)   -1.06 MRR              28%     25%
   term coverage top1      100      72% (sd  21)   -0.95 MRR              35%     28%
   term coverage top1      200      69% (sd  19)   -1.12 MRR              42%     31%

## beir_fiqa  (648 questions; tag alarm fires on 160 = 25%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  31.5  random  28.9  diff  +2.5  p=0.0016
   MRR  : tag  38.2  random  36.4  diff  +1.8  p=0.0033

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.9 (p=0.574)        -1.0 (p=0.371)
   40%            +1.1 (p=0.431)        +0.9 (p=0.349)
   50%            +1.7 (p=0.103)        +1.1 (p=0.189)
   25% nat        -0.2 (p=1.000)        -0.8 (p=0.515)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1: -17.9  95% CI [-21.1, -14.7]  p=0.000
   MRR  : -17.1  95% CI [-19.8, -14.5]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (54%)
   Hit@1:  +3.7  p=0.010
   MRR  :  +1.9  p=0.103

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +2.2/+1.2 (p=0.351)  40%: +4.2/+2.9 (p=0.023)  50%: +4.8/+3.4 (p=0.006)  nat: +2.0/+0.9 (p=0.415)
   vs NQC-like spread      30%: +1.2/+0.5 (p=0.686)  40%: +3.4/+2.5 (p=0.043)  50%: +4.2/+3.0 (p=0.012)  nat: +0.8/-0.1 (p=0.937)
   vs WIG-like             30%: +2.2/+1.4 (p=0.239)  40%: +4.3/+3.3 (p=0.010)  50%: +4.5/+3.5 (p=0.007)  nat: +2.2/+1.3 (p=0.264)
   vs term coverage top1   30%: +1.7/+1.3 (p=0.209)  40%: +2.6/+2.3 (p=0.050)  50%: +2.0/+1.7 (p=0.165)  nat: +1.9/+1.4 (p=0.145)

G. each selector reranking 160 questions (25%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm            -17.1  [-19.8, -14.5]  p=0.000
   BM25 margin          -16.3  [-18.9, -13.7]  p=0.000
   top5 vs rest         -18.1  [-20.7, -15.4]  p=0.000
   NQC-like spread      -17.0  [-19.7, -14.4]  p=0.000
   WIG-like             -18.4  [-21.0, -15.7]  p=0.000
   term coverage top1   -18.5  [-21.2, -15.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              33.8    37.1    39.9    43.5    46.2    48.3    50.0    51.6    54.3    55.3*   100%
   BM25 margin            33.7    37.3    40.9    42.6    45.1    47.2    49.4    51.7    53.9    55.3*   100%
   top5 vs rest           32.7    35.9    38.8    40.6    42.8    45.2    47.5    50.3    52.9    55.3*   100%
   NQC-like spread        33.5    37.5    39.4    41.1    43.2    45.5    48.2    50.5    53.1    55.3*   100%
   WIG-like               32.6    35.1    38.5    40.2    42.7    45.8    48.0    50.2    52.8    55.3*   100%
   term coverage top1     32.7    35.7    38.6    41.2    44.5    47.2    50.2    51.5    53.7    55.3*   100%
   ORACLE                 39.9    48.3    54.0    56.5*   56.7*   56.7*   56.7*   56.7*   56.7*   55.3*   40%
   random (expected)      32.8    35.3    37.8    40.3    42.8    45.3    47.8    50.3    52.8    55.3*   100%
   (BM25 only 30.3; rerank ALL 55.3)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -21.5[-24.3]  -18.2[-20.9]  -15.4[-17.9]  -11.8[-14.0]   -9.1[-11.1]   -7.0[ -8.8]   -5.3[ -6.8]   -3.7[ -4.9]   -1.0[ -1.8]    100%   (point estimate: 100%)
   BM25 margin          -21.6[-24.4]  -18.0[-20.8]  -14.4[-16.8]  -12.7[-15.0]  -10.2[-12.3]   -8.1[-10.0]   -5.9[ -7.4]   -3.6[ -4.8]   -1.4[ -2.2]    100%   (point estimate: 100%)
   top5 vs rest         -22.6[-25.5]  -19.4[-22.1]  -16.5[-19.0]  -14.7[-17.1]  -12.5[-14.9]  -10.1[-12.2]   -7.8[ -9.7]   -5.0[ -6.6]   -2.4[ -3.6]    100%   (point estimate: 100%)
   NQC-like spread      -21.8[-24.5]  -17.8[-20.4]  -15.9[-18.3]  -14.2[-16.8]  -12.1[-14.4]   -9.8[-11.9]   -7.1[ -9.0]   -4.8[ -6.3]   -2.2[ -3.3]    100%   (point estimate: 100%)
   WIG-like             -22.7[-25.4]  -20.2[-23.0]  -16.8[-19.5]  -15.1[-17.7]  -12.6[-14.9]   -9.5[-11.5]   -7.3[ -9.1]   -5.1[ -6.6]   -2.5[ -3.6]    100%   (point estimate: 100%)
   term coverage top1   -22.6[-25.5]  -19.6[-22.4]  -16.7[-19.1]  -14.1[-16.4]  -10.8[-12.8]   -8.1[ -9.9]   -5.1[ -6.7]   -3.8[ -5.1]   -1.6[ -2.4]    100%   (point estimate: 100%)
   ORACLE               -15.4[-17.7]   -7.0[ -8.6]   -1.3[ -2.2]   +1.2[ +0.6]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#   40%   (point estimate: 40%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -21.5[-24.3]  -18.2[-20.9]  -15.4[-17.9]  -11.8[-14.0]   -9.1[-11.1]   -7.0[ -8.8]   -5.3[ -6.8]   -3.7[ -4.9]   -1.0[ -1.8]    100%   (point estimate: 100%)
   BM25 margin          -21.6[-24.4]  -18.0[-20.8]  -14.4[-16.8]  -12.7[-15.0]  -10.2[-12.3]   -8.1[-10.0]   -5.9[ -7.4]   -3.6[ -4.8]   -1.4[ -2.2]    100%   (point estimate: 100%)
   top5 vs rest         -22.6[-25.5]  -19.4[-22.1]  -16.5[-19.0]  -14.7[-17.1]  -12.5[-14.9]  -10.1[-12.2]   -7.8[ -9.7]   -5.0[ -6.6]   -2.4[ -3.6]    100%   (point estimate: 100%)
   NQC-like spread      -21.8[-24.5]  -17.8[-20.4]  -15.9[-18.3]  -14.2[-16.8]  -12.1[-14.4]   -9.8[-11.9]   -7.1[ -9.0]   -4.8[ -6.3]   -2.2[ -3.3]    100%   (point estimate: 100%)
   WIG-like             -22.7[-25.4]  -20.2[-23.0]  -16.8[-19.5]  -15.1[-17.7]  -12.6[-14.9]   -9.5[-11.5]   -7.3[ -9.1]   -5.1[ -6.6]   -2.5[ -3.6]    100%   (point estimate: 100%)
   term coverage top1   -22.6[-25.5]  -19.6[-22.4]  -16.7[-19.1]  -14.1[-16.4]  -10.8[-12.8]   -8.1[ -9.9]   -5.1[ -6.7]   -3.8[ -5.1]   -1.6[ -2.4]    100%   (point estimate: 100%)
   ORACLE               -15.4[-17.7]   -7.0[ -8.6]   -1.3[ -2.2]   +1.2[ +0.6]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#  +1.4[ +0.8]#   40%   (point estimate: 40%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      94% (sd   8)   -0.85 MRR              45%      6%
   tag alarm               100      95% (sd   6)   -0.63 MRR              40%      5%
   tag alarm               200      97% (sd   5)   -0.45 MRR              32%      3%
   BM25 margin              50      95% (sd   7)   -0.83 MRR              44%      5%
   BM25 margin             100      96% (sd   6)   -0.68 MRR              38%      4%
   BM25 margin             200      98% (sd   4)   -0.37 MRR              22%      2%
   top5 vs rest             50      97% (sd   6)   -0.71 MRR              22%      3%
   top5 vs rest            100      99% (sd   4)   -0.39 MRR              14%      1%
   top5 vs rest            200     100% (sd   2)   -0.12 MRR               4%      0%
   NQC-like spread          50      97% (sd   6)   -0.77 MRR              28%      3%
   NQC-like spread         100      98% (sd   5)   -0.54 MRR              20%      2%
   NQC-like spread         200     100% (sd   2)   -0.11 MRR               4%      0%
   WIG-like                 50      98% (sd   6)   -0.62 MRR              18%      2%
   WIG-like                100      99% (sd   3)   -0.31 MRR              10%      1%
   WIG-like                200     100% (sd   1)   -0.03 MRR               1%      0%
   term coverage top1       50      96% (sd   7)   -0.73 MRR              32%      4%
   term coverage top1      100      97% (sd   5)   -0.48 MRR              24%      3%
   term coverage top1      200      98% (sd   4)   -0.33 MRR              16%      2%

## beir_arguana  (1401 questions; tag alarm fires on 9 = 1%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag   0.1  random   0.1  diff  -0.0  p=1.0000
   MRR  : tag  21.9  random  21.9  diff  +0.0  p=0.4456

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +0.0 (p=1.000)        +0.0 (p=0.938)
   40%            +0.0 (p=1.000)        -0.0 (p=0.767)
   50%            +0.0 (p=1.000)        -0.0 (p=0.875)
   1% nat         +0.0 (p=1.000)        +0.0 (p=0.394)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.1  95% CI [-5.2, -3.1]  p=0.000
   MRR  :  -0.6  95% CI [-1.9, +0.7]  p=0.369

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (21%)
   Hit@1:  +2.6  p=0.000
   MRR  :  +1.2  p=0.003

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.4/-0.8 (p=0.134)  40%: -0.3/-0.7 (p=0.212)  50%: -0.9/-1.2 (p=0.053)  nat: +0.0/-0.0 (p=0.834)
   vs NQC-like spread      30%: -0.1/-0.3 (p=0.413)  40%: -0.1/-0.6 (p=0.198)  50%: -0.8/-1.0 (p=0.023)  nat: +0.0/+0.0 (p=0.389)
   vs WIG-like             30%: +0.4/-0.8 (p=0.087)  40%: +0.4/-0.7 (p=0.215)  50%: -0.1/-1.2 (p=0.027)  nat: +0.0/+0.0 (p=0.688)
   vs term coverage top1   30%: +0.1/-0.3 (p=0.381)  40%: +0.3/-0.6 (p=0.213)  50%: +0.0/-0.9 (p=0.064)  nat: -0.1/+0.0 (p=0.935)

G. each selector reranking 9 questions (1%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -0.6  [-1.9, +0.7]  p=0.369
   BM25 margin           -0.6  [-1.9, +0.7]  p=0.345
   top5 vs rest          -0.6  [-1.9, +0.7]  p=0.377
   NQC-like spread       -0.6  [-1.9, +0.7]  p=0.341
   WIG-like              -0.6  [-1.9, +0.7]  p=0.351
   term coverage top1    -0.6  [-1.9, +0.7]  p=0.359

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              22.0*   21.9*   22.1*   22.0*   21.5    21.5    21.8*   21.7    22.1*   22.5*   90%
   BM25 margin            22.1*   21.9*   22.1*   22.0*   21.5    21.5    21.7    21.7    22.1*   22.5*   90%
   top5 vs rest           22.4*   22.7*   22.8*   22.7*   22.7*   22.6*   22.4*   22.5*   22.6*   22.5*   10%
   NQC-like spread        21.9*   22.1*   22.4*   22.5*   22.5*   22.5*   22.6*   22.7*   22.6*   22.5*   10%
   WIG-like               22.3*   22.9*   22.8*   22.6*   22.7*   22.8*   22.6*   22.7*   22.6*   22.5*   10%
   term coverage top1     21.9*   22.2*   22.4*   22.5*   22.4*   22.6*   22.4*   22.4*   22.6*   22.5*   10%
   ORACLE                 27.2*   29.5*   30.7*   30.9*   30.9*   30.9*   30.3*   28.9*   26.6*   22.5*   10%
   random (expected)      22.0    22.0    22.1    22.2    22.2    22.3    22.3    22.4    22.5    22.5*   100%
   (BM25 only 21.9; rerank ALL 22.5)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.5[ -1.8]   -0.6[ -1.8]   -0.5[ -1.6]   -0.6[ -1.6]   -1.0[ -2.1]   -1.0[ -1.9]   -0.8[ -1.5]   -0.8[ -1.4]   -0.4[ -0.8]#   90%   (point estimate: 60%)
   BM25 margin           -0.5[ -1.7]   -0.7[ -1.8]   -0.5[ -1.6]   -0.6[ -1.6]   -1.0[ -2.1]   -1.0[ -1.9]   -0.8[ -1.6]   -0.8[ -1.4]   -0.4[ -0.8]#   90%   (point estimate: 60%)
   top5 vs rest          -0.1[ -1.3]   +0.2[ -0.9]#  +0.3[ -0.7]#  +0.2[ -0.8]#  +0.2[ -0.7]#  +0.1[ -0.7]#  -0.1[ -0.7]#  -0.0[ -0.6]#  +0.0[ -0.3]#   20%   (point estimate: 10%)
   NQC-like spread       -0.7[ -1.9]   -0.5[ -1.7]   -0.1[ -1.2]   -0.0[ -1.0]   +0.0[ -0.9]#  +0.0[ -0.8]#  +0.1[ -0.7]#  +0.2[ -0.4]#  +0.1[ -0.3]#   50%   (point estimate: 10%)
   WIG-like              -0.2[ -1.4]   +0.4[ -0.7]#  +0.3[ -0.8]#  +0.1[ -0.9]#  +0.2[ -0.7]#  +0.2[ -0.6]#  +0.1[ -0.6]#  +0.2[ -0.4]#  +0.1[ -0.2]#   20%   (point estimate: 10%)
   term coverage top1    -0.6[ -1.8]   -0.4[ -1.5]   -0.1[ -1.2]   -0.0[ -1.1]   -0.1[ -1.1]   +0.1[ -0.7]#  -0.1[ -0.9]#  -0.1[ -0.8]#  +0.1[ -0.4]#   60%   (point estimate: 10%)
   ORACLE                +4.7[ +3.8]#  +7.0[ +6.2]#  +8.1[ +7.4]#  +8.4[ +7.7]#  +8.4[ +7.7]#  +8.3[ +7.6]#  +7.7[ +7.0]#  +6.3[ +5.6]#  +4.0[ +3.4]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -0.5[ -1.8]   -0.6[ -1.8]   -0.5[ -1.6]   -0.6[ -1.6]   -1.0[ -2.1]   -1.0[ -1.9]   -0.8[ -1.5]   -0.8[ -1.4]   -0.4[ -0.8]    100%   (point estimate: 90%)
   BM25 margin           -0.5[ -1.7]   -0.7[ -1.8]   -0.5[ -1.6]   -0.6[ -1.6]   -1.0[ -2.1]   -1.0[ -1.9]   -0.8[ -1.6]   -0.8[ -1.4]   -0.4[ -0.8]    100%   (point estimate: 90%)
   top5 vs rest          -0.1[ -1.3]   +0.2[ -0.9]   +0.3[ -0.7]   +0.2[ -0.8]   +0.2[ -0.7]   +0.1[ -0.7]   -0.1[ -0.7]   -0.0[ -0.6]   +0.0[ -0.3]#   90%   (point estimate: 10%)
   NQC-like spread       -0.7[ -1.9]   -0.5[ -1.7]   -0.1[ -1.2]   -0.0[ -1.0]   +0.0[ -0.9]   +0.0[ -0.8]   +0.1[ -0.7]   +0.2[ -0.4]#  +0.1[ -0.3]#   80%   (point estimate: 20%)
   WIG-like              -0.2[ -1.4]   +0.4[ -0.7]   +0.3[ -0.8]   +0.1[ -0.9]   +0.2[ -0.7]   +0.2[ -0.6]   +0.1[ -0.6]   +0.2[ -0.4]#  +0.1[ -0.2]#   80%   (point estimate: 10%)
   term coverage top1    -0.6[ -1.8]   -0.4[ -1.5]   -0.1[ -1.2]   -0.0[ -1.1]   -0.1[ -1.1]   +0.1[ -0.7]   -0.1[ -0.9]   -0.1[ -0.8]   +0.1[ -0.4]#   90%   (point estimate: 20%)
   ORACLE                +4.7[ +3.8]#  +7.0[ +6.2]#  +8.1[ +7.4]#  +8.4[ +7.7]#  +8.4[ +7.7]#  +8.3[ +7.6]#  +7.7[ +7.0]#  +6.3[ +5.6]#  +4.0[ +3.4]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      62% (sd  38)   -0.48 MRR               4%     38%
   tag alarm               100      66% (sd  35)   -0.49 MRR               4%     34%
   tag alarm               200      60% (sd  37)   -0.58 MRR               8%     40%
   BM25 margin              50      67% (sd  37)   -0.41 MRR               2%     33%
   BM25 margin             100      65% (sd  36)   -0.46 MRR               3%     35%
   BM25 margin             200      61% (sd  36)   -0.55 MRR               4%     39%
   top5 vs rest             50      46% (sd  36)   -0.07 MRR               0%     54%
   top5 vs rest            100      43% (sd  34)   -0.07 MRR               0%     57%
   top5 vs rest            200      32% (sd  28)   -0.09 MRR               0%     68%
   NQC-like spread          50      47% (sd  37)   -0.31 MRR               0%     53%
   NQC-like spread         100      43% (sd  34)   -0.29 MRR               1%     57%
   NQC-like spread         200      29% (sd  26)   -0.42 MRR              10%     71%
   WIG-like                 50      47% (sd  36)   -0.01 MRR               0%     53%
   WIG-like                100      41% (sd  34)   -0.01 MRR               0%     59%
   WIG-like                200      28% (sd  28)   -0.08 MRR               0%     72%
   term coverage top1       50      54% (sd  38)   -0.30 MRR               2%     46%
   term coverage top1      100      54% (sd  36)   -0.33 MRR               4%     46%
   term coverage top1      200      37% (sd  33)   -0.50 MRR              10%     63%

## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.3  random  19.0  diff  +0.3  p=0.2598
   MRR  : tag  29.0  random  28.9  diff  +0.0  p=0.4356

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=0.675)        -0.3 (p=0.465)
   40%            +0.0 (p=1.000)        -0.2 (p=0.420)
   50%            -0.3 (p=0.612)        -0.2 (p=0.578)
   12% nat        +0.6 (p=0.265)        +0.5 (p=0.188)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -2.0  95% CI [-4.2, +0.2]  p=0.086
   MRR  :  -4.4  95% CI [-6.1, -2.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (44%)
   Hit@1:  -0.3  p=0.804
   MRR  :  -0.1  p=0.848

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.8/-0.0 (p=0.959)  40%: +1.4/+0.4 (p=0.482)  50%: +1.2/+0.3 (p=0.656)  nat: +0.4/-0.1 (p=0.689)
   vs NQC-like spread      30%: +1.0/+0.2 (p=0.771)  40%: +0.8/+0.1 (p=0.914)  50%: +1.2/+0.3 (p=0.642)  nat: +0.5/-0.1 (p=0.859)
   vs WIG-like             30%: +0.0/-0.5 (p=0.307)  40%: -0.2/-1.0 (p=0.099)  50%: -0.5/-1.0 (p=0.101)  nat: +0.1/-0.4 (p=0.296)
   vs term coverage top1   30%: -0.6/-0.8 (p=0.146)  40%: -0.9/-1.2 (p=0.031)  50%: -1.6/-1.7 (p=0.006)  nat: +0.0/-0.5 (p=0.189)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -4.4  [-6.1, -2.8]  p=0.000
   BM25 margin           -4.9  [-6.6, -3.3]  p=0.000
   top5 vs rest          -4.3  [-5.9, -2.6]  p=0.000
   NQC-like spread       -4.4  [-6.0, -2.7]  p=0.000
   WIG-like              -4.0  [-5.6, -2.4]  p=0.000
   term coverage top1    -3.9  [-5.5, -2.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              28.9    29.0    29.7    30.2    30.9    31.8    32.1    32.5    33.1*   33.4*   90%
   BM25 margin            28.5    29.4    30.0    30.5    31.1    31.6    32.2    32.4    33.1*   33.4*   90%
   top5 vs rest           28.9    29.7    29.8    29.8    30.6    31.6    32.3    32.7*   33.0*   33.4*   80%
   NQC-like spread        29.0    29.2    29.6    30.1    30.6    31.5    32.1    32.8*   33.5*   33.4*   80%
   WIG-like               29.3    29.9    30.3    31.2    32.0    32.7*   33.1*   33.2*   33.2*   33.4*   60%
   term coverage top1     29.5    30.1    30.5    31.4    32.6*   32.9*   32.9*   33.6*   33.2*   33.4*   50%
   ORACLE                 35.0*   37.3*   38.0*   38.1*   38.1*   38.1*   38.1*   38.1*   37.8*   33.4*   10%
   random (expected)      28.8    29.3    29.8    30.4    30.9    31.4    31.9    32.4    32.9    33.4*   100%
   (BM25 only 28.3; rerank ALL 33.4)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.0 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.5[ -6.2]   -4.4[ -6.1]   -3.7[ -5.1]   -3.2[ -4.5]   -2.5[ -3.7]   -1.6[ -2.7]   -1.3[ -2.2]   -0.9[ -1.6]   -0.3[ -0.8]#   90%   (point estimate: 80%)
   BM25 margin           -4.9[ -6.6]   -4.0[ -5.5]   -3.4[ -4.8]   -2.9[ -4.2]   -2.3[ -3.5]   -1.8[ -2.9]   -1.2[ -2.1]   -0.9[ -1.7]   -0.2[ -0.7]#   90%   (point estimate: 80%)
   top5 vs rest          -4.5[ -6.2]   -3.7[ -5.4]   -3.6[ -5.2]   -3.6[ -5.1]   -2.8[ -4.0]   -1.8[ -2.9]   -1.0[ -2.0]   -0.7[ -1.4]   -0.4[ -0.9]#   90%   (point estimate: 80%)
   NQC-like spread       -4.4[ -6.1]   -4.2[ -5.9]   -3.8[ -5.3]   -3.3[ -4.6]   -2.7[ -4.0]   -1.9[ -2.9]   -1.3[ -2.2]   -0.6[ -1.3]   +0.1[ -0.4]#   90%   (point estimate: 80%)
   WIG-like              -4.1[ -5.7]   -3.5[ -5.1]   -3.1[ -4.6]   -2.2[ -3.6]   -1.4[ -2.7]   -0.7[ -1.8]   -0.3[ -1.3]   -0.2[ -1.0]   -0.1[ -0.8]#   90%   (point estimate: 60%)
   term coverage top1    -3.9[ -5.5]   -3.3[ -4.8]   -2.9[ -4.3]   -1.9[ -3.2]   -0.8[ -1.9]   -0.5[ -1.4]   -0.5[ -1.2]   +0.2[ -0.4]#  -0.1[ -0.6]#   80%   (point estimate: 50%)
   ORACLE                +1.6[ +0.5]#  +3.9[ +3.0]#  +4.6[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.4[ +3.5]#   10%   (point estimate: 10%)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.5 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.5[ -6.2]   -4.4[ -6.1]   -3.7[ -5.1]   -3.2[ -4.5]   -2.5[ -3.7]   -1.6[ -2.7]   -1.3[ -2.2]   -0.9[ -1.6]   -0.3[ -0.8]    100%   (point estimate: 90%)
   BM25 margin           -4.9[ -6.6]   -4.0[ -5.5]   -3.4[ -4.8]   -2.9[ -4.2]   -2.3[ -3.5]   -1.8[ -2.9]   -1.2[ -2.1]   -0.9[ -1.7]   -0.2[ -0.7]    100%   (point estimate: 90%)
   top5 vs rest          -4.5[ -6.2]   -3.7[ -5.4]   -3.6[ -5.2]   -3.6[ -5.1]   -2.8[ -4.0]   -1.8[ -2.9]   -1.0[ -2.0]   -0.7[ -1.4]   -0.4[ -0.9]    100%   (point estimate: 90%)
   NQC-like spread       -4.4[ -6.1]   -4.2[ -5.9]   -3.8[ -5.3]   -3.3[ -4.6]   -2.7[ -4.0]   -1.9[ -2.9]   -1.3[ -2.2]   -0.6[ -1.3]   +0.1[ -0.4]#   90%   (point estimate: 90%)
   WIG-like              -4.1[ -5.7]   -3.5[ -5.1]   -3.1[ -4.6]   -2.2[ -3.6]   -1.4[ -2.7]   -0.7[ -1.8]   -0.3[ -1.3]   -0.2[ -1.0]   -0.1[ -0.8]    100%   (point estimate: 70%)
   term coverage top1    -3.9[ -5.5]   -3.3[ -4.8]   -2.9[ -4.3]   -1.9[ -3.2]   -0.8[ -1.9]   -0.5[ -1.4]   -0.5[ -1.2]   +0.2[ -0.4]#  -0.1[ -0.6]    100%   (point estimate: 70%)
   ORACLE                +1.6[ +0.5]#  +3.9[ +3.0]#  +4.6[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.4[ +3.5]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (200 random splits; margin delta = 1.0): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm                50      76% (sd  25)   -1.13 MRR              34%     24%
   tag alarm               100      78% (sd  21)   -1.08 MRR              36%     22%
   tag alarm               200      80% (sd  16)   -0.98 MRR              37%     20%
   BM25 margin              50      75% (sd  27)   -1.20 MRR              41%     25%
   BM25 margin             100      76% (sd  23)   -1.15 MRR              43%     24%
   BM25 margin             200      78% (sd  17)   -1.03 MRR              41%     22%
   top5 vs rest             50      69% (sd  30)   -1.53 MRR              46%     31%
   top5 vs rest            100      77% (sd  22)   -1.10 MRR              35%     23%
   top5 vs rest            200      77% (sd  18)   -1.09 MRR              42%     23%
   NQC-like spread          50      74% (sd  26)   -1.20 MRR              44%     26%
   NQC-like spread         100      77% (sd  21)   -0.97 MRR              36%     23%
   NQC-like spread         200      77% (sd  13)   -0.86 MRR              40%     23%
   WIG-like                 50      64% (sd  32)   -1.28 MRR              38%     36%
   WIG-like                100      66% (sd  26)   -1.03 MRR              32%     34%
   WIG-like                200      64% (sd  22)   -1.06 MRR              36%     36%
   term coverage top1       50      62% (sd  31)   -1.13 MRR              30%     38%
   term coverage top1      100      60% (sd  26)   -1.02 MRR              28%     40%
   term coverage top1      200      58% (sd  19)   -0.92 MRR              28%     42%

## POOLED over 5 datasets (each dataset uses its own selection)

A. tag alarm vs random (pooled; random draws made within each dataset)
   Hit@1: tag  19.3  random  18.8  diff  +0.5  p=0.0040
   MRR  : tag  32.9  random  32.6  diff  +0.3  p=0.0173

B. tag alarm vs margin, same budget (pooled paired sign-flip)
   30%      Hit@1  -0.3 (p=0.330)   MRR  -0.3 (p=0.243)
   40%      Hit@1  +0.1 (p=0.818)   MRR  -0.0 (p=0.994)
   50%      Hit@1  +0.2 (p=0.356)   MRR  +0.1 (p=0.530)
   natural  Hit@1  -0.0 (p=1.000)   MRR  -0.2 (p=0.553)

C. tag alarm vs rerank ALL (pooled)
   Hit@1:  -6.6  95% CI [-7.7, -5.6]  p=0.000
   MRR  :  -5.6  95% CI [-6.6, -4.7]  p=0.000

D. probe top-3 vs margin, same cost (pooled)
   Hit@1:  +1.8  p=0.000
   MRR  :  +0.9  p=0.007

E. tag alarm vs other label-free signals (pooled; Hit@1 / MRR diff, p on MRR)
   vs top5 vs rest         30%: +0.8/+0.1 (p=0.770)  40%: +1.3/+0.6 (p=0.115)  50%: +1.2/+0.5 (p=0.214)  nat: +0.5/+0.1 (p=0.550)
   vs NQC-like spread      30%: +0.6/-0.0 (p=0.961)  40%: +0.8/+0.2 (p=0.529)  50%: +1.0/+0.3 (p=0.378)  nat: +0.2/-0.1 (p=0.587)
   vs WIG-like             30%: +0.5/-0.3 (p=0.443)  40%: +0.8/+0.0 (p=0.973)  50%: +0.6/-0.1 (p=0.798)  nat: +0.4/+0.1 (p=0.756)
   vs term coverage top1   30%: +0.2/-0.1 (p=0.656)  40%: +0.2/-0.2 (p=0.469)  50%: -0.2/-0.6 (p=0.096)  nat: +0.2/+0.0 (p=0.962)
