## amazon_testfull  (1642 questions; tag alarm fires on 765 = 47%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  57.4  random  55.3  diff  +2.2  p=0.0004
   MRR  : tag  67.2  random  65.3  diff  +1.9  p=0.0001

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            +1.2 (p=0.127)        +0.7 (p=0.225)
   40%            +0.1 (p=1.000)        +0.3 (p=0.641)
   50%            -0.8 (p=0.413)        -0.1 (p=0.856)
   47% nat        -0.2 (p=0.839)        +0.2 (p=0.726)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -4.7  95% CI [-6.4, -3.0]  p=0.000
   MRR  :  -4.4  95% CI [-5.7, -3.2]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (47%)
   Hit@1:  +1.6  p=0.084
   MRR  :  +1.1  p=0.103

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: -0.1/-1.1 (p=0.105)  40%: -0.7/-1.3 (p=0.069)  50%: -1.0/-1.4 (p=0.048)  nat: -0.8/-1.4 (p=0.056)
   vs NQC-like spread      30%: -0.4/-1.3 (p=0.051)  40%: -1.3/-1.6 (p=0.021)  50%: -1.4/-1.7 (p=0.014)  nat: -1.8/-2.0 (p=0.005)
   vs WIG-like             30%: +0.6/-0.4 (p=0.571)  40%: +0.2/-0.3 (p=0.664)  50%: -0.4/-0.7 (p=0.306)  nat: +0.1/-0.6 (p=0.385)
   vs term coverage top1   30%: +3.2/+2.3 (p=0.001)  40%: +3.5/+3.1 (p=0.000)  50%: +3.0/+2.9 (p=0.000)  nat: +2.9/+2.8 (p=0.000)

G. each selector reranking 765 questions (47%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -4.4  [-5.7, -3.2]  p=0.000
   BM25 margin           -4.7  [-6.0, -3.4]  p=0.000
   top5 vs rest          -3.1  [-4.3, -1.8]  p=0.000
   NQC-like spread       -2.5  [-3.7, -1.2]  p=0.000
   WIG-like              -3.8  [-5.2, -2.5]  p=0.000
   term coverage top1    -7.2  [-8.8, -5.8]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              61.4    63.3    65.3    66.6    67.6    68.7    69.5    70.6    71.6*   71.6*   90%
   BM25 margin            61.5    63.3    64.6    66.3    67.7    69.1    70.0    71.1*   71.7*   71.6*   80%
   top5 vs rest           61.7    64.1    66.4    67.9    69.0    70.0    70.5    71.4*   71.6*   71.6*   80%
   NQC-like spread        61.7    64.2    66.7    68.2    69.3    70.4    70.5    71.3*   71.8*   71.6*   80%
   WIG-like               62.2    64.1    65.7    66.9    68.3    69.5    70.7*   71.0*   71.0*   71.6*   70%
   term coverage top1     60.7    62.0    63.0    63.5    64.7    66.3    67.4    68.4    69.8    71.6*   100%
   ORACLE                 68.9    74.6*   77.6*   77.8*   77.8*   77.8*   77.8*   77.8*   77.4*   71.6*   20%
   random (expected)      61.0    62.2    63.4    64.5    65.7    66.9    68.1    69.2    70.4    71.6*   100%
   (BM25 only 59.8; rerank ALL 71.6)

I. NON-INFERIORITY vs reranking ALL, margin delta = 1.43 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm            -10.2[-11.8]   -8.3[ -9.8]   -6.3[ -7.8]   -5.0[ -6.2]   -4.0[ -5.1]   -2.9[ -3.9]   -2.1[ -2.9]   -1.0[ -1.6]   +0.0[ -0.2]#   90%   (point estimate: 80%)
   BM25 margin          -10.1[-11.9]   -8.3[-10.0]   -7.0[ -8.5]   -5.3[ -6.7]   -3.9[ -5.1]   -2.5[ -3.7]   -1.6[ -2.5]   -0.5[ -1.1]#  +0.1[ -0.1]#   80%   (point estimate: 80%)
   top5 vs rest          -9.9[-11.6]   -7.5[ -9.1]   -5.2[ -6.6]   -3.7[ -5.1]   -2.6[ -3.8]   -1.6[ -2.7]   -1.1[ -2.0]   -0.2[ -0.9]#  +0.0[ -0.5]#   80%   (point estimate: 70%)
   NQC-like spread       -9.9[-11.6]   -7.4[ -9.0]   -4.9[ -6.3]   -3.4[ -4.7]   -2.3[ -3.5]   -1.2[ -2.3]   -1.1[ -1.9]   -0.2[ -0.9]#  +0.2[ -0.3]#   80%   (point estimate: 60%)
   WIG-like              -9.4[-11.1]   -7.5[ -9.1]   -5.9[ -7.5]   -4.7[ -6.1]   -3.3[ -4.6]   -2.0[ -3.3]   -0.9[ -2.0]   -0.6[ -1.5]   -0.6[ -1.3]#   90%   (point estimate: 70%)
   term coverage top1   -10.9[-12.7]   -9.6[-11.3]   -8.6[-10.2]   -8.1[ -9.6]   -6.9[ -8.3]   -5.3[ -6.5]   -4.2[ -5.3]   -3.2[ -4.1]   -1.8[ -2.5]    100%   (point estimate: 100%)
   ORACLE                -2.7[ -4.1]   +3.0[ +2.0]#  +6.0[ +5.2]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +6.2[ +5.4]#  +5.8[ +4.9]#   20%   (point estimate: 20%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 1.43): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      80% (sd  14)   -1.15 MRR              20%     20%
   BM25 margin             100      73% (sd  13)   -1.38 MRR              50%     27%
   top5 vs rest            100      70% (sd  12)   -1.14 MRR              40%     30%
   NQC-like spread         100      66% (sd  20)   -1.36 MRR              35%     34%
   WIG-like                100      70% (sd  22)   -1.86 MRR              50%     30%
   term coverage top1      100      96% (sd   6)   -0.62 MRR              30%      4%

