## beir_scidocs  (1000 questions; tag alarm fires on 120 = 12%)

A. tag alarm vs RANDOM selection of the same size (10,000 random draws)
   Hit@1: tag  19.3  random  19.0  diff  +0.3  p=0.2663
   MRR  : tag  29.0  random  28.9  diff  +0.0  p=0.4414

B. tag alarm vs SMALL BM25 MARGIN, same number of questions reranked (paired sign-flip)
   budget         Hit@1 diff (p)          MRR diff (p)
   30%            -0.3 (p=0.675)        -0.3 (p=0.465)
   40%            +0.0 (p=1.000)        -0.2 (p=0.420)
   50%            -0.3 (p=0.612)        -0.2 (p=0.578)
   12% nat        +0.6 (p=0.265)        +0.5 (p=0.188)

C. tag alarm vs reranker on ALL questions (negative = tag alarm loses)
   Hit@1:  -2.0  95% CI [-4.2, +0.2]  p=0.086
   MRR  :  -4.4  95% CI [-6.1, -2.8]  p=0.000

D. probe top-3 (keep BM25 if agree) vs margin at the same cost (44%)
   Hit@1:  -0.3  p=0.804
   MRR  :  -0.1  p=0.848

E. tag alarm vs other label-free confidence signals, same budget (Hit@1 / MRR diff, p)
   vs top5 vs rest         30%: +0.8/-0.0 (p=0.959)  40%: +1.4/+0.4 (p=0.482)  50%: +1.2/+0.3 (p=0.656)  nat: +0.4/-0.1 (p=0.689)
   vs NQC-like spread      30%: +1.0/+0.2 (p=0.771)  40%: +0.8/+0.1 (p=0.914)  50%: +1.2/+0.3 (p=0.642)  nat: +0.5/-0.1 (p=0.859)
   vs WIG-like             30%: +0.0/-0.5 (p=0.307)  40%: -0.2/-1.0 (p=0.099)  50%: -0.5/-1.0 (p=0.101)  nat: +0.1/-0.4 (p=0.296)
   vs term coverage top1   30%: -0.6/-0.8 (p=0.146)  40%: -0.9/-1.2 (p=0.031)  50%: -1.6/-1.7 (p=0.006)  nat: +0.0/-0.5 (p=0.189)

G. each selector reranking 120 questions (12%) vs reranker on ALL (MRR diff, 95% CI)
   tag alarm             -4.4  [-6.1, -2.8]  p=0.000
   BM25 margin           -4.9  [-6.6, -3.3]  p=0.000
   top5 vs rest          -4.3  [-5.9, -2.6]  p=0.000
   NQC-like spread       -4.4  [-6.0, -2.7]  p=0.000
   WIG-like              -4.0  [-5.6, -2.4]  p=0.000
   term coverage top1    -3.9  [-5.5, -2.3]  p=0.000

H. budget curves: MRR at each share reranked; * = no significant loss vs reranking ALL (p >= 0.05 or not lower)
   selector                 10%     20%     30%     40%     50%     60%     70%     80%     90%    100%   smallest budget from which there is no significant loss
   tag alarm              28.9    29.0    29.7    30.2    30.9    31.8    32.1    32.5    33.1*   33.4*   90%
   BM25 margin            28.5    29.4    30.0    30.5    31.1    31.6    32.2    32.4    33.1*   33.4*   90%
   top5 vs rest           28.9    29.7    29.8    29.8    30.6    31.6    32.3    32.7*   33.0*   33.4*   80%
   NQC-like spread        29.0    29.2    29.6    30.1    30.6    31.5    32.1    32.8*   33.5*   33.4*   80%
   WIG-like               29.3    29.9    30.3    31.2    32.0    32.7*   33.1*   33.2*   33.2*   33.4*   60%
   term coverage top1     29.5    30.1    30.5    31.4    32.6*   32.9*   32.9*   33.6*   33.2*   33.4*   50%
   ORACLE                 35.0*   37.3*   38.0*   38.1*   38.1*   38.1*   38.1*   38.1*   37.8*   33.4*   10%
   random (expected)      28.8    29.3    29.8    30.4    30.9    31.4    31.9    32.4    32.9    33.4*   100%
   (BM25 only 28.3; rerank ALL 33.4)

I. NON-INFERIORITY vs reranking ALL, margin delta = 0.67 MRR point(s): mean loss [95% CI lower bound]; # = non-inferior (lower bound > -delta)
   selector                       10%           20%           30%           40%           50%           60%           70%           80%           90%   smallest NI budget
   tag alarm             -4.5[ -6.2]   -4.4[ -6.1]   -3.7[ -5.1]   -3.2[ -4.5]   -2.5[ -3.7]   -1.6[ -2.7]   -1.3[ -2.2]   -0.9[ -1.6]   -0.3[ -0.8]    100%   (point estimate: 90%)
   BM25 margin           -4.9[ -6.6]   -4.0[ -5.5]   -3.4[ -4.8]   -2.9[ -4.2]   -2.3[ -3.5]   -1.8[ -2.9]   -1.2[ -2.1]   -0.9[ -1.7]   -0.2[ -0.7]#   90%   (point estimate: 90%)
   top5 vs rest          -4.5[ -6.2]   -3.7[ -5.4]   -3.6[ -5.2]   -3.6[ -5.1]   -2.8[ -4.0]   -1.8[ -2.9]   -1.0[ -2.0]   -0.7[ -1.4]   -0.4[ -0.9]    100%   (point estimate: 90%)
   NQC-like spread       -4.4[ -6.1]   -4.2[ -5.9]   -3.8[ -5.3]   -3.3[ -4.6]   -2.7[ -4.0]   -1.9[ -2.9]   -1.3[ -2.2]   -0.6[ -1.3]   +0.1[ -0.4]#   90%   (point estimate: 80%)
   WIG-like              -4.1[ -5.7]   -3.5[ -5.1]   -3.1[ -4.6]   -2.2[ -3.6]   -1.4[ -2.7]   -0.7[ -1.8]   -0.3[ -1.3]   -0.2[ -1.0]   -0.1[ -0.8]    100%   (point estimate: 70%)
   term coverage top1    -3.9[ -5.5]   -3.3[ -4.8]   -2.9[ -4.3]   -1.9[ -3.2]   -0.8[ -1.9]   -0.5[ -1.4]   -0.5[ -1.2]   +0.2[ -0.4]#  -0.1[ -0.6]#   80%   (point estimate: 60%)
   ORACLE                +1.6[ +0.5]#  +3.9[ +3.0]#  +4.6[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.7[ +3.8]#  +4.4[ +3.5]#   10%   (point estimate: 10%)

J. HELD-OUT BUDGET CALIBRATION (20 random splits; margin delta = 0.67): budget = smallest b with calibration loss >= -delta for all larger b; then applied to the held-out queries
   selector              n_cal    chosen budget   held-out loss  P(loss < -delta)  saving
   tag alarm               100      80% (sd  26)   -1.03 MRR              40%     20%
   BM25 margin             100      78% (sd  23)   -1.05 MRR              45%     22%
   top5 vs rest            100      78% (sd  23)   -1.09 MRR              55%     22%
   NQC-like spread         100      84% (sd  21)   -0.57 MRR              20%     16%
   WIG-like                100      70% (sd  24)   -0.88 MRR              25%     30%
   term coverage top1      100      75% (sd  21)   -0.41 MRR              25%     25%

