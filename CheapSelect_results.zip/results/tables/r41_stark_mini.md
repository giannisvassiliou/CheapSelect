# router41: label-free signals vs pre-retrieval vs trained routers  (deltas [1.0, 0.5] MRR points)

## amazon_testfull (tag mini; n=1642; mean gain +5.8 MRR; helped 31% hurt 20%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.07   rho(gain) +0.11
   avgIDF   rho(quality) +0.25   rho(gain) -0.12
   maxIDF   rho(quality) +0.29   rho(gain) -0.16
   avgICTF  rho(quality) +0.25   rho(gain) -0.11
   avgSCQ   rho(quality) +0.18   rho(gain) -0.08
   maxSCQ   rho(quality) +0.14   rho(gain) -0.07
   SCS      rho(quality) +0.16   rho(gain) -0.02

Budgets (share of questions reranked). random expected point budget: delta 1.0: 90%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               70/50          70/50           +40             -0.4     -0.7 (0.299)
   tag alarm                                 80/60          80/70           +30             -1.6     -2.0 (0.008)
   top5 vs rest                              70/40          80/50           +50             -0.2     -0.5 (0.349)
   NQC-like spread                           60/40          80/50           +50             +0.0     -0.3 (0.553)
   WIG-like                                  50/40          70/40           +50             +0.4          -
   term coverage top1                       100/100        100/100          -10             -3.6     -4.0 (0.000)
   pre:qlen                                 100/100        100/100          -10             -4.8     -5.2 (0.000)
   pre:avgIDF                                80/60         100/70           +30             -1.3     -1.7 (0.002)
   pre:maxIDF                                60/50          70/50           +40             -0.5     -0.8 (0.163)
   pre:avgICTF                               80/70          90/70           +20             -1.5     -1.9 (0.002)
   pre:avgSCQ                                90/70         100/90           +20             -1.8     -2.2 (0.000)
   pre:maxSCQ                                90/70         100/80           +20             -1.9     -2.3 (0.000)
   pre:SCS                                   90/80         100/100          +10             -3.0     -3.4 (0.000)
   router ridge S (5-fold CV)                40/30          50/40           +60             +1.3     +0.9 (0.060)
   router gbm S (5-fold CV)                  80/60         100/70           +30             -1.1     -1.4 (0.011)
   router ridge S+P (5-fold CV)              50/30          50/40           +60             +1.4     +1.0 (0.045)
   router gbm S+P (5-fold CV)                60/40          70/40           +50             -0.1     -0.5 (0.392)
   router ridge S (other collections)        70/40         100/40           +50             -0.4     -0.8 (0.141)
   router gbm S (other collections)          80/50         100/50           +40             -0.0     -0.4 (0.478)
   router ridge S+P (other collections)      60/40          70/40           +50             -0.2     -0.6 (0.300)
   router gbm S+P (other collections)        70/40          80/50           +50             -0.0     -0.4 (0.474)
   ORACLE                                    10/10          10/10           +80             +9.1     +8.8 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.205, tag alarm +0.025, top5 vs rest -0.195, NQC-like spread +0.130, WIG-like -0.246, term coverage top1 +0.074
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.202, tag alarm +0.030, top5 vs rest -0.183, NQC-like spread +0.105, WIG-like -0.279, term coverage top1 +0.071, qlen +0.045, avgIDF -0.122, maxIDF -0.044, avgICTF -0.069, avgSCQ +0.091, maxSCQ +0.068, SCS +0.239

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 -1.3   +0.3   +0.9
   n=  50  router ridge S+P        -2.1   -0.6   +0.3   P(router > WIG-like @50%) = 17%
   n=  50  router gbm   S+P        -2.5   -1.1   -0.2   P(router > WIG-like @50%) = 10%
   n= 100  WIG-like                 -1.3   +0.3   +0.9
   n= 100  router ridge S+P        -1.7   -0.1   +0.7   P(router > WIG-like @50%) = 34%
   n= 100  router gbm   S+P        -2.5   -1.1   -0.2   P(router > WIG-like @50%) = 3%
   n= 200  WIG-like                 -1.4   +0.3   +0.9
   n= 200  router ridge S+P        -1.3   +0.3   +1.0   P(router > WIG-like @50%) = 60%
   n= 200  router gbm   S+P        -2.5   -1.1   -0.1   P(router > WIG-like @50%) = 3%

## mag_testfull (tag mini; n=2665; mean gain +0.1 MRR; helped 19% hurt 24%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.31   rho(gain) +0.14
   avgIDF   rho(quality) +0.20   rho(gain) +0.05
   maxIDF   rho(quality) +0.07   rho(gain) -0.03
   avgICTF  rho(quality) +0.18   rho(gain) +0.06
   avgSCQ   rho(quality) +0.10   rho(gain) +0.02
   maxSCQ   rho(quality) +0.01   rho(gain) -0.03
   SCS      rho(quality) +0.28   rho(gain) +0.11

Budgets (share of questions reranked). random expected point budget: delta 1.0: 10%, delta 0.5: 10%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               20/10          30/10            +0             +0.7     -0.5 (0.323)
   tag alarm                                 10/10          10/10            +0             +1.8     +0.6 (0.168)
   top5 vs rest                              20/10          90/10            +0             +0.2     -0.9 (0.006)
   NQC-like spread                           20/10          80/10            +0             +0.2     -0.9 (0.007)
   WIG-like                                  10/10          10/10            +0             +1.2          -
   term coverage top1                        10/10          10/10            +0             +1.7     +0.5 (0.123)
   pre:qlen                                  90/80         100/90           -70             -1.6     -2.7 (0.000)
   pre:avgIDF                                80/10         100/10            +0             -0.3     -1.4 (0.001)
   pre:maxIDF                                30/10          50/10            +0             +0.4     -0.8 (0.072)
   pre:avgICTF                               80/10         100/70            +0             -0.4     -1.6 (0.001)
   pre:avgSCQ                                50/10          90/10            +0             -0.1     -1.2 (0.004)
   pre:maxSCQ                                40/10          70/10            +0             +0.4     -0.8 (0.027)
   pre:SCS                                   80/10         100/80            +0             -0.9     -2.1 (0.000)
   router ridge S (5-fold CV)                10/10          10/10            +0             +2.3     +1.2 (0.000)
   router gbm S (5-fold CV)                  10/10          10/10            +0             +1.4     +0.2 (0.615)
   router ridge S+P (5-fold CV)              10/10          10/10            +0             +2.5     +1.3 (0.000)
   router gbm S+P (5-fold CV)                10/10          10/10            +0             +2.2     +1.0 (0.007)
   router ridge S (other collections)        10/10          10/10            +0             +1.9     +0.7 (0.006)
   router gbm S (other collections)          10/10          10/10            +0             +1.3     +0.2 (0.624)
   router ridge S+P (other collections)      10/10          10/10            +0             +2.4     +1.2 (0.000)
   router gbm S+P (other collections)        10/10          10/10            +0             +1.8     +0.6 (0.069)
   ORACLE                                    10/10          10/10            +0             +8.3     +7.1 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.073, tag alarm +0.196, top5 vs rest -0.028, NQC-like spread +0.128, WIG-like -0.144, term coverage top1 -0.070
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.061, tag alarm +0.205, top5 vs rest -0.021, NQC-like spread +0.110, WIG-like -0.058, term coverage top1 -0.132, qlen -0.024, avgIDF -0.076, maxIDF -0.048, avgICTF -0.117, avgSCQ -0.042, maxSCQ +0.038, SCS +0.240

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 +1.7   +1.2   +1.3
   n=  50  router ridge S+P        +1.3   +1.3   +1.0   P(router > WIG-like @50%) = 65%
   n=  50  router gbm   S+P        +0.6   +0.7   +0.6   P(router > WIG-like @50%) = 29%
   n= 100  WIG-like                 +1.7   +1.2   +1.3
   n= 100  router ridge S+P        +1.7   +1.7   +1.3   P(router > WIG-like @50%) = 83%
   n= 100  router gbm   S+P        +1.1   +1.1   +0.9   P(router > WIG-like @50%) = 52%
   n= 200  WIG-like                 +1.8   +1.2   +1.3
   n= 200  router ridge S+P        +2.0   +2.0   +1.6   P(router > WIG-like @50%) = 94%
   n= 200  router gbm   S+P        +1.2   +1.2   +1.0   P(router > WIG-like @50%) = 62%

## prime_testfull (tag mini; n=2801; mean gain +0.4 MRR; helped 26% hurt 24%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) -0.24   rho(gain) +0.18
   avgIDF   rho(quality) +0.10   rho(gain) +0.02
   maxIDF   rho(quality) +0.10   rho(gain) -0.05
   avgICTF  rho(quality) +0.07   rho(gain) +0.02
   avgSCQ   rho(quality) +0.14   rho(gain) +0.01
   maxSCQ   rho(quality) +0.28   rho(gain) -0.06
   SCS      rho(quality) -0.03   rho(gain) +0.12

Budgets (share of questions reranked). random expected point budget: delta 1.0: 10%, delta 0.5: 10%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                               30/10          40/10            +0             +1.1     -0.4 (0.410)
   tag alarm                                 20/10          30/10            +0             +1.9     +0.4 (0.401)
   top5 vs rest                              20/10          30/10            +0             +0.7     -0.8 (0.023)
   NQC-like spread                           20/10          30/10            +0             +1.3     -0.2 (0.523)
   WIG-like                                  10/10          20/10            +0             +1.5          -
   term coverage top1                        20/10          30/10            +0             +1.0     -0.5 (0.185)
   pre:qlen                                 100/90         100/100          -80             -2.6     -4.1 (0.000)
   pre:avgIDF                               100/90         100/100          -80             -0.4     -1.9 (0.000)
   pre:maxIDF                                20/10          40/10            +0             +0.7     -0.8 (0.116)
   pre:avgICTF                              100/90         100/100          -80             -0.3     -1.8 (0.001)
   pre:avgSCQ                                90/10         100/100           +0             +0.1     -1.4 (0.002)
   pre:maxSCQ                                20/10          60/10            +0             +0.3     -1.2 (0.004)
   pre:SCS                                  100/90         100/100          -80             -1.8     -3.3 (0.000)
   router ridge S (5-fold CV)                10/10          20/10            +0             +2.0     +0.5 (0.049)
   router gbm S (5-fold CV)                  20/10          30/10            +0             +1.5     +0.0 (0.972)
   router ridge S+P (5-fold CV)              10/10          20/10            +0             +3.3     +1.8 (0.000)
   router gbm S+P (5-fold CV)                10/10          20/10            +0             +2.5     +1.0 (0.012)
   router ridge S (other collections)        10/10          20/10            +0             +2.3     +0.8 (0.008)
   router gbm S (other collections)          10/10          20/10            +0             +1.8     +0.3 (0.470)
   router ridge S+P (other collections)      10/10          20/10            +0             +3.1     +1.6 (0.000)
   router gbm S+P (other collections)        10/10          10/10            +0             +2.6     +1.1 (0.005)
   ORACLE                                    10/10          10/10            +0             +9.4     +7.9 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.086, tag alarm +0.082, top5 vs rest -0.015, NQC-like spread +0.065, WIG-like -0.169, term coverage top1 -0.003
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.065, tag alarm +0.129, top5 vs rest -0.039, NQC-like spread +0.034, WIG-like -0.080, term coverage top1 -0.055, qlen -0.060, avgIDF +0.279, maxIDF -0.042, avgICTF -0.542, avgSCQ -0.029, maxSCQ +0.023, SCS +0.351

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                 +1.5   +1.5   +1.7
   n=  50  router ridge S+P        +1.0   +1.4   +1.4   P(router > WIG-like @50%) = 58%
   n=  50  router gbm   S+P        +0.6   +0.9   +0.9   P(router > WIG-like @50%) = 29%
   n= 100  WIG-like                 +1.5   +1.5   +1.7
   n= 100  router ridge S+P        +1.4   +2.0   +1.9   P(router > WIG-like @50%) = 81%
   n= 100  router gbm   S+P        +0.9   +1.2   +1.3   P(router > WIG-like @50%) = 34%
   n= 200  WIG-like                 +1.5   +1.5   +1.7
   n= 200  router ridge S+P        +1.7   +2.5   +2.5   P(router > WIG-like @50%) = 96%
   n= 200  router gbm   S+P        +1.0   +1.4   +1.6   P(router > WIG-like @50%) = 43%

## dbpedia_test (tag mini; n=400; mean gain +19.2 MRR; helped 39% hurt 7%)

Pre-retrieval predictors, Spearman rho with BM25 quality and with gain (oriented: higher = 'easy, skip the reranker')
   qlen     rho(quality) +0.22   rho(gain) -0.15
   avgIDF   rho(quality) +0.18   rho(gain) -0.16
   maxIDF   rho(quality) +0.02   rho(gain) -0.06
   avgICTF  rho(quality) +0.16   rho(gain) -0.15
   avgSCQ   rho(quality) +0.25   rho(gain) -0.15
   maxSCQ   rho(quality) +0.11   rho(gain) -0.09
   SCS      rho(quality) +0.20   rho(gain) -0.17

Budgets (share of questions reranked). random expected point budget: delta 1.0: 100%, delta 0.5: 100%
   selector                                NI/pt d=1.0   NI/pt d=0.5   save>rand(d=1st)  sel-all@50%  vs WIG@50% (p)
   BM25 margin                              100/90         100/100          +10             -7.9     -0.3 (0.843)
   tag alarm                                 90/90         100/90           +10             -7.6     +0.0 (0.981)
   top5 vs rest                             100/100        100/100           +0             -8.7     -1.0 (0.426)
   NQC-like spread                          100/100        100/100           +0             -8.1     -0.4 (0.760)
   WIG-like                                 100/90         100/100          +10             -7.7          -
   term coverage top1                       100/100        100/100           +0             -6.2     +1.4 (0.220)
   pre:qlen                                 100/90         100/100          +10             -7.5     +0.2 (0.877)
   pre:avgIDF                               100/100        100/100           +0             -6.9     +0.7 (0.529)
   pre:maxIDF                               100/100        100/100           +0             -8.2     -0.6 (0.669)
   pre:avgICTF                              100/100        100/100           +0             -7.4     +0.2 (0.838)
   pre:avgSCQ                               100/90         100/90           +10             -6.9     +0.8 (0.534)
   pre:maxSCQ                               100/100        100/100           +0             -8.5     -0.8 (0.521)
   pre:SCS                                  100/90         100/100          +10             -6.7     +1.0 (0.405)
   router ridge S (5-fold CV)               100/90         100/100          +10             -7.9     -0.2 (0.832)
   router gbm S (5-fold CV)                 100/100        100/100           +0             -9.8     -2.1 (0.095)
   router ridge S+P (5-fold CV)             100/90         100/100          +10             -7.7     +0.0 (0.984)
   router gbm S+P (5-fold CV)               100/100        100/100           +0             -8.2     -0.5 (0.691)
   router ridge S (other collections)       100/90         100/100          +10             -6.3     +1.4 (0.127)
   router gbm S (other collections)         100/90         100/100          +10             -7.2     +0.5 (0.692)
   router ridge S+P (other collections)     100/90         100/90           +10             -6.9     +0.7 (0.496)
   router gbm S+P (other collections)       100/100        100/100           +0             -8.7     -1.0 (0.456)
   ORACLE                                    30/30          30/30           +70             +2.6    +10.2 (0.000)

Ridge weights, features S, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.109, tag alarm +0.128, top5 vs rest +0.079, NQC-like spread -0.079, WIG-like -0.091, term coverage top1 -0.136
Ridge weights, features S+P, fit on all questions (descriptive; + = more gain expected): BM25 margin -0.077, tag alarm +0.131, top5 vs rest +0.085, NQC-like spread -0.041, WIG-like -0.005, term coverage top1 -0.203, qlen +0.012, avgIDF -0.212, maxIDF -0.064, avgICTF +0.094, avgSCQ -0.075, maxSCQ +0.010, SCS +0.059

Few labels: router trained on n labelled questions, evaluated on the other questions (100 random splits). Loss vs reranking all on held-out (MRR points), at budgets 30/50/70%; P(router > WIG-like at 50%)
   n=  50  WIG-like                -10.8   -7.8   -4.3
   n=  50  router ridge S+P       -12.1   -8.0   -4.3   P(router > WIG-like @50%) = 50%
   n=  50  router gbm   S+P       -12.3   -8.1   -4.5   P(router > WIG-like @50%) = 47%
   n= 100  WIG-like                -10.8   -7.7   -4.2
   n= 100  router ridge S+P       -11.8   -7.7   -4.1   P(router > WIG-like @50%) = 59%
   n= 100  router gbm   S+P       -12.6   -8.6   -4.8   P(router > WIG-like @50%) = 21%
   n= 200  WIG-like                -10.8   -7.8   -4.3
   n= 200  router ridge S+P       -11.6   -7.3   -3.8   P(router > WIG-like @50%) = 66%
   n= 200  router gbm   S+P       -12.5   -8.8   -5.1   P(router > WIG-like @50%) = 26%

